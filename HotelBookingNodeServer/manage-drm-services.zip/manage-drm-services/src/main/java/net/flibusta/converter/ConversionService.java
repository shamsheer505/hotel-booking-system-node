package net.flibusta.converter;

import java.io.File;

public interface ConversionService {
    File convert(File f, String kindlegenPath) throws ConversionException;
}
