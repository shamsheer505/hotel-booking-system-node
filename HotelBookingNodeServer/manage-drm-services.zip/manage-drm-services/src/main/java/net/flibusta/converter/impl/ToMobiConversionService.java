package net.flibusta.converter.impl;

import net.flibusta.converter.ConversionException;
import net.flibusta.converter.ConversionService;
import net.flibusta.converter.ConversionServiceFactory;
import net.flibusta.converter.Converter;
import org.apache.log4j.Logger;

import java.io.File;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Service
public class ToMobiConversionService implements ConversionService {
    private Logger logger = Logger.getLogger(ToMobiConversionService.class);

    private Converter epub2mobi;
//    private Converter fb2epub;
    private ConversionServiceFactory conversionServiceFactory;
 
    public void setEpub2mobi(Converter epub2mobi) {
        this.epub2mobi = epub2mobi;
    }

    public void setConversionServiceFactory(ConversionServiceFactory conversionServiceFactory) {
        this.conversionServiceFactory = conversionServiceFactory;
    }

    @Override
    public File convert(File  epub, String kindlegenPath) throws ConversionException {
        if (epub == null) {
            ConversionService conversionService = conversionServiceFactory.getConversionService("epub");
           // epub = conversionService.convert(bookId);
        }        
        //TODO Check 
        //File mobi = epub2mobi.convert(epub);
        File mobi = new EpubToMobiConverter().convert(epub, kindlegenPath);
        
        return mobi;
      //  return bookDao.addBook(bookId, "mobi", mobi);
    }
}
