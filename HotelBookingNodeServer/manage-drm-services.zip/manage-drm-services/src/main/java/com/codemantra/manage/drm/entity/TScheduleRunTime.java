package com.codemantra.manage.drm.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "tScheduleRunTime")
public class TScheduleRunTime {
	
	@Field("name")
	private String name;

	@Field("lastRun")
	private Date lastRun;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getLastRun() {
		return lastRun;
	}

	public void setLastRun(Date lastRun) {
		this.lastRun = lastRun;
	}

}
