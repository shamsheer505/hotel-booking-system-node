/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "drmRequestAudit")
public class DRMNew {
	private String drmSource;
	private String orderId;
	private String orderType;
	private String clientId;
	private String clientName;
	private String orderDate;	
	private String drmType;
	private Integer device;
	private Integer drmCutPaste;
	private Integer drmPrint;
	private Integer drmLicense;	
	private String clientEmail;
	private String isbn;
	private String deviceFormat;
	private String clientIP;
	
	private String _id;
	private String drmId;
	
	private Date requestDate;
	@Id
	private String requestId;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDrmSource() {
		return drmSource;
	}
	public void setDrmSource(String drmSource) {
		this.drmSource = drmSource;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getDrmType() {
		return drmType;
	}
	public void setDrmType(String drmType) {
		this.drmType = drmType;
	}
	public Integer getDevice() {
		return device;
	}
	public void setDevice(Integer device) {
		this.device = device;
	}
	public Integer getDrmCutPaste() {
		return drmCutPaste;
	}
	public void setDrmCutPaste(Integer drmCutPaste) {
		this.drmCutPaste = drmCutPaste;
	}
	public Integer getDrmPrint() {
		return drmPrint;
	}
	public void setDrmPrint(Integer drmPrint) {
		this.drmPrint = drmPrint;
	}
	public Integer getDrmLicense() {
		return drmLicense;
	}
	public void setDrmLicense(Integer drmLicense) {
		this.drmLicense = drmLicense;
	}
	public String getClientEmail() {
		return clientEmail;
	}
	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDeviceFormat() {
		return deviceFormat;
	}
	public void setDeviceFormat(String deviceFormat) {
		this.deviceFormat = deviceFormat;
	}
	public String getClientIP() {
		return clientIP;
	}
	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getDrmId() {
		return drmId;
	}
	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}
	public Date getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
}
