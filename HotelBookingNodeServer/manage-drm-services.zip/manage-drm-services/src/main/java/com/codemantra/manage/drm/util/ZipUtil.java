




/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codemantra.manage.drm.util;

import com.codemantra.manage.drm.entity.WatermarkEntity;
import com.codemantra.manage.drm.util.CompressArchiveStructure.Item;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import net.sf.sevenzipjbinding.ExtractAskMode;
import net.sf.sevenzipjbinding.ExtractOperationResult;
import net.sf.sevenzipjbinding.IArchiveExtractCallback;
import net.sf.sevenzipjbinding.IInArchive;
import net.sf.sevenzipjbinding.ISequentialOutStream;
import net.sf.sevenzipjbinding.PropID;
import net.sf.sevenzipjbinding.SevenZip;
import net.sf.sevenzipjbinding.SevenZipException;
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.detect.Detector;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.sevenzipjbinding.ArchiveFormat;
import net.sf.sevenzipjbinding.IOutCreateArchive;
import net.sf.sevenzipjbinding.IOutCreateCallback;
import net.sf.sevenzipjbinding.IOutFeatureSetLevel;
import net.sf.sevenzipjbinding.IOutFeatureSetMultithreading;
import net.sf.sevenzipjbinding.IOutItemAllFormats;
import net.sf.sevenzipjbinding.ISequentialInStream;
import net.sf.sevenzipjbinding.SevenZip;
import net.sf.sevenzipjbinding.SevenZipException;
import net.sf.sevenzipjbinding.impl.OutItemFactory;
import net.sf.sevenzipjbinding.impl.RandomAccessFileOutStream;
//import net.sf.sevenzipjbinding.junit.snippets.CompressArchiveStructure.Item;
import net.sf.sevenzipjbinding.util.ByteArrayStream;
import org.apache.commons.io.FileUtils;
 import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;

/**
 *
 * Handles zip files using SevenZipJBinding framework
 */
@Component
//@PropertySource("classpath:config.properties")
public class ZipUtil {
   // private Properties config;

/*@Value("${temp.output.folder}")    
    private String tempFolder;*/
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(ZipUtil.class);
	
	@Value("${TEMP_OUTPUT_FOLDER}")
    private   String TEMP_OUTPUT_FOLDER;

    public ZipUtil() throws Exception
    {
        super();
       // config= new Properties();
        //config.load(this.getClass().getResourceAsStream("/config.properties"));
        //tempFolder = config.getProperty("temp.output.folder");
    }
    private final class MyCreateCallback
            implements IOutCreateCallback<IOutItemAllFormats> {
        List<Item> items ;

        public MyCreateCallback(List<Item> items) {
            this.items = items;
        }
        
        public void setOperationResult(boolean operationResultOk)
                throws SevenZipException {
            // Track each operation result here
        }

        public void setTotal(long total) throws SevenZipException {
            // Track operation progress here
        }

        public void setCompleted(long complete) throws SevenZipException {
            // Track operation progress here
        }

        public IOutItemAllFormats getItemInformation(int index,
                OutItemFactory<IOutItemAllFormats> outItemFactory) {
            IOutItemAllFormats item = outItemFactory.createOutItem();

            if (items.get(index).getContent() == null) {
                // Directory
                item.setPropertyIsDir(true);
            } else {
                // File
//                Item temp = new Item("mimetype");
//                int index2 = items.indexOf(temp);
//                if(!items.get(index2).getIsProcessed())
//                {
//                     
//                    item.setDataSize((long) items.get(index2).getContent().length);
//                    items.get(index2).setIsProcessed(Boolean.TRUE);
//                    item.setPropertyPath(items.get(index2).getPath());
//                    return item;
//                }
//                item.setDataSize((long) items.get(index).getContent().length);
//            }
item.setDataSize((long) items.get(index).getContent().length);
            item.setPropertyPath(items.get(index).getPath());
            //items.get(index).setIsProcessed(Boolean.TRUE);
            }
            return item;
        }

        public ISequentialInStream getStream(int i) throws SevenZipException {
            if (items.get(i).getContent() == null) {
                return null;
            }
           // System.out.println("ITEMS : : : : : : : : : :  "+items.get(i).getPath());
            return new ByteArrayStream(items.get(i).getContent(), true);
        }
    }

     //private List<Item> items;
    public static void main(String[] args) throws Exception {
        //if (args.length != 3)
        {
           // System.out.println("Usage: java CompressGeneric "
             //       + "<archive-format> <archive> <count-of-files>");
            for (ArchiveFormat af : ArchiveFormat.values()) {
                if (af.isOutArchiveSupported()) {
                    System.out.println("Supported formats: " + af.name());
                }
            }
           // return;
        }

        //int itemsCount = Integer.valueOf(args[2]);
                     String footer = "<p style=\"font-size: 11px; text-align: center; "
                    + "color: #666; border-top: 1px solid #9a9a9a; padding: 15px "
                    + "0 0; margin: 50px 0 0;"
                    + "class=\"EPubfirstparagraph epubpagerstart\">"
                    + "This eBook belongs to "+"arun@codemantra.com" + " on "+
                             " 12/12/2012" + "</p>";
    
        File f = new  File("D:/epub/1.epub");
        String path = f.getAbsolutePath();
        String tempDir = "d:/tmp/1.epub".replace("\\", "/")+".zip"+"/";
        
        Set<File> fileList = new ZipUtil().getUnzippedRegularFiles(f,"<Specify name of unzip folder path>");
        File fout = new File("D:/epub/output/1.epub");
        File workdir = new File(f.getAbsolutePath()+".zip");
      //  Integer itemsCount = Integer.valueOf(fileList.size());
        System.out.println();
      try{
          WatermarkEntity entity = new WatermarkEntity();
          entity.setDeviceFormat("E");
          entity.setEmailId("arun@codemantra.com");
          entity.setOrderDateString("12/12/2012");
          
          entity.setInputFileName("");
        new ZipUtil().compress(fout, "ZIP",
                  fileList,tempDir, entity);
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
      finally{
   //FileUtils.deleteDirectory(workdir);
      }
    }

@Autowired
private CompressArchiveStructure compressArchiveStructure;
    public void compress(File filename, String fmtName,   Set<File> f,
            String replaceStr , WatermarkEntity entity) throws SevenZipException, FileNotFoundException, IOException, SAXException, TikaException  {
        
        final  List<Item> items = compressArchiveStructure.manipulateEpub(f, replaceStr, entity);
        // int count = items.size();
        boolean success = false;
        RandomAccessFile raf = null;
        IOutCreateArchive<IOutItemAllFormats> outArchive = null;
        ArchiveFormat archiveFormat = ArchiveFormat.valueOf(fmtName);
        try {
            raf = new RandomAccessFile(filename, "rw");

            // Open out-archive object
            outArchive = SevenZip.openOutArchive(archiveFormat);

            // Configure archive
            if (outArchive instanceof IOutFeatureSetLevel) {
                ((IOutFeatureSetLevel) outArchive).setLevel(5);
            }
            if (outArchive instanceof IOutFeatureSetMultithreading) {
                ((IOutFeatureSetMultithreading) outArchive).setThreadCount(2);
            }

            // Create archive
            outArchive.createArchive(new RandomAccessFileOutStream(raf),
                    items.size(), new MyCreateCallback(items));

            success = true;
       // } catch (SevenZipException e) {
          //  System.err.println("7z-Error occurs:");
            // Get more information using extended method
          //  e.printStackTraceExtended();
        } 
        //catch (Exception e) {
          //  System.err.println("Error occurs: " + e);
///        } 
finally {
            if (outArchive != null) {
                try {
                    outArchive.close();
                } catch (IOException e) {
                    System.err.println("Error closing archive: " + e);
                    success = false;
                }
            }
            if (raf != null) {
                try {
                    raf.close();
                } catch (IOException e) {
                    System.err.println("Error closing file: " + e);
                    success = false;
                }
            }
        }
        if (success) {
            FileUtils.deleteDirectory(new File(TEMP_OUTPUT_FOLDER+"/"+filename+".zip"));
          //  System.out.println(archiveFormat.getMethodName()
                  //  + " archive with " + count + " item(s) created");
        }
    }
    /**
     * Unzips the zip file recursively and returns the list of all regular NON-ZIP files by
     * calling recurseZipFileExtraction method
     * @param zipFile
     * @return
     * @throws Exception
     */
    public Set<File> getUnzippedRegularFiles(File zipFile, String unzippedFolderPath) throws IOException, FileNotFoundException, SAXException, TikaException  
    {
     //   System.out.println(getMimeType(zipFile));
        HashSet<File> listOfRegularFiles = new HashSet<>();
        recurseZipFileExtraction(zipFile, listOfRegularFiles, unzippedFolderPath);
        return listOfRegularFiles;
    }
     public void extract(File file, File extractPath, Set<File> fileList) throws SevenZipException, IOException  {
        IInArchive inArchive = null;
        RandomAccessFile randomAccessFile = null;
        try {
        ///   System.out.println(extractPath + "<<<DIR : : : : : file to be extracted : : : : "+ file);
            randomAccessFile = new RandomAccessFile(file, "r");
            inArchive = (IInArchive) SevenZip.openInArchive(null, new RandomAccessFileInStream(randomAccessFile));
            inArchive.extract(null, false, new MyExtractCallback(inArchive, extractPath, fileList));            
        }
        finally {
            if (inArchive != null) {
                inArchive.close();
            }
            if (randomAccessFile != null) {
                randomAccessFile.close();
            }            
        }
    }
     /**
      * Call back for SevenZipJBinding Framework
      */
      public   class MyExtractCallback implements IArchiveExtractCallback {
        private final IInArchive inArchive;
        File extractPath;
        Set<File> fileList;
        File actualFile;
        public MyExtractCallback(IInArchive inArchive,  File extractPath, Set<File> fileList) {
            this.inArchive = inArchive;
             this.extractPath =  extractPath;
            this.fileList = fileList;
            
        }
        @Override
        public ISequentialOutStream getStream(final int index, ExtractAskMode extractAskMode) throws SevenZipException {
            return new ISequentialOutStream() {
                @Override
                public int write(byte[] data) throws SevenZipException {
                    String filePath = inArchive.getStringProperty(index, PropID.PATH);
                    
                    FileOutputStream fos = null;
                     try {
                        if(filePath == null || filePath.trim().length() == 0)
                        {
                            filePath = extractPath.getName()+".extracted";
                        }
                        File path = new File(extractPath.getAbsolutePath()+"/" +filePath );
                        actualFile = path;
                        if (!path.getParentFile().exists()) {
                            path.getParentFile().mkdirs();
                        }
                        
                        if (!path.exists()) {
                            path.createNewFile();
                        }
                    //   System.out.println("in getStream : : : " + path.getAbsolutePath());
                        fos = new FileOutputStream(path, true);
                        fos.write(data);
                    } 
                    catch (FileNotFoundException ex) {                 
                        Logger.getLogger(ZipUtil.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(ZipUtil.class.getName()).log(Level.SEVERE, null, ex);
                    }                 
                    finally {
                        try {
                            if (fos != null) {
                                fos.flush();
                                fos.close();
                            }
                        } catch (IOException e) {
                            //logger.error("Could not close FileOutputStream", e);
                        }
                    }
                    return data.length;
                }
            };
        }
        @Override
        public void prepareOperation(ExtractAskMode extractAskMode) throws SevenZipException {}
        @Override
        public void setOperationResult(ExtractOperationResult extractOperationResult) throws SevenZipException {
        if(extractOperationResult.OK == extractOperationResult)
        {
            String content = null;
            try
            {
                if(actualFile != null)
            content = getMimeType(actualFile);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                throw new IllegalStateException(e.getMessage());
            }
             if((content != null ) &&
                     !(content.contains("zip")||content.contains("rar")||content.contains("7z")
                     ||content.contains("tar")||content.equals("application/x-mobipocket-ebook")))
            fileList.add(actualFile);
        }
        }
        @Override
        public void setCompleted(long completeValue) throws SevenZipException {}
        @Override
        public void setTotal(long total) throws SevenZipException {}
    }
      
          public static String getMimeType( File file ) throws FileNotFoundException, IOException, SAXException, TikaException
    {
        TikaConfig config = TikaConfig.getDefaultConfig();
 Detector detector = config.getDetector();

 TikaInputStream stream = TikaInputStream.get(file);

 Metadata metadata = new Metadata();
 //metadata.add(Metadata.RESOURCE_NAME_KEY, filenameWithExtension);
 
metadata.set(Metadata.RESOURCE_NAME_KEY, file.getName());
 org.apache.tika.mime.MediaType mediaType = detector.detect(stream, metadata);
     //   System.out.println("mediaTpe : : :: : "+mediaType);
        if(mediaType.toString().contains("text/plain"))
        {
                  Parser parser = new AutoDetectParser();
      BodyContentHandler handler = new BodyContentHandler(-1);
       metadata = new Metadata();
      FileInputStream inputstream = new FileInputStream(file);
      ParseContext context = new ParseContext();
        
      parser.parse(inputstream, handler, metadata, context);
      //System.out.println(handler.toString());
      String encoding = metadata.get("Content-Type");
      if(inputstream != null)
      {
          inputstream.close();
      }
      return encoding;
        }
      if(stream != null)
      {
          stream.close();
      }
      return mediaType.toString();
    }
      
      
    public static String getMimeType( ByteArrayInputStream stream ) throws FileNotFoundException, IOException, SAXException, TikaException
    {
   //     TikaConfig config = TikaConfig.getDefaultConfig();
 //Detector detector = config.getDetector();
BodyContentHandler handler = new BodyContentHandler(-1);
 //TikaInputStream stream = TikaInputStream.get(file);
   Metadata metadata = new Metadata();
 //metadata.add(Metadata.RESOURCE_NAME_KEY, filenameWithExtension);
 
//metadata.set(Metadata.RESOURCE_NAME_KEY, file.getName());
 //org.apache.tika.mime.MediaType mediaType = detector.detect(stream, metadata);
  ParseContext context = new ParseContext();
        Parser parser = new AutoDetectParser(); 
      parser.parse( stream, handler, metadata, context);
      
      //System.out.println(handler.toString());
      String encoding = metadata.get("Content-Type");
       if( stream != null)
      {
           stream.close();
      }
      return encoding;
    }
         /**
          * if @param f is file then examines a MIME type for zip file, if it is
          * then extracts the contents into a folder as <filename>_zip it happens recursively
          * until all contents are UNZIPPED to Regular NON-ZIP files.
          * @param f
          * @param fileList
          * @throws Exception
          */
    private   void recurseZipFileExtraction(File f, Set<File> fileList, String unzippedFolderPath) throws IOException, FileNotFoundException, SAXException, TikaException  
     {
         if(f.isFile())
         {
             String content = null;
             
             content = getMimeType(f);
             
           //  System.out.println("content type : : : : :   : " + content + " : : : : " +f);
             if(content.contains("zip")||content.contains("rar")||content.contains("7z")||content.contains("tar")||content.equals("application/x-mobipocket-ebook"))
             {
                 //String folderName = f.getAbsolutePath()+".zip";
              //   String folderName =tempFolder+"/"+f.getName()+".zip";
                    String folderName =unzippedFolderPath;
                 File folder = new File(folderName);
                 folder.mkdirs();
           //      System.out.println(folder+"\\"+f.getName()+" : : : :  : in recurse zip file extraction : : : : " + folder.getAbsolutePath());
          
                 extract(f,folder, fileList);
                // for(File fo : new File(folderName).listFiles())
               //  recurseZipFileExtraction(fo,fileList);
             }
             else
             {
                 throw new IOException("Invalid zip file");
             }
         }
         else
         {
         //    System.out.println("Regular file : : : : " + f.getAbsolutePath());
         }
     }
}







