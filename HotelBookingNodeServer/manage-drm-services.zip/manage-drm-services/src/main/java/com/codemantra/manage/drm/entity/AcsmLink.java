package com.codemantra.manage.drm.entity;

public class AcsmLink {
	private String link;
	private String uuid;
	private Integer orderFlg;
	private String downloadStatus;
	private String drmRequestStatus;
	
	 
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public Integer getOrderFlg() {
		return orderFlg;
	}
	public void setOrderFlg(Integer orderFlg) {
		this.orderFlg = orderFlg;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public String getDrmRequestStatus() {
		return drmRequestStatus;
	}
	public void setDrmRequestStatus(String drmRequestStatus) {
		this.drmRequestStatus = drmRequestStatus;
	}
	
}
