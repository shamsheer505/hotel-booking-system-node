/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "drmRequestAudit")
public class DRM {

	private String drmId;
	private String drmSource; // To be hardcoded as 'Manage' for our internal calls
	private List<ISBN> isbnList;
	private List<String> emailIdList;
	private String orderType;
	private Integer noOfDevices;
	private Boolean readPermission;
	private Integer noOfDays;
	private Boolean printCopyPermission;
	private Integer printPages;
	private Integer copyPages;	

	private String downloadStatus;  // Not Completed
	private Date downloadCompletedOn; // To be updated once downloaded
	
	private String remarks;
	private String clientIP;
	
	private Date requestDate;
	@Id
	private String requestId;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getDrmId() {
		return drmId;
	}

	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}

	public String getDrmSource() {
		return drmSource;
	}

	public void setDrmSource(String drmSource) {
		this.drmSource = drmSource;
	}

	public List<ISBN> getIsbnList() {
		return isbnList;
	}

	public void setIsbnList(List<ISBN> isbnList) {
		this.isbnList = isbnList;
	}

	public List<String> getEmailIdList() {
		return emailIdList;
	}

	public void setEmailIdList(List<String> emailIdList) {
		this.emailIdList = emailIdList;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Integer getNoOfDevices() {
		return noOfDevices;
	}

	public void setNoOfDevices(Integer noOfDevices) {
		this.noOfDevices = noOfDevices;
	}

	public Boolean getReadPermission() {
		return readPermission;
	}

	public void setReadPermission(Boolean readPermission) {
		this.readPermission = readPermission;
	}

	public Integer getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}

	public Boolean getPrintCopyPermission() {
		return printCopyPermission;
	}

	public void setPrintCopyPermission(Boolean printCopyPermission) {
		this.printCopyPermission = printCopyPermission;
	}

	public Integer getPrintPages() {
		return printPages;
	}

	public void setPrintPages(Integer printPages) {
		this.printPages = printPages;
	}

	public Integer getCopyPages() {
		return copyPages;
	}

	public void setCopyPages(Integer copyPages) {
		this.copyPages = copyPages;
	}

	public String getDownloadStatus() {
		return downloadStatus;
	}

	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}

	public Date getDownloadCompletedOn() {
		return downloadCompletedOn;
	}

	public void setDownloadCompletedOn(Date downloadCompletedOn) {
		this.downloadCompletedOn = downloadCompletedOn;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getClientIP() {
		return clientIP;
	}

	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
}
