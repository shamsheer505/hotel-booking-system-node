package com.codemantra.manage.drm.entity;


import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "mWatermarkContent")
public class MWatermarkContentEntity {

	@Field("client")
	private String client;
	
	@Field("subject")
	private String subject;
	
	@Field("beforeContent")
	private String beforeContent;
	
	@Field("afterContent")
	private String afterContent;
	
	@Field("isActive")
	private String isActive;
	
	@Field("isDeleted")
	private String isDeleted;
	
	@Field("createdOn")
	private String createdOn;
	
	@Field("type")
	private String type;

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBeforeContent() {
		return beforeContent;
	}

	public void setBeforeContent(String beforeContent) {
		this.beforeContent = beforeContent;
	}

	public String getAfterContent() {
		return afterContent;
	}

	public void setAfterContent(String afterContent) {
		this.afterContent = afterContent;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	
	
}
