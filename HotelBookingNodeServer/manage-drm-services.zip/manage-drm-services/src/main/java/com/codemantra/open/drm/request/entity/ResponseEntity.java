/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codemantra.open.drm.request.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 *
 * @author codemantra
 */
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseEntity implements java.io.Serializable{
    public ResponseEntity(){}
    private String status;
    private Integer statusCode;
    private String responseString;

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the statusCode
     */
    public Integer getStatusCode() {
        return statusCode;
    }

    /**
     * @param statusCode the statusCode to set
     */
    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * @return the responseString
     */
    public String getResponseString() {
        return responseString;
    }

    /**
     * @param responseString the responseString to set
     */
    public void setResponseString(String responseString) {
        this.responseString = responseString;
    }
    
}
