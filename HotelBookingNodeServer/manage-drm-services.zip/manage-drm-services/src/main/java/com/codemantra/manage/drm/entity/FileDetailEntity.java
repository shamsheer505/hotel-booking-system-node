package com.codemantra.manage.drm.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class FileDetailEntity {
	
	@Field("fileId")
	private Long fileId;
	@Field("filename")
	private String fileName;
	@Field("type")
	private String type;
	@Field("extension")
	private String extension;
	@Field("version")
	private int version;
	@Field("objectkey")
	private String objectKey;
	@Field("uploadedOn")
	private Date uploadedOn;
	@Field("uploadedBy")
	private String uploadedBy;
	@Field("versionId")
	private String versionId;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	
	public String getObjectKey() {
		return objectKey;
	}
	public void setObjectKey(String objectKey) {
		this.objectKey = objectKey;
	}
	
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public Date getUploadedOn() {
		return uploadedOn;
	}
	public void setUploadedOn(Date uploadedOn) {
		this.uploadedOn = uploadedOn;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public Long getFileId() {
		return fileId;
	}
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@Override
	public String toString() {
		return "FileDetailEntity [fileId=" + fileId + ", fileName=" + fileName + ", type=" + type + ", extension="
				+ extension + ", version=" + version + ", objectKey=" + objectKey + ", uploadedOn=" + uploadedOn
				+ ", uploadedBy=" + uploadedBy + "]";
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	

}
