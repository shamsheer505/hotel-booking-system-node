package com.codemantra.manage.drm.test;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.bson.Document;

import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DB;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;

public class MongoDBToDBTransfer {
	
	/*public static void main(String[] args) {
		MongoCredential mongoCredential = MongoCredential.createScramSha1Credential("devtest", "manage_dev",
				"testdev".toCharArray());
		MongoClient mongoClient = new MongoClient(new ServerAddress("172.16.1.24", Integer.valueOf(27017)),
				Arrays.asList(mongoCredential));
		MongoClient mongoClient1 = new MongoClient("localhost", 27017);

		DB db = mongoClient.getDB("manage_dev");
		Set<String> s = db.getCollectionNames();
		MongoDatabase d = mongoClient.getDatabase("manage_dev");

		MongoDatabase d1 = mongoClient1.getDatabase("manage_dev");
		for (String string : s) {
			DB db1 = mongoClient1.getDB("manage");

			if (!db1.collectionExists(string)) {
				DBObject options = BasicDBObjectBuilder.start().add("capped", false).add("size", 2000000000l).get();
				db1.createCollection(string, options);
				MongoCollection<Document> m22 = d.getCollection(string);
				//FindIterable<Document> da = m22.find().projection(Projections.exclude("_id", "_class"));
				
				FindIterable<Document> da = m22.find();

				if (!"mTransactionsTest".equals(string) && !"system.users".equals(string) && !"mTransactions2".equals(string) ) {
					List<Document> docs = new ArrayList<>();
					for (Document document : da) {
						docs.add(document);
					}
					
					MongoCollection<Document> m = d1.getCollection(string);
					if (docs.size() > 0) {
						m.insertMany(docs);
					}
				}

			} else {
				MongoCollection<Document> m22 = d.getCollection(string);
				//FindIterable<Document> da = m22.find().projection(Projections.exclude("_id", "_class"));
				FindIterable<Document> da = m22.find();
				
				if (!"mTransactionsTest".equals(string) && !"system.users".equals(string) && !"mTransactions2".equals(string) ) {
					List<Document> docs = new ArrayList<>();
					for (Document document : da) {
						docs.add(document);
					}
					MongoCollection<Document> m = d1.getCollection(string);

					if (docs.size() > 0) {
						m.insertMany(docs);
					}
				}
				
				
				
				
				
			}
		}
	}
*/
	
	
	
	public static void main(String[] args) throws IOException {
		
		/*** Pattern Matching ***/
		
	    /*String input = "shahid@gmail.com,   shahid@codemantra.in";
	    final Pattern pattern = Pattern.compile("^((([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))([\\s])*,([\\s])*[\\w]{1})*((([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,})))([\\s])*$");
	    if (!pattern.matcher(input).matches()) {
	        throw new IllegalArgumentException("Invalid String");
	    }else {
	    	System.out.println("valid Pattern");
	    }*/
		
		
		/*** Date Validation ***/
		/*final String DATE_FORMAT = "MM/dd/yyyy";
		
		String yourDate = "03/29/2018";
		
		try {
            DateFormat df = new SimpleDateFormat(DATE_FORMAT);
            df.setLenient(false);
            df.parse(yourDate);
            System.out.println("valid Date");
            
            if(df.parse(yourDate).after(new Date()))
            	System.out.println("Order Date can't be greater than current date");
            
            
        } catch (Exception e) {
        	System.out.println("Invalid Date");
        }*/
		
		Double a = 1.0;
		Double b = 2.0;
		
		System.out.println(Double.compare(a, b));
		
		
	}
}
