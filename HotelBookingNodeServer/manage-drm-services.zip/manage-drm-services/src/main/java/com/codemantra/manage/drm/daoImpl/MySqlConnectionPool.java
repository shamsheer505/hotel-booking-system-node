package com.codemantra.manage.drm.daoImpl;

import javax.sql.DataSource;

import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import ch.qos.logback.classic.Logger;

@Repository
public class MySqlConnectionPool {

	@Value("${spring.datasource.url}")
	String DATABASE_URL;

	@Value("${spring.datasource.username}")
	String USERNAME;

	@Value("${spring.datasource.password}")
	String PASSWORD;

	@Value("${spring.datasource.driver-class-name}")
	String DRIVER_CLASSNAME;

	private static GenericObjectPool gPool = null;

	private static DataSource dataSource = null;

	@SuppressWarnings("unused")
	public DataSource setUpPool() throws Exception {

		if (dataSource != null) {
			//System.out.println("datasource is available. So returning the datasource object");
			return dataSource;
		} else {
			Class.forName(DRIVER_CLASSNAME);
			//System.out.println("datasource is not available. So creating the datasource object");
			// Creates an Instance of GenericObjectPool That Holds Our Pool of Connections
			// Object!
			if (null == gPool)
				gPool = new GenericObjectPool();
			gPool.setMaxActive(7);
			// Creates a ConnectionFactory Object Which Will Be Use by the Pool to Create
			// the Connection Object!
			ConnectionFactory cf = new DriverManagerConnectionFactory(DATABASE_URL, USERNAME, PASSWORD);
			// Creates a PoolableConnectionFactory That Will Wraps the Connection Object
			// Created by the ConnectionFactory to Add Object Pooling Functionality!
			PoolableConnectionFactory pcf = new PoolableConnectionFactory(cf, gPool, null, null, false, true);
			dataSource = new PoolingDataSource(gPool);
			return dataSource;
		}

	}

}
