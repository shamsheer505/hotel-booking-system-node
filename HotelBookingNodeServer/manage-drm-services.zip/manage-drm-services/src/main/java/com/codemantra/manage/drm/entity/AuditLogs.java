/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codemantra.manage.drm.entity;

import java.util.Date;
import java.util.Map;
/**
 *
 * @author codemantra
 */
public class AuditLogs implements java.io.Serializable{
    public AuditLogs (){super();}
    private String id;
    private String clientIp;
    private String emailId;
    private String userId;
    private String status;
    private Date loggedTime;
    private Map<String, Object> otherInfo;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the clientIp
     */
    public String getClientIp() {
        return clientIp;
    }

    /**
     * @param clientIp the clientIp to set
     */
    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the loggedTime
     */
    public Date getLoggedTime() {
        return loggedTime;
    }

    /**
     * @param loggedTime the loggedTime to set
     */
    public void setLoggedTime(Date loggedTime) {
        this.loggedTime = loggedTime;
    }

    /**
     * @return the otherInfo
     */
    public Map<String, Object> getOtherInfo() {
        return otherInfo;
    }

    /**
     * @param otherInfo the otherInfo to set
     */
    public void setOtherInfo(Map<String, Object> otherInfo) {
        this.otherInfo = otherInfo;
    }
}
