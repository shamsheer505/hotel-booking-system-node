/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

public class AssetFileEntity {
		
	private String isbn;
	private String assetId;
	private String formatId;
	private String bucket;
	private String folder;
	private String formatStatus;
	private Integer fileId;
	private String fileName;	
	private String type;
	private String extension;
	private Integer version;
	private String versionId;
	private String objectkey;
	
	private String CountryOfPublication;
	private String PublicationDate;
	private String ProductCategory;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public String getBucket() {
		return bucket;
	}
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = folder;
	}
	public String getFormatStatus() {
		return formatStatus;
	}
	public void setFormatStatus(String formatStatus) {
		this.formatStatus = formatStatus;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getObjectkey() {
		return objectkey;
	}
	public void setObjectkey(String objectkey) {
		this.objectkey = objectkey;
	}
	public String getCountryOfPublication() {
		return CountryOfPublication;
	}
	public void setCountryOfPublication(String countryOfPublication) {
		CountryOfPublication = countryOfPublication;
	}
	public String getPublicationDate() {
		return PublicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		PublicationDate = publicationDate;
	}
	public String getProductCategory() {
		return ProductCategory;
	}
	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}
}
