/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
24-01-2018		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class WatermarkOrderEntity {
	private String watermarkId;
	private String isbn;
	private String deviceFormat;
	private String formatId;
	private Integer fileId;
	private Integer orderFlag;
	private String orderStatus;	
	private String url;
	private Date urlExpiryOn;
	
	private String downloadStatus;
	
	@Field("title")
	private String title;
	@Field("CountryOfPublication")
	private String countryOfPublication;
	@Field("ImprintName")
	private String imprintName;
	@Field("ProductCategory")
	private String productCategory;
	@Field("PublicationDate")
	private String publicationDate;
	
	

	public String getWatermarkId() {
		return watermarkId;
	}
	public void setWatermarkId(String watermarkId) {
		this.watermarkId = watermarkId;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDeviceFormat() {
		return deviceFormat;
	}
	public void setDeviceFormat(String deviceFormat) {
		this.deviceFormat = deviceFormat;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public Integer getOrderFlag() {
		return orderFlag;
	}
	public void setOrderFlag(Integer orderFlag) {
		this.orderFlag = orderFlag;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Date getUrlExpiryOn() {
		return urlExpiryOn;
	}
	public void setUrlExpiryOn(Date urlExpiryOn) {
		this.urlExpiryOn = urlExpiryOn;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCountryOfPublication() {
		return countryOfPublication;
	}
	public void setCountryOfPublication(String countryOfPublication) {
		this.countryOfPublication = countryOfPublication;
	}
	public String getImprintName() {
		return imprintName;
	}
	public void setImprintName(String imprintName) {
		this.imprintName = imprintName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}
	
	
}
