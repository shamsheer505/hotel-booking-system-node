/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
24-01-2018		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

public class ClientEmailEntity {
	private String emailId;
	private String uuid;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}	
	
}
