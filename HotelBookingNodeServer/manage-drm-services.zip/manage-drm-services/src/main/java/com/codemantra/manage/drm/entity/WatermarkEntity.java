/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
29-01-2018		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "watermarkDetails")
public class WatermarkEntity {
	
	@Id
	private String id;
	
	private String drmSource;
	private String orderId;
	private String orderType;
	private String clientId;
	private String clientName;
	private Date orderDate;
	private List<String> clientEmail;	
	private List<WatermarkOrderEntity> order;
	private Integer watermarkFlag;
	private String watermarkRequestStatus = "PENDING";
	private Boolean isActive;
	private Boolean isDeleted;
	private Date createdOn;
	private String createdBy;
	//private List<ResendDRM> resend;
	private String clientIP;
	private String requestId;
	
	
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getClientIP() {
		return clientIP;
	}
	/** For Watermark Creation **/
	private String inputFileName;
	private String outputFolderName;
	private String emailId;
	private String orderDateString;
	private String deviceFormat;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDrmSource() {
		return drmSource;
	}
	public void setDrmSource(String drmSource) {
		this.drmSource = drmSource;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public List<String> getClientEmail() {
		return clientEmail;
	}
	public void setClientEmail(List<String> clientEmail) {
		this.clientEmail = clientEmail;
	}
	public List<WatermarkOrderEntity> getOrder() {
		return order;
	}
	public void setOrder(List<WatermarkOrderEntity> order) {
		this.order = order;
	}
	public Integer getWatermarkFlag() {
		return watermarkFlag;
	}
	public void setWatermarkFlag(Integer watermarkFlag) {
		this.watermarkFlag = watermarkFlag;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getWatermarkRequestStatus() {
		return watermarkRequestStatus;
	}
	public void setWatermarkRequestStatus(String watermarkRequestStatus) {
		this.watermarkRequestStatus = watermarkRequestStatus;
	}
	/*public List<ResendDRM> getResend() {
		return resend;
	}
	public void setResend(List<ResendDRM> resend) {
		this.resend = resend;
	}
	public String getClientIP() {
		return clientIP;
	}*/
	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}
	public String getInputFileName() {
		return inputFileName;
	}
	public void setInputFileName(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	public String getOutputFolderName() {
		return outputFolderName;
	}
	public void setOutputFolderName(String outputFolderName) {
		this.outputFolderName = outputFolderName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getOrderDateString() {
		return orderDateString;
	}
	public void setOrderDateString(String orderDateString) {
		this.orderDateString = orderDateString;
	}
	public String getDeviceFormat() {
		return deviceFormat;
	}
	public void setDeviceFormat(String deviceFormat) {
		this.deviceFormat = deviceFormat;
	}
	
   	
}
