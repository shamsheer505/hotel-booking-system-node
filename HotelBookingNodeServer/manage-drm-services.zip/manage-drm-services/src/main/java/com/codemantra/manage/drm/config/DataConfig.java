/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

@Configuration
@ComponentScan(basePackages = "com.codemantra.manage")
@PropertySource("classpath:manage_resources.properties")



public class DataConfig {

	@Value("${spring.data.mongodb.host}")
	private String mongoDBServer ;
	
	@Value("${spring.data.mongodb.database}")
	private String mongoDBName ;
	
	@Value("${spring.data.mongodb.port}")
	private String mongoDBPort ;
	
	@Value("${spring.data.mongodb.username}")
	private String mongoDBUserName ;
	
	@Value("${spring.data.mongodb.password}")
	private String mongoDBPassword ;
	
	
    @Bean
    public MongoDbFactory mongoDbFactory() throws Exception {
        
       MongoCredential mongoCredential = MongoCredential.createScramSha1Credential(mongoDBUserName, mongoDBName,
    		   mongoDBPassword.toCharArray());
       MongoClient mongoClient = new MongoClient(new ServerAddress(mongoDBServer,Integer.valueOf(mongoDBPort)),Arrays.asList(mongoCredential));
        return new SimpleMongoDbFactory(mongoClient, mongoDBName);
    }
 
    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
        return mongoTemplate;
    }
    @Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}