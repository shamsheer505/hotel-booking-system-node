package com.codemantra.manage.drm.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class PojoToHTML {
    
    final static String empty="&nbsp;";
    // private int columns;
     private final StringBuilder table = new StringBuilder();
     public static String HTML_START = "<html>";
     public static String HTML_END = "</html>";
     public static String TABLE_START_BORDER = "<table border=\"1\">";
     public static String TABLE_START = "<table>";
     public static String TABLE_END = "</table>";
     public static String HEADER_START = "<th>";
     public static String HEADER_END = "</th>";
     public static String ROW_START = "<tr>";
     public static String ROW_END = "</tr>";
     public static String COLUMN_START = "<td>";
     public static String COLUMN_END = "</td>";


     /**
      * @param header
      * @param border
      * @param rows
      * @param columns
     * @throws IllegalAccessException 
     * @throws IllegalArgumentException 
      */
     public <T> PojoToHTML(List<T> source,Boolean header, Boolean border,Boolean removeTableTag) throws IllegalArgumentException, IllegalAccessException {
      //this.columns = columns;

      
      if(!removeTableTag)
      table.append(border ? TABLE_START_BORDER : TABLE_START);
      if (header)  
               addTableHeader(source);
      addRowValues(source);
      if(!removeTableTag)
      table.append(TABLE_END);
      
      
      
      
     }


     /**
      * @param values
     * @throws IllegalAccessException 
     * @throws IllegalArgumentException 
      */
     public <T> void addTableHeader(List<T> source) throws IllegalArgumentException, IllegalAccessException {

      
        StringBuilder sb = new StringBuilder();
        sb.append(ROW_START);
        
            for (String value : getHeaders(source.get(0))) {
             sb.append(HEADER_START);
             sb.append(value);
             sb.append(HEADER_END);
            }
        
        sb.append(ROW_END);
        table.append( sb.toString());
      
      }
    


     /**
      * @param values
     * @throws IllegalAccessException 
     * @throws IllegalArgumentException 
      */
     public <T> void addRowValues(List<T> source) throws IllegalArgumentException, IllegalAccessException {
      
    
        
        for(T t : source)
        {
        StringBuilder sb = new StringBuilder();
        sb.append(ROW_START);
        for (String value : geValues(t)) {
         sb.append(COLUMN_START);
         sb.append(value);
         sb.append(COLUMN_END);
        }
        sb.append(ROW_END);
        table.append( sb.toString());
        }
      
     }


     /**
      * @return
      */
     public String build() {
      return table.toString();
     }
    
    public static <T> List<String> getHeaders(T source) throws IllegalArgumentException, IllegalAccessException {
    //    StringBuilder outHtml= new StringBuilder();
        List<String> _headers = new  ArrayList<String>();
        
        for (Field field : source.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            String name = field.getName();
            _headers.add(name);
           /* Object value = field.get(t);
            System.out.printf("%s: %s%n", name, value);*/
        }
        return _headers;
    }
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static <T> List<String> geValues(T source) throws IllegalArgumentException, IllegalAccessException {
        //    StringBuilder outHtml= new StringBuilder();
            List<String> _values = new  ArrayList<String>();
        
            for (Field field : source.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                Object value = field.get(source);
                if(value!=null)
                {
                    if(value instanceof Collection<?>) {
                        _values.add(
                                ((Collection) value).stream().collect(Collectors.joining(",")).toString()
                          );
                    }
                    else
                        _values.add(String.valueOf(value));
                }
                else
                    _values.add(empty);
            }
            return _values;
        }

}