package com.codemantra.manage.drm.util;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

public class ComparePOJO {
	
	public static ArrayList<String> compareBeans(Object newBean, Object oldBean) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if( newBean.getClass() != oldBean.getClass()  ) {
		throw new IllegalArgumentException("The beans must be from the same Class!");
		}
		ArrayList<String> changesArr = new ArrayList();
		Iterator keysIt = BeanUtils.describe(newBean).keySet().iterator();
		while (keysIt.hasNext()) {
		String key = (String) keysIt.next();
		Object oldValue = PropertyUtils.getProperty(oldBean, key);
		Object newValue = PropertyUtils.getProperty(newBean, key);
		if( oldValue != newValue ) {// Ignores when both are "null"
		if( ( (oldValue != null) && !oldValue.equals(newValue) )
		 || ( (newValue != null) && !newValue.equals(oldValue) ) ) {
		changesArr.add(key);
		} 
		}
		}
		return changesArr;
	}

}
