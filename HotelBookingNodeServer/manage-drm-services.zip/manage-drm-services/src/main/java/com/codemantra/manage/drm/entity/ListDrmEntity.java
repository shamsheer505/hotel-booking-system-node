package com.codemantra.manage.drm.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "drmDetails")
public class ListDrmEntity {
	
	@Field("drmId")
	private String drmId;
	
	@Field("isbn")
	private String isbn;
	
	@Field("formatId")
	private String formatId;
	
	@Field("noOfDevices")
	private String noOfDevices;
	
	@Field("readPermission")
	private String readPermission;
	
	@Field("noOfDays")
	private String noOfDays;
	
	@Field("printCopyPermission")
	private String printCopyPermission; 
	
	@Field("printPages")
	private String printPages; 
	
	@Field("copyPages")
	private String copyPages; 
	
	@Field("downloadStatus")
	private String downloadStatus; 
	
	@Field("isActive")
	private String isActive;
	
	@Field("isDeleted")
	private String isDeleted;
	
	@Field("drmFlg")
	private String drmFlg;

	public String getDrmId() {
		return drmId;
	}

	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getFormatId() {
		return formatId;
	}

	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}

	public String getNoOfDevices() {
		return noOfDevices;
	}

	public void setNoOfDevices(String noOfDevices) {
		this.noOfDevices = noOfDevices;
	}

	public String getReadPermission() {
		return readPermission;
	}

	public void setReadPermission(String readPermission) {
		this.readPermission = readPermission;
	}

	public String getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getPrintCopyPermission() {
		return printCopyPermission;
	}

	public void setPrintCopyPermission(String printCopyPermission) {
		this.printCopyPermission = printCopyPermission;
	}

	public String getPrintPages() {
		return printPages;
	}

	public void setPrintPages(String printPages) {
		this.printPages = printPages;
	}

	public String getCopyPages() {
		return copyPages;
	}

	public void setCopyPages(String copyPages) {
		this.copyPages = copyPages;
	}

	public String getDownloadStatus() {
		return downloadStatus;
	}

	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getDrmFlg() {
		return drmFlg;
	}

	public void setDrmFlg(String drmFlg) {
		this.drmFlg = drmFlg;
	}

	
}
