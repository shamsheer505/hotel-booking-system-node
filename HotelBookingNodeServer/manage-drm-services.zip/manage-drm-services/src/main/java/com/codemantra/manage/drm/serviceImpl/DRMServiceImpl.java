/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.serviceImpl;

import java.awt.Image;
import java.awt.image.BufferedImage;
//import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.tika.exception.TikaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;
import org.xml.sax.SAXException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.ResponseHeaderOverrides;
import com.amazonaws.services.s3.model.S3Object;
import com.codemantra.manage.drm.dao.DRMDao;
import com.codemantra.manage.drm.dto.APIResponse;
import com.codemantra.manage.drm.dto.APIResponse.ResponseCode;
import com.codemantra.manage.drm.dto.Status;
import com.codemantra.manage.drm.entity.AcsmLink;
import com.codemantra.manage.drm.entity.AssetFileEntity;
import com.codemantra.manage.drm.entity.AuditLogs;
import com.codemantra.manage.drm.entity.AwsAPIEntity;
import com.codemantra.manage.drm.entity.ClientEmailEntity;
import com.codemantra.manage.drm.entity.DRMEntity;
import com.codemantra.manage.drm.entity.DRMEntityNew;
import com.codemantra.manage.drm.entity.MDrmContentEntity;
import com.codemantra.manage.drm.entity.MWatermarkContentEntity;
import com.codemantra.manage.drm.entity.OrderEntity;
import com.codemantra.manage.drm.entity.WatermarkEntity;
import com.codemantra.manage.drm.entity.WatermarkOrderEntity;
import com.codemantra.manage.drm.model.DRM;
import com.codemantra.manage.drm.model.DRMNew;
import com.codemantra.manage.drm.model.ISBN;
import com.codemantra.manage.drm.model.KeyValue;
import com.codemantra.manage.drm.model.ResendDRM;
import com.codemantra.manage.drm.model.Watermark;
import com.codemantra.manage.drm.model.WatermarkOrder;
import com.codemantra.manage.drm.service.DRMService;
import com.codemantra.manage.drm.util.DRMDisplay;
import com.codemantra.manage.drm.util.FTPUtil;
import com.codemantra.manage.drm.util.MailTitleDetails;
import com.codemantra.manage.drm.util.PojoToHTML;
import com.codemantra.manage.drm.util.ZipUtil;
import com.codemantra.open.drm.request.entity.RequestEntity;
import com.codemantra.open.drm.request.entity.ResponseEntity;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;

import james.JpegEncoder;
import java.lang.reflect.Array;
import java.util.Properties;
import java.util.function.IntFunction;
import net.f5.Extract;
import net.flibusta.converter.ConversionException;
import net.flibusta.converter.ConversionService;
import net.flibusta.converter.ConversionServiceFactory;
import net.sf.sevenzipjbinding.SevenZipException;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
 

@Service("drmservice")
@EnableScheduling
public class DRMServiceImpl implements DRMService {

	private static final Logger logger = LoggerFactory.getLogger(DRMServiceImpl.class);

	@Autowired
	DRMDao masterDao;

	@Value("${SUCCESS_SAVE_DRM}")
	String SUCCESS_SAVE_DRM;

	@Value("${FAILURE_SAVE_DRM}")
	String FAILURE_SAVE_DRM;

	@Value("${NO_SOURCE_RECORD_EXISTS}")
	String NO_SOURCE_RECORD_EXISTS;

	@Value("${SUCCESS_RESEND_DRM}")
	String SUCCESS_RESEND_DRM;

	@Value("${FAILURE_RESEND_DRM}")
	String FAILURE_RESEND_DRM;

	@Value("${SUCCESS_RETRIEVE_DRM_LIST}")
	String SUCCESS_RETRIEVE_DRM_LIST;

	@Value("${FAILURE_RETRIEVE_DRM_LIST}")
	String FAILURE_RETRIEVE_DRM_LIST;

	@Value("${baseXml}")
	String baseXml;

	@Value("${rightsXml}")
	String rightsXml;

	@Value("${pdfFileType}")
	String pdfFormat;

	@Value("${ePubFileType}")
	String ePub;

	@Value("${baseFTPPath}")
	String baseFTPPath;

	@Value("${ftpUrl}")
	String ftpUrl;

	@Value("${ftpUserName}")
	String ftpUserName;

	@Value("${ftpPassword}")
	String ftpPassword;

	@Value("${ftpPort}")
	int ftpPort;

	@Value("${acs4Operation.package}")
	String acs4OperationPackage;

	@Value("${acs4Operation.rights}")
	String acs4OperationRights;

	@Value("${acs4Operation.ACSM}")
	String acs4OperationACSM;

	@Value("${acsmClientName}")
	String acsmClientName;

	@Value("${acsmKey}")
	String acsmKey;

	@Value("${acsmPackage}")
	String acsmPackage;
	
	@Value("${tempDir}")
	String tempDir;
	
        @Value(value="${EPUB_IMAGE_PASSWORD}")
        private String EPUB_IMAGE_PASSWORD;

        @Autowired
        //@Qualifier("statusCodesProperties")
        private Properties statusCodes;
	@Value("${emailSubject}")
	String emailSubject;
	
	@Value("${MANAGE_DRM_URL}")
	String MANAGE_DRM_URL;
	
	@Value("${MANAGE_EMAIL_SERVICE_URL}")
	String MANAGE_EMAIL_SERVICE_URL;
	
	@Value("${MANAGE_SEARCH_SERVICE_URL}")
	String MANAGE_SEARCH_SERVICE_URL;
	
		
	@Value("${client}")
	String client;
	
	@Value("${supportMail}")
	String supportMail;
	
	@Value("${FAILURE_SAVE_DRM_MULT_FILES}")
	String FAILURE_SAVE_DRM_MULT_FILES;
	
	@Value("${SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST}")
	String SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST;
	
	@Value("${FAILURE_RETRIEVE_ELIGIBLE_FORMAT_LIST}")
	String FAILURE_RETRIEVE_ELIGIBLE_FORMAT_LIST;	
				
	@Value("${AUTH_ERROR}")
	String AUTH_ERROR;
	
	@Value("${INPUT_EMPTY_ERROR}")
	String INPUT_EMPTY_ERROR;
	
	@Value("${EMAIL_INVALID_ERROR}")
	String EMAIL_INVALID_ERROR;
	
	@Value("${ORDER_DATE_INVALID_ERROR}")
	String ORDER_DATE_INVALID_ERROR;
	
	@Value("${DRM_INVALID_ERROR}")
	String DRM_INVALID_ERROR;
	
	@Value("${ISBN_INVALID_ERROR}")
	String ISBN_INVALID_ERROR;
	
	@Value("${FORMAT_INVALID_ERROR}")
	String FORMAT_INVALID_ERROR;
	
	@Value("${INPUT_LENGTH_ERROR}")
	String INPUT_LENGTH_ERROR;
	
	@Value("${SYSTEM_ERROR}")
	String SYSTEM_ERROR;
	
	@Value("${SUCCESS_ADD_DRM}")
	String SUCCESS_ADD_DRM;
	
	@Value("${INTERNAL_DRM_ORDER_TYPE}")
	String INTERNAL_DRM_ORDER_TYPE;	
	
	@Value("${DRM_TYPE_LIMITED}")
	String DRM_TYPE_LIMITED;
	
	@Value("${DRM_TYPE_PERPETUAL}")
	String DRM_TYPE_PERPETUAL;
	
	@Value("${EMAIL_PATTERN}")
	String EMAIL_PATTERN;
	
	@Value("${WATERMARK_URL_EXPIRY_DAYS}")
	String WATERMARK_URL_EXPIRY_DAYS;

	@Value("${WATERMARK_CLIENT}")
	String WATERMARK_CLIENT;
	
	@Value("${WATERMARK_EMAIL_SUBJECT}")
	String WATERMARK_EMAIL_SUBJECT;
	
	@Value("${MANAGE_WATERMARK_URL}")
	String MANAGE_WATERMARK_URL;
	
	@Value("${WATERMARK_SUPPORT_MAIL}")
	String WATERMARK_SUPPORT_MAIL;
	
	@Value(value="${WATERMARK_FILE_S3_PATH}")
    private String WATERMARK_FILE_S3_PATH;

    @Value(value="${PDF_ADMIN_PASSWORD}")
    private String PDF_ADMIN_PASSWORD;

    @Value(value="${PDF_IMAGE_PASSWORD}")
    private String PDF_IMAGE_PASSWORD;

    @Value(value = "${PDF_FONT_SIZE}")
    private   String  PDF_FONT_SIZE;
    
    @Value(value="${PDF_FONT_RED}")
    private String PDF_FONT_RED;
    
    @Value(value="${PDF_FONT_GREEN}")
    private String PDF_FONT_GREEN;
    
    @Value(value="${PDF_FONT_BLUE}")
    private String PDF_FONT_BLUE;
    
    @Value(value="${VIRTUAL_RAM_SIZE}")
    private String VIRTUAL_RAM_SIZE;
    
    @Value(value="${VIRTUAL_DISK_SIZE}")
    private String VIRTUAL_DISK_SIZE;
    
    @Value(value="${FOOTER_TEXT}")
    private String FOOTER_TEXT;
    
    @Value(value="${VIRTUAL_PATH_WATERMARK_INPUT}")
    private String VIRTUAL_PATH_WATERMARK_INPUT;
    
    @Value(value="${VIRTUAL_PATH_WATERMARK_OUTPUT}")
    private String VIRTUAL_PATH_WATERMARK_OUTPUT;
    
    @Value(value="${TEMP_OUTPUT_FOLDER}")
    private String TEMP_OUTPUT_FOLDER;
    
    @Value(value="${EPUB_DRM_MOBI_PATH_BACKUP}")
    private String EPUB_DRM_MOBI_PATH_BACKUP;
    
    @Value(value="${SUCCESS_RETRIEVE_WATERMARK}")
    private String SUCCESS_RETRIEVE_WATERMARK;
    
    @Value(value="${FAILURE_RETRIEVE_WATERMARK}")
    private String FAILURE_RETRIEVE_WATERMARK;
    
    @Value(value="${WATERMARK_NOT_AVAILABLE}")
    private String WATERMARK_NOT_AVAILABLE;
    
    @Value(value="${WATERMARK_MAIL_TEMPLATE}")
    private String WATERMARK_MAIL_TEMPLATE;
    
    @Value(value="${WATERMARK_PENDING_STATUS}")
    private String WATERMARK_PENDING_STATUS;
    
    @Value(value="${WATERMARK_PROCESSED_STATUS}")
    private String WATERMARK_PROCESSED_STATUS;
    
    @Value(value="${WATERMARK_PROCESSING_FAIL_STATUS}")
    private String WATERMARK_PROCESSING_FAIL_STATUS;
    
    @Value(value="${WATERMARK_INVALID_FORMAT}")
    private String WATERMARK_INVALID_FORMAT;
    
    @Value(value="${WATERMARK_ERROR}")
    private String WATERMARK_ERROR;
    
    @Value(value="${KINDLEGEN_PATH}")
    private String KINDLEGEN_PATH;
    
        
    @Value(value="${SUCCESS_REORDER_DRM}")
    private String SUCCESS_REORDER_DRM; 
    
    @Value(value="${FAILURE_REORDER_DRM}")
    private String FAILURE_REORDER_DRM; 
    
    @Value(value="${FAILURE_REORDER_DRM_MULT_FILES}")
    private String FAILURE_REORDER_DRM_MULT_FILES; 
    
    @Value(value="${FAILURE_REORDER_DRM_MISSING}")
    private String FAILURE_REORDER_DRM_MISSING; 
    
    
    @Value("${serviceUrl}")
 	String serviceUrl;
 	
 	
 	@Value("${environment}")
 	String environment;
 	
 	@Value("${COVER_FORMAT_ID}")
 	String coverFormatID;
 	
 	@Value("${SUCCESS_REORDER_WATERMARK}")
 	String SUCCESS_REORDER_WATERMARK;
 	
 	@Value("${FAILURE_REORDER_WATERMARK}")
 	String FAILURE_REORDER_WATERMARK;
 	
 	@Value("${FAILURE_REORDER_WATERMARK_MULT_FILES}")
 	String FAILURE_REORDER_WATERMARK_MULT_FILES;
 	
 	@Value("${FAILURE_REORDER_WATERMARK_MISSING}")
 	String FAILURE_REORDER_WATERMARK_MISSING;
 	
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> save(DRMNew modelObj, String loggedUser) {

		logger.info("Inside new Save DRM...");
		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		boolean validFlg = true;
		LinkedHashMap<String, Object> criteriaMap = new LinkedHashMap<>();
		boolean dataValidFlg = false;
		try {
			
			modelObj.setRequestDate(new Timestamp(new Date().getTime()));
			masterDao.saveEntityObject(modelObj);
			
			String requestId = modelObj.getRequestId();

			String[] isbnArray = modelObj.getIsbn().split("\\s*,\\s*");
			String[] formatArray = modelObj.getDeviceFormat().split("\\s*,\\s*");
			String[] emailArray = modelObj.getClientEmail().split("\\s*,\\s*");
			
			if(null == modelObj.getOrderType() || "".equals(modelObj.getOrderType()))
                modelObj.setOrderType("PAID");

			if (validInputData(modelObj)) {
				final Pattern pattern = Pattern.compile(EMAIL_PATTERN);
				if (!pattern.matcher(modelObj.getClientEmail()).matches()) {
					logger.info("Invalid Email Id Value...");
					// status.setCode("EMAIL_INVALID_ERROR");
					status.setCode("error");
					status.setMessage(EMAIL_INVALID_ERROR);
					status.setStatus(false);
				} else {
					if (validDate(modelObj.getOrderDate())) {
						dataValidFlg = true;
					} else {
						logger.info("Invalid Order Date...");
						/// status.setCode("ORDER_DATE_INVALID_ERROR");
						status.setCode("error");
						status.setMessage(ORDER_DATE_INVALID_ERROR);
						status.setStatus(false);
					}
				}

				if (dataValidFlg) {
					/*List<Object> criteriaList = new ArrayList<>();
					criteriaList.add(Boolean.FALSE);
					criteriaList.add(null);
					criteriaMap.clear();
					criteriaMap.put("Product.RecordReference", Arrays.asList(isbnArray));
					criteriaMap.put("isDeleted", criteriaList);*/
					List<Criteria> criteriaList = new ArrayList<>();
					Criteria[] ISBNCriteria = new Criteria[] {Criteria.where("ProductIDType").is("15"), Criteria.where("IDValue").in(Arrays.asList(isbnArray))}; 						
					criteriaList.add(Criteria.where("Product.ProductIdentifier").elemMatch(new Criteria().andOperator(ISBNCriteria)));
					criteriaList.add(Criteria.where("isDeleted").ne(Boolean.TRUE));
					int docCount = masterDao.getCountOfDocuments("products", new Criteria().andOperator(criteriaList.toArray(new Criteria[criteriaList.size()])));

					if (docCount == isbnArray.length) {
						Map<String, Object> formatMap = new HashMap<>();
						criteriaMap.clear();
						criteriaMap.put("isActive", Boolean.TRUE);
						List<KeyValue> mappedValues = masterDao.getKeyValueList("mDRM", "formatMap", "formatId",
								criteriaMap, null);
						if (mappedValues.size() > 0) {
							formatMap = mappedValues.stream()
									.collect(Collectors.toMap(KeyValue::getKey, KeyValue::getValue));
						}

						if (formatArray.length == 1 || formatArray.length == isbnArray.length) {

							List<OrderEntity> orderList = new ArrayList<>();

							for (int i = 0; i < isbnArray.length; i++) {

								String[] isbnFormatArray;

								if (formatArray.length == 1)
									isbnFormatArray = formatArray[0].split("\\s*\\+\\s*");
								else
									isbnFormatArray = formatArray[i].split("\\s*\\+\\s*");

                                isbnFormatArray = makeUnique(isbnFormatArray);
                                                                
								for (String isbnFormat : isbnFormatArray) {
									if (formatMap.containsKey(isbnFormat)) {

										String formatId = (String) formatMap.get(isbnFormat);

										Object[] queryParams = new Object[3];
										queryParams[0] = isbnArray[i];
										queryParams[1] = formatId;
										queryParams[2] = formatId;

										System.out.println("queryParams[0] " + queryParams[0] + "queryParams[1] : "
												+ queryParams[1] + " queryParams[2] :" + queryParams[2]);
										List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
												.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(),
														queryParams);
										logger.info("No. of Files ["+fileList.size()+"]");
										if (fileList.size()== 1 && null != fileList.get(0).getFileId()) {
											logger.info("FileId ["+fileList.get(0).getFileId()+"]");
											OrderEntity orderEntityObj = new OrderEntity();

											String id = masterDao.getNextSequenceId("drmIdSeq");
											orderEntityObj.setDrmId("DRM".concat(id));
											orderEntityObj.setIsbn(isbnArray[i]);
											orderEntityObj.setDeviceFormat(isbnFormat);
											orderEntityObj.setFormatId(formatId);
											orderEntityObj.setFileId(fileList.get(0).getFileId());
											orderEntityObj.setDevice(modelObj.getDevice());
											orderEntityObj.setOrderFlg(1);
											orderEntityObj.setDownloadStatus("Not Completed");
											
											orderEntityObj.setTitle(getMetaDataField(isbnArray[i], "Title"));
											orderEntityObj.setCountryOfPublication(fileList.get(0).getCountryOfPublication());
											orderEntityObj.setImprintName(getMetaDataField(isbnArray[i], "imprintname"));
											orderEntityObj.setProductCategory(fileList.get(0).getProductCategory());
											orderEntityObj.setPublicationDate(fileList.get(0).getPublicationDate());

											orderList.add(orderEntityObj);
										} else {
											logger.info("Format not available for the ISBN...");
											status.setCode("error");
											// status.setCode("FORMAT_INVALID_ERROR");
											status.setMessage(FORMAT_INVALID_ERROR);
											status.setStatus(false);
											validFlg = false;
											break;
										}

									} else {
										logger.info("Invalid Format...");
										// status.setCode("DRM_INVALID_ERROR");
										status.setCode("error");
										status.setMessage(DRM_INVALID_ERROR);
										status.setStatus(false);
										validFlg = false;
										break;
									}
								}

								if (!validFlg)
									break;

							}

							if (validFlg) {
								DRMEntityNew entityObj = new DRMEntityNew();
								entityObj.setDrmSource(modelObj.getDrmSource());
								entityObj.setOrderId(modelObj.getOrderId());
								entityObj.setOrderType((modelObj.getOrderType()!=null && !modelObj.getOrderType().equalsIgnoreCase(""))?modelObj.getOrderType():"PAID");
								entityObj.setClientId(modelObj.getClientId());
								entityObj.setClientName(modelObj.getClientName());
								entityObj.setOrderDate(new Timestamp(sdf.parse(modelObj.getOrderDate()).getTime()));
								entityObj.setDrmType(modelObj.getDrmType());
								entityObj.setDrmCutPaste(modelObj.getDrmCutPaste());
								entityObj.setDrmPrint(modelObj.getDrmPrint());
								entityObj.setDrmLicense(modelObj.getDrmLicense());
								entityObj.setClientIP(modelObj.getClientIP());
								//entityObj.setClientEmail(Arrays.asList(emailArray));
								
								List<ClientEmailEntity> clientEmailList = Arrays.asList(emailArray).stream()
										.map(temp -> {
											ClientEmailEntity obj = new ClientEmailEntity();
											obj.setEmailId(temp);
											obj.setUuid(UUID.randomUUID().toString());
											return obj;
										}).collect(Collectors.toList());

								entityObj.setClientEmail(clientEmailList);									
								
								entityObj.setDrmFlg(1);
								entityObj.setIsActive(Boolean.TRUE);
								entityObj.setIsDeleted(Boolean.FALSE);
								entityObj.setCreatedBy(loggedUser);
								entityObj.setCreatedOn(new Timestamp(new Date().getTime()));
								entityObj.setOrder(orderList);
								entityObj.setRequestId(requestId);
								
								result = masterDao.saveEntityObject(entityObj);

								if (result) {
									logger.info("Process Identifier [" + entityObj.getId() + "]");
									Map<String, String> orderIdMap = new HashMap<>();
									orderIdMap.put("orderId", entityObj.getId());									

									finalData.put("data", orderIdMap);

									status.setCode("success");
									status.setMessage(SUCCESS_ADD_DRM);
									status.setStatus(true);
								} else {
									// status.setCode("FAILURE_ADD_ACCOUNT");
									status.setCode("error");
									status.setMessage(SYSTEM_ERROR);
									status.setStatus(false);
								}
							}

						} else {
							// status.setCode("INPUT_LENGTH_ERROR");
							status.setCode("error");
							status.setMessage(INPUT_LENGTH_ERROR);
							status.setStatus(false);
						}

					} else {
						// status.setCode("ISBN_INVALID_ERROR");
						status.setCode("error");
						status.setMessage(ISBN_INVALID_ERROR);
						status.setStatus(false);
					}
				}

			} else {
				// status.setCode("INPUT_EMPTY_ERROR");
				status.setCode("error");
				status.setMessage(INPUT_EMPTY_ERROR);
				status.setStatus(false);
			}

		} catch (Exception e) {
			logger.error("Exception in save :: ", e);
			// status.setCode("SYSTEM_ERROR");
			status.setCode("error");
			status.setMessage(SYSTEM_ERROR);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}

		return finalData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> saveDRMInternal(DRM modelObj, String loggedUser) {

		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		boolean validFlg = true;
		try {			
			modelObj.setRequestDate(new Timestamp(new Date().getTime()));
			masterDao.saveEntityObject(modelObj);
			
			String requestId = modelObj.getRequestId();
			
			List<OrderEntity> orderList = new ArrayList<>();

			for (ISBN isbnFormatObj : modelObj.getIsbnList()) {
				Object[] queryParams = new Object[3];
				queryParams[0] = isbnFormatObj.getIsbn();
				queryParams[1] = isbnFormatObj.getFormatId();
				queryParams[2] = isbnFormatObj.getFormatId();
				
				if(null == modelObj.getOrderType() || "".equals(modelObj.getOrderType()))
	                modelObj.setOrderType("PAID");

				System.out.println("queryParams[0] : " + queryParams[0] + "-queryParams[1] : " + queryParams[1]
						+ "-queryParams[2] :" + queryParams[2]);
				List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
						.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(), queryParams);
				System.out.println(fileList.size());
				if (fileList.size() == 1 && null != fileList.get(0).getFileId()) {
					logger.info("FileId [" + fileList.get(0).getFileId() + "]");
					OrderEntity orderEntityObj = new OrderEntity();

					String id = masterDao.getNextSequenceId("drmIdSeq");
					orderEntityObj.setDrmId("DRM".concat(id));
					orderEntityObj.setIsbn(isbnFormatObj.getIsbn());
					orderEntityObj.setDeviceFormat(isbnFormatObj.getFormatId());
					orderEntityObj.setFormatId(isbnFormatObj.getFormatId());
					orderEntityObj.setFileId(fileList.get(0).getFileId());
					orderEntityObj.setDevice(modelObj.getNoOfDevices());
					orderEntityObj.setOrderFlg(1);
					orderEntityObj.setDownloadStatus("Not Completed");
					
					orderEntityObj.setTitle(getMetaDataField(isbnFormatObj.getIsbn(), "Title"));
					orderEntityObj.setCountryOfPublication(fileList.get(0).getCountryOfPublication());
					orderEntityObj.setImprintName(getMetaDataField(isbnFormatObj.getIsbn(), "imprintname"));
					orderEntityObj.setProductCategory(fileList.get(0).getProductCategory());
					orderEntityObj.setPublicationDate(fileList.get(0).getPublicationDate());

					orderList.add(orderEntityObj);
				} else {
					status.setCode("FAILURE_SAVE_DRM_MULT_FILES");
					status.setMessage(FAILURE_SAVE_DRM_MULT_FILES);
					status.setStatus(false);
					validFlg = false;
					break;
				}
			}

			if (validFlg) {
				DRMEntityNew entityObj = new DRMEntityNew();
				String id = masterDao.getNextSequenceId("drmOrderIdSeq");
				entityObj.setOrderId("ORDER".concat(id));
				entityObj.setDrmSource(modelObj.getDrmSource());
				entityObj.setOrderType(modelObj.getOrderType());
				entityObj.setClientId(loggedUser);
				entityObj.setOrderDate(new Timestamp(new Date().getTime()));
				if (modelObj.getPrintCopyPermission()) {
					entityObj.setDrmType(DRM_TYPE_PERPETUAL);
					entityObj.setDrmCutPaste(modelObj.getCopyPages());
					entityObj.setDrmPrint(modelObj.getPrintPages());
				} else {
					entityObj.setDrmType(DRM_TYPE_LIMITED);
					entityObj.setDrmLicense(modelObj.getNoOfDays());
				}
				//entityObj.setClientEmail(modelObj.getEmailIdList());
				

				
				List<ClientEmailEntity> clientEmailList = modelObj.getEmailIdList().stream().map(temp -> {
							ClientEmailEntity obj = new ClientEmailEntity();
							obj.setEmailId(temp);
							obj.setUuid(UUID.randomUUID().toString());
							return obj;
						}).collect(Collectors.toList());

				entityObj.setClientEmail(clientEmailList);
				
				
				entityObj.setOrder(orderList);
				entityObj.setDrmFlg(1);
				entityObj.setIsActive(Boolean.TRUE);
				entityObj.setIsDeleted(Boolean.FALSE);
				entityObj.setCreatedBy(loggedUser);
				entityObj.setCreatedOn(new Timestamp(new Date().getTime()));
				entityObj.setClientIP(modelObj.getClientIP());
				entityObj.setRequestId(requestId);
				result = masterDao.saveEntityObject(entityObj);

				if (result) {
					logger.info("Process Identifier [" + entityObj.getId() + "]");
					Map<String, String> orderIdMap = new HashMap<>();
					orderIdMap.put("orderId", entityObj.getId());

					finalData.put("data", orderIdMap);

					status.setCode("SUCCESS_SAVE_DRM");
					status.setMessage(SUCCESS_SAVE_DRM);
					status.setStatus(true);
				} else {
					status.setCode("FAILURE_SAVE_DRM");
					status.setMessage(FAILURE_SAVE_DRM);
					status.setStatus(false);
				}
			}
		} catch (Exception e) {
			logger.error("Exception in save :: ", e);
			status.setCode("FAILURE_SAVE_DRM");
			status.setMessage(FAILURE_SAVE_DRM);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}
		return finalData;
	}
	
	@Override
	public List<DRMDisplay> getDRM(String id) {
		boolean result = false;
		List<DRMDisplay> displayData = new ArrayList<DRMDisplay>();
		DRMEntityNew entityObj = null;
		try {

			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("id", id);
			criteriaMap.put("isActive", Boolean.TRUE);
			entityObj = masterDao.getEntityObject(new DRMEntityNew(), criteriaMap);
			
			if(entityObj==null)
			{
				criteriaMap.clear();
				criteriaMap.put("_id", id);
				criteriaMap.put("isActive", Boolean.TRUE);
				entityObj = masterDao.getEntityObject(new DRMEntityNew(), criteriaMap);
			}
			
			displayData = getPageDisplay(entityObj);

		} catch (Exception e) {
			logger.error("Exception in Get DRM :: ", e);

		}
		return displayData;
	}

	@Override
	public Map<String, Object> resend(DRM modelObj, String id, String loggedUser) {
		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		try {

			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("drmId", id);
			criteriaMap.put("isActive", Boolean.TRUE);

			DRMEntity entityObj = masterDao.getEntityObject(new DRMEntity(), criteriaMap);
			if (null == entityObj) {
				status.setCode("NO_SOURCE_RECORD_EXISTS");
				status.setMessage("NO_SOURCE_RECOR_EXISTS");
				status.setStatus(false);
			} else {

				ResendDRM resend = new ResendDRM();
				resend.setResendBy(loggedUser);
				resend.setResendOn(new Timestamp(new Date().getTime()));
				resend.setRemarks(modelObj.getRemarks());

				List<ResendDRM> resendList = new LinkedList<>();

				if (entityObj.getResend() != null)
					resendList = entityObj.getResend();

				resendList.add(resend);
				entityObj.setResend(resendList);
				entityObj.setDrmFlg(1);

				result = masterDao.updateEntityObject(entityObj);

				if (result) {
					status.setCode("SUCCESS_RESEND_DRM");
					status.setMessage(SUCCESS_RESEND_DRM);
					status.setStatus(true);
				} else {
					status.setCode("FAILURE_RESEND_DRM");
					status.setMessage(FAILURE_RESEND_DRM);
					status.setStatus(false);
				}
			}
		} catch (Exception e) {
			logger.error("Exception in resend :: ", e);
			status.setCode("FAILURE_RESEND_DRM");
			status.setMessage(FAILURE_RESEND_DRM);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}
		return finalData;
	}

	@SuppressWarnings("unchecked")
	//TODO Change value
	@Scheduled(fixedRate = 5000)
	public void createDRM() {
		// System.out.println("Inside createDRM");

		// List<String> createdDRMIdList = new ArrayList<>();
		// Map<String, String> createdDRMIdList = new HashMap<String, String>();

		try {
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("drmFlg", 1);
			criteriaMap.put("isActive", Boolean.TRUE);

			List<DRMEntityNew> entityObjList = (List<DRMEntityNew>) masterDao.getAllEntityObjects(new DRMEntityNew(),
					criteriaMap);
                        
            AwsAPIEntity apiEntity = null;
            if(null != entityObjList && entityObjList.size()>0)
                apiEntity = masterDao.getAwsCredentials();

			FTPUtil ftp = null;
			
			
			
			for (DRMEntityNew drmEntity : entityObjList) {
				ftp = new FTPUtil(ftpUrl, ftpUserName, ftpPassword, ftpPort);
				DRMEntityNew drmEntityToSave = new DRMEntityNew();
				drmEntityToSave = drmEntity;
				try {
					List<OrderEntity> lstorderEntitySave = new ArrayList<OrderEntity>();

					for (OrderEntity orderDetails : drmEntity.getOrder()) {
						OrderEntity orderEntitySave = new OrderEntity();
						orderEntitySave = orderDetails;

						if (orderDetails.getOrderFlg() == 0 & orderDetails.getAcsmLink() != null) {
							// orderEntitySave =orderDetails;
							lstorderEntitySave.add(orderEntitySave);
							continue;
						}

						// List<AcsmLink> lstAcsmLink = new
						// ArrayList<AcsmLink>();
						// for (ClientEmailEntity emailID :
						// drmEntity.getClientEmail())
						{

							// AcsmLink _acsmLink = new AcsmLink();

							String drmStatus = "";
							Boolean AssetMoved = true;
							int drmFlag = 0;
							Boolean alreadyPacked = false;

							SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
							String strDate = formatter.format(new Date());

							String strCreator = acsmClientName + "-" + orderDetails.getIsbn() + "-" + strDate;

							/*List<FileDetailEntity> drmRequestedFiles = masterDao
									.getFileDetailsByFormatId(orderDetails.getFormatId(), orderDetails.getIsbn());*/
							
							String formatId = orderDetails.getFormatId();

							Object[] queryParams = new Object[3];
							queryParams[0] = orderDetails.getIsbn();
							queryParams[1] = formatId;
							queryParams[2] = formatId;

							System.out.println("queryParams[0] " + queryParams[0] + "queryParams[1] : "
									+ queryParams[1] + " queryParams[2] :" + queryParams[2]);
							List<AssetFileEntity> drmRequestedFiles = (List<AssetFileEntity>) masterDao
									.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(),
											queryParams);

							if (drmRequestedFiles.size() == 1) {

								// check if the file has already been packaged -
								// if
								// not then only package

								criteriaMap.clear();
								criteriaMap.put("drmFlg", 0);
								criteriaMap.put("isActive", Boolean.TRUE);
								criteriaMap.put("order.isbn", orderDetails.getIsbn());
								criteriaMap.put("order.formatId", orderDetails.getFormatId());
								criteriaMap.put("order.fileId", Integer.valueOf(orderDetails.getFileId()));

								//if (drmEntity.getDrmType().equalsIgnoreCase("perpetual")) {
								if(drmEntity.getDrmLicense()!=null)
									criteriaMap.put("drmLicense", Integer.valueOf(drmEntity.getDrmLicense()));
								
								if(drmEntity.getDrmCutPaste()!=null)
										criteriaMap.put("drmCutPaste", Integer.valueOf(drmEntity.getDrmCutPaste()));
								if(drmEntity.getDrmPrint()!=null)
										criteriaMap.put("drmPrint", Integer.valueOf(drmEntity.getDrmPrint()));
								
								criteriaMap.put("drmRequestStatus", "SUCCESS");

								List<DRMEntityNew> drmEntityObjList = (List<DRMEntityNew>) masterDao
										.getAllEntityObjects(new DRMEntityNew(), criteriaMap);
								if (drmEntityObjList != null && drmEntityObjList.size() > 0) {
									for (OrderEntity oe : drmEntityObjList.get(drmEntityObjList.size() - 1)
											.getOrder()) {
										if (oe.getFileId().equals(Integer.valueOf(orderDetails.getFileId()))
												&& oe.getDrmRequestStatus().equalsIgnoreCase("SUCCESS")) {
											strCreator = oe.getCreator();
											alreadyPacked = true;
											break;
										}
									}
									// strCreator =
									// drmEntityObjList.get(0).getCreator();

								}
								orderDetails.setCreator(strCreator);
								System.out.println("ID : " + drmEntity.getId());

								String isbnBaseXml = "";

								if (!alreadyPacked) {
									isbnBaseXml = packageIsbnWithBasePermission(drmEntity, orderDetails, true,
											drmRequestedFiles.get(0).getFileName());
									InputStream in = null;
									try {
										
										
										in = downloadFileAsStream(apiEntity.getBucketName(),
												drmRequestedFiles.get(0).getObjectkey());

										ftp.uploadFile(in, drmRequestedFiles.get(0).getFileName(),
												acsmClientName
												+ File.separator + environment + File.separator + "Acsm-" +
												// orderDetails.getDrmId()+"-"+emailID.getUuid()
														orderDetails.getDrmId());

										/*
										 * ftp.uploadFile(in, drmRequestedFiles.get(0).getFileName( ), acsmClientName +
										 * File.separator + "Acsm-" + drmEntity.getId());
										 */
										String filename = drmRequestedFiles.get(0).getFileName();

										filename = filename.replace(filename.substring(filename.lastIndexOf(".")),
												".xml");

										ftp.uploadFile(IOUtils.toInputStream(isbnBaseXml, "UTF-8"), filename,
												acsmClientName
												+ File.separator + environment + File.separator + "Acsm-" + orderDetails.getDrmId());

										String isbnRightsXml = packageIsbnWithBasePermission(drmEntity, orderDetails,
												false, drmRequestedFiles.get(0).getFileName());// drmEntity.getIsbn(),

										ftp.uploadFile(IOUtils.toInputStream(isbnRightsXml, "UTF-8"),
												"Acsm-" + orderDetails.getDrmId() + "-DRM.xml",
												acsmClientName
												+ File.separator + environment + File.separator + "Acsm-Rights");
									} catch (Exception e) {
										e.printStackTrace();
										AssetMoved = false;
									} finally {
										in.close();
									}

								}
								if (AssetMoved) {

									ftp.uploadFile(
											IOUtils.toInputStream(
													acsmOperations(drmEntity, orderDetails, strCreator, alreadyPacked),
													"UTF-8"),
											"Acsm-" + orderDetails.getDrmId() + "-ACSM.xml",
											acsmClientName
											+ File.separator + environment + File.separator + "Acsm-Operation");
									// ftp.disconnect();

									String WebServiceFile = serviceUrl
											+ baseFTPPath + File.separator + acsmClientName
											+ File.separator + environment + File.separator
											+ "Acsm-Operation" + File.separator + "Acsm-" + orderDetails.getDrmId()
											+ "-ACSM.xml";

									System.out.println("WebService URL" + WebServiceFile);
									String out = executePost(WebServiceFile);
									out = HtmlUtils.htmlUnescape(out);
									String fulFilment = "";
									String acsmTransIdPattern = "<transaction>(.+?)</transaction>";

									String pattern = "(\\<fulfillmentToken[\\s\\S]*<\\/fulfillmentToken\\>)";

									// Create a Pattern object
									Pattern r = Pattern.compile(pattern);

									// Now create matcher object.
									Matcher m = r.matcher(out);
									if (m.find()) {
										System.out.println("Found value: " + m.group());
										fulFilment = m.group();
										
										Pattern transPattern = Pattern.compile(acsmTransIdPattern, Pattern.DOTALL);
										Matcher transMatcher = transPattern.matcher(fulFilment);
										
										if(transMatcher.find()) {
											logger.info("Found transactionId : "+transMatcher.group(1));
											String acsmTransactionId  = transMatcher.group(1);
											orderEntitySave.setAcsmTransactionId(acsmTransactionId);
										}
										
										if(!ftp.downloadFile(acsmClientName
												+ File.separator + environment + File.separator + "Acsm-Operation"
												+ File.separator 
												+"Acsm-" +orderDetails.getDrmId() + "-ACSM.acsm"

												, tempDir + File.separator + "Acsm-"
												+ orderDetails.getDrmId().replaceAll("DRM", "") + "-"
												+ drmEntity.getId() + ".acsm"))
											Files.write(Paths.get(tempDir + File.separator + "Acsm-"
													+ orderDetails.getDrmId().replaceAll("DRM", "") + "-"
													+ drmEntity.getId() + ".acsm"), fulFilment.getBytes());
				
										
										/*Files.write(Paths.get(tempDir + File.separator + "Acsm-"
												+ orderDetails.getDrmId().replaceAll("DRM", "") + "-"
												+ drmEntity.getId() + ".acsm"), fulFilment.getBytes());
										*/
										AcsmLink _acsmLink = new AcsmLink();
										_acsmLink.setLink("Acsm-" + orderDetails.getDrmId().replaceAll("DRM", "") + "-"
												+ drmEntity.getId() + ".acsm");
										orderEntitySave.setAcsmLink(_acsmLink);
										/*
										 * } else { System.out.println("NO MATCH"); }
										 * 
										 * // Share the .acsm file link to the // clientEmailID // need to implement
										 * mail if (!out.toLowerCase().contains( "<output>fail</output>")) //
										 * if("1".equalsIgnoreCase("1")) {
										 */

										drmStatus = "MAIL_PENDING";
										drmFlag = 0;
										/*
										 * if (sendDrmMail(drmEntity)) { drmStatus = "SUCCESS"; drmFlag = 0; } else {
										 * drmStatus = "ERROR:DRM_MAIL_FAIL"; drmFlag = 8; }
										 */

									} else {
										drmStatus = "ERROR:DRM_FAIL";
										drmFlag = 9;
									}
								} else {
									drmStatus = "ERROR:ASSET_MISSING";
									drmFlag = 9;
								}

							} else {
								drmStatus = "ERROR:NO_OF_FILES";
								drmFlag = 9;

							}
							/*
							 * _acsmLink.setDrmRequestStatus(drmStatus); _acsmLink.setOrderFlg(drmFlag);
							 * lstAcsmLink.add(_acsmLink);
							 */
							orderEntitySave.setOrderFlg(drmFlag);
							orderEntitySave.setDrmRequestStatus(drmStatus);
						}

						// orderEntitySave.add(orderDetails);
						lstorderEntitySave.add(orderEntitySave);
					}
					drmEntityToSave.setOrder(lstorderEntitySave);

					drmEntityToSave = sendDrmMailNew(drmEntityToSave);
					// save drmEntity
					drmEntityToSave.setDrmFlg(0);
					drmEntityToSave.setOrderRequestStatus("Completed");
					masterDao.updateEntityObject(drmEntityToSave);

				}

				catch (Exception e) {
					e.printStackTrace();
					
					drmEntityToSave.setDrmFlg(9);
					drmEntityToSave.setOrderRequestStatus("ERROR:" + e.getMessage());
					
					drmEntityToSave.getOrder().forEach(ord -> {
						ord.setOrderFlg(9);
						ord.setDrmRequestStatus("ERROR:" + e.getMessage());
					});
					
					
					masterDao.updateEntityObject(drmEntityToSave);
				}
			}
			if (ftp != null)
				ftp.disconnect();
		} catch (Exception e) {
			logger.error("Exception in DRM Schedular :: ", e);
		}
	}

	
	
	public String getCover(String ISBN){

		Object[] queryParams = new Object[3];
		queryParams[0] = ISBN;
		queryParams[1] = coverFormatID;
		queryParams[2] = coverFormatID;

		System.out.println("queryParams[0] " + queryParams[0] + "queryParams[1] : "
				+ queryParams[1] + " queryParams[2] :" + queryParams[2]);
		List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
				.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(),
						queryParams);
		logger.info("No. of Files ["+fileList.size()+"]");

		if (fileList.size() == 1) {
			AwsAPIEntity apiEntity = masterDao.getAwsCredentials();
			InputStream in = downloadFileAsStream(apiEntity.getBucketName(),
					fileList.get(0).getObjectkey());
			
			String fileType=fileList.get(0).getExtension();
			
			try {

		        BufferedImage sourceImage = ImageIO.read(in);
		        int width = sourceImage.getWidth();
		        int height = sourceImage.getHeight();
 
		        {
		            float extraSize=    width-100;
		            float percentWidth = (extraSize/width)*100;
		            float  percentHight = height - ((height/100)*percentWidth);
		            BufferedImage img = new BufferedImage(100, (int)percentHight, BufferedImage.TYPE_INT_RGB);
		            Image scaledImage = sourceImage.getScaledInstance(Integer.valueOf((int) (width*0.10)),Integer.valueOf((int)(height*0.10)), Image.SCALE_SMOOTH);
		            img.createGraphics().drawImage(scaledImage, 0, 0, null);
	 
		            return "";

		        }

		    } catch (IOException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		        return "NO_COVER";
		    }
			
		}
		else
		{
			return "NO_COVER";
		}
	}
	
 
 	
	public List<DRMDisplay> getPageDisplay(DRMEntityNew drmEntity)
			throws IllegalArgumentException, IllegalAccessException {

		RestTemplate restTemplate = new RestTemplate();

		List<DRMDisplay> pageDatas = new ArrayList<DRMDisplay>();

		for (OrderEntity order : drmEntity.getOrder()) {
			
				//if(0 == order.getOrderFlg()) 
				{
	
				/*
				 * String strSearchTitle = MANAGE_SEARCH_SERVICE_URL + "getMetaDataField/" +
				 * order.getIsbn() + "/Title"; Map<String, Object> searchData = new
				 * HashMap<String, Object>(); searchData.put("responseType",
				 * "application/json;charset=UTF-8"); String title = ""; try {
				 * APIResponse<String> searchResponse =
				 * restTemplate.getForObject(strSearchTitle, APIResponse.class); title =
				 * searchResponse.getData(); // mapTitle.put(order.getIsbn(), title); } catch
				 * (Exception e) { /// title = ""; e.printStackTrace(); }
				 */
				
				String title = getMetaDataField(order.getIsbn(), "Title");
				
				LinkedHashMap<String, Object> criteriaMap = new LinkedHashMap<>();
				criteriaMap.put("formatId", order.getFormatId());
				criteriaMap.put("isActive", Boolean.TRUE);
				List<KeyValue> mappedValues = masterDao.getKeyValueList("mFormat", "formatName", null, criteriaMap, null);
				String formatName = "";
				if (mappedValues.size() > 0) {
					formatName = mappedValues.get(0).getKey();
					// mapFormat.put(order.getFormatId(), formatName);
	
				}
				pageDatas.add(new DRMDisplay(order.getIsbn(), title, formatName,
						order.getAcsmLink() == null ? "#" : order.getAcsmLink().getLink()));
		    }
		}

		return pageDatas;
	}

	public DRMEntityNew sendDrmMailNew(DRMEntityNew drmEntity) throws IllegalArgumentException, IllegalAccessException {

		RestTemplate restTemplate = new RestTemplate();
		/*
		 * Map<String,String> mapTitle = new HashMap<>(); Map<String,String> mapFormat =
		 * new HashMap<>();
		 */
		DRMEntityNew drmEntityToSave = new DRMEntityNew();
		drmEntityToSave = drmEntity;
		List<OrderEntity> lstorderEntitySave = new ArrayList<OrderEntity>();
		// for(ClientEmailEntity client : drmEntity.getClientEmail())
		List<MailTitleDetails> mailDetailsLst = new ArrayList<MailTitleDetails>();
		List<OrderEntity> AcsmOrders = new ArrayList<OrderEntity>();
		for (OrderEntity order : drmEntity.getOrder()) {
			if (order.getOrderFlg().toString().equalsIgnoreCase("9")) {
				lstorderEntitySave.add(order);
				continue;
			}
			AcsmOrders.add(order);
			/*
			 * String strSearchTitle = MANAGE_SEARCH_SERVICE_URL + "getMetaDataField/" +
			 * order.getIsbn() + "/Title"; Map<String, Object> searchData = new
			 * HashMap<String, Object>(); searchData.put("responseType",
			 * "application/json;charset=UTF-8"); String title = ""; try {
			 * APIResponse<String> searchResponse =
			 * restTemplate.getForObject(strSearchTitle, APIResponse.class); title =
			 * searchResponse.getData(); // mapTitle.put(order.getIsbn(), title); } catch
			 * (Exception e) { /// title = ""; e.printStackTrace(); }
			 */
			
			String title = getMetaDataField(order.getIsbn(), "Title");
			
			LinkedHashMap<String, Object> criteriaMap = new LinkedHashMap<>();
			criteriaMap.put("formatId", order.getFormatId());
			criteriaMap.put("isActive", Boolean.TRUE);
			List<KeyValue> mappedValues = masterDao.getKeyValueList("mFormat", "formatName", null, criteriaMap, null);
			String formatName = "";
			if (mappedValues.size() > 0) {
				formatName = mappedValues.get(0).getKey();
				// mapFormat.put(order.getFormatId(), formatName);

			}
			mailDetailsLst.add(new MailTitleDetails( title, formatName));
		}
		
			
		// lstorderEntitySave
		// for(ClientEmailEntity client : drmEntity.getClientEmail())
		String emails = drmEntity.getClientEmail().stream().map(email -> email.getEmailId()).distinct()
				.collect(Collectors.joining(","));
		
		LinkedHashMap<String, Object> contentCriteriaMap = new LinkedHashMap<>();
		/*if(drmEntity.getDrmSource()!=null)
		{
			contentCriteriaMap.put("client", drmEntity.getDrmSource());
			contentCriteriaMap.put("isActive", Boolean.TRUE);
			contentCriteriaMap.put("type", "DRM");
		}*/
		
		contentCriteriaMap.put("client", drmEntity.getDrmSource());
		contentCriteriaMap.put("isActive", Boolean.TRUE);
		contentCriteriaMap.put("type", "DRM");
		
		MDrmContentEntity mDrmContent = masterDao.getEntityObject(new MDrmContentEntity(), contentCriteriaMap);
		if(mDrmContent==null)
		{
			contentCriteriaMap.put("client", "others");
			contentCriteriaMap.put("isActive", Boolean.TRUE);
			contentCriteriaMap.put("type", "DRM");
		}
		mDrmContent = masterDao.getEntityObject(new MDrmContentEntity(), contentCriteriaMap);
		if (mailDetailsLst.size() > 0) {

			MailDetails mailDetails = new MailDetails();
			Map<String, Object> templateData = new HashMap<String, Object>();
			mailDetails.setEmail_from("donotreply@codemantra.com");
			mailDetails.setTo_email(emails);
			mailDetails.setSubject(mDrmContent.getSubject());
			mailDetails.setCreatedBy(drmEntity.getCreatedBy());
			templateData.put("beforeContent", mDrmContent.getBeforeContent()==null?"":mDrmContent.getBeforeContent().replaceAll("#link", MANAGE_DRM_URL + drmEntity.getId()));
			templateData.put("afterContent", mDrmContent.getAfterContent()==null?"":mDrmContent.getAfterContent().replaceAll("#link", MANAGE_DRM_URL + drmEntity.getId()));
			PojoToHTML mailDetailsTbl = new PojoToHTML(mailDetailsLst, false, false, true);
			templateData.put("content", mailDetailsTbl.build());
/*			templateData.put("to", drmEntity.getClientName() == null ? "User" : drmEntity.getClientName());
			templateData.put("downloadLink", MANAGE_DRM_URL + drmEntity.getId());
			templateData.put("from", "Manage Support Team");

			PojoToHTML mailDetailsTbl = new PojoToHTML(mailDetailsLst, true, true, false);
			templateData.put("details", mailDetailsTbl.build());
			templateData.put("client", client);

			templateData.put("supportMail", supportMail);
			templateData.put("type", drmEntity.getOrderType() == null ? "BUY" : drmEntity.getOrderType());
*/
			mailDetails.setTemplateData(templateData);
			mailDetails.setTemplateName("drm.ftl");
			APIResponse response = restTemplate.postForObject(MANAGE_EMAIL_SERVICE_URL, mailDetails, APIResponse.class);

			logger.debug(" Mail API Response Code:" + response.getCode());
			logger.debug(" Mail API Response Message:" + response.getStatusMessage());

			if (ResponseCode.SUCCESS.toString().equals(response.getCode().toString())) {
				{
					for (OrderEntity oe : AcsmOrders) {
						oe.setDrmRequestStatus("SUCCESS");
						oe.setOrderFlg(0);
						lstorderEntitySave.add(oe);
					}
				}
			} else
				for (OrderEntity oe : AcsmOrders) {
					oe.setDrmRequestStatus("ERROR:DRM_MAIL_FAIL");
					oe.setOrderFlg(9);
					lstorderEntitySave.add(oe);
				}
		}
		return drmEntityToSave;
	}

	public String packageIsbnWithBasePermission(DRMEntityNew drmEntity, OrderEntity orderDetails,
			boolean IsBasePermssion, String strFileNmae) {

		String isbnBaseXml = new String(IsBasePermssion ? baseXml : rightsXml);
		String formatName = null;

		logger.info(
				"Format id for DRM Packaging [" + orderDetails.getFormatId() + " on Order :" + orderDetails.getDrmId());

		String isbn = orderDetails.getIsbn();
		String formatId = orderDetails.getFormatId();
		String acsmIdentifier = "Acsm-" + orderDetails.getDrmId();
		
		try {
			LinkedHashMap<String, Object> criteriaMap = new LinkedHashMap<>();
			criteriaMap.put("formatId", formatId);
			criteriaMap.put("isActive", Boolean.TRUE);
			List<KeyValue> mappedValues = masterDao.getKeyValueList("mFormat", "formatName", null, criteriaMap, null);
			
			if (mappedValues.size() > 0)
				formatName = mappedValues.get(0).getKey();

			logger.info("Format Name for DRM Packaging [" + formatName + "]");

			Map<String, String> data = new HashMap<String, String>();
			if (IsBasePermssion) {
				data.put("fmt", getFormatType(formatName));
				data.put("path", baseFTPPath + File.separator + acsmClientName
						+ File.separator + environment + File.separator + acsmIdentifier
						+ File.separator + strFileNmae);
			} else {
				
				if(drmEntity.getDrmLicense() != null && !drmEntity.getDrmLicense().toString().equalsIgnoreCase(""))
					data.put("read","<duration>"+String
						.valueOf(((drmEntity.getDrmLicense() == null ? 0 : drmEntity.getDrmLicense()) * 24 * 60 * 60))	+"</duration>");
				else
					data.put("read", "<duration/>");
				
				data.put("print", String.valueOf(drmEntity.getDrmPrint() == null ? 0 : drmEntity.getDrmPrint()));
				data.put("copy", String.valueOf(drmEntity.getDrmCutPaste() == null ? 0 : drmEntity.getDrmCutPaste()));
			}

			isbnBaseXml = StrSubstitutor.replace(isbnBaseXml, data, "@{", "}");

		} catch (Exception e) {
			logger.error(e.getMessage());
			System.out.println(e);
			isbnBaseXml = "";
			// TODO: handle exception
		}
		return isbnBaseXml.toString();

	}

	public String getFormatType(String formatName) {
		if (formatName.toLowerCase().contains("pdf")) {
			return pdfFormat;
		} else
			return ePub;
	}

	public String acsmOperations(DRMEntityNew drmEntity, OrderEntity orderDetails, String strCreator,
			Boolean AlreadyPacked) {
		StringBuilder acsmOperations = new StringBuilder();

		Map<String, String> packageData = new HashMap<String, String>();

		packageData.put("path",
				baseFTPPath + File.separator + acsmClientName
				+ File.separator + environment + File.separator + "Acsm-" + orderDetails.getDrmId());
		packageData.put("creator", strCreator);
		packageData.put("client", acsmClientName);
		packageData.put("drmtype", drmEntity.getOrderType());
		packageData.put("key", acsmKey);
		packageData.put("rightsPath", baseFTPPath + File.separator + acsmClientName
				+ File.separator + environment + File.separator + "Acsm-Rights"
				+ File.separator + "Acsm-" + orderDetails.getDrmId() + "-DRM.xml");

		if (!AlreadyPacked) {
			acsmOperations.append(StrSubstitutor.replace(acs4OperationPackage, packageData, "@{", "}"));

			acsmOperations.append(StrSubstitutor.replace(acs4OperationRights, packageData, "@{", "}"));
		}

		acsmOperations.append(StrSubstitutor.replace(acs4OperationACSM, packageData, "@{", "}"));

		Map<String, String> acsmData = new HashMap<String, String>();
		acsmData.put("operations", acsmOperations.toString());
		return StrSubstitutor.replace(acsmPackage, acsmData, "@{", "}");

	}

/*	@Override
	public InputStream downloadFileAsStream(String bucketName, String objectKey) {
		BasicAWSCredentials awsCreds = null;
		AwsAPIEntity apiEntity = masterDao.getAwsCredentials();
		awsCreds = new BasicAWSCredentials(apiEntity.getAccessKey(), apiEntity.getSecretKey());
		AmazonS3 s3Client = new AmazonS3Client(awsCreds);
		try {
			GetObjectRequest s3ObjectReq = new GetObjectRequest(bucketName, objectKey);
			logger.info("Downloading file having key = " + objectKey);
			long startTime = System.currentTimeMillis();
			S3Object downlodedObjectMD = s3Client.getObject(s3ObjectReq);

			logger.info("Time to load Stream is " + (System.currentTimeMillis() - startTime) + " ms");
			return downlodedObjectMD.getObjectContent();

		} catch (Exception e) {
			logger.error("EXCEPTION = " + e.getMessage(), e);
			throw e;
		}
		//return null;
	}*/
	
	@Override
	public InputStream downloadFileAsStream(String bucketName, String objectKey) {
		BasicAWSCredentials awsCreds = null;
		AwsAPIEntity apiEntity = masterDao.getAwsCredentials();
		awsCreds = new BasicAWSCredentials(apiEntity.getAccessKey(), apiEntity.getSecretKey());
		AmazonS3 s3Client = new AmazonS3Client(awsCreds);
		S3Object downlodedObjectMD = null;
		InputStream is = null;
		InputStream is2 = null;
		try {
			//GetObjectRequest s3ObjectReq = new GetObjectRequest(bucketName, objectKey);
			
			GetObjectRequest s3ObjectReq = null;
			
			if(objectKey.contains("@@@")) {				
				String[] key = objectKey.split("@@@");
				s3ObjectReq = new GetObjectRequest(bucketName, key[0],key[1]);
			}
			else
				s3ObjectReq = new GetObjectRequest(bucketName, objectKey);			
			
			logger.info("Downloading file having key = " + objectKey);
			long startTime = System.currentTimeMillis();
			downlodedObjectMD = s3Client.getObject(s3ObjectReq);

			logger.info("Time to load Stream is " + (System.currentTimeMillis() - startTime) + " ms");
			is = downlodedObjectMD.getObjectContent();
			
			is2 = IOUtils.toBufferedInputStream(is);
			
			

		} catch (AmazonServiceException e) {
			logger.error(e.getMessage(), e);
		} catch (AmazonClientException e) {
			logger.error(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("EXCEPTION = " + e.getMessage(), e);
		}finally {
			if(downlodedObjectMD != null) {
				try {
					downlodedObjectMD.close();
				}catch (IOException e) {
					logger.error("Unable to close S3 object: {}", e.getMessage(), e);
				}
			}
			
			if(is != null) {
				try {
					is.close();
				}catch(IOException e) {
					logger.error("Unable to close downloaded s3Object stream :: ", e.getMessage(), e);
				}
			}
		}
		
		return is2;
		//return null;
	}

	public String executePost(String targetURL) {
		StringBuilder output = new StringBuilder();
		try {
			URL yahoo = new URL(targetURL);
			URLConnection yc = yahoo.openConnection();

			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine;

			while ((inputLine = in.readLine()) != null) {
				output.append(inputLine);
				System.out.println(inputLine);
			}
			in.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return output.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> retrieveAllDRMRecords() {
		List<DRMEntity> drmRecords = new LinkedList<DRMEntity>();

		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		try {

			// TODO Same Method should handle the requests for Pending and Completed DRM
			// Requests

			drmRecords = (List<DRMEntity>) masterDao.getAllEntityObjects(new DRMEntity());

			status.setCode("SUCCESS_RETRIEVE_DRM_LIST");
			status.setMessage(SUCCESS_RETRIEVE_DRM_LIST);
			status.setStatus(true);
		} catch (Exception e) {
			logger.error("Exception in retrieveAll :: ", e);
			status.setCode("FAILURE_RETRIEVE_DRM_LIST");
			status.setMessage(FAILURE_RETRIEVE_DRM_LIST);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", drmRecords);
		}
		return finalData;
	}
	
/*	public String getProductFilesQuery() {
		StringBuilder query = new StringBuilder();
		
		query.append(" 		");
		
		query.append("{ 'aggregate' : 'products',  'pipeline' : [ "); 
		query.append("    {$match: { $and : [{'Product.RecordReference':#} "); 
		query.append("    ,{ asset : { "); 
		query.append("                $elemMatch :{$and : [ "); 
		query.append("                 {'formatId': #} ");
		//query.append("                 ,{'formatStatus':'Approve'} ");		
		query.append("                ]} "); 
		query.append("         }}] "); 
		query.append("      } "); 
		query.append("    }, "); 
		query.append("    {$project: { "); 
		query.append("        asset: {$filter: { "); 
		query.append("          input: '$asset', "); 
		query.append("          as: 'asset', "); 
		query.append("          cond: {$eq: ['$$asset.formatId', #]} "); 
		query.append("        }}, "); 
		query.append("        _id: 0,'Product':1 "); 
		query.append("      } "); 
		query.append("    }, "); 
		query.append("    {$project : { "); 
		query.append("        'Product.RecordReference'  :1 , "); 
		query.append("        'asset.assetId' : 1, "); 
		query.append("        'asset.formatId' : 1, "); 
		query.append("        'asset.bucket' : 1, "); 
		query.append("        'asset.folder' : 1, "); 
		query.append("        'asset.formatStatus' : 1, "); 
		query.append("        'asset.filedetails.fileId' : 1,  "); 
		query.append("        'asset.filedetails.filename' :1, "); 
		query.append("        'asset.filedetails.type' :1, "); 
		query.append("        'asset.filedetails.extension' :1, "); 
		query.append("        'asset.filedetails.version':1, "); 
		query.append("        'asset.filedetails.versionId':1, "); 
		query.append("        'asset.filedetails.objectkey' : 1 "); 
		query.append("      } "); 
		query.append("    }, "); 
		query.append("    {$unwind : '$asset'}, "); 
		query.append("    {$unwind : '$asset.filedetails'}, "); 
		query.append("    {$group:{  "); 
		query.append("        '_id': '$asset.filedetails.filename', "); 
		query.append("        'maxVersion': { '$max': '$asset.filedetails.version' }, "); 
		query.append("        'files': { '$push': { "); 
		query.append("            'isbn' : '$Product.RecordReference', "); 
		query.append("            'assetId' : '$asset.assetId', "); 
		query.append("            'formatId' : '$asset.formatId', "); 
		query.append("            'bucket' : '$asset.bucket', "); 
		query.append("            'folder' : '$asset.folder', "); 
		query.append("            'formatStatus' : '$asset.formatStatus', "); 
		query.append("            'fileId': '$asset.filedetails.fileId', "); 
		query.append("            'fileName': '$asset.filedetails.filename', "); 
		query.append("            'type' :'$asset.filedetails.type', "); 
		query.append("            'extension' :'$asset.filedetails.extension', "); 
		query.append("            'version': '$asset.filedetails.version', "); 
		query.append("            'versionId': '$asset.filedetails.versionId', "); 
		query.append("            'objectkey' : '$asset.filedetails.objectkey' "); 
		query.append("          } "); 
		query.append("        } "); 
		query.append("      } "); 
		query.append("    }, "); 
		query.append("    { '$project': {         "); 
		query.append("        '_id' : 0, "); 
		query.append("      'files': { "); 
		query.append("          '$setDifference': [ "); 
		query.append("             { '$map': { "); 
		query.append("                 'input': '$files', "); 
		query.append("                 'as': 'file', "); 
		query.append("                 'in': { "); 
		query.append("                     '$cond': [  "); 
		query.append("                         { '$eq': [ '$maxVersion', '$$file.version' ] }, "); 
		query.append("                         '$$file', "); 
		query.append("                         false "); 
		query.append("                     ] "); 
		query.append("                 } "); 
		query.append("             }}, "); 
		query.append("             [false] "); 
		query.append("          ] "); 
		query.append("        } "); 
		query.append("      } "); 
		query.append("    },         "); 		
		query.append("    {$unwind : '$files'}, ");
		query.append("    {$project : { ");
		query.append("        'isbn' : '$files.isbn', ");
		query.append("        'assetId' : '$files.assetId', ");
		query.append("        'formatId' : '$files.formatId', ");
		query.append("        'bucket' : '$files.bucket', ");
		query.append("        'folder' : '$files.folder', ");
		query.append("        'formatStatus' : '$files.formatStatus', ");
		query.append("        'fileId' : '$files.fileId', ");
		query.append("        'fileName' : '$files.fileName', ");
		query.append("        'type' : '$files.type', ");
		query.append("        'extension' : '$files.extension', ");
		query.append("        'version' : '$files.version', ");
		query.append("        'versionId' : '$files.versionId', ");
		query.append("        'objectkey' : '$files.objectkey' ");
		query.append("        } ");
		query.append("     }  ");
		query.append("  ] "); 
		query.append(" } ");
		
		return query.toString();
	}
*/	
	
	public String getProductFilesQuery() {

		HashMap<String, Object> manageConfigCriteriaMap = new LinkedHashMap<>();
	    manageConfigCriteriaMap.put("_id", "drm");

	    List<KeyValue> mappedValues = new ArrayList<>();    

		mappedValues = masterDao.getKeyValueList("manageConfig", null, "config.latestVersionAssetQuery", manageConfigCriteriaMap, null);
		
		return String.valueOf(mappedValues.get(0).getValue());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getEligibleFormats(String loggedUser) {
		List<String> eligibleFormats = new LinkedList<String>();
		List<String> eligibleFormatNames = new LinkedList<>();

		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		try {

			HashMap<String, Object> manageConfigCriteriaMap = new LinkedHashMap<>();
		    manageConfigCriteriaMap.put("_id", "drm");
		    List<KeyValue> mappedValues = new ArrayList<>();
		    
			mappedValues = masterDao.getKeyValueList("manageConfig", null, "config.eligibleFormats",
					manageConfigCriteriaMap, null);
			
			if(mappedValues.size()>0) {	
				eligibleFormats = (List<String>) ( mappedValues.get(0).getValue());
				
				HashMap<String, Object> criteriaMap = new LinkedHashMap<>();
				criteriaMap.put("formatId", eligibleFormats);
				
				eligibleFormatNames = (List<String>) masterDao.getDistinctFieldValues("mFormat", criteriaMap,
						"formatName");
			}
			
			mappedValues = masterDao.getKeyValueList("manageConfig", null, "config.orderType",
					manageConfigCriteriaMap, null);
			
			if(mappedValues.size() > 0) {
				finalData.put("orderTypes", mappedValues.get(0).getValue());
			}else {
				finalData.put("orderTypes", new ArrayList<>());
			}

			status.setCode("SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST");
			status.setMessage(SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST);
			status.setStatus(true);	
		} catch (Exception e) {
			logger.error("Exception in retrieveAll :: ", e);
			status.setCode("SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST");
			status.setMessage(SUCCESS_RETRIEVE_ELIGIBLE_FORMAT_LIST);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("eligibleFormats", eligibleFormats);
			finalData.put("eligibleFormatNames", eligibleFormatNames);
		}
		return finalData;
	}
	
/*	public boolean validInputData(DRMNew modelObj) {

		String[] isbnList = modelObj.getIsbn().split(",");
		String[] formatList = modelObj.getDeviceFormat().split(",");
		String[] emailList = modelObj.getClientEmail().split(",");

		if (isbnList.length > 0 && formatList.length > 0 && emailList.length > 0 && modelObj.getDevice() != null
				&& modelObj.getDrmType() != null && modelObj.getOrderDate() != null && modelObj.getClientName() != null
				&& modelObj.getClientId() != null && modelObj.getOrderId() != null && modelObj.getDrmSource() != null) {
			if ("perpetual".equalsIgnoreCase(modelObj.getDrmType())) {
				if (modelObj.getDrmCutPaste() != null && modelObj.getDrmPrint() != null)
					return true;
				else
					return false;

			} else {
				if (modelObj.getDrmLicense() != null)
					return true;
				else
					return false;
			}
		} else
			return false;
	}
*/
	
	public boolean validInputData(DRMNew modelObj) {
		
		if(isNull(modelObj.getIsbn()) || isNull(modelObj.getDeviceFormat()) || isNull(modelObj.getClientEmail()))
			return false;

		String[] isbnList = modelObj.getIsbn().split(",");
		String[] formatList = modelObj.getDeviceFormat().split(",");
		String[] emailList = modelObj.getClientEmail().split(",");

		if (isbnList.length > 0 && formatList.length > 0 && emailList.length > 0 && !isNull(modelObj.getDevice())
				&&  !isNull(modelObj.getDrmType()) && !isNull(modelObj.getOrderDate()) && !isNull(modelObj.getClientName())
				&& !isNull(modelObj.getClientId()) && !isNull(modelObj.getOrderId()) && !isNull(modelObj.getDrmSource())) {
			if ("perpetual".equalsIgnoreCase(modelObj.getDrmType())) {
				if (!isNull(modelObj.getDrmCutPaste()) && !isNull(modelObj.getDrmPrint()))
					return true;
				else
					return false;

			} else if ("limited".equalsIgnoreCase(modelObj.getDrmType())) {
				if (!isNull(modelObj.getDrmLicense()) && modelObj.getDrmLicense() > 0)
					return true;
				else
					return false;
			} else
				return false;
		} else
			return false;
	}
	
	public <T> boolean  isNull(T obj){
		
		if(obj instanceof Collection<?>)
			return (obj == null || ((Collection<?>) obj).isEmpty());
		else if(obj instanceof String)
			return (obj == null || ((String) obj).trim().isEmpty());
		else
			return obj == null;
		
	}
	
	public boolean validDate(String inputDate) {
		
		if(inputDate == null){
			logger.info("Invalid Order Date");
			return false;
		}
		
		try {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			df.setLenient(false);
			df.parse(inputDate);
			
			/** Validation removed for for different timezone issue **/
			/*if (df.parse(inputDate).after(new Date())) {
				logger.info("Order Date is greater than current Date");
				return false;
			} else
				return true;*/

		} catch (Exception e) {
			logger.info("Invalid Order Date");
			return false;
		}
		
		return true;
	}
	
	
	
				/** Water Mark 	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> saveWaterMark(Watermark modelObj, String loggedUser) {

		logger.info("Inside new Save Watermark...");
		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		boolean validFlg = true;
		LinkedHashMap<String, Object> criteriaMap = new LinkedHashMap<>();
		boolean dataValidFlg = false;
		try {
			
			modelObj.setRequestDate(new Timestamp(new Date().getTime()));
			masterDao.saveEntityObject(modelObj);
			
			String requestId = modelObj.getRequestId();

			String[] isbnArray = modelObj.getIsbn().split("\\s*,\\s*");
			String[] formatArray = modelObj.getDeviceFormat().split("\\s*,\\s*");
			String[] emailArray = modelObj.getClientEmail().split("\\s*,\\s*");
			
			if(null == modelObj.getOrderType() || "".equals(modelObj.getOrderType()))
                modelObj.setOrderType("PAID");

			if (validWaterMarkInputData(modelObj)) {
				final Pattern pattern = Pattern.compile(EMAIL_PATTERN);
				
				if (!pattern.matcher(modelObj.getClientEmail()).matches()) {
					logger.info("Invalid Email Id Value...");
					// status.setCode("EMAIL_INVALID_ERROR");
					status.setCode("error");
					status.setMessage(EMAIL_INVALID_ERROR);
					status.setStatus(false);
				} else {
					if (validDate(modelObj.getOrderDate())) {
						dataValidFlg = true;
					} else {
						logger.info("Invalid Order Date...");
						/// status.setCode("ORDER_DATE_INVALID_ERROR");
						status.setCode("error");
						status.setMessage(ORDER_DATE_INVALID_ERROR);
						status.setStatus(false);
					}
				}

				if (dataValidFlg) {
					/*List<Object> criteriaList = new ArrayList<>();
					criteriaList.add(Boolean.FALSE);
					criteriaList.add(null);
					criteriaMap.clear();
					criteriaMap.put("Product.RecordReference", Arrays.asList(isbnArray));
					criteriaMap.put("isDeleted", criteriaList);*/
					
					List<Criteria> criteriaList = new ArrayList<>();
					
					Criteria[] ISBNCriteria = new Criteria[] {Criteria.where("ProductIDType").is("15"), Criteria.where("IDValue").in(Arrays.asList(isbnArray))}; 						
					criteriaList.add(Criteria.where("Product.ProductIdentifier").elemMatch(new Criteria().andOperator(ISBNCriteria)));
					criteriaList.add(Criteria.where("isDeleted").ne(Boolean.TRUE));
					
					int docCount = masterDao.getCountOfDocuments("products", new Criteria().andOperator(criteriaList.toArray(new Criteria[criteriaList.size()])));

					if (docCount == isbnArray.length) {
						Map<String, Object> formatMap = new HashMap<>();
						criteriaMap.clear();
						criteriaMap.put("isActive", Boolean.TRUE);
						List<KeyValue> mappedValues = masterDao.getKeyValueList("mWatermark", "formatMap", "formatId",
								criteriaMap, null);
						if (mappedValues.size() > 0) {
							formatMap = mappedValues.stream()
									.collect(Collectors.toMap(KeyValue::getKey, KeyValue::getValue));
						}

						if (formatArray.length == 1 || formatArray.length == isbnArray.length) {

							List<WatermarkOrderEntity> orderList = new ArrayList<>();

							for (int i = 0; i < isbnArray.length; i++) {

								String[] isbnFormatArray;

								if (formatArray.length == 1)
									isbnFormatArray = formatArray[0].split("\\s*\\+\\s*");
								else
									isbnFormatArray = formatArray[i].split("\\s*\\+\\s*");
                                                                
                                isbnFormatArray = makeUnique(isbnFormatArray);

								for (String isbnFormat : isbnFormatArray) {
									if (formatMap.containsKey(isbnFormat)) {

										String formatId = (String) formatMap.get(isbnFormat);

										Object[] queryParams = new Object[3];
										queryParams[0] = isbnArray[i];
										queryParams[1] = formatId;
										queryParams[2] = formatId;

										System.out.println("queryParams[0] " + queryParams[0] + "queryParams[1] : "
												+ queryParams[1] + " queryParams[2] :" + queryParams[2]);
										List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
												.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(),
														queryParams);
										logger.info("No. of Files [" + fileList.size() + "]");
										if (fileList.size() == 1 && null != fileList.get(0).getFileId()) {
											logger.info("FileId [" + fileList.get(0).getFileId() + "]");
											WatermarkOrderEntity orderEntityObj = new WatermarkOrderEntity();

											String id = masterDao.getNextSequenceId("waterMarkIdSeq");
											orderEntityObj.setWatermarkId("WM".concat(id));
											orderEntityObj.setIsbn(isbnArray[i]);
											orderEntityObj.setDeviceFormat(isbnFormat);
											orderEntityObj.setFormatId(formatId);
											orderEntityObj.setFileId(fileList.get(0).getFileId());
											orderEntityObj.setOrderFlag(1);
											orderEntityObj.setOrderStatus(WATERMARK_PENDING_STATUS);
											// orderEntityObj.setDownloadStatus("Not Completed");
											
											orderEntityObj.setTitle(getMetaDataField(isbnArray[i], "Title"));
											orderEntityObj.setCountryOfPublication(fileList.get(0).getCountryOfPublication());
											orderEntityObj.setImprintName(getMetaDataField(isbnArray[i], "imprintname"));
											orderEntityObj.setProductCategory(fileList.get(0).getProductCategory());
											orderEntityObj.setPublicationDate(fileList.get(0).getPublicationDate());

											orderList.add(orderEntityObj);
										} else {
											logger.info("Format not available for the ISBN...");
											status.setCode("error");
											// status.setCode("FORMAT_INVALID_ERROR");
											status.setMessage(FORMAT_INVALID_ERROR);
											status.setStatus(false);
											validFlg = false;
											break;
										}

									} else {
										logger.info("Invalid Format...");
										// status.setCode("DRM_INVALID_ERROR");
										status.setCode("error");
										status.setMessage(DRM_INVALID_ERROR);
										status.setStatus(false);
										validFlg = false;
										break;
									}
								}

								if (!validFlg)
									break;

							}

							if (validFlg) {
								WatermarkEntity entityObj = new WatermarkEntity();
								entityObj.setDrmSource(modelObj.getDrmSource());
								entityObj.setOrderId(modelObj.getOrderId());
								entityObj.setOrderType(modelObj.getOrderType());
								entityObj.setClientId(modelObj.getClientId());
								entityObj.setClientName(modelObj.getClientName());
								entityObj.setOrderDate(new Timestamp(sdf.parse(modelObj.getOrderDate()).getTime()));
								entityObj.setClientEmail(Arrays.asList(emailArray));
								entityObj.setWatermarkFlag(1);
								entityObj.setWatermarkRequestStatus(WATERMARK_PENDING_STATUS);
								entityObj.setIsActive(Boolean.TRUE);
								entityObj.setIsDeleted(Boolean.FALSE);
								entityObj.setCreatedBy(loggedUser);
								entityObj.setCreatedOn(new Timestamp(new Date().getTime()));
								entityObj.setOrder(orderList);
								entityObj.setClientIP(modelObj.getClientIP());
								entityObj.setRequestId(requestId);

								result = masterDao.saveEntityObject(entityObj);

								if (result) {
									logger.info("Process Identifier [" + entityObj.getId() + "]");
									Map<String, String> orderIdMap = new HashMap<>();
									orderIdMap.put("orderId", entityObj.getId());

									finalData.put("data", orderIdMap);

									status.setCode("success");
									status.setMessage(SUCCESS_ADD_DRM);
									status.setStatus(true);
								} else {
									// status.setCode("FAILURE_ADD_ACCOUNT");
									status.setCode("error");
									status.setMessage(SYSTEM_ERROR);
									status.setStatus(false);
								}
							}

						} else {
							// status.setCode("INPUT_LENGTH_ERROR");
							status.setCode("error");
							status.setMessage(INPUT_LENGTH_ERROR);
							status.setStatus(false);
						}

					} else {
						// status.setCode("ISBN_INVALID_ERROR");
						status.setCode("error");
						status.setMessage(ISBN_INVALID_ERROR);
						status.setStatus(false);
					}
				}

			} else {
				// status.setCode("INPUT_EMPTY_ERROR");
				status.setCode("error");
				status.setMessage(INPUT_EMPTY_ERROR);
				status.setStatus(false);
			}

		} catch (Exception e) {
			logger.error("Exception in save :: ", e);
			// status.setCode("SYSTEM_ERROR");
			status.setCode("error");
			status.setMessage(SYSTEM_ERROR);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}

		return finalData;
	}

	public boolean validWaterMarkInputData(Watermark modelObj) {

		String[] isbnList = modelObj.getIsbn().split(",");
		String[] formatList = modelObj.getDeviceFormat().split(",");
		String[] emailList = modelObj.getClientEmail().split(",");

		if (isbnList.length > 0 && formatList.length > 0 && emailList.length > 0 && modelObj.getOrderDate() != null
				&& modelObj.getClientName() != null && modelObj.getClientId() != null && modelObj.getOrderId() != null
				&& modelObj.getDrmSource() != null) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings({ "unchecked"})
	@Scheduled(fixedRate = 5000)
	public void createWaterMark() {

		try {
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("watermarkFlag", 1);
			criteriaMap.put("isActive", Boolean.TRUE);
			List<WatermarkEntity> entityObjList = (List<WatermarkEntity>) masterDao
					.getAllEntityObjects(new WatermarkEntity(), criteriaMap);

			AwsAPIEntity apiEntity = null;
            if(null != entityObjList && entityObjList.size()>0)
                apiEntity = masterDao.getAwsCredentials();

			for (WatermarkEntity entityObj : entityObjList) {
				String watermarkRequestStatus = WATERMARK_PROCESSING_FAIL_STATUS;
				Integer watermarkFlag = -1;

				List<WatermarkOrderEntity> processedList = new ArrayList<>();
				
				try {

					Date watermarkUrlExpiryDate = new Date();
					long msec = watermarkUrlExpiryDate.getTime();
					msec += Integer.valueOf(WATERMARK_URL_EXPIRY_DAYS) * 24 * 60 * 60 * 1000;
					watermarkUrlExpiryDate.setTime(msec);
					
					
					String orderStatus = WATERMARK_PROCESSING_FAIL_STATUS;
					Integer orderFlag = -1;
					URL url = null;

					for (WatermarkOrderEntity orderEntityObj : entityObj.getOrder()) {
						InputStream in = null;
						OutputStream out = null;
						try {
							Object[] queryParams = new Object[3];
							queryParams[0] = orderEntityObj.getIsbn();
							queryParams[1] = orderEntityObj.getFormatId();
							queryParams[2] = orderEntityObj.getFormatId();

							List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
									.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(), queryParams);
							if (fileList.size() == 1 && null != fileList.get(0).getFileId()) {
								String tempInputPath = VIRTUAL_PATH_WATERMARK_INPUT + File.separator + entityObj.getId()
										+ File.separator + orderEntityObj.getWatermarkId();
								String tempOutputPath = VIRTUAL_PATH_WATERMARK_OUTPUT + File.separator + entityObj.getId()
										+ File.separator + orderEntityObj.getWatermarkId();

								in = downloadFileAsStream(apiEntity.getBucketName(), fileList.get(0).getObjectkey());

								File tempDirInput = new File(tempInputPath);
								File tempDirOutput = new File(tempOutputPath);
								if (!tempDirInput.exists())
									tempDirInput.mkdirs();
								if (!tempDirOutput.exists())
									tempDirOutput.mkdirs();

								out = new FileOutputStream(new File(tempDirInput + File.separator + fileList.get(0).getFileName()));

								int read = 0;
								byte[] bytes = new byte[1024];

								while ((read = in.read(bytes)) != -1) {
									out.write(bytes, 0, read);
								}

								SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/YYYY");
								String orderDateString = formatter.format(entityObj.getOrderDate());
								String emailString = entityObj.getClientEmail().stream().collect(Collectors.joining(","));

								entityObj.setInputFileName(tempInputPath + File.separator + fileList.get(0).getFileName());
								entityObj.setOutputFolderName(tempOutputPath);
								entityObj.setEmailId(emailString);
								entityObj.setOrderDateString(orderDateString);

								Map<String, Object> formatWatermarkTypeMap = new HashMap<>();
								criteriaMap.clear();
								criteriaMap.put("isActive", Boolean.TRUE);
								List<KeyValue> mappedValues = masterDao.getKeyValueList("mWatermark", "formatMap", "watermarkType", criteriaMap, null);
								if (mappedValues.size() > 0) {
									formatWatermarkTypeMap = mappedValues.stream()
											.collect(Collectors.toMap(KeyValue::getKey, KeyValue::getValue));
								}
								
								boolean watermarkAddFlg = false;

								if ("PDF".equals(formatWatermarkTypeMap.get(orderEntityObj.getDeviceFormat()))) {
									watermarkAddFlg = createPdfWatermark(entityObj);
									if(!watermarkAddFlg) {
										orderStatus = WATERMARK_ERROR;
										orderFlag = 2;
									}
								} else if ("EPUB".equals(formatWatermarkTypeMap.get(orderEntityObj.getDeviceFormat()))) {
									watermarkAddFlg = createEpubWatermark(entityObj);
									if(!watermarkAddFlg) {
										orderStatus = WATERMARK_ERROR;
										orderFlag = 2;
									}
								} else if ("MOBI".equals(formatWatermarkTypeMap.get(orderEntityObj.getDeviceFormat()))) {
									watermarkAddFlg = createMobiWatermark(entityObj);
									if(!watermarkAddFlg) {
										orderStatus = WATERMARK_ERROR;
										orderFlag = 2;
									}
								} else {
									watermarkAddFlg = false;
									orderStatus = WATERMARK_INVALID_FORMAT;
									orderFlag = 3;
								}
								
								if(watermarkAddFlg) {
									String watermarkedFilePath = "";
									String s3FilePath = "";

									if ("MOBI".equals(formatWatermarkTypeMap.get(orderEntityObj.getDeviceFormat()))) {
										watermarkedFilePath = tempOutputPath + File.separator + fileList.get(0).getFileName().replace(".epub", ".mobi");
										s3FilePath = entityObj.getId() + File.separator + orderEntityObj.getWatermarkId() + File.separator + fileList.get(0).getFileName().replace(".epub", ".mobi");
									} else {
										watermarkedFilePath = tempOutputPath + File.separator + fileList.get(0).getFileName();
										s3FilePath = entityObj.getId() + File.separator + orderEntityObj.getWatermarkId() + File.separator + fileList.get(0).getFileName();
									}

									url = uploadFileToS3(apiEntity, watermarkedFilePath, s3FilePath, watermarkUrlExpiryDate);
									
									if(null != url) {
										orderStatus = "SUCCESS";
										orderFlag = 0;
									}else {
										orderStatus = "ERROR:DOWNLOAD LINK GENERATION FAILED";
										orderFlag = 4;
									}
								}
							} else {
								orderStatus = "ERROR:ASSET_MISSING";
								orderFlag = 9;
							}
						}catch(Exception e) {
							logger.info("Exception in Processing watermarkId ["+orderEntityObj.getWatermarkId()+"]");
							watermarkRequestStatus = WATERMARK_PROCESSING_FAIL_STATUS + " : ERROR :: "+e.getMessage();
							orderStatus = WATERMARK_PROCESSING_FAIL_STATUS + " : ERROR :: "+e.getMessage();
							watermarkFlag = -1;
							e.printStackTrace();
						}finally {
                            IOUtils.closeQuietly(in);
                            IOUtils.closeQuietly(out);
							FileUtils.deleteDirectory(new File(VIRTUAL_PATH_WATERMARK_INPUT+File.separator+File.separator+entityObj.getId()));
							FileUtils.deleteDirectory(new File(VIRTUAL_PATH_WATERMARK_OUTPUT+File.separator+File.separator+entityObj.getId()));
							WatermarkOrderEntity processedOrderEntityObj = new WatermarkOrderEntity();
							BeanUtils.copyProperties(orderEntityObj, processedOrderEntityObj);
							processedOrderEntityObj.setOrderFlag(orderFlag);
							processedOrderEntityObj.setOrderStatus(orderStatus);
							processedOrderEntityObj.setUrl(url == null ? null : url.toString());
							processedOrderEntityObj.setUrlExpiryOn(watermarkUrlExpiryDate);

							processedList.add(processedOrderEntityObj);
						}
					}

					entityObj.setOrder(processedList);

					if (sendWatermarkMail(entityObj)) {
						watermarkRequestStatus = WATERMARK_PROCESSED_STATUS;
						watermarkFlag = 0;
					} else {
						watermarkRequestStatus = "ERROR:WATERMARK_MAIL_FAIL";
						watermarkFlag = 8;
						
						
						entityObj.getOrder().forEach(ord -> 
						{
							ord.setOrderFlag(8);
							ord.setOrderStatus("ERROR:WATERMARK_MAIL_FAIL");
						});
						
						
					}
					
				}catch(Exception e) {					
					logger.info("Exception in Processing orderId ["+entityObj.getId()+"]");
					watermarkRequestStatus = WATERMARK_PROCESSING_FAIL_STATUS + " : Exception :: "+e.getMessage();
					watermarkFlag = -1;
					e.printStackTrace();
					entityObj.getOrder().forEach(ord -> 
					{
						ord.setOrderFlag(-1);
						ord.setOrderStatus(WATERMARK_PROCESSING_FAIL_STATUS + " : Exception :: "+e.getMessage());
					});
				}finally {
					FileUtils.deleteDirectory(new File(VIRTUAL_PATH_WATERMARK_INPUT+File.separator+File.separator+entityObj.getId()));
					FileUtils.deleteDirectory(new File(VIRTUAL_PATH_WATERMARK_OUTPUT+File.separator+File.separator+entityObj.getId()));
					criteriaMap.clear();
					criteriaMap.put("_id", entityObj.getId());
					criteriaMap.put("isActive", Boolean.TRUE);
					criteriaMap.put("isDeleted", Boolean.FALSE);

					Map<String, Object> updateMap = new HashMap<>();
					updateMap.put("order", processedList);
					updateMap.put("watermarkFlag", watermarkFlag);
					updateMap.put("watermarkRequestStatus", watermarkRequestStatus);

					masterDao.updateCollectionDocument("watermarkDetails", criteriaMap, updateMap);
				}
				
			}

		} catch (Exception e) {
			logger.error("Exception in Watermark Schedular :: ", e);
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public URL uploadFileToS3(AwsAPIEntity apiEntity, String inputFilePath, String S3FilePath,
			Date watermarkUrlExpiryDate) {

		URL url = null;

		try {
			BasicAWSCredentials awsCreds = null;
			awsCreds = new BasicAWSCredentials(apiEntity.getAccessKey(), apiEntity.getSecretKey());
			AmazonS3 s3client = new AmazonS3Client(awsCreds);

			System.out.println("Uploading a new object to S3 from a file\n");
			String fileName = WATERMARK_FILE_S3_PATH + File.separator + S3FilePath;
			s3client.putObject(new PutObjectRequest(apiEntity.getBucketName(), fileName, new File(inputFilePath))
					.withCannedAcl(CannedAccessControlList.PublicRead));
			System.out.println("File " + fileName + " uploaded successfully");

			GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(
					apiEntity.getBucketName(), fileName);
			generatePresignedUrlRequest.setMethod(HttpMethod.GET); // Default.
			generatePresignedUrlRequest.setExpiration(watermarkUrlExpiryDate);
			
			ResponseHeaderOverrides t = new ResponseHeaderOverrides();
            t.setContentDisposition("attachment");
            t.setContentType("application/octet-stream");            
            generatePresignedUrlRequest.setResponseHeaders(t);

			s3client.setRegion(Region.getRegion(Regions.fromName(apiEntity.getRegion())));
			/*
			 * if(!versionId.equalsIgnoreCase(""))
			 * generatePresignedUrlRequest.addRequestParameter("versionId", versionId);
			 * 
			 * if("cw-demo-us-standard.s3-accelerate.amazonaws.com".contains("accelerate"))
			 * { s3client.setS3ClientOptions(S3ClientOptions.builder().
			 * setAccelerateModeEnabled(true).build()); }
			 */
			s3client.setS3ClientOptions(S3ClientOptions.builder().setAccelerateModeEnabled(true).build());
			url = s3client.generatePresignedUrl(generatePresignedUrlRequest);

		} catch (Exception e) {
			e.printStackTrace();
			url = null;
		}

		return url;
	}

	@SuppressWarnings({ "rawtypes" })
	public Boolean sendWatermarkMail(WatermarkEntity entityObj)
			throws IllegalArgumentException, IllegalAccessException {

		RestTemplate restTemplate = new RestTemplate();
		boolean mailFlg = true;

		List<String> titleList = CollectionUtils.emptyIfNull(entityObj.getOrder()).stream()
				.filter(data -> data.getOrderFlag() == 0)
				.map(data -> data.getIsbn())
				.distinct()
				.map(isbn -> getMetaDataField(isbn, "Title"))
				.collect(Collectors.toList());

		if (titleList.size() > 0) {
			
			LinkedHashMap<String, Object> contentCriteriaMap = new LinkedHashMap<>();
			
			contentCriteriaMap.put("client", entityObj.getDrmSource());
			contentCriteriaMap.put("isActive", Boolean.TRUE);
			contentCriteriaMap.put("type", "WATERMARK");
			contentCriteriaMap.put("orderType", entityObj.getOrderType());
			
			MWatermarkContentEntity mDrmContent = masterDao.getEntityObject(new MWatermarkContentEntity(), contentCriteriaMap);
			if(mDrmContent==null)
			{
				contentCriteriaMap.clear();
				contentCriteriaMap.put("client", "others");
				contentCriteriaMap.put("isActive", Boolean.TRUE);
				contentCriteriaMap.put("type", "WATERMARK");
				contentCriteriaMap.put("orderType", entityObj.getOrderType());
			}
			mDrmContent = masterDao.getEntityObject(new MWatermarkContentEntity(), contentCriteriaMap);
			
			if(mDrmContent==null)
			{
				contentCriteriaMap.clear();
				contentCriteriaMap.put("client", "others");
				contentCriteriaMap.put("type", "WATERMARK");
				contentCriteriaMap.put("orderType", "others");
			}
			mDrmContent = masterDao.getEntityObject(new MWatermarkContentEntity(), contentCriteriaMap);

			try {
				String emails = entityObj.getClientEmail().stream().collect(Collectors.joining(","));

				MailDetails mailDetails = new MailDetails();
				Map<String, Object> templateData = new HashMap<String, Object>();
				mailDetails.setEmail_from("donotreply@codemantra.com");
				mailDetails.setTo_email(emails);
				mailDetails.setSubject(mDrmContent.getSubject());
				mailDetails.setCreatedBy(entityObj.getCreatedBy());
				

				templateData.put("beforeContent", mDrmContent.getBeforeContent()==null?"":mDrmContent.getBeforeContent().replaceAll("#link", MANAGE_WATERMARK_URL + entityObj.getId()));
				templateData.put("afterContent", mDrmContent.getAfterContent()==null?"":mDrmContent.getAfterContent().replaceAll("#link", MANAGE_WATERMARK_URL + entityObj.getId()));
								
				StringBuilder content = new StringBuilder("");
				for(String title : titleList) {
					content.append("<p>").append(title).append("</p>");
				}
				
				templateData.put("content", content.toString());
				
				mailDetails.setTemplateData(templateData);
				mailDetails.setTemplateName(WATERMARK_MAIL_TEMPLATE);

				APIResponse response = restTemplate.postForObject(MANAGE_EMAIL_SERVICE_URL, mailDetails,
						APIResponse.class);

				logger.info("Email id [" + emails + "]");
				logger.info(" Mail API Response Code:" + response.getCode());
				logger.info(" Mail API Response Message:" + response.getStatusMessage());

				logger.debug(" Mail API Response Code:" + response.getCode());
				logger.debug(" Mail API Response Message:" + response.getStatusMessage());
			} catch (Exception e) {
				logger.info("Exception in sending Watermark Mail...");
				mailFlg = false;
			}
		}

		return mailFlg;

	}

	public boolean createPdfWatermark(WatermarkEntity entity){
		boolean waterMarkAddFlg = true;
		String str2bEmbeddedInPdf = entity.getId();
		String footerText = this.FOOTER_TEXT.replace("$1", entity.getClientName()).replace("$2", entity.getEmailId())
				.replace("$3", entity.getOrderDateString());

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			InputStream imageStream = this.getClass().getResourceAsStream("/test.jpg");
			byte[] b1 = IOUtils.toByteArray(imageStream);

			if (imageStream != null) {
				try {
					imageStream.close();
				} catch (Exception e) {
				}
			}
			//Image image = Toolkit.getDefaultToolkit().createImage(b1);
                        ByteArrayInputStream tempIs = new ByteArrayInputStream(b1);;
                        Image image  =   ImageIO.read(tempIs); //Patched for 
                        IOUtils.closeQuietly(tempIs);
			JpegEncoder encoder = new JpegEncoder(image, 70, baos, "Test Comments");

			ByteArrayInputStream in = new ByteArrayInputStream(str2bEmbeddedInPdf.getBytes());
			encoder.Compress(in, this.PDF_IMAGE_PASSWORD);
			if (baos != null)
				baos.close();
			byte[] b = baos.toByteArray();
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}
			in = new ByteArrayInputStream(b);
			if (baos != null) {
				try {
					baos.close();
				} catch (Exception e) {
				}
			}

			String path = null;
			try {
				List<Integer> pageNos = null;
				path = addPdfWatermark(new File(entity.getInputFileName()), new File(entity.getOutputFolderName()), b,
						footerText, pageNos);
				
				waterMarkAddFlg = path == null ? false:true;
				
				if (in != null) {
					try {
						in.close();
					} catch (Exception e) {
					}
				}
			} catch (Exception e) {
				waterMarkAddFlg = false;
				e.printStackTrace();
				/*
				 * response.setStatusCode(714);
				 * response.setResponseString(statusCodes.getProperty("714"));
				 * response.setStatus("Failure"); logger.error("714 : " +
				 * this.statusCodes.getProperty("714"), e);
				 * 
				 * return response;
				 */
			} catch (Error e) {
				waterMarkAddFlg = false;
				/*
				 * e.printStackTrace(); response.setStatusCode(714);
				 * response.setResponseString(statusCodes.getProperty("714"));
				 * response.setStatus("Failure"); logger.error("714 : " +
				 * this.statusCodes.getProperty("714"), e);
				 * 
				 * return response;
				 */
			}
			/*
			 * response.setStatusCode(200); response.setResponseString(path);
			 * response.setStatus("Success");
			 */
			// return response;
		}catch(Exception e) {
			waterMarkAddFlg = false;
			e.printStackTrace();
		}

		return waterMarkAddFlg;
	}

	@SuppressWarnings("deprecation")
	private String addPdfWatermark(File inputFile, File outputFile, byte[] imageStream, final String emailFooter,
			final List<Integer> pageNos) throws IOException
	// , BadSecurityHandlerException, CryptographyException, COSVisitorException
	{
		int virtualRam = Integer.parseInt(this.VIRTUAL_RAM_SIZE);
		// int virtualDisk = Integer.parseInt(this.VIRTUAL_DISK_SIZE);
		MemoryUsageSetting settings = MemoryUsageSetting.setupMixed(1024 * 1024 * virtualRam);

		PDDocument doc = PDDocument.load(inputFile, settings);
		float FONT_SIZE = Float.valueOf(PDF_FONT_SIZE);
		PDPageContentStream footercontentStream = null;
		String outFilePath = null;
		try {
			PDType1Font helveticaBold = PDType1Font.HELVETICA_BOLD;
			PDPageTree pages = doc.getDocumentCatalog().getPages();
			Set<Integer> shuffles = shuffle(pages.getCount(), 2);

			for (int i = 0; i < pages.getCount(); i++) {
				PDPage page = ((PDPage) pages.get(i));
				if (shuffles.contains(i)) {
					float x = 1f;
					float y = 1f;
					float scale = 0.000001f;

					footercontentStream = new PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND,
							true);
					PDImageXObject img = PDImageXObject.createFromByteArray(doc, imageStream, "Image1");

					footercontentStream.drawImage(img, x, y, x + scale, y + scale);
					footercontentStream.close();
				}
				if (i == 0) // Supposed to be cover page
					continue;

				if (((pageNos != null) && pageNos.contains(i + 1)) || pageNos == null // For watermarking all pages
																						// except cover page
				) {
					footercontentStream = new PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND,
							true);
					footercontentStream.beginText();
					footercontentStream.setNonStrokingColor(128, 128, 128);// Setting the font color to Gray
					footercontentStream.setFont(helveticaBold, FONT_SIZE);// Reduced font size to 4.5f

					float titleWidth = helveticaBold.getStringWidth(emailFooter) / 1000 * FONT_SIZE;
					/*float titleHeight = helveticaBold.getFontDescriptor().getFontBoundingBox().getHeight()
							/ (1000 * FONT_SIZE);*/

					if (page.getCropBox() != null) {

						while (((page.getCropBox().getWidth() - titleWidth) / 2) < 0.0) {
							FONT_SIZE = FONT_SIZE - 0.1f;
							titleWidth = helveticaBold.getStringWidth(emailFooter) / 1000 * FONT_SIZE;

						}
						footercontentStream.setFont(helveticaBold, FONT_SIZE);
						footercontentStream.moveTextPositionByAmount(
								(page.getCropBox().getWidth() - titleWidth) / 2 + page.getCropBox().getLowerLeftX(),
								page.getCropBox().getLowerLeftY() + 3.5f);
					}

					else if (page.getArtBox() != null) {
						while (((page.getArtBox().getWidth() - titleWidth) / 2) < 0.0) {
							FONT_SIZE = FONT_SIZE - 0.1f;
							titleWidth = helveticaBold.getStringWidth(emailFooter) / 1000 * FONT_SIZE;

						}
						footercontentStream.setFont(helveticaBold, FONT_SIZE);
						footercontentStream.moveTextPositionByAmount(
								(page.getArtBox().getWidth() - titleWidth) / 2 + page.getArtBox().getLowerLeftX(),
								page.getArtBox().getLowerLeftY() + 3.5f);
					} else if (page.getBleedBox() != null) {
						while (((page.getBleedBox().getWidth() - titleWidth) / 2) < 0.0) {
							FONT_SIZE = FONT_SIZE - 0.1f;
							titleWidth = helveticaBold.getStringWidth(emailFooter) / 1000 * FONT_SIZE;

						}
						footercontentStream.moveTextPositionByAmount(
								(page.getBleedBox().getWidth() - titleWidth) / 2 + page.getBleedBox().getLowerLeftX(),
								page.getBleedBox().getLowerLeftY() + 3.5f);
					}

					else {
						while (((page.getMediaBox().getWidth() - titleWidth) / 2) < 0.0) {
							FONT_SIZE = FONT_SIZE - 0.1f;
							titleWidth = helveticaBold.getStringWidth(emailFooter) / 1000 * FONT_SIZE;

						}
						footercontentStream.moveTextPositionByAmount(
								(page.getMediaBox().getWidth() - titleWidth) / 2 + page.getMediaBox().getLowerLeftX(),
								page.getMediaBox().getLowerLeftY() + 3.5f);
					}

					footercontentStream.drawString(emailFooter);
					footercontentStream.endText();
					footercontentStream.close();
				}
			} // end for

			org.apache.pdfbox.pdmodel.encryption.AccessPermission perms = new AccessPermission();
			perms.setCanAssembleDocument(false);
			;
			perms.setCanExtractContent(false);
			perms.setCanModify(false);
			//perms.setCanModifyAnnotations(false); //Access granted For highlighting and comments purposes
			perms.setCanModifyAnnotations(true);
			perms.setCanExtractForAccessibility(false);
			perms.setCanFillInForm(false);

			perms.setCanPrint(false);
			perms.setReadOnly();
			perms.setCanPrintDegraded(false);
			perms.setCanExtractForAccessibility(false);
			doc.setAllSecurityToBeRemoved(false);

			org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy policy = new StandardProtectionPolicy(
					this.PDF_ADMIN_PASSWORD, "", perms);
			policy.setPermissions(perms);
			policy.setEncryptionKeyLength(128);
			policy.setOwnerPassword(this.PDF_ADMIN_PASSWORD);
			policy.setPermissions(perms);
			policy.setUserPassword("");

			doc.protect(policy);
			doc.save(outputFile.getAbsolutePath() + File.separator + inputFile.getName());
			doc.close();
			
			outFilePath = outputFile.getAbsolutePath() + File.separator + inputFile.getName();
		}catch(Exception e) {
			outFilePath = null;
			e.printStackTrace();
		}finally {
			if (doc != null) {
				doc.close();
			}
		}

		return outFilePath;
	}

	@Autowired
	private ZipUtil zipUtil;

	public boolean createEpubWatermark(WatermarkEntity entity) {
		
		boolean watermarkAddFlg = false;

		File inputFile = new File(entity.getInputFileName());
		String uuid = UUID.randomUUID().toString();
		
		//String tempEpubDirPath = TEMP_OUTPUT_FOLDER + File.separator;
		String tempEpubDirPath = TEMP_OUTPUT_FOLDER;
		File tempEpubDir = new File(tempEpubDirPath);
		if (!tempEpubDir.exists())
			tempEpubDir.mkdirs();

		String unzippedFolderPath = tempEpubDirPath + File.separator + inputFile.getName()+ ".zip/";
		File outputFile = new File(entity.getOutputFolderName() + File.separator + inputFile.getName());

		Set<File> unzippedFiles = null;

		{

			try {
				unzippedFiles = zipUtil.getUnzippedRegularFiles(inputFile, unzippedFolderPath);
				watermarkAddFlg = null == unzippedFiles ? false : true;
			} catch (SevenZipException e) {
				watermarkAddFlg = false;
				e.printStackTrace();
				logger.info("101");
				/*
				 * response.setStatusCode(711);
				 * response.setResponseString(statusCodes.getProperty("711"));
				 * response.setStatus("Failure"); logger.error("711 : " +
				 * this.statusCodes.getProperty("711"), e);
				 * 
				 * return response;
				 */
			} catch (FileNotFoundException e) {
				watermarkAddFlg = false;
				e.printStackTrace();

				logger.info("102");
				/*
				 * response.setStatusCode(713);
				 * response.setResponseString(statusCodes.getProperty("713"));
				 * response.setStatus("Failure"); logger.error("713 : " +
				 * this.statusCodes.getProperty("713"), e);
				 * 
				 * return response;
				 */
			} catch (SAXException e) {
				watermarkAddFlg = false;
				e.printStackTrace();

				logger.info("103");
				/*
				 * response.setStatusCode(715);
				 * response.setResponseString(statusCodes.getProperty("715"));
				 * response.setStatus("Failure"); logger.error("715 : " +
				 * this.statusCodes.getProperty("715"), e);
				 * 
				 * return response;
				 */
			} catch (TikaException e) {
				watermarkAddFlg = false;
				e.printStackTrace();
				logger.info("104");
				/*
				 * response.setStatusCode(718);
				 * response.setResponseString(statusCodes.getProperty("718"));
				 * response.setStatus("Failure"); logger.error("718 : " +
				 * this.statusCodes.getProperty("718"), e);
				 * 
				 * return response;
				 */
			} catch (IOException e) {
				watermarkAddFlg = false;
				e.printStackTrace();

				logger.info("105");
				/*
				 * response.setStatusCode(703);
				 * response.setResponseString(statusCodes.getProperty("703"));
				 * response.setStatus("Failure"); logger.error("703 : " +
				 * this.statusCodes.getProperty("703"), e);
				 * 
				 * return response;
				 */
			} catch (Exception e) {
				watermarkAddFlg = false;
				e.printStackTrace();
				logger.info("106");
				/*
				 * response.setStatusCode(714);
				 * response.setResponseString(statusCodes.getProperty("714"));
				 * response.setStatus("Failure"); logger.error("714 : " +
				 * this.statusCodes.getProperty("714"), e);
				 * 
				 * return response;
				 */
			} catch (Error e) {
				watermarkAddFlg = false;
				e.printStackTrace();

				logger.info("107");
				/*
				 * response.setStatusCode(714);
				 * response.setResponseString(statusCodes.getProperty("714"));
				 * response.setStatus("Failure"); logger.error("714 : " +
				 * this.statusCodes.getProperty("714"), e);
				 * 
				 * return response;
				 */
			}
			
			if(watermarkAddFlg) {
				try {
					zipUtil.compress(outputFile, "ZIP", unzippedFiles, unzippedFolderPath, entity);
				} catch (FileNotFoundException e) {
					watermarkAddFlg = false;
					e.printStackTrace();
					logger.info("108");
					/*
					 * response.setStatusCode(713);
					 * response.setResponseString(statusCodes.getProperty("713"));
					 * response.setStatus("Failure"); logger.error("713 : " +
					 * this.statusCodes.getProperty("713"), e);
					 * 
					 * return response;
					 */
				} catch (SevenZipException e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("109");
					/*
					 * response.setStatusCode(711);
					 * response.setResponseString(statusCodes.getProperty("711"));
					 * response.setStatus("Failure"); logger.error("711 : " +
					 * this.statusCodes.getProperty("711"), e);
					 * 
					 * return response;
					 */
				} catch (TikaException e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("110");
					/*
					 * response.setStatusCode(718);
					 * response.setResponseString(statusCodes.getProperty("718"));
					 * response.setStatus("Failure"); logger.error("718 : " +
					 * this.statusCodes.getProperty("718"), e);
					 * 
					 * return response;
					 */
				} catch (SAXException e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("111");
					/*
					 * response.setStatusCode(715);
					 * response.setResponseString(statusCodes.getProperty("715"));
					 * response.setStatus("Failure"); logger.error("715 : " +
					 * this.statusCodes.getProperty("715"), e);
					 * 
					 * return response;
					 */
				} catch (IOException e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("112");
					/*
					 * response.setStatusCode(716);
					 * response.setResponseString(statusCodes.getProperty("716"));
					 * response.setStatus("Failure"); logger.error("716 : " +
					 * this.statusCodes.getProperty("716"), e);
					 * 
					 * return response;
					 */
				} catch (Exception e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("113");
					/*
					 * response.setStatusCode(714);
					 * response.setResponseString(statusCodes.getProperty("714"));
					 * response.setStatus("Failure"); logger.error("714 : " +
					 * this.statusCodes.getProperty("714"), e);
					 * 
					 * return response;
					 */
				} catch (Error e) {
					watermarkAddFlg = false;
					e.printStackTrace();

					logger.info("114");
					/*
					 * response.setStatusCode(714);
					 * response.setResponseString(statusCodes.getProperty("714"));
					 * response.setStatus("Failure"); logger.error("714 : " +
					 * this.statusCodes.getProperty("714"), e);
					 * 
					 * return response;
					 */
				}
				/*try {
					FileUtils.deleteDirectory(new File(tempEpubDirPath));
				} catch (Exception e) {
					// don't do anythinbg
				}*/
			}
			
			
			
		}

		{
			try {
				FileUtils.deleteDirectory(new File(tempEpubDirPath));
			} catch (Exception e1) {
				// don't do anything
			}

		}
		
		
		return watermarkAddFlg;
	}

	@Autowired
	private ConversionServiceFactory conversionServiceFactory;

	public boolean createMobiWatermark(WatermarkEntity entity) {
		boolean watermarkAddFlg = false;
		File inputFile = new File(entity.getInputFileName());
		File mobi = null;
		String uuid = UUID.randomUUID().toString();

		String tempMobiDirPath = TEMP_OUTPUT_FOLDER + File.separator + uuid;
		File tempMobiDir = new File(tempMobiDirPath);
		if (!tempMobiDir.exists())
			tempMobiDir.mkdirs();

		String unzippedFolderPath = tempMobiDirPath + File.separator + inputFile.getName() + ".zip/";
		File outputFile = new File(entity.getOutputFolderName() + File.separator + inputFile.getName());
		String backupDir = EPUB_DRM_MOBI_PATH_BACKUP + File.separator + uuid + File.separator;

		Set<File> unzippedFiles = null;
		{

			try {
				unzippedFiles = zipUtil.getUnzippedRegularFiles(inputFile, unzippedFolderPath);
				watermarkAddFlg = null == unzippedFiles ? false : true;
			} catch (Exception e) {
				watermarkAddFlg = false;
				e.printStackTrace();
				System.out.println("201");
			} catch (Error e) {
				watermarkAddFlg = false;
				e.printStackTrace();
				System.out.println("206");
			}

			if (watermarkAddFlg) {

				final File tempFile4Epub = new File(unzippedFolderPath + outputFile.getName());
				try {
					zipUtil.compress(tempFile4Epub, "ZIP", unzippedFiles, unzippedFolderPath, entity);
				} catch (Exception e) {
					watermarkAddFlg = false;
					e.printStackTrace();
					System.out.println("201");
				} catch (Error e) {
					watermarkAddFlg = false;
					e.printStackTrace();
					System.out.println("206");
				}

				if (watermarkAddFlg) {
					new File(backupDir).mkdirs();
					File epubBackup = new File(backupDir + tempFile4Epub.getName());
					FileInputStream input = null;
					try {
						input = new FileInputStream(tempFile4Epub);
						watermarkAddFlg = null == input ? false : true;
					} catch (FileNotFoundException e) {
						watermarkAddFlg = false;
						e.printStackTrace();
						System.out.println("213");
					}

					if (watermarkAddFlg) {
						FileOutputStream fos = null;
						try {
							fos = new FileOutputStream(epubBackup, false);
							IOUtils.copyLarge(input, fos);
						} catch (IOException e) {
							watermarkAddFlg = false;
							e.printStackTrace();
							System.out.println("214");
						}
						if (fos != null) {
							try {
								fos.close();
							} catch (Exception e) {
							}
						}
						if (input != null) {
							try {
								input.close();
							} catch (Exception e) {
							}
						}
						epubBackup = new File(backupDir + tempFile4Epub.getName());

						ConversionService conversionService = conversionServiceFactory.getConversionService("mobi");

						try {
							mobi = conversionService.convert(epubBackup, KINDLEGEN_PATH);
						} catch (ConversionException e) {
							watermarkAddFlg = false;
							e.printStackTrace();
							System.out.println("215");
						} catch (Error e) {
							watermarkAddFlg = false;
							e.printStackTrace();
							System.out.println("216");
						}

						if (watermarkAddFlg) {
							outputFile = new File(entity.getOutputFolderName() + "/" + mobi.getName());
							try {
								input = new FileInputStream(mobi);
								fos = new FileOutputStream(outputFile, false);
								IOUtils.copyLarge(input, fos);
							} catch (IOException e) {
								watermarkAddFlg = false;
								e.printStackTrace();
								System.out.println("217");
							} catch (Error e) {
								watermarkAddFlg = false;
								e.printStackTrace();
								System.out.println("218");
							}
						}
						if (fos != null) {
							try {
								fos.close();
							} catch (Exception e) {
							}
						}
					}
				}

			}

		}

		{
			try {
				FileUtils.deleteDirectory(new File(tempMobiDirPath));
				FileUtils.deleteDirectory(new File(backupDir));
			} catch (Exception e1) {
				// don't do anything
			}
		}
		
		return watermarkAddFlg;
	}

	private static Set<Integer> shuffle(final int size, int numbOfShuffles) {
		Random random = new Random();
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < size; i++) {
			list.add(new Integer(i));
		}
		Collections.shuffle(list);
		Collections.shuffle(list, random);
		HashSet<Integer> hash = new HashSet<Integer>();
		for (int i = 0; i < numbOfShuffles; i++) {
			if (i < list.size())
				hash.add(list.get(i));
		}

		return hash;
	}	

	
    public String getMetaDataField(String idValue,String fieldDisplayName) {
        String filterList = null;
        String referencePathValue = "";
        String jsonPathValue = "";
        Object obj = null;
        String optTitleList = "";
        try {
        	
        	Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("metaDataFieldName", fieldDisplayName);
			criteriaMap.put("isActive", Boolean.TRUE);
			criteriaMap.put("isDeleted", Boolean.FALSE);

			List<KeyValue> mappedValues = masterDao.getKeyValueList("metaDataFieldConfig", "referencePath",
					"jsonPath", criteriaMap, null);
			
			
			if (mappedValues.size() ==1) {
	            referencePathValue = mappedValues.get(0).getKey();
	            jsonPathValue = (String) mappedValues.get(0).getValue();
	            filterList = masterDao.getMetaDataField(referencePathValue,idValue,fieldDisplayName);

	            DocumentContext docCtx = JsonPath.parse(filterList);
	            JsonPath jsonPath = JsonPath.compile(jsonPathValue);
	            /*obj = docCtx.read(jsonPath);
	            optTitleList = obj.toString().replace("[", "").replace("]", "").replace("\"", "");*/
	            //optTitleList = obj.toString();
	            
	            try {
	            	obj = docCtx.read(jsonPath);
		            optTitleList = obj.toString().replace("[", "").replace("]", "").replace("\"", "");
				}catch(PathNotFoundException e) {
					//Don't do anything
					optTitleList = "";
				}
			}

        } catch (Exception e) {
			logger.error("Exception in getMetadataField :: ", e.getMessage());
			optTitleList = "";
		}
        return optTitleList;
    }
    
	@Override
	public Map<String, Object> retrieveWatermark(String id) {
		WatermarkEntity watermarkEntityObj = null;
		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		List<WatermarkOrder> orderList = new ArrayList<>();

		try {

			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("_id", id);
			criteriaMap.put("isDeleted", Boolean.FALSE);

			watermarkEntityObj = masterDao.getEntityObject(new WatermarkEntity(), criteriaMap);

			if (null == watermarkEntityObj) {
				status.setCode("WATERMARK_NOT_AVAILABLE");
				status.setMessage(WATERMARK_NOT_AVAILABLE);
				status.setStatus(false);
			} else {
				criteriaMap.clear();
				criteriaMap.put("isActive", Boolean.TRUE);
				List<KeyValue> keyValueList = masterDao.getKeyValueList("mWatermark", "formatMap", "displayFormatId",
						criteriaMap, null);

				Map<String, Object> watermarkDisplayFormatMap = keyValueList.stream()
						.collect(Collectors.toMap(KeyValue::getKey, KeyValue::getValue));

				orderList = watermarkEntityObj.getOrder().stream().filter(data -> data.getOrderFlag() == 0).map(temp -> {
					WatermarkOrder obj = new WatermarkOrder();

					LinkedHashMap<String, Object> criteriaMapFormat = new LinkedHashMap<>();
					criteriaMapFormat.put("formatId", watermarkDisplayFormatMap.get(temp.getDeviceFormat()));
					criteriaMapFormat.put("isActive", Boolean.TRUE);
					List<KeyValue> mappedValues = masterDao.getKeyValueList("mFormat", "formatId", "formatName",
							criteriaMapFormat, null);

					String format = mappedValues.stream().filter(formatObj -> watermarkDisplayFormatMap
							.get(temp.getDeviceFormat()).equals(formatObj.getKey())).map(data -> {
								String formatName = (String) data.getValue();
								return formatName;
							}).findAny().orElse("");

					obj.setUrl(temp.getUrl());
					obj.setIsbn(temp.getIsbn());
					obj.setTitle(getMetaDataField(temp.getIsbn(), "Title"));
					obj.setAuthor(getMetaDataField(temp.getIsbn(), "author"));
					obj.setFormat(format);

					return obj;
				}).collect(Collectors.toList());

				status.setCode("SUCCESS_RETRIEVE_WATERMARK");
				status.setMessage(SUCCESS_RETRIEVE_WATERMARK);
				status.setStatus(true);
			}
		} catch (Exception e) {
			logger.error("Exception in retrieveWatermark :: ", e);
			status.setCode("FAILURE_RETRIEVE_WATERMARK");
			status.setMessage(FAILURE_RETRIEVE_WATERMARK);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", orderList);
			finalData.put("orderType", watermarkEntityObj.getOrderType());
		}
		return finalData;
	}
	

	@Override
	public Map<String, Object> listDrmPendingDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> updateDrm(String formatId, String loggedUser) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> reorderDRM(DRMNew modelObj, String loggedUser) {
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		boolean result = false;
		
		try {		
			
			DRMEntityNew entityObj = masterDao.getDRMOrderObject(modelObj.get_id(), modelObj.getDrmId());
			
			if(null != entityObj) {
				Object[] queryParams = new Object[3];
				queryParams[0] = entityObj.getOrder().get(0).getIsbn();
				queryParams[1] = entityObj.getOrder().get(0).getFormatId();
				queryParams[2] = entityObj.getOrder().get(0).getFormatId();

				System.out.println("queryParams[0] : " + queryParams[0] + "-queryParams[1] : " + queryParams[1]
						+ "-queryParams[2] :" + queryParams[2]);
				List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
						.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(), queryParams);
				System.out.println(fileList.size());
				if (fileList.size() == 1 && null != fileList.get(0).getFileId()) {
					
					String id = masterDao.getNextSequenceId("drmOrderIdSeq");
					entityObj.setOrderId("ORDER".concat(id));
					entityObj.setClientId(loggedUser);
					entityObj.setOrderDate(new Timestamp(new Date().getTime()));
					entityObj.setDrmFlg(1);
					entityObj.setIsActive(Boolean.TRUE);
					entityObj.setIsDeleted(Boolean.FALSE);
					entityObj.setCreatedBy(loggedUser);
					entityObj.setCreatedOn(new Timestamp(new Date().getTime()));
					entityObj.setClientIP(modelObj.getClientIP());
					
					String drmId = masterDao.getNextSequenceId("drmIdSeq");
					
					entityObj.getOrder().get(0).setDrmId("DRM".concat(drmId));
					entityObj.getOrder().get(0).setOrderFlg(1);
					entityObj.getOrder().get(0).setFileId(fileList.get(0).getFileId());
					entityObj.getOrder().get(0).setDownloadStatus("Not Completed");
										
					result = masterDao.saveEntityObject(entityObj);

					if (result) {
						logger.info("Process Identifier [" + entityObj.getId() + "]");
						Map<String, String> orderIdMap = new HashMap<>();
						orderIdMap.put("orderId", entityObj.getId());

						finalData.put("data", orderIdMap);

						status.setCode("SUCCESS_REORDER_DRM");
						status.setMessage(SUCCESS_REORDER_DRM);
						status.setStatus(true);
					} else {
						status.setCode("FAILURE_REORDER_DRM");
						status.setMessage(FAILURE_REORDER_DRM);
						status.setStatus(false);
					}
				} else {
					status.setCode("FAILURE_REORDER_DRM_MULT_FILES");
					status.setMessage(FAILURE_REORDER_DRM_MULT_FILES);
					status.setStatus(false);
				}
			}else {
				status.setCode("FAILURE_REORDER_DRM_MISSING");
				status.setMessage(FAILURE_REORDER_DRM_MISSING);
				status.setStatus(false);
			}			
		}catch(Exception e) {
			status.setCode("FAILURE_REORDER_DRM");
			status.setMessage(FAILURE_REORDER_DRM);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}
		
		return finalData;		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> reorderWatermark(Watermark modelObj, String loggedUser) {
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		boolean result = false;
		
		try {		
			
			WatermarkEntity entityObj = masterDao.getWatermarkOrderObject(modelObj.get_id(), modelObj.getWatermarkId());
			
			if(null != entityObj) {
				Object[] queryParams = new Object[3];
				queryParams[0] = entityObj.getOrder().get(0).getIsbn();
				queryParams[1] = entityObj.getOrder().get(0).getFormatId();
				queryParams[2] = entityObj.getOrder().get(0).getFormatId();

				System.out.println("queryParams[0] : " + queryParams[0] + "-queryParams[1] : " + queryParams[1]
						+ "-queryParams[2] :" + queryParams[2]);
				List<AssetFileEntity> fileList = (List<AssetFileEntity>) masterDao
						.runNativeMongoQuery(new AssetFileEntity(), getProductFilesQuery(), queryParams);
				System.out.println(fileList.size());
				if (fileList.size() == 1 && null != fileList.get(0).getFileId()) {
					
					entityObj.setOrderId(modelObj.getOrderId());
					entityObj.setClientId(loggedUser);
					entityObj.setOrderDate(new Timestamp(new Date().getTime()));
					entityObj.setWatermarkFlag(1);
					entityObj.setIsActive(Boolean.TRUE);
					entityObj.setIsDeleted(Boolean.FALSE);
					entityObj.setCreatedBy(loggedUser);
					entityObj.setCreatedOn(new Timestamp(new Date().getTime()));
					entityObj.setClientIP(modelObj.getClientIP());
					
					String watermarkId = masterDao.getNextSequenceId("waterMarkIdSeq");
					entityObj.getOrder().get(0).setWatermarkId("WM".concat(watermarkId));
					entityObj.getOrder().get(0).setOrderFlag(1);
					entityObj.getOrder().get(0).setFileId(fileList.get(0).getFileId());
					entityObj.getOrder().get(0).setOrderStatus(WATERMARK_PENDING_STATUS);
					entityObj.getOrder().get(0).setDownloadStatus("Not Completed");
										
					result = masterDao.saveEntityObject(entityObj);

					if (result) {
						logger.info("Process Identifier [" + entityObj.getId() + "]");
						Map<String, String> orderIdMap = new HashMap<>();
						orderIdMap.put("orderId", entityObj.getId());

						finalData.put("data", orderIdMap);

						status.setCode("SUCCESS_REORDER_WATERMARK");
						status.setMessage(SUCCESS_REORDER_WATERMARK);
						status.setStatus(true);
					} else {
						status.setCode("FAILURE_REORDER_WATERMARK");
						status.setMessage(FAILURE_REORDER_WATERMARK);
						status.setStatus(false);
					}
				} else {
					status.setCode("FAILURE_REORDER_WATERMARK_MULT_FILES");
					status.setMessage(FAILURE_REORDER_WATERMARK_MULT_FILES);
					status.setStatus(false);
				}
			}else {
				status.setCode("FAILURE_REORDER_WATERMARK_MISSING");
				status.setMessage(FAILURE_REORDER_WATERMARK_MISSING);
				status.setStatus(false);
			}			
		}catch(Exception e) {
			status.setCode("FAILURE_REORDER_WATERMARK");
			status.setMessage(FAILURE_REORDER_WATERMARK);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
		}
		
		return finalData;		
	}

   @Override
    public Map<String, Object> extractWatermark(String loggedUser, 
                                                File inputFile, 
                                                 String address) throws IOException, Exception {
        ResponseEntity response = null;
        RequestEntity entity = null;
        String path2File = inputFile.getAbsolutePath();
        //byte[] fileInBytes = multiPartFile.getBytes();
        long size = inputFile.length();
         String fileName = inputFile.getName();
     //   String contentType = multiPartFile.getContentType();
        Boolean isFailure = false;
        String orderId =  null;
       // int read = 0;
      //  byte[] bytes = new byte[1024];
         //String uuid = UUID.randomUUID().toString();
         String msg = null;
       //  String outputPath = VIRTUAL_PATH_WATERMARK_INPUT + File.separator + uuid;
	// File tempOutputPath = new File(outputPath);
	// if (!tempOutputPath.exists())
	  //     tempOutputPath.mkdirs();
    //    String path2File = outputPath + File.separator + fileName;
        

	//OutputStream out = new FileOutputStream(new File(path2File));
       // InputStream in = multiPartFile.getInputStream();
        Map<String, Object> map = new HashMap<>();
        try
        {
      //  IOUtils.copyLarge(in, out);
       // IOUtils.closeQuietly(in);
       // IOUtils.closeQuietly(out);
        entity = new RequestEntity();
        entity.setInputFileName(path2File);
        
        if(path2File.toUpperCase().endsWith(".PDF"))//hard coded for pdf
        {
            entity.setDeviceFormat("U");
            response = extractPdfWatermark(entity);
        }
        else if(path2File.toUpperCase().endsWith(".EPUB")
                ||path2File.toUpperCase().endsWith(".MOBI"))//hard coded for epub/mobi
        {
            entity.setDeviceFormat("E");
            response = extractEpubWatermark(entity);
        }
        orderId = response.getResponseString();
        logger.info("Extracted Order# : : : " + orderId);
        //Map criteriaMap = new HashMap();
       // criteriaMap.put("_id", orderId);
       // WatermarkEntity watermarkEntity = masterDao.getEntityObject(new WatermarkEntity(), criteriaMap);
      //  map.put("isbn", watermarkEntity.getOrder().get(0).);
      map = this.masterDao.getClientInfo(orderId, loggedUser);
              
      //System.out.println();
        }
        catch(Exception e)
        {
            isFailure = true;
            msg=e.getMessage();
            throw new IllegalStateException(e);
        }
        finally
        {
            AuditLogs info = new AuditLogs();
        info.setClientIp(address);
        //info.setEmailId(emailId);
        info.setStatus("WatermarkExtraction");
        info.setUserId(loggedUser);
        info.setLoggedTime(new Date());
        Map<String, Object> otherInfo = new HashMap<>();
        otherInfo.put("fileName", fileName);
        otherInfo.put("fileSize", size);
        if(isFailure)
        {
            otherInfo.put("status", "Failure");
            otherInfo.put("message" , msg);
        }
        else
        {
            otherInfo.put("status", "Success");
            otherInfo.put("message" ,orderId);
        }
        info.setOtherInfo(otherInfo);
       // IOUtils.closeQuietly(in);
        //IOUtils.closeQuietly(out);
//        System.out.println("tempOutputPath : : : : : :  " + tempOutputPath);
         FileUtils.deleteQuietly(inputFile);
        masterDao.saveAuditInfo(info);
        }
        /*
        catch(TikaException e)
       {
           
            response.setStatusCode(718);
            response.setResponseString(statusCodes.getProperty("718"));
            response.setStatus("Failure");
            logger.error("718 : " + this.statusCodes.getProperty("718"), e);
            map.put("response", response);
       }
       catch(FileNotFoundException e)
       {
            response.setStatusCode(713);
            response.setResponseString(statusCodes.getProperty("713"));
            response.setStatus("Failure");
            logger.error("713 : " + this.statusCodes.getProperty("713"), e);
            
             map.put("response", response);
       }
       catch(SAXException e)
       {
           response.setStatusCode(715);
            response.setResponseString(statusCodes.getProperty("715"));
            response.setStatus("Failure"); 
            logger.error("715 : " + this.statusCodes.getProperty("715"), e);
            
            map.put("response", response);
       }
       catch(IOException e)
        {
            response.setStatusCode(703);
            response.setResponseString(statusCodes.getProperty("703"));
            response.setStatus("Failure");
            logger.error("703 : " + this.statusCodes.getProperty("703"), e);
            map.put("response",response);
             
        }
       catch(Exception e)
       {
            response.setStatusCode(714);
            response.setResponseString(statusCodes.getProperty("714"));
            response.setStatus("Failure");
            logger.error("714 : " + this.statusCodes.getProperty("714"), e);
            
            map.put("response", response);
       }
        */
        return map;
    }

    @Override
    public ResponseEntity extractPdfWatermark(RequestEntity entity) throws Exception {
        File  inputFile = new File(entity.getInputFileName());
        ResponseEntity response = new ResponseEntity();
        String orderId=  null;
        List<Object> loggers = new ArrayList<Object>();
        Date startTime = new Date();
        loggers.add(startTime);
        loggers.add(inputFile.getAbsolutePath());
        loggers.add(inputFile.length());
        logger.info("Start Time : {}, File Path : {}, File Length : {}", loggers.toArray());
        loggers.clear();
      // try
       {
           orderId = extractImages(inputFile);
       }
      
        response.setStatusCode(200);
           Date endTime = new Date();
   loggers.add(endTime);
loggers.add(inputFile.getAbsolutePath());
loggers.add((endTime.getTime() - startTime.getTime()) + " ms");
logger.info("End Time : {}, File Path : {}, Time Elapsed : {}", loggers.toArray());
        response.setResponseString(orderId);
        response.setStatus("Success");
       return response;
      /* if(orderId != null)
           return orderId;
       else
       {
           return pdfTextStripper(inputFile);
           
       }
       */
    }

 @Override
    public ResponseEntity extractEpubWatermark(RequestEntity entity)   {
        File inputFile = new File(entity.getInputFileName());
        //System.out.println("FILE NAME  TO BE COMMENDED :"+inputFile.getAbsolutePath());
        //String uuid = UUID.randomUUID().toString();
        ResponseEntity response = new ResponseEntity();
       // String unzippedFolderPath = tempFolder.replace("\\", "/")+uuid+"/" + inputFile.getName()+".zip/";
        String unzippedFolderPath = entity.getInputFileName()+".zip/";
        //File outputFile = new File(entity.getOutputFolderName()+"/"+inputFile.getName());
        List<File> fileNames = new ArrayList<File>();
         String mimetype = null;
        String clientNameAndEmail = null;
        ByteArrayInputStream fis = null;
        FileInputStream fs = null;
        ByteArrayOutputStream fos = null;
        Set<File> unzippedFiles = null;
         List<Object> loggers = new ArrayList<Object>();
        Date startTime = new Date();
        loggers.add(startTime);
        loggers.add(inputFile.getAbsolutePath());
        loggers.add(inputFile.length());
        logger.info("Start Time : {}, File Path : {}, File Length : {}", loggers.toArray());
        loggers.clear();
        
      //  try
        {
        /*
            Set<File> unzippedFiles = zipUtil.getUnzippedRegularFiles(inputFile);
        zipUtil.compress(outputFile, 
                "ZIP", unzippedFiles, 
                tempFolder.replace("\\", "/")+inputFile.getName()+".zip/", entity);
            */
        
        try
        {
        unzippedFiles = zipUtil.getUnzippedRegularFiles(inputFile, unzippedFolderPath);
        }
        catch(Exception e)
        {
            throw new IllegalStateException(e);
        }
        /*
        catch(SevenZipException e)
        {
            e.printStackTrace();
            response.setStatusCode(711);
            response.setResponseString(statusCodes.getProperty("711"));
            response.setStatus("Failure");
            logger.error("711 : " + this.statusCodes.getProperty("711"), e);
            
            return response;
        }
        catch(TikaException e)
        {
            e.printStackTrace();
              response.setStatusCode(718);
            response.setResponseString(statusCodes.getProperty("718"));
            response.setStatus("Failure");
            logger.error("718 : " + this.statusCodes.getProperty("718"), e);
            
            return response;
        }
        catch(SAXException e)
        {
            e.printStackTrace();
             response.setStatusCode(715);
            response.setResponseString(statusCodes.getProperty("715"));
            response.setStatus("Failure");
            logger.error("715 : " + this.statusCodes.getProperty("715"), e);
            
            return response;
        }
        
        catch(IOException e)
        {
            e.printStackTrace();
             response.setStatusCode(711);
            response.setResponseString(statusCodes.getProperty("711"));
            response.setStatus("Failure");
            logger.error("711); : " + this.statusCodes.getProperty("711"), e);
            
            return response;
        }
        catch(Exception e)
        {
            e.printStackTrace();
              response.setStatusCode(714);
            response.setResponseString(statusCodes.getProperty("714"));
            response.setStatus("Failure");
            logger.error("714 : " + this.statusCodes.getProperty("714"), e);
            
            return response;
        }
        catch(Error e)
        {
            e.printStackTrace();
              response.setStatusCode(714);
            response.setResponseString(statusCodes.getProperty("714"));
            response.setStatus("Failure");
            logger.error("714 : " + this.statusCodes.getProperty("714"), e);
            
            return response;
        } 
        */
        for(File f : unzippedFiles)    
        {
            try {
                mimetype = ZipUtil.getMimeType(f);
            }
            catch(Exception e)
            {
                throw new IllegalStateException(e);
            }
            /*catch(TikaException e)
        {
              response.setStatusCode(718);
            response.setResponseString(statusCodes.getProperty("718"));
            response.setStatus("Failure");
            logger.error("718 : " + this.statusCodes.getProperty("718"), e);
            
            return response;
        }
        catch(SAXException e)
        {
            e.printStackTrace();
             response.setStatusCode(715);
            response.setResponseString(statusCodes.getProperty("715"));
            response.setStatus("Failure");
            logger.error("715 : " + this.statusCodes.getProperty("715"), e);
            
            return response;
        }
        
        catch(IOException e)
        {
             response.setStatusCode(711);
            response.setResponseString(statusCodes.getProperty("711"));
      
            response.setStatus("Failure");
            logger.error("711 : " + this.statusCodes.getProperty("711"), e);
            
            return response;
        }
        catch(Exception e)
        {
              response.setStatusCode(714);
            response.setResponseString(statusCodes.getProperty("714"));
            response.setStatus("Failure");
            logger.error("714 : " + this.statusCodes.getProperty("714"), e);
            
            return response;
        }
        catch(Error e)
        {
            e.printStackTrace();
              response.setStatusCode(714);
            response.setResponseString(statusCodes.getProperty("714"));
            response.setStatus("Failure");
            logger.error("714 : " + this.statusCodes.getProperty("714"), e);
            
            return response;
        }
            */
            if(mimetype.contains("jpeg"))
            {
                 
                try {
                     fs = new FileInputStream(f);
                    fis = new ByteArrayInputStream(IOUtils.toByteArray(fs));
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                  /*    response.setStatusCode(717);
            response.setResponseString(statusCodes.getProperty("717"));
            logger.error("717 : " + this.statusCodes.getProperty("717"), e);
            
            response.setStatus("Failure");
            return response;
*/
                }
                if(fs != null )
                {
                    try{fs.close();}catch(Exception e){}
                }
                  fos = new ByteArrayOutputStream();
                 try
                {
                 new Extract().
                        extract(fis, (int)f.length(), fos, this.EPUB_IMAGE_PASSWORD);
                }
                 catch(Exception e)
                {
                   //Don't do anything
                }
                 if(fis != null)
                 {
                     try{fis.close();} catch(Exception e){}
                 }
                 byte[]b = fos.toByteArray();
                 String t = new String(b);
                 if((t!= null) && !t.contains("Incomplete") && t.trim().length() > 0)
                 {
                     response.setResponseString(t);
                     response.setStatus("Success");
                      Date endTime = new Date();
                        loggers.add(endTime);
                     loggers.add(inputFile.getAbsolutePath());
                     loggers.add((endTime.getTime() - startTime.getTime()) + " ms");
                     logger.info("End Time : {}, File Path : {}, Time Elapsed : {}", loggers.toArray());
                     response.setStatusCode(200);
                     return response;
                 }
                 //else if(f.getName().lastIndexOf(".")>=0)
                 {
                     fileNames.add(f);
                 }
            }
            else if(f.getName().lastIndexOf(".") >=0)
            {
                fileNames.add(f);
            }
        }
        //Commented for the time being will have to confirm from Arun whether clientName and email extraction
        //would be better or order id
        //clientNameAndEmail = processFileNamesForClientNameAndEmail(fileNames);
        try{
            //FileUtils.deleteDirectory(new File(tempFolder.replace("\\", "/")+inputFile.getName()+".zip/"));
                System.out.println("unzippedFolderPath : : 1: : :  :"+unzippedFolderPath);
            
            FileUtils.deleteDirectory(new File(unzippedFolderPath));
        }
        catch(Exception e)
        {
            //don't do anythinbg
        }
        }
        //catch(Exception e)
        {
            try
            {
                //FileUtils.deleteDirectory(new File(tempFolder.replace("\\", "/")+inputFile.getName()+".zip/"));
                System.out.println("unzippedFolderPath : : : :2 :  :"+unzippedFolderPath);
                FileUtils.deleteDirectory(new File(unzippedFolderPath));
            }
            catch(Exception e1)
            {
                //don't do anything
            }
            //throw new IllegalStateException(e);
        } 
        response.setResponseString(statusCodes.getProperty("708"));
        response.setStatusCode(708);
        response.setStatus("Failure");
         Date endTime = new Date();
        loggers.add(endTime);
     loggers.add(inputFile.getAbsolutePath());
     loggers.add((endTime.getTime() - startTime.getTime()) + " ms");
     logger.info("End Time : {}, File Path : {}, Time Elapsed : {}", loggers.toArray());
        logger.error("708 : " + this.statusCodes.getProperty("708"));
        
        return response;
      //  return clientNameAndEmail;
    
    }

    @Override
    public ResponseEntity extractMobiWatermark(RequestEntity entity) throws Exception {
            return this.extractEpubWatermark(entity);
    }
    private   String extractImages(File sourceFile) throws //CryptographyException, 
        IOException, FileNotFoundException, SAXException, TikaException
     {
            ByteArrayOutputStream baos = null;
            int pageCount = 0;
            String mimetype = null;
            byte[] b = null;
            String t = null;
            if (sourceFile.exists()) {    
                    PDDocument document = PDDocument.load(sourceFile, this.PDF_ADMIN_PASSWORD);
                    if(document.isEncrypted())
                    {
                        document.setAllSecurityToBeRemoved(true);
                    }
                    PDPageTree list = document.getDocumentCatalog().getPages();
                    for (PDPage page : list) {
                        pageCount ++;
                        PDResources pdResources = page.getResources();
                        if(pdResources !=null)
                        {
                            Iterable<COSName> pageImages = pdResources.getXObjectNames();
                            if (pageImages != null) {
                            //Iterator imageIter = pageImages.keySet().iterator();
                            for (COSName xObjectName : pdResources.getXObjectNames()) {
                                PDXObject xObject = pdResources.getXObject(xObjectName);
                                if (xObject instanceof PDImageXObject) {
                                    PDImageXObject imageObj = (PDImageXObject)xObject;
                                    String suffix = imageObj.getSuffix();
                                    baos = new ByteArrayOutputStream();
                                    InputStream is = imageObj.getPDStream().getStream().createRawInputStream();
                                    b = IOUtils.toByteArray(is);
                                    if(is != null)
                                    {
                                        try{
                                            is.close();
                                        }catch(Exception e){}
                                    }
        
                            if(baos != null)
                            {
                                try{baos.close();}catch(Exception e){}
                            }
                            if(b.length >2*1024)
                            {
                                mimetype = ZipUtil.getMimeType(new ByteArrayInputStream(b));
                            }
                            if(mimetype.contains("jpeg") && ((suffix != null) && suffix.contains("jpg")||suffix.contains("jpeg")))
                            {
                                baos = new ByteArrayOutputStream();
                                ByteArrayInputStream fis = new ByteArrayInputStream(b);
                                // System.out.println("Extract : : :  : " + b.length);
                                try
                                {
                                    new Extract().extract(fis, b.length, 
                                            baos , this.PDF_IMAGE_PASSWORD);
                                }
                                catch(Exception e)
                                {
                                    //Don't do anything
                                    //e.printStackTrace();
                                }
                                t = new String(baos.toByteArray(),"UTF-8");
                                // System.out.println(pageCount + " : : : :: : " + t);
                                if(fis != null)
                                {
                                    fis.close();
                                }
                                if(baos != null)
                                {
                                    baos.close();
                                }
                                if( (t.matches("[0-9A-Za-z\\s-]+")) &&(t!= null) && !t.contains("Incomplete") && t.trim().length() >16&& t.trim().length() <50)
                                {
                                    //  System.out.println(t);
                                    return t;//returning the order#
                                }    
                            }
                        }
                    }
                } else {
                    System.err.println("File not exists");
                }
            }
            // return null;
        }//end for inner for pdResources
      }//end for outer for pages
      return null;
}

    @SuppressWarnings("unchecked")
    public static <T> T[] makeUnique(T[] values)
    {
        return Arrays.stream(values).distinct().toArray(new IntFunction<T[]>()
        {
            @Override
            public T[] apply(int length)
            {
                return (T[]) Array.newInstance(values.getClass().getComponentType(), length);
            }        
        });
    }
         
}
