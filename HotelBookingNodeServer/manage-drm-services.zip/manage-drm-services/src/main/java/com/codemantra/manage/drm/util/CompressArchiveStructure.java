package com.codemantra.manage.drm.util;

import com.codemantra.manage.drm.entity.WatermarkEntity;
//import com.sun.image.codec.jpeg.JPEGCodec;
import james.JpegEncoder;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.CopyOption;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import net.f5.Embed;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.XmlStreamReader;
import org.apache.commons.lang.StringUtils;
import org.apache.tika.exception.TikaException;
 import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.*;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;
import sun.security.provider.SecureRandom;
import static com.codemantra.manage.drm.util.DrmUtils.*;
import javax.imageio.ImageIO;
import org.slf4j.LoggerFactory;
        
//@PropertySource("classpath:config.properties")
@Component
public class CompressArchiveStructure {
    @Value("${TEMP_OUTPUT_FOLDER}")
    private   String TEMP_OUTPUT_FOLDER;
    @Value(value = "${PDF_FONT_SIZE}")
    private   String  PDF_FONT_SIZE;
     @Value(value = "${EPUB_DRM_MOBI_PATH_BACKUP}")
    private   String  EPUB_DRM_MOBI_PATH_BACKUP;
     @Value(value="${PDF_ADMIN_PASSWORD}")
     private String PDF_ADMIN_PASSWORD;
     @Value(value="${PDF_IMAGE_PASSWORD}")
     private String PDF_IMAGE_PASSWORD;
     @Value(value="${EPUB_IMAGE_PASSWORD}")
     private String EPUB_IMAGE_PASSWORD;
     @Value(value="${FOOTER_TEXT}")
     private String FOOTER_TEXT;
     private SecureRandom random = new SecureRandom();
	    private static org.slf4j.Logger logger = LoggerFactory.getLogger(CompressArchiveStructure.class);

      static String [] strings= {"a","b","c","d","e","f",
        "g","h","i","j","k","l","m","n","o","p","q","r","s",
"t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","0",
    "A","B","C","D","E","F",
        "G","H","I","J","K","L","M","N","O","P","Q","R","S",
"T","U","V","W","X","Y","Z"
    };
    private static int someMethod(String file)
{
    Random random = new Random();
    ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i=0; i<file.length(); i++) {
            list.add(new Integer(i));
        }
        Collections.shuffle(list);
        Collections.shuffle(list, random);
        for (int i=0; i<1; i++) {
            String a = file.substring(0,list.get(i));
            
            String b = null;
            if(list.get(i) <file.length())
                b = file.substring(list.get(i));
            else
                 b = file.substring(file.length())+"tinkoo";
          //  //System.out.println(a+b +": "+list.get(i));
            return list.get(i);
        }
        return 0;
}
private static String someMethod(String[] file, int len)
{
    Random random = new Random();
    ArrayList<Integer> list = new ArrayList<Integer>();
    String a = "";
        for (int i=0; i<file.length; i++) {
            list.add(new Integer(i));
        }
        Collections.shuffle(list);
        Collections.shuffle(list, random);
        for (int i=0; i<len; i++) {
            if(i<list.size())
            {
                int index = list.get(i);
                  a= a + file[index];
            }
            else
            {
                int index = len%list.size();
                a= a + file[index];
            }
            
        }
        return a.substring(0, 3);
}
    public String nextSessionId() {
//        return new BigInteger(130, random).toString(32);
        return UUID.randomUUID().toString();
    }
                    //String temp22 = "CodemantraArunCodemantracom";
 
     @SuppressWarnings("empty-statement")
    public List<Item> manipulateEpub(Set<File> fileList ,
            String replaceString,  WatermarkEntity
            entity) throws IOException, FileNotFoundException, SAXException, TikaException  
    {
      
            Map<String, String> mapFiles = new HashMap<String, String>();
            //Map<String, Integer> pageNos2bWatermarked = new HashMap<String, Integer>();
            List<String> pageNos2bWatermarked = new ArrayList<String>();
              List<Item> items = new ArrayList<>();
            String absolutePath = null;
            int lastIndexOfSlash = -1;
            String parentPath =null;
            //String orderId = entity.getId();
            List<File> tempList = new ArrayList<>();
            String emailId = entity.getEmailId();
            String tempEmail = emailId;
            String username = tempEmail.substring(0, tempEmail.indexOf("@"));
            String clientName =  entity.getClientName();
            tempEmail=tempEmail.replace(username, "");
            List<Integer> sequences = null;
            String pages = null;
            if(pages != null)
            {
                sequences = DrmUtils.convertPageRanges2List(pages);
            }
                    //.replace(".", "").replace("-", "");
             username= username.replace(".", "").replace("-", "");
            String companyname=tempEmail.substring(tempEmail.indexOf("@")+1,
                    tempEmail.indexOf("."));
            
           tempEmail= tempEmail.replace("@"+companyname, "")
                   .replace(".", "").replace("-", "");
           companyname=companyname.replace(".", ".").replace("-", "");
            String other=null;
            if(tempEmail.indexOf(".")>=0)
                    other=tempEmail.substring(tempEmail.indexOf(".")+1);
            else
                other = tempEmail;
            other= other.replace(".", "").replace("-", "");
            //other=other.replace(".", "");
            String temp22 = entity.getClientName().replace(" ", "")
                    .replace(".", "")
                    .replace("-", "")
                    .replace("@", "")
                    +username+companyname+other;
           // //System.out.println(temp22 + " < <<<<<< test>>>>>>>>>.");
           /*
             String str2bEmbeddedInEpub = "Book is Authorized to: "
                +entity.getEmail()+" having order id : " + entity.getOrderId()
                + " date purchased : " + entity.getOrderDate() ;
           */
           String str2bEmbeddedInEpub = entity.getId();
            int i = 0;
            for(File a : fileList)
            {
          
            absolutePath = a.getAbsolutePath().replace("\\", "/");
            absolutePath=absolutePath.replace(replaceString,"");
            lastIndexOfSlash= absolutePath.lastIndexOf("/");
            String fileName="";
            String primaryFileName = "";
            String extnFileName ="";
            String mimeType = ZipUtil.getMimeType(a);
          //  //System.out.println(a.getName()+"   minme   :: : : : " + ZipUtil.getMimeType(a));

            if(absolutePath.startsWith("META-INF"))
            {
                 mapFiles.put(a.getName(),a.getName());  
            }
            else if(a.getName().equals("mimetype"))
            {
                mapFiles.put("mimetype","mimetype");
                continue;
               // //System.out.println("mimetype" + " : : : : : " +"mimetype");
            }
            else if (mimeType.equals("application/x-dtbncx+xml")
                    ||mimeType.contains("font")
                    ||mimeType.contains("oebps-package+xml")
                     ||mimeType.contains("charset=Big5")
                  //  ||mimeType.contains("css")
                    )
            {
                mapFiles.put(a.getName(), a.getName());
                    if((mimeType.equals("application/oebps-package+xml")) 
                            &&((sequences != null)&& sequences.size() >0))
                    {
                        List<String> htmlOrder = getSpine(a);
                        for(int id = 0;id<sequences.size();id++)
                        {
                            try
                            {
                                int someId = sequences.get(id);
                           // if(sequences.get(id) == (id+1))
                            {
                                if(someId -1 <=0)
                                {
                                    //pageNos2bWatermarked.add(htmlOrder.get(0));
                                    continue;//Will not watermark as it is a title image
                                }
                                else if(someId>=htmlOrder.size())
                                {
                                    someId = htmlOrder.size() - 1;
                                    if(someId >=0)
                                    pageNos2bWatermarked.add(lastIndexOfFilenameFromSpineEntry(htmlOrder.get(someId)));
                                }
                                else if((someId -1)<htmlOrder.size()&& (someId -1) >=0)
                                {
                                    pageNos2bWatermarked.add(lastIndexOfFilenameFromSpineEntry(htmlOrder.get(someId-1)));
                                }
                                
                               // System.out.println(htmlOrder.get(someId )+ " : : : ::  " + someId+ " :: : : " + htmlOrder);
                            }
                            }
                            catch(Exception e)
                            {
                                //Don't do anything - Index out of bounds exception may occur
                            }
                        }
                        pageNos2bWatermarked.add(lastIndexOfFilenameFromSpineEntry(htmlOrder.get(htmlOrder.size() -1)));
                    }
                    else if (mimeType.equals("application/oebps-package+xml"))
                    {
                        List<String> htmlOrder = getSpine(a);
                        for(int id = 0;id<htmlOrder.size();id++)
                        {
                          try
                            {
                          
                           // if(sequences.get(id) == (id+1))
                            {
                                if(id <=0)
                                {
                                    //pageNos2bWatermarked.add(htmlOrder.get(0));
                                    continue;//Will not watermark as it is a title image
                                }
                                else 
                                {
                                    pageNos2bWatermarked.add(lastIndexOfFilenameFromSpineEntry(htmlOrder.get(id)));
                                }

                                
                               // System.out.println(htmlOrder.get(someId )+ " : : : ::  " + someId+ " :: : : " + htmlOrder);
                            }
                            }
                            catch(Exception e)
                            {
                                //Don't do anything - Index out of bounds exception may occur
                            }
                        //pageNos2bWatermarked.add(lastIndexOfFilenameFromSpineEntry(htmlOrder.get(htmlOrder.size() -1)));
                        }
                    }
            }
            else if(lastIndexOfSlash >=0)
            {
                fileName = absolutePath.substring(lastIndexOfSlash+1);
                int lastIndexOfDot = fileName.lastIndexOf(".");
                if(lastIndexOfDot >=0)
                {
                    primaryFileName = fileName.substring(0, lastIndexOfDot)+""+temp22;
                    int x = someMethod(primaryFileName);
                            String puss = primaryFileName.substring(0, x)+":"+primaryFileName.substring(x, primaryFileName.length());
        puss = puss.replace(":", someMethod(strings, puss.length()));
primaryFileName = puss;
                    extnFileName = fileName.substring(lastIndexOfDot);
                    
                }
                else
                {
                    primaryFileName = a.getName()+temp22;
                        int x = someMethod(primaryFileName);
                            String puss = primaryFileName.substring(0, x)+":"+primaryFileName.substring(x, primaryFileName.length());
        puss = puss.replace(":", someMethod(strings, puss.length()));
fileName = puss;
 
                }
                
                mapFiles.put(fileName,primaryFileName+extnFileName);  
                    
            //    //System.out.println(fileName + " : : : : : " +primaryFileName+extnFileName);
            }
            else
            {
                fileName = absolutePath;
                int lastIndexOfDot = fileName.lastIndexOf(".");
                if(lastIndexOfDot >=0)
                {
                    
                    
                    primaryFileName = fileName.substring(0, lastIndexOfDot)+""+temp22;
                    int x = someMethod(primaryFileName);
                            String puss = primaryFileName.substring(0, x)+":"+primaryFileName.substring(x, primaryFileName.length());
        puss = puss.replace(":", someMethod(strings, puss.length()));
primaryFileName = puss;
                    extnFileName = fileName.substring(lastIndexOfDot);
                    
                }
                else
                {
                    primaryFileName = a.getName()+temp22;
                        int x = someMethod(primaryFileName);
                            String puss = primaryFileName.substring(0, x)+":"+primaryFileName.substring(x, primaryFileName.length());
        puss = puss.replace(":", someMethod(strings, puss.length()));
fileName = puss;
 
                }
                
                mapFiles.put(fileName,primaryFileName+extnFileName);  
                    
               // //System.out.println(fileName + " : : : : : " +primaryFileName+extnFileName);
            }
        }
                
      
       for(File a : fileList)
       {
            absolutePath = a.getAbsolutePath().replace("\\", "/");
            absolutePath=absolutePath.replace(replaceString,"");
            lastIndexOfSlash= absolutePath.lastIndexOf("/")+1;
            parentPath = a.getParent()+"/";
            //System.out.println("FILENAME : : : : : : : "+a.getAbsolutePath());
              absolutePath = a.getAbsolutePath().replace("\\", "/");
              
            lastIndexOfSlash= absolutePath.lastIndexOf("/");
            String fileName = absolutePath.substring(lastIndexOfSlash+1);
            String renamedFileName = mapFiles.get(fileName);
            String renamedFilePath = "";
            absolutePath=absolutePath.replace(replaceString,"");
             String  somefileName = a.getName();
          //  //System.out.println(a.getAbsolutePath());
            if(renamedFileName == null)
                continue;
            tempList.add(a);
             String mimeType = ZipUtil.getMimeType(a);
            byte[] b = null;
            FileInputStream is = new FileInputStream(a);
                b = IOUtils.toByteArray(is);
                if(is != null)
                {
                    try{is.close();} catch(Exception e){}
                }
                    if(!absolutePath.endsWith("container.xml")
                    && !absolutePath.endsWith("mimetype")
                  /*  &&!mimeType.equals("application/x-dtbncx+xml")
                    &&!mimeType.contains("font")
                    &&!mimeType.contains("charset=Big5")
                    &&!mimeType.contains("oebps-package+xml")
                    */
                    )
            {
                renamedFilePath = parentPath+renamedFileName;
                renamedFilePath= renamedFilePath.replaceAll("\\\\","/");
                a.renameTo(new File(renamedFilePath));
            }
            
       //   //System.out.println(a.getName() + " : : : : " + mimeType + " : : : " + renamedFileName);
        
            if(mimeType.contains("html")
                    || (mimeType.contains("xml") && !absolutePath.startsWith("META-INF"))
                    || (mimeType.contains("text/plain")
                    && !a.getName().equals("mimetype")
                    
                    )
                    )
            {
                String temp = new String (b,"UTF-8");  
//                if(a.getName().equals("container.xml"))
//                {
//                   // b = null;
//                    
//                
//                }
                
                ////System.out.println(a.getName()+":::::: "+renamedFilePath+ "  ::after :: " + new String(b));
                
//                //System.out.println("--------------BEGIN----------------" + temp);
 
                 if(a.getName().endsWith(".opf")||
                        a.getName().endsWith(".ncx")||
                        mimeType.contains("html")
                     )
                {
                   

                for(String key :mapFiles.keySet())
                {
                        String replace= mapFiles.get(key);
                       //System.out.println(key +":::::"+replace + " Before : :: : " + temp);
                             //   temp=temp.replaceAll(key, replace);
                     //temp = temp.replaceAll("\\b"+key+"\\b", replace);
      temp = temp.replaceAll("([\"|\'|/])"+key, "$1"+replace);
                       // temp = StringUtils.replace(temp, key, replace);
                       //  System.out.println("After : : : : : : "+temp);
                              // temp= StringUtils.replaceOnce(temp, key, replace);
                       // if(!key.equals("container.xml"))
                       // temp=temp.replaceAll(key, replace);
                }
              
                }
                else
                for(String key :mapFiles.keySet())
                {
                        String replace= mapFiles.get(key);
                        if(!key.equals("container.xml"))
                       // temp=temp.replaceAll("(?<!\\S)"+key+"(?!\\S)", replace);
                             temp=temp.replaceAll(key, replace);
                }
                
                if(mimeType.contains("html") && 
                        (pageNos2bWatermarked.contains(somefileName)))
                {
                    //b = temp.getBytes();
                    Pattern pattern2=Pattern.compile("(<\\/body>)",Pattern.CASE_INSENSITIVE);
                 //   //System.out.println(" before : : : : : " + temp );
                    String c = "<p style = \"font-size: 11px; text-align: center;color: #666; border-top: 1px"
                            + " solid #9a9a9a; padding: 15px 0 0; margin: 50px 0 0\"  ";
                    c = c + "class = \"EPubfirstparagraph epubpagerstart\">";
                    /*c = c+"This ebook belongs to "+entity.getClientName()+" ("+entity.getEmail() + "), purchased on "+
                            entity.getOrderDate()+"</p>"
                    */
                    String footerText = this.FOOTER_TEXT.replace("$1", entity.getClientName())
                    .replace("$2", entity.getEmailId())
                    .replace("$3", entity.getOrderDateString());
                    c=c+footerText+"</p>"
            //                This ebook belongs to Arun Rajendran (arun@codemantra.com), purchased on 11/18/2017
                           // + "</body>"
                            ;
                      temp = temp.replaceAll(pattern2.pattern(), c+"$1");
                    
                    b= temp.getBytes("UTF-8");
                }
                else
                b = temp.getBytes("UTF-8");
                
                FileOutputStream out = null;
                if(absolutePath.endsWith("container.xml"))
                {
                    renamedFilePath = a.getAbsolutePath().replace("\\", "/");
                }
                out = new FileOutputStream(renamedFilePath, false);
                IOUtils.write(b, out);
                
                IOUtils.closeQuietly(out);
                if(out != null)
                {
                    try{out.close();}catch(Exception e){}
                }
                Item t = new Item(renamedFilePath.replace(replaceString,""), b);
                items.add(t);
            }
            else
            {
                FileOutputStream out = null;
                if(absolutePath.endsWith("container.xml")||absolutePath.endsWith("mimetype"))
                {
                    renamedFilePath = a.getAbsolutePath().replaceAll("\\\\", "/");
                }
                if(mimeType.endsWith("jpeg"))
                {
                    if(b.length >=(512 * 9))
                    {
                   // Image image = Toolkit.getDefaultToolkit().createImage(b); //Commented by m6s
                        
                        ByteArrayInputStream tempIs = new ByteArrayInputStream(b);;
                        Image image  =   ImageIO.read(tempIs); //Patched for 
                        IOUtils.closeQuietly(tempIs);
                    ByteArrayOutputStream out1 = new ByteArrayOutputStream();
                    
                    JpegEncoder encoder = new  JpegEncoder(image, 90, out1, "Testing");
                     ByteArrayInputStream iss = new ByteArrayInputStream(str2bEmbeddedInEpub.getBytes());
                    encoder.Compress(iss, this.EPUB_IMAGE_PASSWORD);
                    
                    if(iss != null)
                    {
                        try{iss.close();} catch(Exception e){}
                    }
                    b = out1.toByteArray();
                    if(out1 != null)
                    {
                        try{out1.close();} catch(Exception e){}
                    }
                    }
                }
                out = new FileOutputStream(renamedFilePath, false);
                IOUtils.write(b, out);
                IOUtils.closeQuietly(out);
                 if(out != null)
                 {
                     try{out.close();}catch(Exception e){}
                 }
                 replaceString = replaceString.replace("//", "/");
                Item t = new Item(renamedFilePath.replaceAll(replaceString,""), b);
                 items.add(t);
            }
       }


       ArrayList<Item> items2 = new ArrayList<>();
       ;
      // try{
      Item t1 = items.get(0);
      int size = items.size();
      int mimeindex=items.indexOf(new Item("mimetype"));
      if(mimeindex >= 0)
      {
        Item mimeitem =items.get(mimeindex);
        items2.add(mimeitem);
        items2.add(t1);
        for( i=0;i<size;i++)
        {
              if(i == mimeindex||i==0)
                  continue;
                Item i1=items.get(i);
                //if(!items2.contains(i1))
                items2.add(i1);
        }
       return items2;
      }
      // }
      // catch(Exception e)
       {
          // throw new IllegalStateException("This epub does not contain mimetype file");
       }
      return items;
    }
    
    static class Item {
        private String path;
        private byte[] content;

        Item (String path)
        {
            this.path=path;
        }
        Item(String path, String content) {
            this(path, content.getBytes());
        }

        Item(String path, byte[] content) {
            this.path= path;
            this.content= content;
        }

        public int hashCode()
        {
            return (path !=null)?path.hashCode():new String().hashCode();
        }
        public boolean equals(Object o)
        {
            if ((o !=null) && o instanceof Item )
            {
                Item o1 =(Item)o;
                if (o1.path.equals(this.path))
                {
                    return true;
                }
            }
            return false;
        }
        String getPath() {
            return path;
        }

        byte[] getContent() {
            return content;
        }
    }
}








