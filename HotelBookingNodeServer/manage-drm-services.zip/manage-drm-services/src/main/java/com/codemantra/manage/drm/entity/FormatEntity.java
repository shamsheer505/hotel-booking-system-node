/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
13-06-2017			v1.0       	     Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "mFormat")
public class FormatEntity {

	@Field("formatId")
	private String formatId;
	
	@Field("formatName")
	private String formatName;
	
	@Field("filePurpose")
	private String filePurpose;
	
	@Field("extension")
	private List<String> extension;
	
	@Field("namingConvention")
	private String namingConvention;
	
	@Field("singleFile")
	private boolean singleFile;
	
	@Field("formatTypeId")
	private String formatTypeId;
	
	@Field("isActive")
	private boolean isActive;
	
	@Field("isDeleted")
	private boolean isDeleted;
	
	@Field("createdBy")
	private String createdBy;
	
	@Field("createdOn")
	private Date createdOn;
	
	@Field("modifiedBy")
	private String ModifiedBy;
	
	@Field("modifiedOn")
	private Date ModifiedOn;

	public String getFormatId() {
		return formatId;
	}

	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}

	public String getFormatName() {
		return formatName;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

	public String getFilePurpose() {
		return filePurpose;
	}

	public void setFilePurpose(String filePurpose) {
		this.filePurpose = filePurpose;
	}

	public List<String> getExtension() {
		return extension;
	}

	public void setExtension(List<String> extension) {
		this.extension = extension;
	}

	public String getFormatTypeId() {
		return formatTypeId;
	}

	public void setFormatTypeId(String formatTypeId) {
		this.formatTypeId = formatTypeId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return ModifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		ModifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return ModifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		ModifiedOn = modifiedOn;
	}

	public String getNamingConvention() {
		return namingConvention;
	}

	public void setNamingConvention(String namingConvention) {
		this.namingConvention = namingConvention;
	}

	public boolean isSingleFile() {
		return singleFile;
	}

	public void setSingleFile(boolean singleFile) {
		this.singleFile = singleFile;
	}
	
}
