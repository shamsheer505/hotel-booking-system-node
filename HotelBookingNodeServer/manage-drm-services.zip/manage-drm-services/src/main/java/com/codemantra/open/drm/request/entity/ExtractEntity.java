/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codemantra.open.drm.request.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Date;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author codemantra
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExtractEntity implements java.io.Serializable{
    public ExtractEntity()
    {
        super();
    }
    @NotBlank
    @NotNull
   private String deviceFormat;

        @NotBlank
    @NotNull
   private String orderId;
   private String orderDate;
       @NotBlank
    @NotNull
   private String email;
           @NotBlank
    @NotNull
   private String inputFileName;
               @NotBlank
    @NotNull
   private String outputFolderName;
    @NotNull
    private String clientName;
    

    /**
     * @return the orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId the orderId to set
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return the orderDate
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * @param orderDate the orderDate to set
     */
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the inputFileName
     */
    public String getInputFileName() {
        return inputFileName;
    }

    /**
     * @param inputFileName the inputFileName to set
     */
    public void setInputFileName(String inputFileName) {
        this.inputFileName = inputFileName;
    }

    /**
     * @return the outputFolderName
     */
    public String getOutputFolderName() {
        return outputFolderName;
    }

    /**
     * @param outputFolderName the outputFolderName to set
     */
    public void setOutputFolderName(String outputFolderName) {
        this.outputFolderName = outputFolderName;
    }

    /**
     * @return the format
     */
    public String getDeviceFormat() {
        return this.deviceFormat;
    }

    /**
     * @param format the format to set
     */
    public void setDeviceFormat(String format) {
        this.deviceFormat = format;
    }

    /**
     * @return the clientName
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * @param clientName the clientName to set
     */
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
}
