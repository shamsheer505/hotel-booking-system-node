/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
24-01-2018		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;

public class OrderEntity {
	private String drmId;
	private String isbn;
	private String deviceFormat;
	private String formatId;
	private Integer fileId;
	private Integer device;
	private Integer orderFlg;
	private String downloadStatus;
	private String creator;
	private String drmRequestStatus;
	private AcsmLink acsmLink;
	private Date downloadedDate;
	private String acsmTransactionId;
	private String title;
	private String CountryOfPublication;
	private String ImprintName;
	private String ProductCategory;
	private String PublicationDate;
	
	
	public String getDrmId() {
		return drmId;
	}
	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getDeviceFormat() {
		return deviceFormat;
	}
	public void setDeviceFormat(String deviceFormat) {
		this.deviceFormat = deviceFormat;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public Integer getDevice() {
		return device;
	}
	public void setDevice(Integer device) {
		this.device = device;
	}
	public Integer getOrderFlg() {
		return orderFlg;
	}
	public void setOrderFlg(Integer orderFlg) {
		this.orderFlg = orderFlg;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getDrmRequestStatus() {
		return drmRequestStatus;
	}
	public void setDrmRequestStatus(String drmRequestStatus) {
		this.drmRequestStatus = drmRequestStatus;
	}
	public AcsmLink getAcsmLink() {
		return acsmLink;
	}
	public void setAcsmLink(AcsmLink acsmLink) {
		this.acsmLink = acsmLink;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCountryOfPublication() {
		return CountryOfPublication;
	}
	public void setCountryOfPublication(String countryOfPublication) {
		CountryOfPublication = countryOfPublication;
	}
	public String getImprintName() {
		return ImprintName;
	}
	public void setImprintName(String imprintName) {
		ImprintName = imprintName;
	}
	public String getProductCategory() {
		return ProductCategory;
	}
	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}
	public String getPublicationDate() {
		return PublicationDate;
	}
	public void setPublicationDate(String publicationDate) {
		PublicationDate = publicationDate;
	}
	public String getAcsmTransactionId() {
		return acsmTransactionId;
	}
	public void setAcsmTransactionId(String acsmTransactionId) {
		this.acsmTransactionId = acsmTransactionId;
	}
	public Date getDownloadedDate() {
		return downloadedDate;
	}
	public void setDownloadedDate(Date downloadedDate) {
		this.downloadedDate = downloadedDate;
	}
	
}
