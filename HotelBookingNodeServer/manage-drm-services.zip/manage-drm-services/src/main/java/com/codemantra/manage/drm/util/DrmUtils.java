/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codemantra.manage.drm.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.tika.exception.TikaException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.xml.sax.SAXException;

import com.codemantra.manage.drm.util.ZipUtil;

/**
 *
 * @author SENTHILMS
 */
public class DrmUtils {
    public static String lastIndexOfFilenameFromSpineEntry(String fileName)
    {
        if((fileName != null) &&  fileName.lastIndexOf("/") >=0)
        {
            return fileName.substring(fileName.lastIndexOf("/")+1, fileName.length());
        }
        return fileName;
    }
    public static List<String> getSpine(File fileName) throws FileNotFoundException, IOException, SAXException, TikaException   
    {
        if(!ZipUtil.getMimeType(fileName).contains("application/oebps-package+xml"))
        {
            return null;
        }
        Document doc = Jsoup.parse(new FileInputStream(fileName), "UTF-8",
                "", Parser.xmlParser());
       // String mimeType = ZipUtil.getMimeType(fileName);
        Elements elem = doc.getElementsByTag("spine");
        elem = elem.tagName("itemref");
        Elements elem2 = doc.getElementsByTag("manifest");
        elem2 = elem2.tagName("item");
        List<String> htmlFileNames = new LinkedList<String>();
        for(int i = 0;i<elem.size();i++)
        {
            Element el= elem.get(i);
            for(int k = 0 ;(el.children() !=null)&& k<el.children().size();k++)
            {
                Element e = el.child(k);
                String linear = el.attr("linear");
                if((linear != null) && linear.equalsIgnoreCase("no"))
                {
                    continue;
                }
                String attrValue = e .attr("idref");
                for(int j = 0;j<elem2.size() ; j++)
                {
                    Element itemElement =  elem2.get(j);
                    for(int k1 = 0;(itemElement.children()!=null)&&k1<itemElement.children().size();k1++)
                    {
                        Element e2 = itemElement.child(k1);
                        if(e2.attr("id").equals(attrValue))
                        {
                            //System.out.println(e2.attr("id") + " : : : : : : " + e2.attr("href"));
                            htmlFileNames.add(e2.attr("href"));
                            break;
                        }
                    }
                }
            }
        }
        return htmlFileNames;
    }
    public static List<Integer> convertPageRanges2List(String s)
    {
        Pattern p = Pattern.compile("^\\d+(-\\d+)?(?:,\\d+(?:-\\d+)?)*+$");
       // System.out.println(p.matcher(s).matches());
        if(p.matcher(s).matches())
        {
            ArrayList<Integer> intArray = new ArrayList<Integer>();
            String splits[] = s.split(",");
            for(String sp : splits)
            {
                if(sp.contains("-"))
                {
                    String spi [] = sp.split("-");
                Integer b1 = Integer.parseInt(spi[0]);
                Integer b2 = Integer.parseInt(spi[1]);
                if(b1<=b2)
                for(int i = b1;i<=b2;i++)
                {
                   // System.out.println(i);
                    intArray.add(i);
                }
                else if(b2<=b1)
                for(int i = b2;i<=b1;i++)
                {
                    //System.out.println(i);
                    intArray.add(i);
                }
            }
            else
            {
                intArray.add(Integer.parseInt(sp));
                //System.out.println(Integer.parseInt(sp));
            }
        }
        return intArray;
        }
        else
        {
            throw new IllegalStateException("Specify page range like with - without spaces "
                    + "and include comma within pages");
        }
        
    }
}
