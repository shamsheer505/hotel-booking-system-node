/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
24-01-2018		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.codemantra.manage.drm.model.ResendDRM;

@Document(collection = "drmDetails")
public class DRMEntityNew {
	
	@Id
	private String id;
	
	private String drmSource;
	private String orderId;
	private String orderType;
	private String clientId;
	private String clientName;
	private Date orderDate;	
	private String drmType;
	private Integer drmCutPaste;
	private Integer drmPrint;
	private Integer drmLicense;
	private List<ClientEmailEntity> clientEmail;	
	private List<OrderEntity> order;
	private Integer drmFlg;
	private Boolean isActive;
	private Boolean isDeleted;
	private Date createdOn;
	private String createdBy;
	private String orderRequestStatus;
	private List<ResendDRM> resend;
	private String clientIP;
	private String requestId;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDrmSource() {
		return drmSource;
	}
	public void setDrmSource(String drmSource) {
		this.drmSource = drmSource;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getDrmType() {
		return drmType;
	}
	public void setDrmType(String drmType) {
		this.drmType = drmType;
	}
	public Integer getDrmCutPaste() {
		return drmCutPaste;
	}
	public void setDrmCutPaste(Integer drmCutPaste) {
		this.drmCutPaste = drmCutPaste;
	}
	public Integer getDrmPrint() {
		return drmPrint;
	}
	public void setDrmPrint(Integer drmPrint) {
		this.drmPrint = drmPrint;
	}
	public Integer getDrmLicense() {
		return drmLicense;
	}
	public void setDrmLicense(Integer drmLicense) {
		this.drmLicense = drmLicense;
	}
	public List<ClientEmailEntity> getClientEmail() {
		return clientEmail;
	}
	public void setClientEmail(List<ClientEmailEntity> clientEmail) {
		this.clientEmail = clientEmail;
	}
	public List<OrderEntity> getOrder() {
		return order;
	}
	public void setOrder(List<OrderEntity> order) {
		this.order = order;
	}
	public Integer getDrmFlg() {
		return drmFlg;
	}
	public void setDrmFlg(Integer drmFlg) {
		this.drmFlg = drmFlg;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getOrderRequestStatus() {
		return orderRequestStatus;
	}
	public void setOrderRequestStatus(String orderRequestStatus) {
		this.orderRequestStatus = orderRequestStatus;
	}
	public List<ResendDRM> getResend() {
		return resend;
	}
	public void setResend(List<ResendDRM> resend) {
		this.resend = resend;
	}
	public String getClientIP() {
		return clientIP;
	}
	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
   	
}
