/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.codemantra.manage.drm.model.ResendDRM;

@Document(collection = "drmDetails")
public class DRMEntity {
	
	@Id
	private String id;
	
	private String drmId;
	private String drmSource;
	private String clientName;
	private String clientEmailId;
	private String isbn;
	private String formatId;
	private String orderType="BUY";	
	private Integer noOfDevices;
	private Boolean readPermission;
	private Integer noOfDays;
	private Boolean printCopyPermission;
	private Integer printPages;
	private Integer copyPages;
	private String downloadStatus;
	private Date downloadCompletedOn;
	private Boolean isActive;
	private Boolean isDeleted;
	private Date createdOn;
	private String createdBy;
	private Integer drmFlg;
	private List<ResendDRM> resend;
	private String creator;
	private String drmRequestStatus;
	//private String fileId;
	private String formatName;
	private Integer fileId;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDrmId() {
		return drmId;
	}
	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}
	public String getDrmSource() {
		return drmSource;
	}
	public void setDrmSource(String drmSource) {
		this.drmSource = drmSource;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientEmailId() {
		return clientEmailId;
	}
	public void setClientEmailId(String clientEmailId) {
		this.clientEmailId = clientEmailId;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public Integer getNoOfDevices() {
		return noOfDevices;
	}
	public void setNoOfDevices(Integer noOfDevices) {
		this.noOfDevices = noOfDevices;
	}
	public Boolean getReadPermission() {
		return readPermission;
	}
	public void setReadPermission(Boolean readPermission) {
		this.readPermission = readPermission;
	}
	public Integer getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}
	public Boolean getPrintCopyPermission() {
		return printCopyPermission;
	}
	public void setPrintCopyPermission(Boolean printCopyPermission) {
		this.printCopyPermission = printCopyPermission;
	}
	public Integer getPrintPages() {
		return printPages;
	}
	public void setPrintPages(Integer printPages) {
		this.printPages = printPages;
	}
	public Integer getCopyPages() {
		return copyPages;
	}
	public void setCopyPages(Integer copyPages) {
		this.copyPages = copyPages;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public Date getDownloadCompletedOn() {
		return downloadCompletedOn;
	}
	public void setDownloadCompletedOn(Date downloadCompletedOn) {
		this.downloadCompletedOn = downloadCompletedOn;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getDrmFlg() {
		return drmFlg;
	}
	public void setDrmFlg(Integer drmFlg) {
		this.drmFlg = drmFlg;
	}
	public List<ResendDRM> getResend() {
		return resend;
	}
	public void setResend(List<ResendDRM> resend) {
		this.resend = resend;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getDrmRequestStatus() {
		return drmRequestStatus;
	}
	public void setDrmRequestStatus(String drmRequestStatus) {
		this.drmRequestStatus = drmRequestStatus;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public String getFormatName() {
		return formatName;
	}
	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}
	
   	
}
