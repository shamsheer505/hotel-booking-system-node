/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.codemantra.manage.drm.model.DRM;
import com.codemantra.manage.drm.model.DRMNew;
import com.codemantra.manage.drm.model.Watermark;
import com.codemantra.manage.drm.util.DRMDisplay;
import com.codemantra.open.drm.request.entity.RequestEntity;
import com.codemantra.open.drm.request.entity.ResponseEntity;

public interface DRMService {	
	
	//public Map<String, Object> saveDRM(DRM modeoObj, String loggedUser);
	
	public Map<String, Object> resend(DRM modelObj, String id, String loggedUser);
	
	public Map<String, Object> retrieveAllDRMRecords();
	
	public Map<String, Object> getEligibleFormats(String loggedUser);
	
	public Map<String, Object> save(DRMNew modeoObj, String loggedUser);
	
	public Map<String, Object> saveDRMInternal(DRM modelObj, String loggedUser);
	
	public Map<String, Object> saveWaterMark(Watermark modelObj, String loggedUser);
	
	public Map<String, Object> retrieveWatermark(String id);
	
	public Map<String, Object> reorderDRM(DRMNew modelObj, String loggedUser);
	
	public Map<String, Object> reorderWatermark(Watermark modelObj, String loggedUser);
	
	// JP
	
	public Map<String, Object> listDrmPendingDetails();
	
	public Map<String, Object> updateDrm(String formatId,String loggedUser);
	public InputStream downloadFileAsStream(String bucketName, String objectKey);
	
	public List<DRMDisplay> getDRM(String id);
	
	public String getCover(String ISBN);
        public Map<String, Object> extractWatermark(String loggedUser, File multiPartFile, String clientIp) throws IOException, Exception;
        public ResponseEntity extractPdfWatermark(RequestEntity entity)   throws   Exception;
        public ResponseEntity extractEpubWatermark(RequestEntity entity) throws Exception;
        public ResponseEntity extractMobiWatermark(RequestEntity entity) throws Exception;

}
