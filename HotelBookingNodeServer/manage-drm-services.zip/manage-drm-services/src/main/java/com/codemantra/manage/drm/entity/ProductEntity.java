/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
13-06-2017			v1.0       	     Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.drm.entity;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


@Document(collection = "products")
public class ProductEntity {

	@Field("asset")
	private List<AssetEntity> assest;

	public List<AssetEntity> getAssest() {
		return assest;
	}

	public void setAssest(List<AssetEntity> assest) {
		this.assest = assest;
	}
	

}
