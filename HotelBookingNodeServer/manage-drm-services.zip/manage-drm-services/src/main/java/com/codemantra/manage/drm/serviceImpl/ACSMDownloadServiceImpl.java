package com.codemantra.manage.drm.serviceImpl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.codemantra.manage.drm.dao.DRMDao;
import com.codemantra.manage.drm.entity.DRMEntityNew;
import com.codemantra.manage.drm.entity.OrderEntity;
import com.codemantra.manage.drm.entity.TScheduleRunTime;
import com.codemantra.manage.drm.service.ACSMDownloadService;

@Service("acsmService")
@EnableScheduling
public class ACSMDownloadServiceImpl implements ACSMDownloadService {

	private static final Logger logger = LoggerFactory.getLogger(ACSMDownloadServiceImpl.class);

	@Autowired
	DRMDao masterDao;
	
	@Value("${spring.datasource.query}")
	String query;
	
	@Value("${date.lastRun}")
	String lastRunDate;
	
	@Value("${date.timeZone}")
	String timeZone;
	
	@Value("${FORMAT.TEMPLATE.DATE}")
	String timeFormat;
	

	@Scheduled(fixedRate = 900000)//Every 15 mins
	public void acsmDownloadDateUpdate() {
		updateDRMDetails();
	}

	private void updateDRMDetails() {

		List<String> transactionIds = new ArrayList<>();
		Date nextRun = null;
		ZonedDateTime userDateTime = null;
		String dateStamp = null;
		try {
			TScheduleRunTime runTime = masterDao.getLastRun("DRM");
			Date date = null;
			if(null != runTime) {
				date = runTime.getLastRun();
				logger.info("last run time to update transactiondate : "+date);
				userDateTime = ZonedDateTime.now(ZoneId.of(timeZone));
				dateStamp = DateTimeFormatter.ofPattern(timeFormat).format(userDateTime);
				nextRun = new SimpleDateFormat(timeFormat).parse(dateStamp);
			}else {
				 date = new SimpleDateFormat(timeFormat).parse(lastRunDate);
				 userDateTime = ZonedDateTime.now(ZoneId.of(timeZone));
				 dateStamp = DateTimeFormatter.ofPattern(timeFormat).format(userDateTime);
				 nextRun = new SimpleDateFormat(timeFormat).parse(dateStamp);
			}
	    	Calendar cal = Calendar.getInstance();
	    	cal.setTime(date);
	    	cal.set(Calendar.MILLISECOND, 0);
            Timestamp timeStamp  = new java.sql.Timestamp(date.getTime());
            logger.info("SQL Query :" +query);
			Map<String, Date> acsmdownloadMap = masterDao.fetchACSMDownloadedData(timeStamp, query);
			if (null != acsmdownloadMap) {
				for (Map.Entry<String, Date> entry : acsmdownloadMap.entrySet()) {
					transactionIds.add(entry.getKey());
					logger.info("transId : "+entry.getKey());
					logger.info("transtime : "+entry.getValue());
				}
			}
			Map<String, Object> drmDetailsByTransId = new HashMap<String, Object>();
			drmDetailsByTransId.put("order.acsmTransactionId", transactionIds);
			List<DRMEntityNew> drmEntityList = (List<DRMEntityNew>) masterDao.getAllEntityObjects(new DRMEntityNew(),
					drmDetailsByTransId);

			if (null != drmEntityList) {
				for (DRMEntityNew drmEntity : drmEntityList) {
					if (null != drmEntity.getOrder() && drmEntity.getOrder().size() > 0) {
						for (OrderEntity orderEntity : drmEntity.getOrder()) {
							Date downloadedDate = acsmdownloadMap.get(orderEntity.getAcsmTransactionId());
							if (null != downloadedDate) {
								DateFormat formatterIST = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								formatterIST.setTimeZone(TimeZone.getTimeZone("America/New_York"));
								TimeZone timeZone = formatterIST.getTimeZone();
								if(timeZone.useDaylightTime()) {	
								downloadedDate = DateUtils.addHours(downloadedDate, 5);
								}else {
									downloadedDate = DateUtils.addHours(downloadedDate, 4);
								}
								logger.info("date after convertion to UTC "+downloadedDate);
								orderEntity.setDownloadedDate(downloadedDate);
								orderEntity.setDownloadStatus("Completed");
								boolean flag = masterDao.updateEntityObject(drmEntity);
								if (flag) {
									logger.info("DRM document with transId " + orderEntity.getAcsmTransactionId() + " updated with downloaded date " + downloadedDate);
								}
							}
						}
					}
				}
			}
			logger.info("updation completed");
			runTime = new TScheduleRunTime();
			runTime.setName("DRM");
			runTime.setLastRun(nextRun);
			masterDao.updateLastRuntime(runTime);

		} catch (Exception e) {
			logger.error("Error while updating DRM details with downloaded time "+e.getMessage());
			e.printStackTrace();
		}

	}

}
