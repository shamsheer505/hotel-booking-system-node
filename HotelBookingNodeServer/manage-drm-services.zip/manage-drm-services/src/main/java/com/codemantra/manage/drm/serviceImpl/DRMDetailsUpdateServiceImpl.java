package com.codemantra.manage.drm.serviceImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.codemantra.manage.drm.dao.DRMDao;
import com.codemantra.manage.drm.entity.DRMEntityNew;
import com.codemantra.manage.drm.entity.OrderEntity;
import com.codemantra.manage.drm.model.DRMDetailsVO;
import com.opencsv.bean.CsvToBeanBuilder;

@Service("drmDetailsUpdate")
public class DRMDetailsUpdateServiceImpl {

	@Autowired
	DRMDao masterDao;

	@Value("${DRM.FOLDER.PATH}")
	String folderPath;

	@Value("${DRM.FOLDER.BACKUP.PATH}")
	String backupFolderPath;

	@Value("${FORMAT.TEMPLATE.DATE}")
	String templateDateFormat;

	private static final Logger logger = LoggerFactory.getLogger(DRMDetailsUpdateServiceImpl.class);

	static boolean flag = false; 
	
	@Scheduled(fixedRate = 14400000)
	public void startDRMDetailsUpdateProcess() {
		if(!flag)
		 flag = ProcessDRMDetailsUpdate();
	}

	private boolean ProcessDRMDetailsUpdate() {
		
		SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = sm.format(new Date());
		logger.info("folder path "+folderPath);
		File file1 = new File(folderPath);
		String filePath = "";
		String fileProcessing = "";
		Boolean hasExcelFile = false;
		List<DRMDetailsVO> list = null;

		if (file1.isDirectory()) {
			for (File temp : file1.listFiles()) {
				filePath = folderPath + File.separator + temp.getName();
				fileProcessing = temp.getName();
				logger.info("Trying to access File::" + filePath);
				logger.info("Trying to access File Length::" + temp.length());
				Long prevLength = temp.length();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					logger.error("Error occurred while accessing file::" + e.getMessage());
				}
				Long newlength = temp.length();

				while (prevLength < newlength) {
					prevLength = newlength;
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					newlength = temp.length();
				}
				hasExcelFile = true;
				break;
			}
			if (!hasExcelFile)
				return false;
			try {
				Files.move(new File(filePath).toPath(),
						new File(backupFolderPath + File.separator + "Done_" + strDate + "_" + fileProcessing)
								.toPath());
				filePath = backupFolderPath + File.separator + "Done_" + strDate + "_" + fileProcessing;
			} catch (IOException e) {
				e.printStackTrace();
			}

			try {
				//@SuppressWarnings({ "unchecked", "rawtypes" })
				 list = new CsvToBeanBuilder(new FileReader(filePath)).withType(DRMDetailsVO.class)
						.build().parse();
				LinkedHashMap<String, Object> contentCriteriaMap = new LinkedHashMap<>();
				int counter = 0;
				if (null != list) {
					logger.info("started the process of updating drm details with trans id");
					for (DRMDetailsVO drmVO : list) {
						contentCriteriaMap.put("order.drmId", drmVO.getDrmId());
						DRMEntityNew drmEntity = masterDao.getEntityObject(new DRMEntityNew(), contentCriteriaMap);
						if (null != drmEntity && null != drmEntity.getOrder() && drmEntity.getOrder().size() > 0) {
							for (OrderEntity orderEntity : drmEntity.getOrder()) {
								if (null != orderEntity.getDrmId()
										&& orderEntity.getDrmId().equalsIgnoreCase(drmVO.getDrmId())) {
									orderEntity.setAcsmTransactionId(drmVO.getAcsmTransactionId());
									Date date =  masterDao.fetchACSMTransactionDate(drmVO.getAcsmTransactionId());
									if(null != date) {
										DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
										formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
										TimeZone timeZone = formatterUTC.getTimeZone();
										if(timeZone.useDaylightTime()) {
											date = DateUtils.addHours(date, 5);
										}else {
											date = DateUtils.addHours(date, 4);	
										}
										orderEntity.setDownloadedDate(date);
										orderEntity.setDownloadStatus("Completed");
									}
								}
							}
							boolean flag = masterDao.updateEntityObject(drmEntity);
							if (flag) {
								logger.info("updated drm details with drmId " + drmVO.getDrmId() + " with transId "
										+ drmVO.getAcsmTransactionId());
								counter++;
							} else {
								logger.info("failed to update drm details with drmId " + drmVO.getDrmId()
										+ " with transId " + drmVO.getAcsmTransactionId());
							}
						}
						contentCriteriaMap.clear();
					}
					logger.info("update completed.");
					logger.info("Total no of documents updated : "+counter);
				}

			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}
		return true;
	}
}
