
/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.controller;


import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.codemantra.manage.drm.dto.APIResponse;
import com.codemantra.manage.drm.dto.APIResponse.ResponseCode;
import com.codemantra.manage.drm.dto.Status;
import com.codemantra.manage.drm.model.DRM;
import com.codemantra.manage.drm.model.DRMNew;
import com.codemantra.manage.drm.model.Watermark;
import com.codemantra.manage.drm.service.DRMService;
import com.codemantra.manage.drm.util.DRMDisplay;
import com.codemantra.open.drm.request.entity.RequestEntity;

@CrossOrigin
@RestController
@RequestMapping("/manage-drm-service/")
public class DRMController {
	private static final Logger logger = LoggerFactory.getLogger(DRMController.class);

	@Autowired
	DRMService service;
/*	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "drm", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> saveDRM(@RequestBody DRM modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.saveDRM(modelObj, loggedUser);
			finalData = service.saveDRM(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}*/
	
	//@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "drminternal", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> saveDRMInternal(@RequestBody DRM modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser,HttpServletRequest request) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "] on "+ request.getRemoteAddr());
		modelObj.setClientIP(request.getRemoteAddr());
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.saveDRMInternal(modelObj, loggedUser);
			//finalData = service.saveDRM(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "drm", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> saveDRM(@RequestBody DRMNew modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser,HttpServletRequest request) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "] on "+ request.getRemoteAddr());
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		modelObj.setClientIP(request.getRemoteAddr());
		Status status = null;
		try {
			/*finalData = service.saveDRM(modelObj, loggedUser);*/
			finalData = service.save(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "resend/{id}", method = RequestMethod.PUT, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> resend(@RequestBody DRM modelObj, @PathVariable String id,
			@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("URI Parameters :: Id [" + id + "]");
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.resend(modelObj, id, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "drm/reorder", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> reorderDRM(@RequestBody DRMNew modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser,HttpServletRequest request) {
		//logger.info("URI Parameters :: Id [" + id + "]");
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		modelObj.setClientIP(request.getRemoteAddr());
		Status status = null;
		try {
			finalData = service.reorderDRM(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "drm", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody
	public APIResponse<Object> retrieveAll(@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.retrieveAllDRMRecords();
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());
			
			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());	
			

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@RequestMapping(value = "drm/{id}", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody
	
	public APIResponse<Object> getdrm(@PathVariable String id
			) {
		logger.info("URI Parameters :: Id [" + id + "]");
		
		APIResponse<Object> response = new APIResponse<Object>();
		List<DRMDisplay> drmEntity=null;
		//Status status = null;
		try {
			drmEntity = service.getDRM(id);
			response.setData(drmEntity);
			response.setCode("200");
			response.setStatus("SUCCESS");
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			
			response.setData(null);
			response.setCode("400");
			response.setStatus("ERROR");
			response.setStatusMessage(e.getMessage());
		}
		return response;
	}
	
	@RequestMapping(value = "cover/{isbn}", method = RequestMethod.GET)
	@ResponseBody
	
	public APIResponse<Object> getTitleCover(@PathVariable String isbn) {
		logger.info("URI Parameters :: for Getting cover [" + isbn + "]");
		
		
		APIResponse<Object> response = new APIResponse<Object>();
	
		String coverStr=service.getCover(isbn);
		if(coverStr.equalsIgnoreCase("NO_COVER"))
		{
			response.setCode("500");
			response.setData("nocover");
			response.setStatus("ERROR");
		}
		else{
			response.setCode("200");
			response.setData("data:image/png;base64,"+coverStr);
			response.setStatus("Success");
		}
		return response;
	
	}
	
	@RequestMapping(value = "eligibleFormats", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> getEligibleFormats(@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.getEligibleFormats(loggedUser);
			status = (Status) finalData.get("status");

			if(status.getCode().equals("REQUEST_FORBIDDEN"))
				response.setCode(ResponseCode.FORBIDDEN.toString());
			else {
				if (status.isStatus())
					response.setCode(ResponseCode.SUCCESS.toString());
				else
					response.setCode(ResponseCode.ERROR.toString());
			}
			
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());		
			finalData.remove("status");
			response.setData(finalData);
			

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "watermark", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> saveWatermark(@RequestBody Watermark modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser,HttpServletRequest request) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "] on "+ request.getRemoteAddr());
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		modelObj.setClientIP(request.getRemoteAddr());
		try {
			finalData = service.saveWaterMark(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	
    @RequestMapping(value = "watermark/{id}", method = RequestMethod.GET, consumes = "application/json")
    @ResponseBody
   
    public APIResponse<Object> retrieveWatermark(@PathVariable String id) {
    	logger.info("URI Parameters :: ID ["+id+"]");
    	APIResponse<Object> response = new APIResponse<Object>();	
    	Map<String, Object> finalData = null;
    	Status status = null;
    	
    	try {    		
    			finalData = service.retrieveWatermark(id);  
    			status = (Status) finalData.get("status");
    			if(status.getCode().equals("REQUEST_FORBIDDEN"))
    				response.setCode(ResponseCode.FORBIDDEN.toString());
    			else {
    				if (status.isStatus())
    					response.setCode(ResponseCode.SUCCESS.toString());
    				else
    					response.setCode(ResponseCode.ERROR.toString());
    			}

				response.setStatus(status.getCode());
				response.setStatusMessage(status.getMessage());
				finalData.remove("status");	
    			response.setData(finalData);
    	} catch(Exception e) {
    		logger.error("Exception :: ", e);
    	}      
        return response;    
    }
    
    

	
	@PreAuthorize("hasAuthority('DRM')")
	@RequestMapping(value = "watermark/reorder", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> reorderWatermark(@RequestBody Watermark modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser,HttpServletRequest request) {
		//logger.info("URI Parameters :: Id [" + id + "]");
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		modelObj.setClientIP(request.getRemoteAddr());
		Status status = null;
		try {
			finalData = service.reorderWatermark(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
        @Autowired
        private HttpServletRequest request;
        @RequestMapping(value="extractwatermark",
                 method=RequestMethod.POST,
                 consumes={MediaType.APPLICATION_JSON_VALUE},
                 produces={MediaType.APPLICATION_JSON_VALUE})
      //  @PreAuthorize("hasAuthority('DRM')")
         public APIResponse<Object> extractWatermark(@RequestBody RequestEntity entity)
         {
             APIResponse<Object> response = new APIResponse<>();
            // String deviceFormat = request.getParameter("deviceFormat");
            // Iterator<String> iterator = req.getFileNames();
             
            // MultipartFile multiFile = req.getFile(iterator.next());
             Map<String, Object> temp = null;
            try {
                String loggedUser = request.getParameter("loggedUser");
                temp = service.extractWatermark(loggedUser, new File(entity.getInputFileName()),request.getRemoteAddr());
                response.setData(temp);
                response.setCode("200");
                response.setStatus("Success");
                response.setStatusMessage("Client Information Extracted Successfully");
            } catch (Exception ex) {
                java.util.logging.Logger.getLogger(DRMController.class.getName()).log(Level.SEVERE, null, ex);
            }
              return response;
         }
	
}

