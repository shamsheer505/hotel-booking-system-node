/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.drm.model;

import java.util.Date;

public class ResendDRM{


	private Date resendOn;
	private String resendBy;
	private String remarks;
	
	public String getResendBy() {
		return resendBy;
	}
	public void setResendBy(String resendBy) {
		this.resendBy = resendBy;
	}
	public Date getResendOn() {
		return resendOn;
	}
	public void setResendOn(Date resendOn) {
		this.resendOn = resendOn;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
}
