/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.drm.daoImpl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;
import static org.springframework.data.mongodb.core.aggregation.ArrayOperators.Filter.filter;
import static org.springframework.data.mongodb.core.aggregation.VariableOperators.mapItemsOf;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.bson.types.ObjectId;
import org.jongo.Jongo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.ComparisonOperators;
import org.springframework.data.mongodb.core.aggregation.Fields;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.codemantra.manage.drm.dao.DRMDao;
import com.codemantra.manage.drm.entity.AssetEntity;
import com.codemantra.manage.drm.entity.AuditLogs;
import com.codemantra.manage.drm.entity.AwsAPIEntity;
import com.codemantra.manage.drm.entity.DRMEntityNew;
import com.codemantra.manage.drm.entity.FileDetailEntity;
import com.codemantra.manage.drm.entity.ListDrmEntity;
import com.codemantra.manage.drm.entity.ListFormatEntity;
import com.codemantra.manage.drm.entity.ProductEntity;
import com.codemantra.manage.drm.entity.SequenceId;
import com.codemantra.manage.drm.entity.TScheduleRunTime;
import com.codemantra.manage.drm.entity.WatermarkEntity;
import com.codemantra.manage.drm.model.KeyValue;
import com.codemantra.manage.drm.model.UserInfo;
import com.mongodb.BasicDBObject;
import com.mongodb.WriteResult;


@Repository
@Qualifier("drmDao")
public class DRMDaoImpl implements DRMDao{
	
	private static final Logger logger = LoggerFactory.getLogger(DRMDaoImpl.class);
	
	@Autowired
	MongoTemplate mongoTemplate;
	@Autowired
	MongoOperations mongoOperations;
	@Autowired
	Jongo jongo;
	@Autowired
	MySqlConnectionPool mySqlConnectionPool;

	/**
	 * This Method is used to retrieve a document from a collection using single criteria for filtering out the document
	 * Parameter 'criteriaFieldName' is used to get the name of the criteria field
	 * Parameter 'criteriaFieldValue' is used to get the value of the criteria field
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getEntityObject(T masterObj, String criteriaFieldName, String criteriaFieldValue) {
		
		try {
			Query query = new Query();			
			
			query.addCriteria(Criteria.where(criteriaFieldName).is(criteriaFieldValue));  
			logger.info("Query ["+query+"]");
			masterObj = (T) mongoTemplate.findOne(query, masterObj.getClass());
			logger.info("Master Data ["+masterObj+"]");
		} catch (Exception e) {
			logger.error("Exception occured while retrieving Master Data by Name :: "+e);
			masterObj = null;
		}
		
		return masterObj;
	}

	/**
	 * This Method is used to retrieve a document from a collection using multiple criteria for filtering out the document
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the document to be retrieved
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getEntityObject(T masterObj, Map<String, Object> criteriaMap) {

		try {
			Query query = new Query();

			if (criteriaMap != null && criteriaMap.size() > 0) {
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());
				criteriaMap.forEach((k, v) -> {
					if (v instanceof Collection<?>) {
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					} else
						criterias.add(Criteria.where(k).is(v));
				});
				criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
				query.addCriteria(criteria);
			}

			logger.info("Query [" + query + "]");
			masterObj = (T) mongoTemplate.findOne(query, masterObj.getClass());
			logger.info("Master Data [" + masterObj + "]");
		} catch (Exception e) {
			logger.error("Exception occured while retrieving Master Data by Name :: " + e);
			masterObj = null;
		}

		return masterObj;
	}
	
/*	@SuppressWarnings("unchecked")
	public <T> T getEntityObject(String collection, T masterObj, List<Criteria> criteriaList, String unwindField) {
		
		try {
			Criteria criteria = new Criteria().andOperator(criteriaList.toArray(new Criteria[criteriaList.size()]));
			Aggregation aggregation;
			
			if(null == unwindField){
				aggregation = newAggregation(
						match(criteria)	        
				    );
			}else{
				aggregation = newAggregation(
						unwind(unwindField),
						match(criteria)	        
				    );
			}
			
			AggregationResults<T> groupResults =  (AggregationResults<T>) mongoTemplate.aggregate(aggregation, collection, masterObj.getClass());
			
			System.out.println(new Gson().toJson(groupResults));
			
			if(groupResults.getMappedResults().size() == 1)
				masterObj = groupResults.getMappedResults().get(0);	
			else
				masterObj = null;
		} catch (Exception e) {
			logger.info("Exception occured while updating Master :: "+e);
			masterObj = null;
		}
		
		return masterObj;
	}*/
	
	/**
	 * This Method is used to retrieve the next sequence id from a particular sequence
	 * Parameter 'key' filters out the sequence whose next value is to be retrieved
	 */	
	
	@Override
	public String getNextSequenceId(String key){
		logger.info("Sequence Key ["+key+"]");
		SequenceId seqId = null;		
		
		try{
			Query query = new Query(Criteria.where("_id").is(key));	
			Update update = new Update();
		    update.inc("seq", 1);
			FindAndModifyOptions options = new FindAndModifyOptions();
			options.returnNew(true);
			
			seqId =  mongoOperations.findAndModify(query, update, options, SequenceId.class);
		}catch (Exception e) {
			logger.error("Exception occured while generating id for Master :: "+e);
			seqId = null;
		}
		
		if(null == seqId)
			return "-1";
		else
			return(String.format("%09d", seqId.getSeq()));
	}

	/**
	 * This Method is used to save a document inside a collection using Entity Object of the collection
	 * Parameter 'masterObj' is used to get the entity object(document) to be saved
	 */

	@Override
	public <T> boolean saveEntityObject(T masterObj) throws Exception {
		boolean result = false;
		try {
			
			mongoTemplate.insert(masterObj);
			
			result = true;
			
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			throw e;		
		} 
		return result;
	}

	/**
	 * This Method is used to retrieve all the documents inside a collection, using Entity Class T to identify the collection
	 */
	
	@Override
	public <T> List<?> getAllEntityObjects(T masterObj) {
		List<?> masterObjects = null;
		
		try {				
			Query query = new Query();			
			/** Deleted Master Objects should not be retrieved **/
			query.addCriteria(Criteria.where("isDeleted").is(false));			
			logger.info("Query ["+query+"]");
			
			masterObjects = mongoOperations.find(query, masterObj.getClass());			
			
		} catch (Exception e) {
			logger.error("Exception occured while retrieving Account list :: "+e.getMessage());
			throw e;
		}
		return masterObjects;
	}
	
	
	/**
	 * This Method is used to retrieve multiple documents from a collection, filtered using a set of criteria
	 * The class Type 'T' of parameter masterObj is used to identify the collection and the bucket class
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents to be retrieved
	 */
	
	@Override
	public <T> List<?> getAllEntityObjects(T masterObj, Map<String, Object> criteriaMap) {
		List<?> masterObjects = null;
		
		try {				
			Query query = new Query();
			
			if(criteriaMap != null && criteriaMap.size() > 0){
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			    query.addCriteria(criteria);
			}
			
			masterObjects = mongoOperations.find(query, masterObj.getClass());			
			
		} catch (Exception e) {
			logger.error("Exception occured while retrieving Account list :: "+e.getMessage());
			throw e;
		}
		return masterObjects;
	}
	
	/**
	 * This Method is used to retrieve key-value pairs across multiple documents/sub-documents in a collection filtered using single criteria
	 * Parameter 'keyField' is used to get the name of the key field
	 * Parameter 'valueField' is used to get the name of the value field
	 * Parameter 'criteriaFieldName' is used to get the name of the field to be used for filtering out the documents/sub-documents
	 * Parameter 'criteriaFieldValue' is used to get the value of the criteria field for filtering out the documents/sub-documents
	 * Parameter 'unwindField', is used to get the name of the unwind field, if unwinding is needed else null
	 */
	
	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField, String criteriaFieldName, U criteriaFieldValue, String unwindField) {
		
		List<KeyValue> result = null;
		try {
			
			Aggregation aggregation;
			
			if(null == unwindField){
				aggregation = newAggregation(
						match(Criteria.where(criteriaFieldName).is(criteriaFieldValue)),
						project(Fields.fields().and("key", keyField).and("value",valueField))	        
				    );
			}else{
				aggregation = newAggregation(
						unwind(unwindField),
						match(Criteria.where(criteriaFieldName).is(criteriaFieldValue)),
						project(Fields.fields().and("key", keyField).and("value",valueField))		        
				    );
			}
			
			AggregationResults<KeyValue> groupResults =  mongoTemplate.aggregate(aggregation, collection, KeyValue.class);
		    result = groupResults.getMappedResults();			
		} catch (Exception e) {
			logger.info("Exception occured while updating Master :: "+e);
			result = null;
		}
		
		return result;
	}
	
	/**
	 * This Method is used to retrieve key-value pairs across multiple documents/sub-documents in a collection filtered using multiple criteria
	 * Parameter 'keyField' is used to get the name of the key field
	 * Parameter 'valueField' is used to get the name of the value field
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents/sub-documents
	 * Parameter 'unwindField', is used to get the name of the unwind field, if unwinding is needed else null
	 */
	
	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField, Map<String, Object> criteriaMap, String unwindField) {
		
		List<KeyValue> result = null;
		Criteria criteria =  new Criteria();
		try {				
			if(criteriaMap != null && criteriaMap.size() > 0){
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));					
			}
			
			Aggregation aggregation;
			
			if(null == unwindField){
				aggregation = newAggregation(
						match(criteria),
						project(Fields.fields().and("key", keyField).and("value",valueField))	        
				    );
			}else{
				aggregation = newAggregation(
						unwind(unwindField),
						match(criteria),
						project(Fields.fields().and("key", keyField).and("value",valueField))		        
				    );
			}
			
			AggregationResults<KeyValue> groupResults =  mongoTemplate.aggregate(aggregation, collection, KeyValue.class);
		    result = groupResults.getMappedResults();			
		} catch (Exception e) {
			logger.info("Exception occured while Retrieving Data in getSingleFieldValueList :: "+e);
			result = null;
		}
		
		return result;
	}

	/**
	 * This Method is used to save/update (upsert) a document inside a collection using Entity Object of the collection
	 */
	@Override
	public <T> boolean updateEntityObject(T masterObj) {
		boolean result = false;
		try {

			mongoTemplate.save(masterObj);
			result = true;

		} catch (Exception e) {
			logger.info("Exception occured while updating Master :: "+e);
			result = false;			
		} 
		return result;
	}

	/**
	 * This Method is used to update a document/documents inside a collection without using Entity Object of the collection with single criteria and single field update
	 * Parameter 'criteriaFieldName' is used to get the name of the criteria field
	 * Parameter 'criteriaFieldValue' is used to get the value of the criteria field
	 * Parameter 'updateFieldName' is used to get the name of the field to be updated in the document
	 * Parameter 'updateFieldValue' is used to get the value to be updated for the 'updateFieldName'
	 */

	@Override
	public <T> boolean updateCollectionDocument(String collection, String criteriaFieldName, String criteriaFieldValue, String updateFieldName, T updateFieldValue){
		WriteResult wrResult;
		try{
			Query query = new Query();
			query.addCriteria(Criteria.where(criteriaFieldName).is(criteriaFieldValue));

			Update update = new Update();

			update.set(updateFieldName, updateFieldValue);
			
			wrResult = mongoTemplate.updateMulti(query, update, collection);
			
			logger.info("No. of documents updated "+wrResult.getN());
		}catch(Exception e){
			logger.error("Exception :: ", e);
			return false;
		}
		return (wrResult.getN() > 0);
		
	}
	
	
	/**
	 * This Method is used to update a document/documents inside a collection without using Entity Object of the collection with multiple criteria and multiple field update
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents to be updated
	 * Parameter 'updateMap' is used to get the names and new values of the fields to updated in the document
	 */
	@Override
	public <T> boolean updateCollectionDocument(String collection, Map<String, Object> criteriaMap, Map<String, Object> updateMap){
		WriteResult wrResult;
		try{
			Query query = new Query();			
			if(criteriaMap != null && criteriaMap.size() > 0){
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			    query.addCriteria(criteria);
			}

			Update update = new Update();			
			updateMap.forEach((k,v) -> update.set(k, v));
			
			wrResult = mongoTemplate.updateMulti(query, update, collection);
			
			logger.info("No. of documents updated "+wrResult.getN());
		}catch(Exception e){
			logger.error("Exception :: ", e);
			return false;
		}
		return (wrResult.getN() > 0);		
	}
	
	/**
	 * This Method is used to get the number of documents inside a collection
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents
	 */

	@Override
	public Integer getCountOfDocuments(String collection, LinkedHashMap<String, Object> criteriaMap) {
		Integer docCount=0;
		
		try {				
			Query query = new Query();	
			
			if(criteriaMap != null && criteriaMap.size() > 0){
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			    query.addCriteria(criteria);
			}
			logger.info("Query ["+query+"]");
			docCount = (int) mongoTemplate.count(query, collection);
					
			logger.info("Document Count -"+docCount);
			
		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return docCount;
	}
	
	/**
	 * This Method is used to get the number of documents inside a collection
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents
	 */

	@Override
	public Integer getCountOfDocuments(String collection, Criteria criteria) {
		Integer docCount=0;
		
		try {				
			Query query = new Query();
			
			/*if(criteriaMap != null && criteriaMap.size() > 0){
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			    query.addCriteria(criteria);
			}*/
			
			query.addCriteria(criteria);
			logger.info("Query ["+query+"]");
			docCount = (int) mongoTemplate.count(query, collection);
					
			logger.info("Document Count -"+docCount);
			
		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return docCount;
	}
	


	/**
	 * This Method is used to save a List of documents inside a collection Parameter
	 * 'entityObjList' is used to get the entity object(document) List to be saved
	 */

	@Override
	public <T> boolean saveEntityObjectList(Collection<T> entityObjList) throws Exception {
		boolean result = false;
		System.out.println("Inside saveEntityObjectList");
		try {

			mongoTemplate.insertAll(entityObjList);
			result = true;

		} catch (Exception e) {
			logger.error("Exception :: ", e);
			throw e;
		}
		return result;
	}
	
	/**
	 * This Method is used to join two collections
	 * 'masterObj' is used to get bean which will store the joined result
	 * 'collection' is used to get source collection name - (from collection)
	 * 'criteriaMap' is used to filter out the result
	 * 'lookupOperation' is used get the information about the join - the other joining collection name, the linking field names ( local field & foreign field), & join result alias
	 * 'unwindField' is used to get the field name for unwinding, if unwinding is required, else null
	 */

	@Override
	public <T> List<?> joinCollections(T masterObj, String collection, Map<String, Object> criteriaMap,
			LookupOperation lookupOperation, String unwindField) {
		List<?> joinedObjects = null;
		Criteria criteria = new Criteria();

		try {
			if (criteriaMap != null && criteriaMap.size() > 0) {
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());
				criteriaMap.forEach((k, v) -> {
					if (v instanceof Collection<?>) {
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					} else
						criterias.add(Criteria.where(k).is(v));
				});
				criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			}

			Aggregation aggregation;

			if (null == unwindField) {
				aggregation = newAggregation(match(criteria), lookupOperation);
			} else {
				aggregation = newAggregation(match(criteria), lookupOperation, unwind(unwindField));
			}

			AggregationResults<?> groupResults = mongoTemplate.aggregate(aggregation, "mUser", masterObj.getClass());
			joinedObjects = groupResults.getMappedResults();

		} catch (Exception e) {
			logger.error("Exception occured while joining collections :: " , e);
			joinedObjects = null;
		}

		return joinedObjects;

	}
	
	/**
	 * This Method is used to run native mongodb queries
	 * 'masterObj' is used to get bean which will store the query result
	 * 'query' is used to get query to run
	 * 'parameters' is used to query parameter array
	 */
	
	public <T> List<?> runNativeMongoQuery(T masterObj, String query, Object... parameters) {
		List<?> results = new LinkedList<>();
		
		logger.info("Query ["+query+"]");
		logger.info("parameters ["+parameters+"]");

		try {
			if(parameters.length == 0)
				results = jongo.runCommand(query).field("result").as(masterObj.getClass());
			else
				results = jongo.runCommand(query, parameters).field("result").as(masterObj.getClass());
			
		} catch (Exception e) {
			logger.error("Exception in executing native mongo query :: ", e);
		}

		return results;
	}


	
	///////////// JP  ////////////////////////
	
	@Override
	public List<ListDrmEntity> listDrmPendingDetails() {

		List<ListDrmEntity> listDrmPendingDetails;
		Map<String, String> listOfDRM = new HashMap<>();
		try {

			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(true));
			logger.info("Query [" + query + "]");
			listDrmPendingDetails = (List<ListDrmEntity>) mongoOperations.find(query, ListDrmEntity.class, "drmDetails");
			/*for (ListDrmEntity listDrm : listDrmPendingDetails) {
				listOfDRM.put("drmId",listDrm.getDrmId());
				listOfDRM.put("isbn",listDrm.getIsbn());
				listOfDRM.put("formatId",listDrm.getFormatId());
				listOfDRM.put("noOfDays",listDrm.getNoOfDays());
				listOfDRM.put("noOfDevices",listDrm.getNoOfDevices());
				listOfDRM.put("readPermission", listDrm.getReadPermission());
				listOfDRM.put("printCopyPermission", listDrm.getPrintCopyPermission());
				listOfDRM.put("printPages", listDrm.getPrintPages());
				listOfDRM.put("copyPages", listDrm.getCopyPages());
				listOfDRM.put("downloadStatus", listDrm.getDownloadStatus());
				
			}*/

		} catch (Exception e) {
			logger.error("Exception occured while retrieving user list :: " + e.getMessage());
			throw e;
		}
		return listDrmPendingDetails;
	}
	
	public String listFormatDetails(String formatId) {

		String listFormatDetails = null;
		//Map<String, String> listOfDRM = new HashMap<>();
		ListFormatEntity listFormat = null;
		try {

			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(true).and("formatId").is(formatId));
			query.fields().include("formatName");			
			listFormat = mongoOperations.findOne(query, ListFormatEntity.class);
			/*for (ListDrmEntity listDrm : listDrmPendingDetails) {
				listOfDRM.put("drmId",listDrm.getDrmId());
				listOfDRM.put("isbn",listDrm.getIsbn());
				listOfDRM.put("formatId",listDrm.getFormatId());
				listOfDRM.put("noOfDays",listDrm.getNoOfDays());
				listOfDRM.put("noOfDevices",listDrm.getNoOfDevices());
				listOfDRM.put("readPermission", listDrm.getReadPermission());
				listOfDRM.put("printCopyPermission", listDrm.getPrintCopyPermission());
				listOfDRM.put("printPages", listDrm.getPrintPages());
				listOfDRM.put("copyPages", listDrm.getCopyPages());
				listOfDRM.put("downloadStatus", listDrm.getDownloadStatus());
				
				
			}*/
			if(null!= listFormat){
				listFormatDetails = listFormat.getFormatName();
			}
			System.out.println("Format Name: "+listFormatDetails);
		} catch (Exception e) {
			logger.error("Exception occured while retrieving user list :: " + e.getMessage());
			throw e;
		}
		return listFormatDetails;
	}
	
	@Override
	public AwsAPIEntity getAwsCredentials() {
		AwsAPIEntity apiEntity = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("company").is("US"));
			apiEntity = (AwsAPIEntity) mongoOperations.findOne(query, AwsAPIEntity.class);

		} catch (Exception e) {
			logger.error("Exception occured while AWS credentials :: " + e.getMessage());
			throw e;
		}
		return apiEntity;
	}
	
	
	@Override
	public List<FileDetailEntity> getFileDetailsByFormatId(String formatId, String isbn) {

		List<FileDetailEntity> fileList = new ArrayList<>();
		List<String> filename = new ArrayList<>();
		try {

			List<ProductEntity> productList;
			List<AssetEntity> assetList = new ArrayList<>();
			Query q = new Query();
			q.addCriteria(
					Criteria.where("asset.formatId").is(formatId).and("Product.ProductIdentifier.IDValue").is(isbn));

			productList = mongoOperations.find(q, ProductEntity.class);
			for (ProductEntity productEntity : productList) {
				assetList = productEntity.getAssest();
				for (AssetEntity assetEntity : assetList) {
					if (assetEntity.getFormatId().equalsIgnoreCase(formatId)) {
						for(FileDetailEntity fDetail: assetEntity.getFiledetails())
						{
							if(fDetail.getVersion()==1 )
								fileList.add(fDetail);
						}
							
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while retrieving user list :: " + e.getMessage());
			throw e;
		}
		return fileList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDistinctFieldValues(String collectionName, Map<String, Object> criteriaMap, String fieldName) {
		List<String> valueList = null;
		
		try {				
			Query query = new Query();
			
			if(criteriaMap != null && criteriaMap.size() > 0){
				Criteria criteria = new Criteria();
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			    query.addCriteria(criteria);
			}			
			
			query.fields().include(fieldName).exclude("_id");			
			valueList = mongoTemplate.getCollection(collectionName).distinct(fieldName,
					query.getQueryObject());	
			
		} catch (Exception e) {
			logger.error("Exception occured while retrieving Account list :: "+e.getMessage());
			throw e;
		}
		return valueList;
	}
	
	@Override
    public String getMetaDataField(String referencePathValue,String filterText,String displayName) {
        String filterList = null;
        
        try {
            Query query2 = new Query();
           /* query2.addCriteria(Criteria.where("Product.ProductIdentifier.ProductIDType").is("15")
                        .and("Product.ProductIdentifier.IDValue").regex(filterText,"i"));*/
            
            Criteria[] ISBNCriteria = new Criteria[] {Criteria.where("ProductIDType").is("15"), Criteria.where("IDValue").regex(filterText,"i")}; 						
            query2.addCriteria(Criteria.where("Product.ProductIdentifier").elemMatch(new Criteria().andOperator(ISBNCriteria)));
            
            query2.fields().exclude("_id");
            filterList = mongoTemplate.findOne(query2, String.class,"products");
        } catch (Exception e) {
            throw e;
        }
        return filterList;
    }
	
	@SuppressWarnings("unchecked")
	public DRMEntityNew getDRMOrderObject(String id, String drmId) {
		
		DRMEntityNew masterObj = new DRMEntityNew();
		
		try {
			Aggregation aggregation;
			
			aggregation = newAggregation(
					match(Criteria.where("_id").is(new ObjectId(id))),
					project("drmSource", "orderType", "clientId", "clientName",
							"orderDate", "drmType", "drmCutPaste","drmPrint", "drmLicense")
					.and(mapItemsOf("clientEmail").
                            as("u").
                            andApply(aggregationOperationContext -> new BasicDBObject("emailId", "$$u.emailId")))
					.as("clientEmail")
					.and(filter("order")
							.as("item")
							.by(ComparisonOperators.Eq.valueOf("item.drmId")
									.equalToValue(drmId)))
					.as("order").andExclude("_id"),
					project("drmSource", "orderType", "clientId", "clientName",
							"orderDate", "drmType", "drmCutPaste","drmPrint", "drmLicense", "clientEmail")
					.and(mapItemsOf("order").
                            as("v").
                            andApply(aggregationOperationContext -> new BasicDBObject("isbn", "$$v.isbn")
                            		//.append("drmId", "$$v.drmId")
                            		.append("isbn", "$$v.isbn")
                            		.append("deviceFormat", "$$v.deviceFormat")
                            		.append("formatId", "$$v.formatId")
                            		.append("device", "$$v.device")                           		
                            		.append("title", "$$v.title")
                            		.append("CountryOfPublication", "$$v.CountryOfPublication")
                            		.append("ImprintName", "$$v.ImprintName")
                            		.append("ProductCategory", "$$v.ProductCategory")
                            		.append("PublicationDate", "$$v.PublicationDate")
                            		))
					.as("order")
			    );
			
			AggregationResults<DRMEntityNew> groupResults =   mongoTemplate.aggregate(aggregation, "drmDetails", DRMEntityNew.class);
						
			if(groupResults.getMappedResults().size() == 1)
				masterObj = groupResults.getMappedResults().get(0);	
			else
				masterObj = null;
		} catch (Exception e) {
			logger.info("Exception occured in getDRMOrderObject :: "+e);
			e.printStackTrace();
			masterObj = null;
		}
		
		return masterObj;
	}
	
	@SuppressWarnings("unchecked")
	public WatermarkEntity getWatermarkOrderObject(String id, String watermarkId) {
		
		WatermarkEntity masterObj = new WatermarkEntity();
		
		try {
			Aggregation aggregation;
			
			aggregation = newAggregation(
					match(Criteria.where("_id").is(new ObjectId(id))),
					project("drmSource", "orderType", "clientId", "clientName",	"orderDate", "clientEmail")
					.and(filter("order")
							.as("item")
							.by(ComparisonOperators.Eq.valueOf("item.watermarkId")
									.equalToValue(watermarkId)))
					.as("order").andExclude("_id"),
					project("drmSource", "orderType", "clientId", "clientName",	"orderDate", "clientEmail")
					.and(mapItemsOf("order").
                            as("v").
                            andApply(aggregationOperationContext -> new BasicDBObject("isbn", "$$v.isbn")
                            		.append("deviceFormat", "$$v.deviceFormat")
                            		.append("formatId", "$$v.formatId")                            		
                            		.append("title", "$$v.title")
                            		.append("CountryOfPublication", "$$v.CountryOfPublication")
                            		.append("ImprintName", "$$v.ImprintName")
                            		.append("ProductCategory", "$$v.ProductCategory")
                            		.append("PublicationDate", "$$v.PublicationDate")
                            		))
					.as("order")
			    );
			
			AggregationResults<WatermarkEntity> groupResults =   mongoTemplate.aggregate(aggregation, "watermarkDetails", WatermarkEntity.class);
						
			if(groupResults.getMappedResults().size() == 1)
				masterObj = groupResults.getMappedResults().get(0);	
			else
				masterObj = null;
		} catch (Exception e) {
			logger.info("Exception occured in getWatermarkOrderObject:: "+e);
			e.printStackTrace();
			masterObj = null;
		}
		
		return masterObj;
	}

          @Value(value = "${WATERMARK_ORDER_DATE_FORMAT}")
        private String watermarkOrderDateFormat;
    @Override
    public Map<String, Object> getClientInfo(String _id, String loggedUser) {
        Map<String, Object> clientInfo = new HashMap<>();
        /*WatermarkEntity watermarkEntity = jongo.getCollection("watermarkDetails")
                .findOne("{_id : #}", new ObjectId(_id))
                .projection("{orderType : 1, clientEmail : 1, createdBy:1, createdOn :1 "
                + "     ,orderDate:1, \n" +
                    "     'clientId':1, clientName : 1,_id : 0}")
                .as(WatermarkEntity.class);*/
        
        /** Changed By Shahid **/
        
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(_id));
        WatermarkEntity watermarkEntity = mongoTemplate.findOne(query, WatermarkEntity.class);
        
        
        /*List<WatermarkOrderEntity> list = watermarkEntity.getOrder();
        List<String> isbns = new  ArrayList<>();
        for(WatermarkOrderEntity orderEntity : list)
        {
            isbns.add(orderEntity.getIsbn());
        }
        String query="{ 'aggregate' : 'products', 'pipeline' : [{$match: { $and : [\n" +
                        "{ 'Product.ProductIdentifier' : { $elemMatch : { $and : [ { 'ProductIDType' : '15'}, \n" +
                        "{ 'IDValue' : {$in : #}}]}}}]}}, \n" +
                        "{$project : {'Product.Title.TitleText' : 1,_id : 1}}, \n" +
                        "{$unwind : '$Product.Title'} ,\n" +
                        "{$project : {title : '$Product.Title.TitleText' }}\n" +
                        "]}";
        List<ISBN> titles = jongo.runCommand(query, isbns)
                .field("result").as(ISBN.class);
        clientInfo.put("ISBN", titles)
                */
        String emailId="";
        String a;
        int n = watermarkEntity.getClientEmail().size();
        for(int i = 0;i<n ;i++)
        {
            a = watermarkEntity.getClientEmail().get(i);
            if(i <(n-1))
            emailId = emailId +""+ a+",";
            else
                emailId = emailId+"" + a;
            
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(watermarkOrderDateFormat);
        clientInfo.put("clientName", watermarkEntity.getClientName());
        clientInfo.put("orderType", watermarkEntity.getOrderType());
        clientInfo.put("createdBy", getUserName(watermarkEntity.getCreatedBy()));        
        clientInfo.put("orderDate", dateFormat.format(watermarkEntity.getOrderDate()));        
        clientInfo.put("clientEmailId", emailId);        
        clientInfo.put("createdOn", dateFormat.format(watermarkEntity.getCreatedOn()));
        return clientInfo;
    }

    @Override
    public String getUserName(String userId) {
        UserInfo firstName =null;
        firstName = jongo.getCollection("mUser")
                .findOne("{userId : #}",userId)
                .projection("{firstName : 1 , _id : 0}")
                .as(UserInfo.class);
        return (null == firstName ? "" : (firstName.getFirstName() == null)? "":firstName.getFirstName());
    }

    @Override
    public void saveAuditInfo(AuditLogs info) {
        WriteResult result = jongo.getCollection("AuditLogs").save(info);
        if(result.getN() >=0)
        {
            logger.info("Save to auditlogs successful");
        }
        else
        {
            logger.info("Save to auditlogs not successful");
        }
    }
    
    
    @Override
    public Map<String, Date> fetchACSMDownloadedData(Timestamp date, String query) {
    	
    	Connection connectionObj = null;
    	PreparedStatement pstmtObj = null;
        Map<String, Date> resultMap = null;
        ResultSet rs = null;
    	try {
    		resultMap = new HashMap<>();
			DataSource dataSource = mySqlConnectionPool.setUpPool();
			connectionObj = dataSource.getConnection();
		   pstmtObj = connectionObj.prepareStatement(query);
		   pstmtObj.setObject(1, date);
           rs = pstmtObj.executeQuery();
           while(rs.next()) {
        	   String transId = rs.getString("transid");
        	   Date transDate = rs.getTimestamp("transtime");
        	   resultMap.put(transId, transDate);
           }
			
		} catch (Exception e) {
			logger.error("Error while connecting to MySQL Database : "+e.getMessage());
			e.printStackTrace();
		}
    	finally {
    		if(null != rs)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
    		if(null !=pstmtObj) {
    			try {
					pstmtObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
    		}
    		if(null != connectionObj) {
    			try {
					connectionObj.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	}
    	return resultMap;
    }
    
    @Override
    public Date fetchACSMTransactionDate(String transactionId) {
    	
    	Connection connectionObj = null;
    	PreparedStatement pstmtObj = null;
        Map<String, Date> resultMap = null;
        ResultSet rs = null;
        Date transDate = null;
    	try {
    		resultMap = new HashMap<>();
			DataSource dataSource = mySqlConnectionPool.setUpPool();
			connectionObj = dataSource.getConnection();
		   pstmtObj = connectionObj.prepareStatement("select transtime from fulfillment where transid = ?");
		   pstmtObj.setString(1, transactionId);
           rs = pstmtObj.executeQuery();
           while(rs.next()) {
        	    transDate = rs.getTimestamp("transtime");
           }
			
		} catch (Exception e) {
			logger.error("Error while connecting to MySQL Database : "+e.getMessage());
			e.printStackTrace();
		}
    	finally {
    		if(null != rs)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
    		if(null !=pstmtObj) {
    			try {
					pstmtObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
    		}
    		if(null != connectionObj) {
    			try {
					connectionObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
    		}
    	}
    	return transDate;
    }
    
    
    
    @Override
	public TScheduleRunTime getLastRun(String serviceName) {
		TScheduleRunTime scRunTime = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(serviceName));
			scRunTime = mongoTemplate.findOne(query, TScheduleRunTime.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive last run time by name." + e.getMessage());
			throw e;
		}

		return scRunTime;
	}
    
    @Override
	public boolean updateLastRuntime(TScheduleRunTime runTime) {
		boolean result = Boolean.FALSE;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(runTime.getName()));
			Update update = new Update();
			update.set("lastRun", runTime.getLastRun());
			WriteResult wResult = mongoTemplate.updateFirst(query, update, TScheduleRunTime.class);
			if (wResult.getN() > 0) {
				result = Boolean.TRUE;
			} else {
				mongoTemplate.save(runTime);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable to update lastRun by name: " + runTime.getName() + "." + e.getMessage());
		}
		return result;
	}
}
