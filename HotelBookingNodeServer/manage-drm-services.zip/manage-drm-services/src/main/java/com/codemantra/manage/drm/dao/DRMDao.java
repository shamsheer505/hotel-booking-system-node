/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
09-10-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.drm.dao;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import com.codemantra.manage.drm.entity.AuditLogs;
import com.codemantra.manage.drm.entity.AwsAPIEntity;
import com.codemantra.manage.drm.entity.FileDetailEntity;
import com.codemantra.manage.drm.entity.ListDrmEntity;
import com.codemantra.manage.drm.entity.TScheduleRunTime;
import com.codemantra.manage.drm.model.KeyValue;

public interface DRMDao {
	public <T> T getEntityObject(T masterObj, String criteriaFieldName, String criteriaFieldValue);

	public <T> T getEntityObject(T masterObj, Map<String, Object> criteriaMap);

	public String getNextSequenceId(String key);

	public <T> boolean saveEntityObject(T masterObj) throws Exception;

	public <T> List<?> getAllEntityObjects(T masterObj);

	public <T> List<?> getAllEntityObjects(T masterObj, Map<String, Object> criteriaMap);

	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField,
			String criteriaFieldName, U criteriaFieldValue, String unwindField);

	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField,
			Map<String, Object> criteriaMap, String unwindField);

	public <T> boolean updateEntityObject(T masterObj);

	public <T> boolean updateCollectionDocument(String collection, String criteriaFieldName, String criteriaFieldValue,
			String updateFieldName, T updateFieldValue);

	public <T> boolean updateCollectionDocument(String collection, Map<String, Object> criteriaMap,
			Map<String, Object> updateMap);

	public Integer getCountOfDocuments(String collection, LinkedHashMap<String, Object> criteriaMap);

	public Integer getCountOfDocuments(String collection, Criteria criteria);

	public <T> boolean saveEntityObjectList(Collection<T> entityObjList) throws Exception;

	public <T> List<?> joinCollections(T masterObj, String collection, Map<String, Object> criteriaMap,
			LookupOperation lookupOperation, String unwindField);

	public <T> List<?> runNativeMongoQuery(T masterObj, String query, Object... parameters);

	public List<String> getDistinctFieldValues(String collectionName, Map<String, Object> criteriaMap,
			String fieldName);

	public String getMetaDataField(String referencePathValue, String filterText, String displayName);

	public <T> T getDRMOrderObject(String id, String drmId);

	public <T> T getWatermarkOrderObject(String id, String watermarkId);

	// JP

	public List<ListDrmEntity> listDrmPendingDetails();

	public String listFormatDetails(String formatId);

	public AwsAPIEntity getAwsCredentials();

	public List<FileDetailEntity> getFileDetailsByFormatId(String formatId, String isbn);

	public Map<String, Object> getClientInfo(String id, String loggedUser);

	public String getUserName(String userId);

	public void saveAuditInfo(AuditLogs info);

	Map<String, Date> fetchACSMDownloadedData(Timestamp date, String query);

	TScheduleRunTime getLastRun(String mailName);

	boolean updateLastRuntime(TScheduleRunTime runTime);

	public Date fetchACSMTransactionDate(String transactionId);
}
