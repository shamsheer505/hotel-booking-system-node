package com.codemantra.manage.drm.util;

public class MailTitleDetails {
	//String ISBN;
	String Title;
	String Format;
	public MailTitleDetails(String title, String format) {
		super();
		//ISBN = iSBN;
		Title = title;
		Format = format;
	}

}
