package com.codemantra.manage.drm.model;

public class WatermarkOrder {
	//private String watermarkId;
	private String isbn;
	/*private String deviceFormat;
	private String formatId;
	private Integer fileId;
	private Integer orderFlag;
	private String orderStatus;	*/
	private String url;
	//private Date urlExpiryOn;
	
	//private String downloadStatus;
	
	private String title;
	private String format;
	private String author;
	
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	/*public String getWatermarkId() {
		return watermarkId;
	}
	public void setWatermarkId(String watermarkId) {
		this.watermarkId = watermarkId;
	}*/
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	/*public String getDeviceFormat() {
		return deviceFormat;
	}
	public void setDeviceFormat(String deviceFormat) {
		this.deviceFormat = deviceFormat;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public Integer getOrderFlag() {
		return orderFlag;
	}
	public void setOrderFlag(Integer orderFlag) {
		this.orderFlag = orderFlag;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}*/
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	/*public Date getUrlExpiryOn() {
		return urlExpiryOn;
	}
	public void setUrlExpiryOn(Date urlExpiryOn) {
		this.urlExpiryOn = urlExpiryOn;
	}
	public String getDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(String downloadStatus) {
		this.downloadStatus = downloadStatus;
	}*/
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
}
