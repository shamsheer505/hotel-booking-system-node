package com.codemantra.manage.drm.entity;

import java.util.Date;

public class AcsmDownloadedDate {
	
	private String transactionId;
	private Date downloadedDate;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Date getDownloadedDate() {
		return downloadedDate;
	}
	public void setDownloadedDate(Date downloadedDate) {
		this.downloadedDate = downloadedDate;
	}
	
}
