package com.codemantra.manage.drm.util;

public class DRMDisplay {
	String ISBN;
	String Title;
	String Format;
	String link;
	
	
	
	
	public DRMDisplay(String iSBN, String title, String format, String link) {
		super();
		ISBN = iSBN;
		Title = title;
		Format = format;
		this.link = link;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getFormat() {
		return Format;
	}
	public void setFormat(String format) {
		Format = format;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	

	
	
}