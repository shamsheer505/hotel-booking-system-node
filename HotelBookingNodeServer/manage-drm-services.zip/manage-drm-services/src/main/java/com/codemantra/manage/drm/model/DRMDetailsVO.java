package com.codemantra.manage.drm.model;

import com.opencsv.bean.CsvBindByName;

public class DRMDetailsVO {
	
	@CsvBindByName
	private String drmId;
	
	@CsvBindByName
	private String acsmTransactionId;

	public String getDrmId() {
		return drmId;
	}

	public void setDrmId(String drmId) {
		this.drmId = drmId;
	}

	public String getAcsmTransactionId() {
		return acsmTransactionId;
	}

	public void setAcsmTransactionId(String acsmTransactionId) {
		this.acsmTransactionId = acsmTransactionId;
	}

}

