/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package st.malike.auth.client.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;

/**
 *
 * @author malike_st
 */
@Configuration
@EnableResourceServer
@ComponentScan(basePackages = {"com.codemantra","st.malike"})
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {

	 @Value("${oauth.security.enabled}")
	 private Boolean oauthEnabled;
	 
    @Override 
    public void configure(HttpSecurity http) throws Exception {
    	System.out.println("oauthEnabled : "+oauthEnabled);
    	if(oauthEnabled)
    	{		
	        http
	                .authorizeRequests()
	                .antMatchers("/drm/**").permitAll()
	                .antMatchers("/drm").authenticated()
	                .and()
	                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    	}
    	else
    	{
    		http
            .authorizeRequests()
            .antMatchers("/**").permitAll()
            .and()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    	}
    		
        }
}