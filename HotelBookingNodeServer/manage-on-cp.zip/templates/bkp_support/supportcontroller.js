app.controller('supportController', [
		'$scope',
		'$http',
		'$timeout',
		'$filter',
		'$rootScope',
		'$location',
		"$route",
		"$window","$compile",
		function($scope, $http, $timeout, $filter, $rootScope, $location, $route,
				$window,$compile) {

$scope.duplicatePartnerList=angular.copy($rootScope.distColumnPartners);
$scope.dummyPartnerList=angular.copy($rootScope.distColumnPartners);
$scope.showNotificationInput=true;
$scope.searchISBNValue = "";
$scope.partnerFilterList = [];
$scope.isbnFilterList = [];
$scope.selectedRadio="Completed";
$scope.to_emailid="";
$scope.ccto_emailid="";
$scope.errorMSG=false;
$scope.errorMsg="";
$scope.errorMsgForPartner="";
$scope.errorMSGforPartner=false;
$scope.remarks="";
$scope.checkCountForISBN=0;
$scope.userNameLoggedInForSupport=$rootScope.loggedUser.firstName;
$scope.partnerListFilterSearch;
$scope.statusListforPartner=angular.copy($rootScope.statusList);
$scope.rowForSupport=0;
$scope.rowPerPageForSupport=30;
$scope.buttonText = "Load More";
$scope.showLoadMoreRows = false;
$scope.selectedMailRadio="Internal";
$scope.emailerrorMSG=false;
$scope.emailccerrorMSG=false;
$scope.emailInvaliderrorMSG=false;
$scope.emailccInvaliderrorMSG=false;
$scope.emailISBNerrorMSG=false;
$scope.countCheck=0;
$scope.externalChecked=false;
$scope.completedChecked=true;
$scope.disableSubmitButtonForSupport=false;
$scope.supportpartnerAllSelected=false;
$scope.errorMessageForUpdate='';
$scope.partnerSearch=[];
$scope.showSupportTable=false;
//$rootScope.showPartnerTable=false;

//$scope.populateSelectedField();

angular.forEach($scope.duplicatePartnerList,function(list){
	list.selected = false;
});

angular.forEach($scope.dummyPartnerList,function(list){
	list.selected = false;
});


$scope.populateSelectedField = function()
{
	angular.forEach($scope.duplicatePartnerList,function(list){
		list.selected = false;
	});

	angular.forEach($scope.dummyPartnerList,function(list){
		list.selected = false;
	});


}

console.log($scope.duplicatePartnerList);

$scope.partnerAllSelect = function($event){
   // $scope.partnerFilterList=[];
   $scope.errorMsgForPartner="";
    var checkbox = $event.target;
     var action = (checkbox.checked ? 'add' : 'remove');
        if(action === 'add'){
      	    //$scope.partnerFilterList=[];
            angular.forEach($scope.duplicatePartnerList,function(imp){
                document.getElementById("partner_"+imp.partnerName).checked=true;
                if(imp.selected==false){
                $scope.partnerFilterList.push(imp.partnerId);
     			         imp.selected=true;
     		    }
                angular.forEach($scope.dummyPartnerList, function(item) {
     			if(angular.equals(imp.partnerId,item.partnerId))
			         item.selected=true;
		      });
            });
           
        } else if(action === 'remove'){
            angular.forEach($scope.duplicatePartnerList,function(imp){
                document.getElementById("partner_"+imp.partnerName).checked=false;
                $scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(imp.partnerId), 1);
            angular.forEach($scope.dummyPartnerList, function(item) {
     			if(angular.equals(imp.partnerId,item.partnerId))
     			{
			         item.selected=false;
                   //  $scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(item.partnerId), 1);
				}
		      });
           		imp.selected=false;
            });
          //  $scope.partnerFilterList=[];
        }  
        if($scope.duplicatePartnerList.length==0)
        	$scope.supportpartnerAllSelected=false;
 }

 console.log($scope.duplicatePartnerList);
 
 $scope.partnerTags = function (input,checkPartner) {
       var checkCount = 0;
       $scope.errorMsgForPartner="";
     angular.forEach($scope.duplicatePartnerList, function(item) {
         if(null!=document.getElementById("partner_"+item.partnerName))
         if(document.getElementById("partner_"+item.partnerName).checked){
         		document.getElementById("partner_"+item.partnerName).checked=true;
             	checkCount++;
         }
     });
    if(checkPartner){
       		document.getElementById("partner_"+input.partnerName).checked=true;			     
            $scope.partnerFilterList.push(input.partnerId);
            angular.forEach($scope.dummyPartnerList, function(item) {
		         if(angular.equals(item.partnerId,input.partnerId))
		         {
			         item.selected=true;
            		document.getElementById("partner_"+item.partnerName).checked=true;			     
		         }
	        input.selected=true;
    	      });
     } else {
            $scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(input.partnerId), 1);
            input.selected=false;
            angular.forEach($scope.dummyPartnerList, function(item) {
		         if(angular.equals(item.partnerId,input.partnerId))
			         item.selected=false;
		      });
     }
        
     $timeout(function(){
           $scope.supportpartnerAllSelected = (checkCount === $scope.duplicatePartnerList.length);
           document.getElementById("supportpartnerAllSelected").checked= (checkCount === $scope.duplicatePartnerList.length)
       },100);
     console.log($scope.partnerFilterList);
     console.log($scope.duplicatePartnerList);
     console.log($scope.dummyPartnerList);

 };

$scope.refreshPartnerSelectList = function() {

		var checkAllSelected=0;
		//$scope.partnerFilterList = [];
		document.getElementById("supportpartnerAllSelected").checked=false;
       var filteredList = $filter('filter')($scope.dummyPartnerList, function(data) { var re = new RegExp($scope.partnerListFilterSearch, 'gi'); return data.partnerName.match(re); });
       $scope.duplicatePartnerList = angular.copy(filteredList);
       angular.forEach($scope.duplicatePartnerList,function(imp){
       		if(imp.selected==true)
       			checkAllSelected++;
       });
       if(checkAllSelected==$scope.duplicatePartnerList.length && $scope.duplicatePartnerList.length>0)
       {
       	document.getElementById("supportpartnerAllSelected").checked=true;
       }
       else
       	document.getElementById("supportpartnerAllSelected").checked=false;


 /*      $timeout(function() {
           $scope.supportpartnerAllSelected = filteredList.every(function(itm) { return itm.partnerName; }) && filteredList.length > 0;
       }, 10);*/
    };

$scope.validateISBN=function(isbns){
	var checkCountforISBN=0;
	//var arrayIsbn=isbns.replace(/(\r\n|\n|\r)/gm," ").replace(/\s/g, "").split(',');
	//var arrayIsbn=isbns.split(',');
    var arrayIsbn=isbns.replace(/\s/g,"").split(',');
    angular.forEach(arrayIsbn,function(key,value){
    	if(key.length==13 && /^\d+$/.test(key))
    	{
    		isValid=true;
    	}
    	else
    	{
    		checkCountforISBN++;
    	}
    });
    if(checkCountforISBN>0)
    {
				$scope.showSupportTable=false;
	            $scope.errorMSG=true;
	            $scope.errorMsg="Please enter valid isbn(s)";
	}
	else
	{
		 $scope.errorMSG=false;
	}
}


 $scope.updateAllISBNs=function($event){
    $scope.isbnFilterList=[];
    var checkbox = $event.target;
     var action = (checkbox.checked ? 'add' : 'remove');
        if(action === 'add'){
            angular.forEach($scope.partnerSearch,function(imp){
                document.getElementById("checkbox_"+imp._id).checked=true;
                $scope.isbnFilterList.push(imp._id);
            });
            $scope.checkCountForISBN=$scope.isbnFilterList.length;
        } else if(action === 'remove'){
            angular.forEach($scope.partnerSearch,function(imp){
                document.getElementById("checkbox_"+imp._id).checked=false;
            })
            $scope.checkCountForISBN=0;
            $scope.isbnFilterList=[];
        }  
 }


 $scope.updateISBN=function ($event,partnerResult,partnerFormat) {
     //  var check_Count = 0;
            var checkbox = $event.target;
            var action = (checkbox.checked ? 'add' : 'remove');
            if(action === 'add'){
                    document.getElementById("checkbox_"+partnerResult._id).checked=true
                    $scope.isbnFilterList.push(partnerResult._id);
                    $scope.checkCountForISBN++;
                   // console.log($rootScope.checkCount1);
            }
             else if(action === 'remove'){
                    document.getElementById("checkbox_"+partnerResult._id).checked=false;
                    $scope.isbnFilterList.splice($scope.isbnFilterList.indexOf(partnerResult._id), 1);
                    $scope.checkCountForISBN--;
            //        delete $scope.isbnFilterList[partnerResult];
            }
             $timeout(function(){
          // $scope.supportpartnerAllSelected = (checkCount === $scope.duplicatePartnerList.length);
           document.getElementById("checkAllISBN").checked= ($scope.checkCountForISBN === $scope.rowForSupport || $scope.checkCountForISBN == $scope.supportSearchCount)
       },100);
             if($scope.isbnFilterList!=0)
            	 {
            	 	$scope.emailISBNerrorMSG=false;
            	 }
        //        $scope.isbnFilterList=[];
        
     };

$scope.clearFilterValueForSupport=function(input,chk,input1){
     
     if(chk === 'par'){
     if($scope.partnerFilterList.length > '0'){
     	angular.forEach($scope.duplicatePartnerList,function(imp) {
     		if(angular.equals(imp.partnerId,input1))
     		{
     			imp.selected=false;
     		}
     	});
     	angular.forEach($scope.dummyPartnerList, function(item) {
		         if(angular.equals(item.partnerId,input1))
		         {
			         item.selected=false;
		         }
    	      });
        //document.getElementById("partner_"+input).checked=false;
         $scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(input1), 1);
         $scope.supportpartnerAllSelected =false;
         $scope.searchPartners();

         document.getElementById("supportpartnerAllSelected").checked=false;
         //$scope.reportCommonFilter();

         }if($scope.partnerFilterList.length == '0'){
             $scope.partnerAllSelect =false;
         }
     }
     else if(chk === 'searchKey'){
         $scope.searchISBNValue = "";
         angular.element($("#searchISBNValue")).val('');

        // $rootScope.rptSearchSuggestions[fieldName]=chk;
       // delete $rootScope.RPTHeadSearchList[fieldName]
        // alert(JSON.stringify($rootScope.RPTHeadSearchList));
     }
 if($scope.searchISBNValue === '' || $scope.partnerSearch.length === 0 || $scope.partnerSearch =='' || $scope.partnerSearch == null)
    {
          $scope.showSupportTable=false;
          $scope.errorMSG=true;
    }
     /*
     setTimeout(function() {
            angular.element(".innerFilter").addClass('active');
            angular.element(".innerFilterDropdown").addClass('active');
         }, 50);*/
 }
  
 $scope.clearReport=function(chk){

         $scope.searchISBNValue = "";
         angular.element($("#searchISBNValue")).val('');
     //if($scope.partnerFilterList.length > '0'){
 /*    angular.forEach($scope.duplicatePartnerList,function(imp){
        document.getElementById("partner_"+imp.partnerName).checked=false;
    });
*/
     angular.forEach($scope.duplicatePartnerList,function(imp){
  				imp.selected=false;
    });

     angular.forEach($scope.dummyPartnerList,function(item){
  				item.selected=false;
    });
     $scope.partnerFilterList = [];
     $scope.supportpartnerAllSelected =false;
     document.getElementById("supportpartnerAllSelected").checked=false;
  
}


/*
$scope.validateEmailIds=function(flag)
{
  //return re.test(email);
    if(flag === 'TO')
    {
        if($scope.to_emailid === '')
            $scope.emailerrorMSG=true;
        else
        {
            $scope.emailerrorMSG=false;
               //var value = emailcntl.value;
                //if (value != '') {
                    var result = $scope.to_emailid.split(',');
                    for (var i = 0; i < result.length; i++) {
                        if (result[i] != '') {
                            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
                                 if(!regex.test(result[i]))
                                 {
                                    $scope.emailInvaliderrorMSG=true;
                                 }
                                 else
                                    $scope.emailInvaliderrorMSG=false;

                            }
                        }
        }
    }        
    else if(flag === 'CC' )
    {
        if($scope.ccto_emailid === '')
            $scope.emailccerrorMSG=true;
        else
        {
            $scope.emailccerrorMSG=false;
               //var value = emailcntl.value;
                //if (value != '') {
                    var result = $scope.ccto_emailid.split(',');
                    for (var i = 0; i < result.length; i++) {
                        if (result[i] != '') {
                            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
                                 if(!regex.test(result[i]))
                                 {
                                    $scope.emailccInvaliderrorMSG=true;
                                 }
                                 else
                                    $scope.emailccInvaliderrorMSG=false;
                            }
                        }
        }
    }
}
*/

$scope.validateEmailIds=function(flag,emailValue)
{ 
	// var x = angular.element("#to_email").val();
	// $rootScope.toEmailVal = document.getElementById("to_email").value;  
	// alert($rootScope.toEmailVal)
  //return re.test(email);

    if(flag === 'TO')
    {

    		$scope.to_emailid=emailValue;
            if($scope.to_emailid === '')
                 $scope.emailInvaliderrorMSG=false;
           // $scope.emailerrorMSG=false;
               //var value = emailcntl.value;
                //if (value != '') {
             else{       
                    var result = $scope.to_emailid.split(',');
                    for (var i = 0; i < result.length; i++) {
                        if (result[i] != '') {
                            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
                                 if(!regex.test(result[i]))
                                 {
                                    $scope.emailInvaliderrorMSG=true;
                                 }
                                 else
                                 { 
                                    $scope.countCheck++;
                                    $scope.emailerrorMSG=false;
                                    $scope.emailInvaliderrorMSG=false;
                                  }
                            }
                        }
                  }      
        }
            
    else if(flag === 'CC' )
    {
    		$scope.ccto_emailid=emailValue;
            if($scope.ccto_emailid === '')
                 $scope.emailccInvaliderrorMSG=false;
            //$scope.emailccerrorMSG=false;
               //var value = emailcntl.value;
                //if (value != '') {
             else{       
                    var result = $scope.ccto_emailid.split(',');
                    for (var i = 0; i < result.length; i++) {
                        if (result[i] != '') {
                            var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
                                 if(!regex.test(result[i]))
                                 {
                                    $scope.emailccInvaliderrorMSG=true;
                                 }
                                 else
                                 {   
                                    $scope.countCheck++;
                                    $scope.emailerrorMSG=false;
                                    $scope.emailccInvaliderrorMSG=false;
                                 }   
                            }
                        }
                  }      
        }
    
}

$scope.getSupportPosts=function(){
	if(document.getElementById("checkAllISBN").checked)
    	document.getElementById("checkAllISBN").checked=false;
    if($scope.searchISBNValue != '' && $scope.partnerFilterList.length > 0)
    {    
        $scope.emailISBNerrorMSG=false;
        $scope.errorMSG=false;
        $scope.showSupportTable=true;

     //   $rootScope.showLoader($('.user-master'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/searchPartnersforSupport',
             data :  { 
                    
                skipCountforSupport:$scope.rowForSupport,    
                permission:$scope.searchISBNValue.replace(/\s/g,""),
                format:$scope.partnerFilterList,
                
             }
            }).then(function (response) {
       if($scope.partnerSearch.length <= $scope.supportSearchCount){
       if(response.data.data !='' ){
        $scope.rowForSupport+=$scope.rowPerPageForSupport;
        if($scope.partnerSearch != undefined){
            $scope.buttonText = "Loading ...";
            setTimeout(function() {
                $scope.$apply(function(){
                    angular.forEach(response.data.data,function(item) {
                        $scope.partnerSearch.push(item);
               
                    });
                    if($scope.partnerSearch.length>=$scope.supportSearchCount){
                           $scope.showLoadMoreRows = false;
                           $scope.partnerSearch.length = $scope.supportSearchCount;
                       }else{
                           $scope.showLoadMoreRows = true;}
                    $scope.buttonText = "Load More";
          });
         },500);
     
        }else{
         //$scope.posts = response.data;
            $scope.partnerSearch = response.data.data;
        }
      
       }else{
           $scope.showLoadMoreRows = false;
       }
      }else{
           $scope.showLoadMoreRows = false;
           $scope.partnerSearch.length = $scope.supportSearchCount;
      }
      });
    }   
    else
        {
            $scope.errorMSG=true;
            $scope.errorMsg="Please select values from both fields";
        }     
}



$scope.searchPartners=function(){

	$scope.isbnFilterList=[];
	var checkCountforISBN=0;
	//var a=/^(\d?[\d,]+[\d,]+[\d,]+\d?,)*(\d?[\d,]+[\d,]+[\d,]+)$/;
	//var isValid = /([0-9][,])$/.test($scope.searchISBNValue);
	//var isValid = /(\d?[\d,]+[\d,]+[\d,]+\d?,)*(\d?[\d,]+[\d,]+[\d,]+)$/.test($scope.searchISBNValue);
    var arrayIsbn=$scope.searchISBNValue.replace(/\s/g,"").split(',');
    
    angular.forEach(arrayIsbn,function(key,value){
    	if(key.length==13 && /^\d+$/.test(key))
    	{
    		isValid=true;
    	}
    	else
    	{
    		checkCountforISBN++;
    	}
    })
   //var isValid = /(^[0-9]{13}$)+(,(^[0-9]{13}))*/.test($scope.searchISBNValue);
    if($scope.searchISBNValue != '' && $scope.partnerFilterList.length > 0 && checkCountforISBN==0)
    {    
    	if(document.getElementById("checkAllISBN").checked)
    		document.getElementById("checkAllISBN").checked=false;
    	$scope.emailISBNerrorMSG=false;
        $scope.disableSearchButtonForSupport=true;
        $scope.emailISBNerrorMSG=false;
        $scope.errorMSG=false;
        $scope.showSupportTable=true;
        $rootScope.showLoader($('.support-master'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/searchPartnersforSupport',
             data :  { 
                    
                skipCountforSupport:0,    
                permission:$scope.searchISBNValue.replace(/\s/g,""),
                format:$scope.partnerFilterList,
                
             }
            }).then(function (response) {
             //alert("data"+response.data.data)
                $scope.partnerSearch = response.data.data;
                $scope.supportSearchCount = response.data.searchCount;
                console.log($scope.searchISBNValue);
                //$scope.partnerNameinPartnerSearch=response.data.data.isbn;
               // $scope.populateEachFieldValueinArray();
                $scope.checkCountForISBN = 0;
                $scope.rowForSupport = 30;
                $scope.disableSearchButtonForSupport=false;
                if($scope.supportSearchCount>30)
                {
                    $scope.showLoadMoreRows = true;
                }
               // $rootScope.showPartnerTable=true;

            //    $rootScope.series = response.data.data.series;
              //  $rootScope.data = response.data.data.data;       
                
                $rootScope.hideLoader('support-master'); 

            });
    }   
    else
        {
        	if($scope.searchISBNValue.length == 0 || checkCountforISBN>0)
        	{	
				$scope.showSupportTable=false;
	            $scope.errorMSG=true;
	            $scope.errorMsg="Please enter valid isbn(s)";
	        }  
	        else
	        {
	        	$scope.errorMSG=false;
	        	$scope.showSupportTable=false;
	            $scope.errorMSGforPartner=true;
	            $scope.errorMsgForPartner="Please select partner(s)";
	        }	
        }	
}
/*
$scope.partnerISBNinPartnerSearch=[];
$scope.partnerNameinPartnerSearch=[];
$scope.partnerIdinPartnerSearch=[];
$scope.StatusinPartnerSearch=[];
$scope.searchForColumnFilter={};
$scope.searchForColumnFilter.isbn='';
$scope.searchForColumnFilter.partnerId='';
$scope.populateEachFieldValueinArray=function(){
			$scope.partnerISBNinPartnerSearch=$scope.partnerSearch.map(a => a.isbn);
			$scope.partnerIdinPartnerSearch=$scope.partnerSearch.map(a => a.partnerId);
			$scope.StatusinPartnerSearch=$scope.partnerSearch.map(a => a.transactionStatus);
			$scope.duplicatepartnerIdinPartnerSearch=angular.copy($scope.partnerIdinPartnerSearch);
			$scope.duplicatepartnerISBNinPartnerSearch=angular.copy($scope.partnerISBNinPartnerSearch);
			//var result = objArray.map(a => a.foo);

}

$scope.refreshISBNColumnSelectList=function(){
	var filteredList = $filter('filter')($scope.duplicatepartnerISBNinPartnerSearch, function(data) { var re = new RegExp($scope.searchForColumnFilter.isbn, 'gi'); return data.match(re); });
       $scope.partnerISBNinPartnerSearch = angular.copy(filteredList);
			}

$scope.refreshPartnerNameColumnSelectList=function(){
	var filteredList = $filter('filter')($scope.duplicatepartnerIdinPartnerSearch, function(data) { var re = new RegExp($scope.searchForColumnFilter.partnerId, 'gi'); return data.match(re); });
       $scope.partnerIdinPartnerSearch = angular.copy(filteredList);
			}			
*/			
//$scope.disableSubmitButtonForSupport=true;

$scope.updateAndSend=function(){
  /*  if($scope.countCheck === 0)
    {
        $scope.emailerrorMSG=true;
    }    
  */
 // $scope.disableSubmitButtonForSupport=true;
                    console.log($scope.to_emailid+",,,,,,,,,,,"+$scope.ccto_emailid);

  if($scope.showSupportTable==false || ($scope.partnerFilterList.length == 0 || $scope.searchISBNValue =='') && ($scope.isbnFilterList.length === 0 || $scope.isbnFilterList ==='' || $scope.isbnFilterList ===null))
  {
		if($scope.searchISBNValue=='')
  		{
  			$scope.errorMSG=true;
	        $scope.errorMsg="Please enter valid isbn(s)";
  		}
  		else if($scope.partnerFilterList.length==0)
  		{
  			$scope.errorMSGforPartner=true;
	        $scope.errorMsgForPartner="Please select partner(s)";
  		}
        $scope.emailISBNerrorMSG=true;
        $scope.errorMessageForUpdate="Please click search and proceed";
      //  $('#searchrequestforsupport').modal('toggle');
  }
  else if($scope.partnerSearch!=null && $scope.isbnFilterList.length === 0){
  			$scope.errorMessageForUpdate="Please select records to update";
  			$scope.emailISBNerrorMSG=true;	
  }
  else if($scope.isbnFilterList.length==0)
  {
  		$scope.errorMessageForUpdate="No records found to update";
  		$scope.emailISBNerrorMSG=true;		
  }
  /*  if($scope.partnerSearch.length === 0 || $scope.partnerSearch ==='' || $scope.partnerSearch === null)
    {
        $scope.emailISBNerrorMSG=true;
    }    
  */
   
    if($scope.isbnFilterList.length != 0 && $scope.isbnFilterList !='' && $scope.isbnFilterList != null && $scope.partnerSearch.length != 0 && $scope.partnerSearch !='' && $scope.partnerSearch != null && $scope.searchISBNValue != '' && $scope.partnerFilterList.length > 0 && $scope.emailerrorMSG === false && $scope.emailccInvaliderrorMSG === false && $scope.emailInvaliderrorMSG === false)
    {    
    		$scope.disableSubmitButtonForSupport=true;

    		//document.getElementById("supportSubmitButton").disabled = true;
//$scope.to_emailid = document.getElementById("to_emailid").value;
 //   	$scope.ccto_emailid = document.getElementById("ccto_emailid").value;
        $http({
            method: 'POST',
            url: '/updateAndSendEmail',
             data :  { 
                permission:$scope.selectedRadio,
                format:$scope.isbnFilterList,
                to_emailid:$scope.to_emailid,
                ccto_emailid:$scope.ccto_emailid,  
                remarks:$scope.remarks,   
                userName:$scope.userNameLoggedInForSupport,    
                mailGroup:$scope.selectedMailRadio,
             }
            }).then(function (response) {
             //alert("data"+response.data.data)

             	angular.element('#SuccessRecordUpdate').fadeIn();
                $scope.updatedList = response.data.data;
                if($scope.updatedList.length>0)
                {
				    $scope.showeditSaveSupportDetails=true;
	            	$scope.editSaveSupportSuccessMsg="Records Updated Successfully";

                }
                else
                {
				    $scope.showeditSaveSupportDetails=true;
                	$scope.editSaveSupportSuccessMsg="No Records Updated";
                }
      		    $scope.disableSubmitButtonForSupport=false;

    		//	document.getElementById("supportSubmitButton").disabled = false;
                $scope.searchISBNValue = "";
				$scope.partnerFilterList = [];
                $scope.isbnFilterList=[];
                $scope.to_emailid = "";
                $scope.remarks = "";
                $scope.ccto_emailid = "";
                $scope.selectedRadio="Completed";
			    $scope.selectedMailRadio = "Internal";
                $scope.populateSelectedField();
                $scope.supportpartnerAllSelected=false;
	    		angular.element('#SuccessRecordUpdate').delay(3000).fadeOut();

                $scope.showSupportTable=false;
                $scope.checkCountForISBN=0;
                $scope.completedChecked=true;
			   	$scope.externalChecked=false;
			    document.getElementById("checkAllISBN").checked=false;
			    document.getElementById("to_emailid").value='';
			    document.getElementById("ccto_emailid").value='';
			    $scope.partnerListFilterSearch='';
			    $scope.refreshPartnerSelectList();
			    //document.getElementById("supportpartnerAllSelected").checked=false;
			    angular.forEach($scope.duplicatePartnerList,function(imp){
			    document.getElementById("partner_"+imp.partnerName).checked=false;
});

            //    $rootScope.series = response.data.data.series;
              //  $rootScope.data = response.data.data.data;       
                
                //$rootScope.hideLoader('user-master'); 

            });
    }
}

 $scope.checkWidgetItems=function(chk){
    if(chk==='CAN')
    {
        $scope.selectedRadio="Cancelled";
        $scope.completedChecked=false;
    }
    else if(chk==='COM')
    {
        $scope.selectedRadio="Completed";
        $scope.completedChecked=true;
    }
    else if(chk=='EXT')
    {
    	$scope.selectedMailRadio="External";
    	$scope.showNotificationInput=false;
    	$scope.externalChecked=true;
    }
    else if(chk=='INT')
    {
    	$scope.selectedMailRadio="Internal";
    //	$scope.showNotificationInput=true;
    }
 }




}]);


