'use strict';app.controller('RoleMasterController',['$scope','$http','$rootScope','$window','$timeout','$location',function($scope,$http,$rootScope,$window,$timeout,$location){$rootScope.newRoleModuleNames=[];$rootScope.test=!1;angular.forEach($scope.moduleList,function(itm){itm.selected=!1});$scope.roleModuleList=angular.copy($rootScope.moduleList);$rootScope.testScroll();$http({method:'GET',url:'/getWidget'}).then(function successCallback(response){$rootScope.widgetList=response.data.data},function errorCallback(response){console.log('Error status: '+response.status)});$scope.passDataToActiveDeactModal=function(role){$scope.roleActDeact=role}
$scope.closeRoleDelete=function(){$scope.roleDelete=null;$('#role-delete').modal('toggle');$rootScope.getRoles()}
$scope.closeRoleDeactivateModal=function(){$('#role-deactivate').modal('toggle');$rootScope.getRoles()}
$scope.closeRoleDeactivateModal=function(){$('#role-deactivate').modal('toggle');$rootScope.getRoles()}
$scope.closeRoleCreateModal=function(){$location.url('/role-master');$rootScope.getRoles()}
$scope.passDataToDeletedModal=function(role){$scope.roleDelete=role}
$scope.toggleAllModule=function(chk){angular.forEach($scope.roleModuleList,function(module){if(chk.target.checked){document.getElementById("module_"+module.moduleId).checked=!0;if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}
if(module.moduleId=="MOD00001")
$rootScope.showDashbord=!0;if(module.moduleId=="MOD00002")
$rootScope.showAsset=!0;if(module.moduleId=="MOD00003")
$rootScope.showMetadata=!0;if(module.moduleId=="MOD00004")
$rootScope.showReport=!0;if(module.moduleId=="MOD00005")
$rootScope.showShelf=!0;if(module.moduleId=="MOD00007")
$rootScope.showWidget=!0;if(module.moduleId=="MOD00008")
$rootScope.showCatalogue=!0;if(module.moduleId=="MOD00009")
$rootScope.showConversion=!0;if(module.moduleId=="MOD00010")
$rootScope.showDRM=!0;if(module.moduleId=="MOD00011")
$rootScope.showMD=!0;if(module.moduleId=="MOD00013")
$rootScope.showWM=!0}else{if(module.moduleId=="MOD00001"){$scope.parameterEmpty('dashboard');$rootScope.showDashbord=!1}
if(module.moduleId=="MOD00002"){$rootScope.showAsset=!1;$scope.parameterEmpty('asset')}
if(module.moduleId=="MOD00003"){$rootScope.showMetadata=!1;$scope.parameterEmpty('metadata')}
if(module.moduleId=="MOD00004"){$rootScope.showReport=!1;$scope.parameterEmpty('report')}
if(module.moduleId=="MOD00005"){$rootScope.showShelf=!1;$scope.parameterEmpty('shelf')}
if(module.moduleId=="MOD00007"){$rootScope.showWidget=!1;$scope.parameterEmpty('widget')}
if(module.moduleId=="MOD00008"){$rootScope.showCatalogue=!1;$scope.parameterEmpty('catg')}
if(module.moduleId=="MOD00009"){$rootScope.showConversion=!1;$scope.parameterEmpty('conversion')}
if(module.moduleId=="MOD00010"){$rootScope.showDRM=!1;$scope.parameterEmpty('drm')}
if(module.moduleId=="MOD00011"){$rootScope.showMD=!1;$scope.parameterEmpty('MD')}
if(module.moduleId=="MOD00013"){$rootScope.showWM=!1;$scope.parameterEmpty('WM')}
document.getElementById("module_"+module.moduleId).checked=!1;if(module.moduleId!="MOD00006"&&module.moduleId!="MOD00012"){var index=$rootScope.newRoleModuleNames.indexOf(module.moduleName);$rootScope.newRoleModuleNames.splice(index,1)}else{document.getElementById("module_"+module.moduleId).checked=!0}
$scope.parameterEmpty('administrator')}})}
$scope.closeModule=function(val,name){if(val=="MOD00001"){$rootScope.showDashbord=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('dashboard')}else if(val=="MOD00002"){$rootScope.showAsset=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('asset')}else if(val=="MOD00003"){$rootScope.showMetadata=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('metadata')}else if(val=="MOD00004"){$rootScope.showReport=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('report')}else if(val=="MOD00005"){$rootScope.showShelf=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('shelf')}else if(val=="MOD00006"){$rootScope.showAdmin=!1;document.getElementById("module_"+val).checked=!1}else if(val=="MOD00007"){$rootScope.showWidget=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('widget')}else if(val=="MOD00008"){$rootScope.showCatalogue=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('catg')}else if(val=="MOD00009"){$rootScope.showConversion=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('conversion')}else if(val=="MOD00010"){$rootScope.showDRM=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('drm')}else if(val=="MOD00013"){$rootScope.showWM=!1;document.getElementById("module_"+val).checked=!1;$scope.parameterEmpty('WM')}
$rootScope.newRoleModuleNames.splice($rootScope.newRoleModuleNames.indexOf(name),1);document.getElementById("moduleAllSelected").checked=($rootScope.newRoleModuleNames.length===$scope.roleModuleList.length)}
$scope.atCheckAll=function(chk,view,mu,bu,download,dwShare,buShare,dis,del,apl,con,delApprove){$rootScope.assetAccessArray=[];if(chk.target.checked){document.getElementById("assetView").checked=!0;document.getElementById("assetMU").checked=!0;document.getElementById("assetBU").checked=!0;document.getElementById("assetDownload").checked=!0;document.getElementById("downloadShare").checked=!0;document.getElementById("BUShare").checked=!0;document.getElementById("assetDistribution").checked=!0;document.getElementById("assetConversion").checked=!0;document.getElementById("assetDelete").checked=!0;document.getElementById("assetApproval").checked=!0;document.getElementById("assetDeleteApproval").checked=!0;if($rootScope.assetView=!0)
$rootScope.assetAccessArray.push(view);if($rootScope.assetMU=!0)
$rootScope.assetAccessArray.push(mu);if($rootScope.assetBU=!0)
$rootScope.assetAccessArray.push(bu);if($rootScope.assetDownload=!0)
$rootScope.assetAccessArray.push(download);if($rootScope.downloadShare=!0)
$rootScope.assetAccessArray.push(dwShare);if($rootScope.BUShare=!0)
$rootScope.assetAccessArray.push(buShare);if($rootScope.assetDistribution=!0)
$rootScope.assetAccessArray.push(dis);if($rootScope.assetDelete=!0)
$rootScope.assetAccessArray.push(del);if($rootScope.assetApproval=!0)
$rootScope.assetAccessArray.push(apl);if($rootScope.assetConversion=!0)
$rootScope.assetAccessArray.push(con);if($rootScope.assetDeleteApproval=!0)
$rootScope.assetAccessArray.push(delApprove)}else{document.getElementById("assetView").checked=!1;document.getElementById("assetMU").checked=!1;document.getElementById("assetBU").checked=!1;document.getElementById("assetDownload").checked=!1;document.getElementById("downloadShare").checked=!1;document.getElementById("BUShare").checked=!1;document.getElementById("assetDistribution").checked=!1;document.getElementById("assetConversion").checked=!1;document.getElementById("assetDelete").checked=!1;document.getElementById("assetApproval").checked=!1;document.getElementById("assetDeleteApproval").checked=!1;$rootScope.assetView=!1;$rootScope.assetMU=!1;$rootScope.assetBU=!1;$rootScope.downloadShare=!1;$rootScope.BUShare=!1;$rootScope.assetDistribution=!1;$rootScope.assetConversion=!1;$rootScope.assetDelete=!1;$rootScope.assetApproval=!1;$rootScope.assetDownload=!1;$rootScope.assetDeleteApproval=!1;$rootScope.assetAccessArray=[];$scope.parameterEmpty('asset')}
if($rootScope.assetAccessArray.indexOf('VIEW')>=0&&$rootScope.assetAccessArray.length>1){$rootScope.assetViewCheck=!0}else{$rootScope.assetViewCheck=!1}}
$scope.mtCheckAll=function(chk,view,create,edit,bu,download,share,dis,del,apl,exp){document.getElementById("mtView").checked=!0;document.getElementById("mtCreate").checked=!0;document.getElementById("mtEdit").checked=!0;document.getElementById("mtBU").checked=!0;document.getElementById("mtDownload").checked=!0;document.getElementById("mtShare").checked=!0;document.getElementById("mtDistribution").checked=!0;document.getElementById("mtApproval").checked=!0;document.getElementById("mtDelete").checked=!0;document.getElementById("mtExport").checked=!0;$rootScope.metaDataAccessArray=[];if(chk.target.checked){if($rootScope.mtView=!0)
$rootScope.metaDataAccessArray.push(view);if($rootScope.mtCreate=!0)
$rootScope.metaDataAccessArray.push(create);if($rootScope.mtEdit=!0)
$rootScope.metaDataAccessArray.push(edit);if($rootScope.mtBU=!0)
$rootScope.metaDataAccessArray.push(bu);if($rootScope.mtDownload=!0)
$rootScope.metaDataAccessArray.push(download);if($rootScope.mtShare=!0)
$rootScope.metaDataAccessArray.push(share);if($rootScope.mtDistribution=!0)
$rootScope.metaDataAccessArray.push(dis);if($rootScope.mtDelete=!0)
$rootScope.metaDataAccessArray.push(del);if($rootScope.mtApproval=!0)
$rootScope.metaDataAccessArray.push(apl);if($rootScope.mtExport=!0)
$rootScope.metaDataAccessArray.push(exp)}else{document.getElementById("mtView").checked=!1;document.getElementById("mtCreate").checked=!1;document.getElementById("mtEdit").checked=!1;document.getElementById("mtBU").checked=!1;document.getElementById("mtDownload").checked=!1;document.getElementById("mtShare").checked=!1;document.getElementById("mtDistribution").checked=!1;document.getElementById("mtApproval").checked=!1;document.getElementById("mtDelete").checked=!1;document.getElementById("mtExport").checked=!1;$rootScope.mtView=!1;$rootScope.mtCreate=!1;$rootScope.mtEdit=!1;$rootScope.mtBU=!1;$rootScope.mtDownload=!1;$rootScope.mtShare=!1;$rootScope.mtDistribution=!1;$rootScope.mtDelete=!1;$rootScope.mtExport=!1;$rootScope.mtApproval=!1;$rootScope.metaDataAccessArray=[];$scope.parameterEmpty('metadata')}
if($rootScope.metaDataAccessArray.indexOf('VIEW')>=0&&$rootScope.metaDataAccessArray.length>1){$rootScope.mtViewCheck=!0}else{$rootScope.mtViewCheck=!1}}
$scope.reportCheckAll=function(chk,view,create,del){$rootScope.reportAccessArray=[];if(chk){if(document.getElementById("cReportView").checked=!0)
$rootScope.reportAccessArray.push(view);if(document.getElementById("cReportCreate").checked=!0)
$rootScope.reportAccessArray.push(create);if(document.getElementById("cReportDelete").checked=!0)
$rootScope.reportAccessArray.push(del)}else{document.getElementById("cReportView").checked=!1;document.getElementById("cReportCreate").checked=!1;document.getElementById("cReportDelete").checked=!1;$rootScope.reportAccessArray=[];$scope.parameterEmpty('report')}}
$scope.shelfCheckAll=function(chk,view,create,edit,dwld,share,del){$rootScope.shelfAccessArray=[];if(chk.target.checked){document.getElementById("cShelfView").checked=!0;document.getElementById("cShelfCreate").checked=!0;document.getElementById("cShelfEdit").checked=!0;document.getElementById("cShelfDelete").checked=!0;document.getElementById("cShelfShare").checked=!0;document.getElementById("cShelfDownload").checked=!0;if($rootScope.cShelfView=!0)
$rootScope.shelfAccessArray.push(view);if($rootScope.cShelfCreate=!0)
$rootScope.shelfAccessArray.push(create);if($rootScope.cShelfEdit=!0)
$rootScope.shelfAccessArray.push(edit);if($rootScope.cShelfDelete=!0)
$rootScope.shelfAccessArray.push(del);if($rootScope.cShelfShare=!0)
$rootScope.shelfAccessArray.push(share);if($rootScope.cShelfDownload=!0)
$rootScope.shelfAccessArray.push(dwld)}else{document.getElementById("cShelfView").checked=!1;document.getElementById("cShelfCreate").checked=!1;document.getElementById("cShelfEdit").checked=!1;document.getElementById("cShelfDelete").checked=!1;document.getElementById("cShelfShare").checked=!1;document.getElementById("cShelfDownload").checked=!1;$rootScope.cShelfView=!1;$rootScope.cShelfCreate=!1;$rootScope.cShelfEdit=!1;$rootScope.cShelfDelete=!1;$rootScope.cShelfShare=!1;$rootScope.cShelfDownload=!1;$rootScope.shelfAccessArray=[];$scope.parameterEmpty('shelf')}
if($rootScope.shelfAccessArray.indexOf('VIEW')>=0&&$rootScope.shelfAccessArray.length>1){$rootScope.shelfViewCheck=!0}else{$rootScope.shelfViewCheck=!1}}
$scope.widgetCheckAll=function(chk,view,create,edit,del,actv){$rootScope.widgetAccessArray=[];if(chk.target.checked){document.getElementById("wdView").checked=!0;document.getElementById("wdCreate").checked=!0;document.getElementById("wdEdit").checked=!0;document.getElementById("wdDelete").checked=!0;document.getElementById("wdActivate").checked=!0;if($rootScope.wdView=!0)
$rootScope.widgetAccessArray.push(view);if($rootScope.wdCreate=!0)
$rootScope.widgetAccessArray.push(create);if($rootScope.wdEdit=!0)
$rootScope.widgetAccessArray.push(edit);if($rootScope.wdDelete=!0)
$rootScope.widgetAccessArray.push(del);if($rootScope.wdActivate=!0)
$rootScope.widgetAccessArray.push(actv)}else{document.getElementById("wdView").checked=!1;document.getElementById("wdCreate").checked=!1;document.getElementById("wdEdit").checked=!1;document.getElementById("wdDelete").checked=!1;document.getElementById("wdActivate").checked=!1;$rootScope.wdView=!1;$rootScope.wdCreate=!1;$rootScope.wdEdit=!1;$rootScope.wdDelete=!1;$rootScope.wdActivate=!1;$rootScope.widgetAccessArray=[];$scope.parameterEmpty('widget')}
if($rootScope.widgetAccessArray.indexOf('VIEW')>=0&&$rootScope.widgetAccessArray.length>1){$rootScope.wdViewCheck=!0}else{$rootScope.wdViewCheck=!1}}
$scope.ctlgCheckAll=function(chk,view,create,edit,del){$rootScope.catalogueAccessArray=[];if(chk.target.checked){document.getElementById("catgView").checked=!0;document.getElementById("catgCreate").checked=!0;document.getElementById("catgEdit").checked=!0;document.getElementById("catgDelete").checked=!0;if($rootScope.catgView=!0)
$rootScope.catalogueAccessArray.push(view);if($rootScope.catgCreate=!0)
$rootScope.catalogueAccessArray.push(create);if($rootScope.catgEdit=!0)
$rootScope.catalogueAccessArray.push(edit);if($rootScope.catgDelete=!0)
$rootScope.catalogueAccessArray.push(del)}else{document.getElementById("catgView").checked=!1;document.getElementById("catgCreate").checked=!1;document.getElementById("catgEdit").checked=!1;document.getElementById("catgDelete").checked=!1;$rootScope.catgView=!1;$rootScope.catgCreate=!1;$rootScope.catgEdit=!1;$rootScope.catgDelete=!1;$rootScope.catalogueAccessArray=[];$scope.parameterEmpty('catg')}
if($rootScope.catalogueAccessArray.indexOf('VIEW')>=0&&$rootScope.catalogueAccessArray.length>1){$rootScope.catgViewCheck=!0}else{$rootScope.catgViewCheck=!1}}
$scope.conCheckAll=function(chk,view,create,edit,del){$rootScope.conversionAccessArray=[];if(chk.target.checked){document.getElementById("cConView").checked=!0;document.getElementById("cConCreate").checked=!0;document.getElementById("cConEdit").checked=!0;document.getElementById("cConDelete").checked=!0;if($rootScope.cConView=!0)
$rootScope.conversionAccessArray.push(view);if($rootScope.cConCreate=!0)
$rootScope.conversionAccessArray.push(create);if($rootScope.cConEdit=!0)
$rootScope.conversionAccessArray.push(edit);if($rootScope.cConDelete=!0)
$rootScope.conversionAccessArray.push(del)}else{document.getElementById("cConView").checked=!1;document.getElementById("cConCreate").checked=!1;document.getElementById("cConEdit").checked=!1;document.getElementById("cConDelete").checked=!1;$rootScope.cConView=!1;$rootScope.cConCreate=!1;$rootScope.cConEdit=!1;$rootScope.cConDelete=!1;$rootScope.conversionAccessArray=[];$scope.parameterEmpty('conversion')}
if($rootScope.conversionAccessArray.indexOf('VIEW')>=0&&$rootScope.conversionAccessArray.length>1){$rootScope.cConViewCheck=!0}else{$rootScope.cConViewCheck=!1}}
$scope.drmCheckAll=function(chk,create,edit,reorder,del){$rootScope.DRMAccessArray=[];if(chk.target.checked){document.getElementById("cDRMCreate").checked=!0;document.getElementById("cDRMEdit").checked=!0;document.getElementById("cDRMOrder").checked=!0;document.getElementById("cDRMDelete").checked=!0;if($rootScope.cDRMCreate=!0)
$rootScope.DRMAccessArray.push(create);if($rootScope.cDRMEdit=!0)
$rootScope.DRMAccessArray.push(edit);if($rootScope.cDRMOrder=!0)
$rootScope.DRMAccessArray.push(reorder);if($rootScope.cDRMDelete=!0)
$rootScope.DRMAccessArray.push(del)}else{document.getElementById("cDRMCreate").checked=!1;document.getElementById("cDRMEdit").checked=!1;document.getElementById("cDRMOrder").checked=!1;document.getElementById("cDRMDelete").checked=!1;$rootScope.cConCreate=!1;$rootScope.cConEdit=!1;$rootScope.cDRMOrder=!1;$rootScope.cConDelete=!1;$rootScope.DRMAccessArray=[];$scope.parameterEmpty('drm')}}
$scope.wmCheckAll=function(chk,create,edit,reorder,del,extract){$rootScope.waterMarkArray=[];if(chk.target.checked){document.getElementById("cWMCreate").checked=!0;document.getElementById("cWMEdit").checked=!0;document.getElementById("cWMOrder").checked=!0;document.getElementById("cWMDelete").checked=!0;document.getElementById("cWMExtract").checked=!0;if($rootScope.cWMCreate=!0)
$rootScope.waterMarkArray.push(create);if($rootScope.cWMEdit=!0)
$rootScope.waterMarkArray.push(edit);if($rootScope.cWMOrder=!0)
$rootScope.waterMarkArray.push(reorder);if($rootScope.cWMDelete=!0)
$rootScope.waterMarkArray.push(del);if($rootScope.cWMExtract=!0)
$rootScope.waterMarkArray.push(extract)}else{document.getElementById("cWMCreate").checked=!1;document.getElementById("cWMEdit").checked=!1;document.getElementById("cWMOrder").checked=!1;document.getElementById("cWMDelete").checked=!1;document.getElementById("cWMExtract").checked=!1;$rootScope.cWMCreate=!1;$rootScope.cWMEdit=!1;$rootScope.cWMOrder=!1;$rootScope.cWMDelete=!1;$rootScope.cWMExtract=!1;$rootScope.waterMarkArray=[];$scope.parameterEmpty('WM')}}
$rootScope.showDashbord=!1;$rootScope.showAsset=!1;$rootScope.showMetadata=!1;$rootScope.showReport=!1;$rootScope.showShelf=!1;$rootScope.showWidget=!1;$rootScope.showCatalogue=!1;$rootScope.showConversion=!1;$rootScope.showDRM=!1;$rootScope.showMD=!1;$rootScope.showWM=!1;$scope.createNewRole=function(){$rootScope.moduleAllSelected=!1;$rootScope.roleCreateButton=!0;$rootScope.roleEditButton=!1;$rootScope.customDashboardArray=[];$rootScope.customWidgetdArray=[];$rootScope.dWidgetAccessArray=[];$rootScope.assetAccessArray=[];$rootScope.metaDataAccessArray=[];$rootScope.shelfAccessArray=[];$rootScope.dReportAccessArray=[];$rootScope.accoutAccessArray=[];$rootScope.metaAccessArray=[];$rootScope.pCAccessArray=[];$rootScope.formatAccessArray=[];$rootScope.bRuleAccessArray=[];$rootScope.reportAdminArray=[];$rootScope.roleAccessArray=[];$rootScope.userAccessArray=[];$rootScope.partnerAccessArray=[];$rootScope.vendorAccessArray=[];$rootScope.widgetAccessArray=[];$rootScope.catalogueAccessArray=[];$rootScope.conversionAccessArray=[];$rootScope.DRMAccessArray=[];$rootScope.notificationAccess=[];$rootScope.cAFSCAccess=[];$rootScope.cADAAccess=[];$rootScope.cMDAAccess=[];$rootScope.miscellaneousArray=[];$rootScope.waterMarkArray=[];$rootScope.roleName='';$scope.editParameterEmpty();$scope.parameterEmpty('administrator');$scope.checkAdministrator('CREATE')}
$scope.parameterEmpty=function(checkVal){if(checkVal=='dashboard'){$rootScope.cDashboradView=!1;document.getElementById("cDashboradView").checked=!1;$rootScope.cWidgetView=!1;angular.forEach($rootScope.widgetList,function(value){var test='dwidget_'+value.widgetId;$rootScope[test]=!1;document.getElementById('dwidget_'+value.widgetId).checked=!1});document.getElementById("dWidgetCheck").checked=!1;$rootScope.dWidgetCheck=!1}else if(checkVal=='dwidget'){angular.forEach($rootScope.widgetList,function(value){var test='dwidget_'+value.widgetId;$rootScope[test]=!1})
$rootScope.dWidgetCheck=!1}
else if(checkVal=='asset'){document.getElementById("atCheck").checked=!1;$rootScope.atCheck=!1;$rootScope.assetView=!1;$rootScope.assetMU=!1;$rootScope.assetBU=!1;$rootScope.downloadShare=!1;$rootScope.BUShare=!1;$rootScope.assetDistribution=!1;$rootScope.assetConversion=!1;$rootScope.assetDelete=!1;$rootScope.assetApproval=!1;$rootScope.assetDownload=!1;$rootScope.assetDeleteApproval=!1}
else if(checkVal=='metadata'){$rootScope.mtCheck=!1;document.getElementById("mtCheck").checked=!1;$rootScope.mtView=!1;$rootScope.mtCreate=!1;$rootScope.mtEdit=!1;$rootScope.mtBU=!1;$rootScope.mtDownload=!1;$rootScope.mtShare=!1;$rootScope.mtDistribution=!1;$rootScope.mtDelete=!1;$rootScope.mtExport=!1;$rootScope.mtApproval=!1}
else if(checkVal=='report'){$rootScope.dReportCheck=!1;document.getElementById("dReportCheck").checked=!1;angular.forEach($rootScope.reportList,function(value){var checkReoprt="cReport_"+value.reportId;$rootScope[checkReoprt]=!1;document.getElementById("cReport_"+value.reportId).checked=!1})}
else if(checkVal=='shelf'){document.getElementById("shelfCheck").checked=!1;$rootScope.shelfCheck=!1;$rootScope.cShelfView=!1;$rootScope.cShelfCreate=!1;$rootScope.cShelfEdit=!1;$rootScope.cShelfDownload=!1;$rootScope.cShelfShare=!1;$rootScope.cShelfDelete=!1}
else if(checkVal=='administrator'){$rootScope.aAccountCreate=!1;$rootScope.aAccountEdit=!1;$rootScope.aAccountDelete=!1;$rootScope.aAccountCheck=!1;if(document.getElementById("aAccountCheck"))
document.getElementById("aAccountCheck").checked=!1;$rootScope.aMtCreate=!1;$rootScope.aMtEdit=!1;$rootScope.aMtDelete=!1;$rootScope.aMtShare=!1;$rootScope.aMtCheck=!1;if(document.getElementById("aMtCheck"))
document.getElementById("aMtCheck").checked=!1;$rootScope.aPcCreate=!1;$rootScope.aPcEdit=!1;$rootScope.aPcDelete=!1;$rootScope.aPcCheck=!1;if(document.getElementById("aPcCheck"))
document.getElementById("aPcCheck").checked=!1;$rootScope.aFmtCreate=!1;$rootScope.aFmtEdit=!1;$rootScope.aFmtDelete=!1;$rootScope.aFmtCheck=!1;if(document.getElementById("aFmtCheck"))
document.getElementById("aFmtCheck").checked=!1;$rootScope.aBrCreate=!1;$rootScope.aBrEdit=!1;$rootScope.aBrDelete=!1;$rootScope.aBrApprove=!1;$rootScope.aBrDuplicate=!1;$rootScope.aBrCheck=!1;if(document.getElementById("aBrCheck"))
document.getElementById("aBrCheck").checked=!1;$rootScope.aRpCreate=!1;$rootScope.aRpEdit=!1;$rootScope.aRpDelete=!1;$rootScope.aRoleCreate=!1;$rootScope.aRoleEdit=!1;$rootScope.aRoleDelete=!1;$rootScope.aRoleActivate=!1;$rootScope.aRoleCheck=!1;if(document.getElementById("aRoleCheck"))
document.getElementById("aRoleCheck").checked=!1;$rootScope.aUserCreate=!1;$rootScope.aUserEdit=!1;$rootScope.aUserDelete=!1;$rootScope.aUserDeactivate=!1;$rootScope.aUserActivate=!1;$rootScope.aUserResend=!1;$rootScope.aUserCheck=!1;$rootScope.aUserUnlock=!1;if(document.getElementById("aUserCheck"))
document.getElementById("aUserCheck").checked=!1;$rootScope.aPtCreate=!1;$rootScope.aPtEdit=!1;$rootScope.aPtDelete=!1;$rootScope.aPtSFP=!1;$rootScope.aPtUFP=!1;$rootScope.aPtActivate=!1;$rootScope.aPtCheck=!1;if(document.getElementById("aPtCheck"))
document.getElementById("aPtCheck").checked=!1;$rootScope.aVdCreate=!1;$rootScope.aVdEdit=!1;$rootScope.aVdDelete=!1;$rootScope.aVdActivate=!1;$rootScope.aVdCheck=!1;if(document.getElementById("aVdCheck"))
document.getElementById("aVdCheck").checked=!1;$rootScope.aNFCreate=!1;$rootScope.aNFEdit=!1;$rootScope.aNFDelete=!1;$rootScope.aNFCheck=!1;if(document.getElementById("aNFCheck"))
document.getElementById("aNFCheck").checked=!1;$rootScope.aSDCreate=!1;$rootScope.aSDEdit=!1;$rootScope.aSDCheck=!1;if(document.getElementById("aSDCheck"))
document.getElementById("aSDCheck").checked=!1}
else if(checkVal=='widget'){if(document.getElementById("widgetCheck"))
document.getElementById("widgetCheck").checked=!1;$rootScope.widgetCheck=!1;$rootScope.wdView=!1;$rootScope.wdCreate=!1;$rootScope.wdEdit=!1;$rootScope.wdDelete=!1;$rootScope.wdActivate=!1}
else if(checkVal=='catg'){if(document.getElementById("ctlgCheck"))
document.getElementById("ctlgCheck").checked=!1;$rootScope.ctlgCheck=!1;$rootScope.catgView=!1;$rootScope.catgCreate=!1;$rootScope.catgEdit=!1;$rootScope.catgDelete=!1;$rootScope.ctlgCheck=!1}
else if(checkVal=='conversion'){if(document.getElementById("conCheck"))
document.getElementById("conCheck").checked=!1;$rootScope.conCheck=!1;$rootScope.cConView=!1;$rootScope.cConCreate=!1;$rootScope.cConEdit=!1;$rootScope.cConDelete=!1;if(document.getElementById("cAFSCApproval")){document.getElementById("cAFSCApproval").checked=!1;$rootScope.cAFSCApproval=!1}}
else if(checkVal=='drm'){if(document.getElementById("drmCheck"))
document.getElementById("drmCheck").checked=!1;$rootScope.drmCheck=!1;$rootScope.cDRMCreate=!1;$rootScope.cDRMEdit=!1;$rootScope.cDRMOrder=!1;$rootScope.cDRMDelete=!1}else if(checkVal=='MD'){$rootScope.aCPaccess=!1;document.getElementById("aCPaccess").checked=!1;$rootScope.aCDSaccess=!1;document.getElementById("aCDSaccess").checked=!1;$rootScope.mCPaccess=!1;document.getElementById("mCPaccess").checked=!1;$rootScope.mCDSaccess=!1;document.getElementById("mCDSaccess").checked=!1}else if(checkVal=='WM'){if(document.getElementById("wmCheck"))
document.getElementById("wmCheck").checked=!1;$rootScope.wmCheck=!1;$rootScope.cWMCreate=!1;$rootScope.cWMEdit=!1;$rootScope.cWMOrder=!1;$rootScope.cWMDelete=!1;$rootScope.cWMExtract=!1}
$rootScope.inactiveTitles=!1;if(document.getElementById("inactiveTitles"))
document.getElementById("inactiveTitles").checked=!1;$rootScope.sPOC=!1;if(document.getElementById("sPOC"))
document.getElementById("sPOC").checked=!1}
$scope.editParameterEmpty=function(){$rootScope.cDashboradView=!1;$rootScope.cWidgetView=!1;$rootScope.dWidgetCheck=!1;angular.forEach($rootScope.widgetList,function(value){var test='dwidget_'+value.widgetId;$rootScope[test]=!1})
$rootScope.atCheck=!1;$rootScope.assetView=!1;$rootScope.assetMU=!1;$rootScope.assetBU=!1;$rootScope.downloadShare=!1;$rootScope.BUShare=!1;$rootScope.assetDistribution=!1;$rootScope.assetConversion=!1;$rootScope.assetDelete=!1;$rootScope.assetApproval=!1;$rootScope.assetDownload=!1;$rootScope.assetDeleteApproval=!1;$rootScope.mtCheck=!1;$rootScope.mtView=!1;$rootScope.mtCreate=!1;$rootScope.mtEdit=!1;$rootScope.mtBU=!1;$rootScope.mtDownload=!1;$rootScope.mtShare=!1;$rootScope.mtDistribution=!1;$rootScope.mtDelete=!1;$rootScope.mtExport=!1;$rootScope.mtApproval=!1;angular.forEach($rootScope.reportList,function(value){var checkReoprt="cReport_"+value.reportId;$rootScope[checkReoprt]=!1});$rootScope.dReportCheck=!1;$rootScope.cShelfView=!1;$rootScope.cShelfCreate=!1;$rootScope.cShelfEdit=!1;$rootScope.cShelfDownload=!1;$rootScope.cShelfShare=!1;$rootScope.cShelfDelete=!1;$rootScope.shelfCheck=!1
$rootScope.aAccountView=!1;$rootScope.aAccountCreate=!1;$rootScope.aAccountEdit=!1;$rootScope.aAccountDelete=!1;$rootScope.aMtView=!1;$rootScope.aMtCreate=!1;$rootScope.aMtEdit=!1;$rootScope.aMtDelete=!1;$rootScope.aMtShare=!1;$rootScope.aMtCheck=!1;$rootScope.aPcView=!1;$rootScope.aPcCreate=!1;$rootScope.aPcEdit=!1;$rootScope.aPcDelete=!1;$rootScope.aPcCheck=!1;$rootScope.aFmtView=!1;$rootScope.aFmtCreate=!1;$rootScope.aFmtEdit=!1;$rootScope.aFmtDelete=!1;$rootScope.aFmtCheck=!1;$rootScope.aBrView=!1;$rootScope.aBrCreate=!1;$rootScope.aBrEdit=!1;$rootScope.aBrDelete=!1;$rootScope.aBrApprove=!1;$rootScope.aBrDuplicate=!1;$rootScope.aBrCheck=!1;$rootScope.aRpView=!1;$rootScope.aRpCreate=!1;$rootScope.aRpEdit=!1;$rootScope.aRpDelete=!1;$rootScope.aRoleView=!1;$rootScope.aRoleCreate=!1;$rootScope.aRoleEdit=!1;$rootScope.aRoleDelete=!1;$rootScope.aRoleActivate=!1;$rootScope.aRoleCheck=!1;$rootScope.aUserView=!1;$rootScope.aUserCreate=!1;$rootScope.aUserEdit=!1;$rootScope.aUserDelete=!1;$rootScope.aUserDeactivate=!1;$rootScope.aUserActivate=!1;$rootScope.aUserResend=!1;$rootScope.aUserCheck=!1;$rootScope.aUserUnlock=!1;$rootScope.aPtView=!1;$rootScope.aPtCreate=!1;$rootScope.aPtEdit=!1;$rootScope.aPtDelete=!1;$rootScope.aPtSFP=!1;$rootScope.aPtUFP=!1;$rootScope.aPtActivate=!1;$rootScope.aPtCheck=!1;$rootScope.aVdView=!1;$rootScope.aVdCreate=!1;$rootScope.aVdEdit=!1;$rootScope.aVdDelete=!1;$rootScope.aVdActivate=!1;$rootScope.aVdCheck=!1;$rootScope.aNFView=!1;$rootScope.aNFCreate=!1;$rootScope.aNFEdit=!1;$rootScope.aNFDelete=!1;$rootScope.aNFCheck=!1;$rootScope.aSDView=!1;$rootScope.aSDCreate=!1;$rootScope.aSDEdit=!1;$rootScope.aSDCheck=!1;$rootScope.wdView=!1;$rootScope.wdCreate=!1;$rootScope.wdEdit=!1;$rootScope.wdDelete=!1;$rootScope.wdActivate=!1;$rootScope.widgetCheck=!1;$rootScope.catgView=!1;$rootScope.catgCreate=!1;$rootScope.catgEdit=!1;$rootScope.catgDelete=!1;$rootScope.ctlgCheck=!1;$rootScope.cConView=!1;$rootScope.cConCreate=!1;$rootScope.cConEdit=!1;$rootScope.cConDelete=!1;$rootScope.conCheck=!1;$rootScope.cAFSCApproval=!1;$rootScope.cDRMCreate=!1;$rootScope.cDRMEdit=!1;$rootScope.cDRMOrder=!1;$rootScope.cDRMDelete=!1;$rootScope.drmCheck=!1;$rootScope.aCPaccess=!1;$rootScope.aCDSaccess=!1;$rootScope.mCPaccess=!1;$rootScope.mCDSaccess=!1;$rootScope.wmCheck=!1;$rootScope.cWMCreate=!1;$rootScope.cWMEdit=!1;$rootScope.cWMOrder=!1;$rootScope.cWMDelete=!1;$rootScope.cWMExtract=!1;$rootScope.inactiveTitles=!1;$rootScope.sPOC=!1}
$scope.checkAdministrator=function(checkParam){$rootScope.accoutAccessArray=[];$rootScope.metaAccessArray=[];$rootScope.pCAccessArray=[];$rootScope.formatAccessArray=[];$rootScope.bRuleAccessArray=[];$rootScope.reportAdminArray=[];$rootScope.roleAccessArray=[];$rootScope.userAccessArray=[];$rootScope.partnerAccessArray=[];$rootScope.vendorAccessArray=[];$rootScope.widgetAccessArray=[];$rootScope.catalogueAccessArray=[];$rootScope.conversionAccessArray=[];$rootScope.DRMAccessArray=[];$rootScope.notificationAccess=[];$rootScope.cAFSCAccess=[];$rootScope.cADAAccess=[];$rootScope.cMDAAccess=[];$rootScope.miscellaneousArray=[];$rootScope.stdDashboardAccessArray=[];angular.forEach($scope.roleModuleList,function(module){if(checkParam=='CREATE'){if(module.moduleId=="MOD00006"){$timeout(function(){if(document.getElementById("module_"+module.moduleId))
document.getElementById("module_"+module.moduleId).checked=!0;if(document.getElementById("module_"+module.moduleId))
angular.element(document.getElementById("module_"+module.moduleId))[0].disabled=!0;if($rootScope.accoutAccessArray.indexOf("VIEW")==-1)
$rootScope.accoutAccessArray.push("VIEW");$rootScope.aAccountView=!0;if($rootScope.metaAccessArray.indexOf("VIEW")==-1)
$rootScope.metaAccessArray.push("VIEW");$rootScope.aMtView=!0;if($rootScope.pCAccessArray.indexOf("VIEW")==-1)
$rootScope.pCAccessArray.push("VIEW");$rootScope.aPcView=!0;if($rootScope.formatAccessArray.indexOf("VIEW")==-1)
$rootScope.formatAccessArray.push("VIEW");$rootScope.aFmtView=!0;if($rootScope.bRuleAccessArray.indexOf("VIEW")==-1)
$rootScope.bRuleAccessArray.push("VIEW");$rootScope.aBrView=!0;if($rootScope.roleAccessArray.indexOf("VIEW")==-1)
$rootScope.roleAccessArray.push("VIEW");$rootScope.aRoleView=!0;if($rootScope.userAccessArray.indexOf("VIEW")==-1)
$rootScope.userAccessArray.push("VIEW");$rootScope.aUserView=!0;if($rootScope.partnerAccessArray.indexOf("VIEW")==-1);$rootScope.partnerAccessArray.push("VIEW");$rootScope.aPtView=!0;if($rootScope.vendorAccessArray.indexOf("VIEW")==-1)
$rootScope.vendorAccessArray.push("VIEW");$rootScope.aVdView=!0;if($rootScope.notificationAccess.indexOf("VIEW")==-1)
$rootScope.notificationAccess.push("VIEW");$rootScope.aNFView=!0;if($rootScope.stdDashboardAccessArray.indexOf("VIEW")==-1)
$rootScope.stdDashboardAccessArray.push("VIEW");$rootScope.aSDView=!0;$rootScope.showAdmin=!0;if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}},200)}
if(module.moduleId=="MOD00012"){$timeout(function(){if(document.getElementById("module_"+module.moduleId))
document.getElementById("module_"+module.moduleId).checked=!0;if(document.getElementById("module_"+module.moduleId))
angular.element(document.getElementById("module_"+module.moduleId))[0].disabled=!0;$rootScope.showMisclus=!0;if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}},200)}}else{if(module.moduleId=="MOD00006"){$timeout(function(){if(document.getElementById("module_"+module.moduleId))
document.getElementById("module_"+module.moduleId).checked=!0;if(document.getElementById("module_"+module.moduleId))
angular.element(document.getElementById("module_"+module.moduleId))[0].disabled=!0},200);$rootScope.showAdmin=!0;if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}}
if(module.moduleId=="MOD00012"){$timeout(function(){if(document.getElementById("module_"+module.moduleId))
document.getElementById("module_"+module.moduleId).checked=!0;if(document.getElementById("module_"+module.moduleId))
angular.element(document.getElementById("module_"+module.moduleId))[0].disabled=!0},200);$rootScope.showMisclus=!0;if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}}}})}
$scope.moduleToggled=function(module,chk){if(chk){if(module.moduleId=="MOD00001")
$rootScope.showDashbord=!0;if(module.moduleId=="MOD00002"){$rootScope.showAsset=!0}
if(module.moduleId=="MOD00003"){$rootScope.showMetadata=!0}
if(module.moduleId=="MOD00004"){$rootScope.showReport=!0}
if(module.moduleId=="MOD00005"){$rootScope.showShelf=!0}
if(module.moduleId=="MOD00007"){$rootScope.showWidget=!0}
if(module.moduleId=="MOD00008"){$rootScope.showCatalogue=!0}
if(module.moduleId=="MOD00009"){$rootScope.showConversion=!0}
if(module.moduleId=="MOD00010"){$rootScope.showDRM=!0}
if(module.moduleId=="MOD00011"){$rootScope.showMD=!0}
if(module.moduleId=="MOD00013"){$rootScope.showWM=!0}
if($rootScope.newRoleModuleNames.indexOf(module.moduleName)==-1){$rootScope.newRoleModuleNames.push(module.moduleName)}}else{if(module.moduleId=="MOD00001"){$rootScope.showDashbord=!1;$scope.parameterEmpty('dashboard')}
if(module.moduleId=="MOD00002"){$rootScope.showAsset=!1;$scope.parameterEmpty('asset')}
if(module.moduleId=="MOD00003"){$rootScope.showMetadata=!1;$scope.parameterEmpty('metadata')}
if(module.moduleId=="MOD00004"){$rootScope.showReport=!1;$scope.parameterEmpty('report')}
if(module.moduleId=="MOD00005"){$rootScope.showShelf=!1;$scope.parameterEmpty('shelf')}
if(module.moduleId=="MOD00007"){$rootScope.showWidget=!1;$scope.parameterEmpty('widget')}
if(module.moduleId=="MOD00008"){$rootScope.showCatalogue=!1;$scope.parameterEmpty('catg')}
if(module.moduleId=="MOD00009"){$rootScope.showConversion=!1;$scope.parameterEmpty('conversion')}
if(module.moduleId=="MOD00010"){$rootScope.showDRM=!1;$scope.parameterEmpty('drm')}
if(module.moduleId=="MOD00011"){$rootScope.showMD=!1;$scope.parameterEmpty('MD')}
if(module.moduleId=="MOD00013"){$rootScope.showWM=!1;$scope.parameterEmpty('WM')}
var index=$rootScope.newRoleModuleNames.indexOf(module.moduleName);$rootScope.newRoleModuleNames.splice(index,1)}
var count=0;angular.forEach($scope.roleModuleList,function(val){if(document.getElementById("module_"+val.moduleId).checked){count++}});document.getElementById("moduleAllSelected").checked=(count===$scope.roleModuleList.length)}
$scope.cDashboradChecked=function(value,checked){if(checked.target.checked){$rootScope.cWidgetView=!0;$rootScope.customDashboardArray.push(value);$rootScope.customWidgetdArray.push(value)}else{$rootScope.cWidgetView=!1;$rootScope.customDashboardArray.splice(value,1);$rootScope.customWidgetdArray.splice(value,1)}}
$scope.cWidgetChecked=function(value,checked){if(checked.target.checked){$rootScope.customWidgetdArray.push(value)}else{$rootScope.customWidgetdArray.splice(value,1)}}
$scope.dWidgetChecked=function(value,checked){if(checked.target.checked){$rootScope.dWidgetAccessArray.push(value)}else{$rootScope.dWidgetAccessArray.splice($rootScope.dWidgetAccessArray.indexOf(value),1)}
$timeout(function(){document.getElementById("dWidgetCheck").checked=($rootScope.dWidgetAccessArray.length===$rootScope.widgetList.length);$rootScope.dWidgetCheck=($rootScope.dWidgetAccessArray.length===$rootScope.widgetList.length)},100)}
$scope.dWidgetCheckAll=function(checked){$rootScope.dWidgetAccessArray=[];if(checked.target.checked){angular.forEach($rootScope.widgetList,function(val){document.getElementById("dwidget_"+val.widgetId).checked=!0;$rootScope.dWidgetAccessArray.push(val.widgetId)})}else{angular.forEach($rootScope.widgetList,function(val){document.getElementById("dwidget_"+val.widgetId).checked=!1});$rootScope.dWidgetAccessArray=[];$scope.parameterEmpty('dwidget')}}
$scope.aAccessChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("assetView").checked=!0;$rootScope.assetView=!0;if($rootScope.assetAccessArray.indexOf("VIEW")==-1)
$rootScope.assetAccessArray.push("VIEW")
if($rootScope.assetAccessArray.indexOf(value)==-1)
$rootScope.assetAccessArray.push(value)}else $rootScope.assetAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.assetAccessArray.indexOf(value);$rootScope.assetAccessArray.splice(index,1)}else{document.getElementById("assetView").checked=!1;$rootScope.assetView=!1;$rootScope.assetAccessArray.splice($rootScope.assetAccessArray.indexOf(value),1)}}
if($rootScope.assetAccessArray.indexOf('VIEW')>=0&&$rootScope.assetAccessArray.length>1){$rootScope.assetViewCheck=!0}else{$rootScope.assetViewCheck=!1}
if($rootScope.assetAccessArray.length<11){document.getElementById("atCheck").checked=!1;$rootScope.atCheck=!1}else if($rootScope.assetAccessArray.length==11){document.getElementById("atCheck").checked=!0;$rootScope.atCheck=!0}}
$scope.mtAccessChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("mtView").checked=!0;$rootScope.mtView=!0;if($rootScope.metaDataAccessArray.indexOf("VIEW")==-1)
$rootScope.metaDataAccessArray.push("VIEW")
if($rootScope.metaDataAccessArray.indexOf(value)==-1)
$rootScope.metaDataAccessArray.push(value)}else $rootScope.metaDataAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.metaDataAccessArray.indexOf(value);$rootScope.metaDataAccessArray.splice(index,1)}else{document.getElementById("mtView").checked=!1;$rootScope.mtView=!1;$rootScope.metaDataAccessArray.splice($rootScope.metaDataAccessArray.indexOf(value),1)}}
if($rootScope.metaDataAccessArray.indexOf('VIEW')>=0&&$rootScope.metaDataAccessArray.length>1){$rootScope.mtViewCheck=!0}else{$rootScope.mtViewCheck=!1}
if($rootScope.metaDataAccessArray.length<'10'){document.getElementById("mtCheck").checked=!1;$rootScope.mtCheck=!1}else if($rootScope.metaDataAccessArray.length=='10'){document.getElementById("mtCheck").checked=!0;$rootScope.mtCheck=!0}}
$scope.cReportChecked=function(value,checked){if(checked){if(value!="VIEW"){document.getElementById("cReportView").checked=!0;if($rootScope.reportAccessArray.indexOf("VIEW")==-1)
$rootScope.reportAccessArray.push("VIEW")
if($rootScope.reportAccessArray.indexOf(value)==-1)
$rootScope.reportAccessArray.push(value)}else $rootScope.reportAccessArray.push(value)}else{var index=$rootScope.reportAccessArray.indexOf(value);$rootScope.reportAccessArray.splice(index,1)}
if($rootScope.reportAccessArray.length<'3'){document.getElementById("reportCheck").checked=!1;return!1}else if($rootScope.reportAccessArray.length=='3'){document.getElementById("reportCheck").checked=!0;return!0}}
$scope.dReportChecked=function(value,checked){$timeout(function(){$scope.dReportCheck=($rootScope.dReportAccessArray.length===$rootScope.reportList.length)},100);if(checked.target.checked){$rootScope.dReportAccessArray.push(value)}else{$rootScope.dReportAccessArray.splice($rootScope.dReportAccessArray.indexOf(value),1)}}
$scope.dReportCheckAll=function(checked){$rootScope.dReportAccessArray=[];if(checked.target.checked){angular.forEach($rootScope.reportList,function(val){document.getElementById("cReport_"+val.reportId).checked=!0;$rootScope.dReportAccessArray.push(val.reportId)})}else{angular.forEach($rootScope.reportList,function(val){document.getElementById("cReport_"+val.reportId).checked=!1});$rootScope.dReportAccessArray=[];$scope.parameterEmpty('report')}}
$scope.cShelfChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("cShelfView").checked=!0;$rootScope.cShelfView=!0;if($rootScope.shelfAccessArray.indexOf("VIEW")==-1)
$rootScope.shelfAccessArray.push("VIEW")
if($rootScope.shelfAccessArray.indexOf(value)==-1)
$rootScope.shelfAccessArray.push(value)}else $rootScope.shelfAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.shelfAccessArray.indexOf(value);$rootScope.shelfAccessArray.splice(index,1)}else{document.getElementById("cShelfView").checked=!1;$rootScope.cShelfView=!1;$rootScope.shelfAccessArray.splice($rootScope.shelfAccessArray.indexOf(value),1)}}
if($rootScope.shelfAccessArray.indexOf('VIEW')>=0&&$rootScope.shelfAccessArray.length>1){$rootScope.shelfViewCheck=!0}else{$rootScope.shelfViewCheck=!1}
if($rootScope.shelfAccessArray.length<'6'){document.getElementById("shelfCheck").checked=!1;$rootScope.shelfCheck=!1}else if($rootScope.shelfAccessArray.length=='6'){document.getElementById("shelfCheck").checked=!0;$rootScope.shelfCheck=!0}}
$scope.aAccountCheckAll=function(chk,view,create,edit,del){$rootScope.accoutAccessArray=[];if(chk.target.checked){document.getElementById("aAccountView").checked=!0;document.getElementById("aAccountCreate").checked=!0;document.getElementById("aAccountEdit").checked=!0;document.getElementById("aAccountDelete").checked=!0;if($rootScope.aAccountCreate=!0){if($rootScope.accoutAccessArray.indexOf("VIEW")==-1)
$rootScope.accoutAccessArray.push("VIEW")}
if($rootScope.aAccountCreate=!0)
$rootScope.accoutAccessArray.push(create);if($rootScope.aAccountEdit=!0)
$rootScope.accoutAccessArray.push(edit);if($rootScope.aAccountDelete=!0)
$rootScope.accoutAccessArray.push(del)}else{document.getElementById("aAccountCreate").checked=!1;document.getElementById("aAccountEdit").checked=!1;document.getElementById("aAccountDelete").checked=!1;$rootScope.aAccountCreate=!1;$rootScope.aAccountEdit=!1;$rootScope.aAccountDelete=!1;$rootScope.accoutAccessArray=[]}
if($rootScope.accoutAccessArray.indexOf('VIEW')>=0&&$rootScope.accoutAccessArray.length>1){$rootScope.aActViewCheck=!0}else{$rootScope.aActViewCheck=!1}}
$scope.aAccoutChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aAccountView").checked=!0;$rootScope.aAccountView=!0;if($rootScope.accoutAccessArray.indexOf("VIEW")==-1)
$rootScope.accoutAccessArray.push("VIEW")
if($rootScope.accoutAccessArray.indexOf(value)==-1)
$rootScope.accoutAccessArray.push(value)}else $rootScope.accoutAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.accoutAccessArray.indexOf(value);$rootScope.accoutAccessArray.splice(index,1)}else{document.getElementById("aAccountView").checked=!1;$rootScope.aAccountView=!1;$rootScope.accoutAccessArray.splice($rootScope.accoutAccessArray.indexOf(value),1)}}
if($rootScope.accoutAccessArray.indexOf('VIEW')>=0&&$rootScope.accoutAccessArray.length>1){$rootScope.aActViewCheck=!0}else{$rootScope.aActViewCheck=!1}
if($rootScope.accoutAccessArray.length<'4'){document.getElementById("aAccountCheck").checked=!1;$rootScope.aAccountCheck=!1}else if($rootScope.accoutAccessArray.length=='4'){document.getElementById("aAccountCheck").checked=!0;$rootScope.aAccountCheck=!0}}
$scope.aMtCheckAll=function(chk,view,create,edit,del,share){$rootScope.metaAccessArray=[];if(chk.target.checked){document.getElementById("aMtView").checked=!0;document.getElementById("aMtCreate").checked=!0;document.getElementById("aMtEdit").checked=!0;document.getElementById("aMtDelete").checked=!0;document.getElementById("aMtShare").checked=!0;if($rootScope.aMtView=!0){if($rootScope.metaAccessArray.indexOf("VIEW")==-1)
$rootScope.metaAccessArray.push("VIEW")}
if($rootScope.aMtCreate=!0)
$rootScope.metaAccessArray.push(create);if($rootScope.aMtEdit=!0)
$rootScope.metaAccessArray.push(edit);if($rootScope.aMtDelete=!0)
$rootScope.metaAccessArray.push(del);if($rootScope.aMtShare=!0)
$rootScope.metaAccessArray.push(share)}else{document.getElementById("aMtCreate").checked=!1;document.getElementById("aMtEdit").checked=!1;document.getElementById("aMtDelete").checked=!1;document.getElementById("aMtShare").checked=!1;$rootScope.aMtCreate=!1;$rootScope.aMtEdit=!1;$rootScope.aMtDelete=!1;$rootScope.aMtShare=!1;$rootScope.metaAccessArray=[]}}
$scope.aMtChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aMtView").checked=!0;$rootScope.aMtView=!0;if($rootScope.metaAccessArray.indexOf("VIEW")==-1)
$rootScope.metaAccessArray.push("VIEW")
if($rootScope.metaAccessArray.indexOf(value)==-1)
$rootScope.metaAccessArray.push(value)}else $rootScope.metaAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.metaAccessArray.indexOf(value);$rootScope.metaAccessArray.splice(index,1)}else{document.getElementById("aMtView").checked=!1;$rootScope.aMtView=!1;$rootScope.metaAccessArray.splice($rootScope.metaAccessArray.indexOf(value),1)}}
if($rootScope.metaAccessArray.indexOf('VIEW')>=0&&$rootScope.metaAccessArray.length>1){$rootScope.aMtViewCheck=!0}else{$rootScope.aMtViewCheck=!1}
if($rootScope.metaAccessArray.length<'5'){document.getElementById("aMtCheck").checked=!1;$rootScope.aMtCheck=!1}else if($rootScope.metaAccessArray.length=='5'){document.getElementById("aMtCheck").checked=!0;$rootScope.aMtCheck=!0}}
$scope.aPcCheckAll=function(chk,view,create,edit,del){$rootScope.pCAccessArray=[];if(chk.target.checked){document.getElementById("aPcView").checked=!0;document.getElementById("aPcCreate").checked=!0;document.getElementById("aPcEdit").checked=!0;document.getElementById("aPcDelete").checked=!0;if($rootScope.aPcView=!0){if($rootScope.pCAccessArray.indexOf("VIEW")==-1)
$rootScope.pCAccessArray.push("VIEW")}
if($rootScope.aPcCreate=!0)
$rootScope.pCAccessArray.push(create);if($rootScope.aPcEdit=!0)
$rootScope.pCAccessArray.push(edit);if($rootScope.aPcDelete=!0)
$rootScope.pCAccessArray.push(del)}else{document.getElementById("aPcCreate").checked=!1;document.getElementById("aPcEdit").checked=!1;document.getElementById("aPcDelete").checked=!1;$rootScope.aPcCreate=!1;$rootScope.aPcEdit=!1;$rootScope.aPcDelete=!1;$rootScope.pCAccessArray=[]}}
$scope.aPcChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aPcView").checked=!0;$rootScope.aPcView=!0;if($rootScope.pCAccessArray.indexOf("VIEW")==-1)
$rootScope.pCAccessArray.push("VIEW")
if($rootScope.pCAccessArray.indexOf(value)==-1)
$rootScope.pCAccessArray.push(value)}else $rootScope.pCAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.pCAccessArray.indexOf(value);$rootScope.pCAccessArray.splice(index,1)}else{document.getElementById("aPcView").checked=!1;$rootScope.aPcView=!1;$rootScope.pCAccessArray.splice($rootScope.pCAccessArray.indexOf(value),1)}}
if($rootScope.pCAccessArray.indexOf('VIEW')>=0&&$rootScope.pCAccessArray.length>1){$rootScope.aPcViewCheck=!0}else{$rootScope.aPcViewCheck=!1}
if($rootScope.pCAccessArray.length<'4'){document.getElementById("aPcCheck").checked=!1;$rootScope.aPcCheck=!1}else if($rootScope.pCAccessArray.length=='4'){document.getElementById("aPcCheck").checked=!0;$rootScope.aPcCheck=!0}}
$scope.aFmtCheckAll=function(chk,view,create,edit,del){$rootScope.formatAccessArray=[];if(chk.target.checked){document.getElementById("aFmtView").checked=!0;document.getElementById("aFmtCreate").checked=!0;document.getElementById("aFmtEdit").checked=!0;document.getElementById("aFmtDelete").checked=!0;if($rootScope.aFmtView=!0){if($rootScope.formatAccessArray.indexOf("VIEW")==-1)
$rootScope.formatAccessArray.push("VIEW")}
if($rootScope.aFmtCreate=!0)
$rootScope.formatAccessArray.push(create);if($rootScope.aFmtEdit=!0)
$rootScope.formatAccessArray.push(edit);if($rootScope.aFmtDelete=!0)
$rootScope.formatAccessArray.push(del)}else{document.getElementById("aFmtCreate").checked=!1;document.getElementById("aFmtEdit").checked=!1;document.getElementById("aFmtDelete").checked=!1;$rootScope.aFmtCreate=!1;$rootScope.aFmtEdit=!1;$rootScope.aFmtDelete=!1;$rootScope.formatAccessArray=[]}}
$scope.aFmtChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aFmtView").checked=!0;$rootScope.aFmtView=!0;if($rootScope.formatAccessArray.indexOf("VIEW")==-1)
$rootScope.formatAccessArray.push("VIEW")
if($rootScope.formatAccessArray.indexOf(value)==-1)
$rootScope.formatAccessArray.push(value)}else $rootScope.formatAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.formatAccessArray.indexOf(value);$rootScope.formatAccessArray.splice(index,1)}else{document.getElementById("aFmtView").checked=!1;$rootScope.aFmtView=!1;$rootScope.formatAccessArray.splice($rootScope.formatAccessArray.indexOf(value),1)}}
if($rootScope.formatAccessArray.indexOf('VIEW')>=0&&$rootScope.formatAccessArray.length>1){$rootScope.aFmtViewCheck=!0}else{$rootScope.aFmtViewCheck=!1}
if($rootScope.formatAccessArray.length<'4'){document.getElementById("aFmtCheck").checked=!1;$rootScope.aFmtCheck=!1}else if($rootScope.formatAccessArray.length=='4'){document.getElementById("aFmtCheck").checked=!0;$rootScope.aFmtCheck=!0}}
$scope.aBRCheckAll=function(chk,VIEW,CREATE,EDIT,DEL,APPROVE,DUPLICATE){$rootScope.bRuleAccessArray=[];if(chk.target.checked){document.getElementById("aBrView").checked=!0;document.getElementById("aBrCreate").checked=!0;document.getElementById("aBrEdit").checked=!0;document.getElementById("aBrDelete").checked=!0;document.getElementById("aBrApprove").checked=!0;document.getElementById("aBrDuplicate").checked=!0;if($rootScope.aBrView=!0){if($rootScope.bRuleAccessArray.indexOf("VIEW")==-1)
$rootScope.bRuleAccessArray.push("VIEW")}
if($rootScope.aBrCreate=!0)
$rootScope.bRuleAccessArray.push(CREATE);if($rootScope.aBrEdit=!0)
$rootScope.bRuleAccessArray.push(EDIT);if($rootScope.aBrDelete=!0)
$rootScope.bRuleAccessArray.push(DEL);if($rootScope.aBrApprove=!0)
$rootScope.bRuleAccessArray.push(APPROVE);if($rootScope.aBrDuplicate=!0)
$rootScope.bRuleAccessArray.push(DUPLICATE)}else{document.getElementById("aBrCreate").checked=!1;document.getElementById("aBrEdit").checked=!1;document.getElementById("aBrDelete").checked=!1;document.getElementById("aBrApprove").checked=!1;document.getElementById("aBrDuplicate").checked=!1;$rootScope.aBrCreate=!1;$rootScope.aBrEdit=!1;$rootScope.aBrDelete=!1;$rootScope.aBrApprove=!1;$rootScope.aBrDuplicate=!1;$rootScope.bRuleAccessArray=[]}}
$scope.aBRChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aBrView").checked=!0;$rootScope.aBrView=!0;if($rootScope.bRuleAccessArray.indexOf("VIEW")==-1)
$rootScope.bRuleAccessArray.push("VIEW")
if($rootScope.bRuleAccessArray.indexOf(value)==-1)
$rootScope.bRuleAccessArray.push(value)}else $rootScope.bRuleAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.bRuleAccessArray.indexOf(value);$rootScope.bRuleAccessArray.splice(index,1)}else{document.getElementById("aBrView").checked=!1;$rootScope.aBrView=!1;$rootScope.bRuleAccessArray.splice($rootScope.bRuleAccessArray.indexOf(value),1)}}
if($rootScope.bRuleAccessArray.indexOf('VIEW')>=0&&$rootScope.bRuleAccessArray.length>1){$rootScope.aBrViewCheck=!0}else{$rootScope.aBrViewCheck=!1}
if($rootScope.bRuleAccessArray.length<'6'){document.getElementById("aBrCheck").checked=!1;$rootScope.aBrCheck=!1}else if($rootScope.bRuleAccessArray.length=='6'){document.getElementById("aBrCheck").checked=!0;$rootScope.aBrCheck=!0}}
$scope.aRpChecked=function(value,checked){if(checked){if($rootScope.reportAdminArray.indexOf("VIEW")==-1)
$rootScope.reportAdminArray.push("VIEW")
$rootScope.reportAdminArray.push(value)}else{var index=$rootScope.reportAdminArray.indexOf(value);$rootScope.reportAdminArray.splice(index,1)}}
$scope.aRoleCheckAll=function(chk,VIEW,CREATE,EDIT,DEL,activate){$rootScope.roleAccessArray=[];if(chk.target.checked){document.getElementById("aRoleView").checked=!0;document.getElementById("aRoleCreate").checked=!0;document.getElementById("aRoleEdit").checked=!0;document.getElementById("aRoleDelete").checked=!0;document.getElementById("aRoleActivate").checked=!0;if($rootScope.aRoleView=!0){if($rootScope.roleAccessArray.indexOf("VIEW")==-1)
$rootScope.roleAccessArray.push("VIEW")}
if($rootScope.aRoleCreate=!0)
$rootScope.roleAccessArray.push(CREATE);if($rootScope.aRoleEdit=!0)
$rootScope.roleAccessArray.push(EDIT);if($rootScope.aRoleDelete=!0)
$rootScope.roleAccessArray.push(DEL);if($rootScope.aRoleActivate=!0)
$rootScope.roleAccessArray.push(activate)}else{document.getElementById("aRoleCreate").checked=!1;document.getElementById("aRoleEdit").checked=!1;document.getElementById("aRoleDelete").checked=!1;document.getElementById("aRoleActivate").checked=!1;$rootScope.aRoleCreate=!1;$rootScope.aRoleEdit=!1;$rootScope.aRoleDelete=!1;$rootScope.aRoleActivate=!1;$rootScope.roleAccessArray=[]}}
$scope.aRoleChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aRoleView").checked=!0;$rootScope.aRoleView=!0;if($rootScope.roleAccessArray.indexOf("VIEW")==-1)
$rootScope.roleAccessArray.push("VIEW")
if($rootScope.roleAccessArray.indexOf(value)==-1)
$rootScope.roleAccessArray.push(value)}else $rootScope.roleAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.roleAccessArray.indexOf(value);$rootScope.roleAccessArray.splice(index,1)}else{document.getElementById("aRoleView").checked=!1;$rootScope.aRoleView=!1;$rootScope.roleAccessArray.splice($rootScope.roleAccessArray.indexOf(value),1)}}
if($rootScope.roleAccessArray.indexOf('VIEW')>=0&&$rootScope.roleAccessArray.length>1){$rootScope.aRoleViewCheck=!0}else{$rootScope.aRoleViewCheck=!1}
if($rootScope.roleAccessArray.length<'5'){document.getElementById("aRoleCheck").checked=!1;$rootScope.aRoleCheck=!1}else if($rootScope.roleAccessArray.length=='5'){document.getElementById("aRoleCheck").checked=!0;$rootScope.aRoleCheck=!0}}
$scope.aUserCheckAll=function(chk,VIEW,CREATE,EDIT,DEL,activate,resend,unlock){$rootScope.userAccessArray=[];if(chk.target.checked){document.getElementById("aUserView").checked=!0;document.getElementById("aUserCreate").checked=!0;document.getElementById("aUserEdit").checked=!0;document.getElementById("aUserDelete").checked=!0;document.getElementById("aUserActivate").checked=!0;document.getElementById("aUserResend").checked=!0;document.getElementById("aUserUnlock").checked=!0;if($rootScope.aUserView=!0){if($rootScope.userAccessArray.indexOf("VIEW")==-1)
$rootScope.userAccessArray.push("VIEW")}
if($rootScope.aUserCreate=!0)
$rootScope.userAccessArray.push(CREATE);if($rootScope.aUserEdit=!0)
$rootScope.userAccessArray.push(EDIT);if($rootScope.aUserDelete=!0)
$rootScope.userAccessArray.push(DEL);if($rootScope.aUserActivate=!0)
$rootScope.userAccessArray.push(activate);if($rootScope.aUserResend=!0)
$rootScope.userAccessArray.push(resend);if($rootScope.aUserUnlock=!0)
$rootScope.userAccessArray.push(unlock)}else{document.getElementById("aUserCreate").checked=!1;document.getElementById("aUserEdit").checked=!1;document.getElementById("aUserDelete").checked=!1;document.getElementById("aUserActivate").checked=!1;document.getElementById("aUserResend").checked=!1;document.getElementById("aUserUnlock").checked=!1;$rootScope.aUserCreate=!1;$rootScope.aUserEdit=!1;$rootScope.aUserDelete=!1;$rootScope.aUserActivate=!1;$rootScope.aUserResend=!1;$rootScope.aUserUnlock=!1;$rootScope.userAccessArray=[]}}
$scope.aUserChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aUserView").checked=!0;$rootScope.aUserView=!0;if($rootScope.userAccessArray.indexOf("VIEW")==-1)
$rootScope.userAccessArray.push("VIEW")
if($rootScope.userAccessArray.indexOf(value)==-1)
$rootScope.userAccessArray.push(value)}else $rootScope.userAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.userAccessArray.indexOf(value);$rootScope.userAccessArray.splice(index,1)}else{document.getElementById("aUserView").checked=!1;$rootScope.aUserView=!1;$rootScope.userAccessArray.splice($rootScope.userAccessArray.indexOf(value),1)}}
if($rootScope.userAccessArray.indexOf('VIEW')>=0&&$rootScope.userAccessArray.length>1){$rootScope.aUserViewCheck=!0}else{$rootScope.aUserViewCheck=!1}
if($rootScope.userAccessArray.length<'7'){document.getElementById("aUserCheck").checked=!1;$rootScope.aUserCheck=!1}else if($rootScope.userAccessArray.length=='7'){$rootScope.aUserCheck=!0;document.getElementById("aUserCheck").checked=!0}}
$scope.aPtCheckAll=function(chk,VIEW,CREATE,EDIT,DEL,SFP,UFP,activate){$rootScope.partnerAccessArray=[];if(chk.target.checked){document.getElementById("aPtView").checked=!0;document.getElementById("aPtCreate").checked=!0;document.getElementById("aPtEdit").checked=!0;document.getElementById("aPtDelete").checked=!0;document.getElementById("aPtActivate").checked=!0;document.getElementById("aPtSFP").checked=!0;document.getElementById("aPtUFP").checked=!0;if($rootScope.aPtView=!0){if($rootScope.partnerAccessArray.indexOf("VIEW")==-1)
$rootScope.partnerAccessArray.push("VIEW")}
if($rootScope.aPtCreate=!0)
$rootScope.partnerAccessArray.push(CREATE);if($rootScope.aPtEdit=!0)
$rootScope.partnerAccessArray.push(EDIT);if($rootScope.aPtDelete=!0)
$rootScope.partnerAccessArray.push(DEL);if($rootScope.aPtActivate=!0)
$rootScope.partnerAccessArray.push(activate);if($rootScope.aPtSFP=!0)
$rootScope.partnerAccessArray.push(SFP);if($rootScope.aPtUFP=!0)
$rootScope.partnerAccessArray.push(UFP)}else{document.getElementById("aPtCreate").checked=!1;document.getElementById("aPtEdit").checked=!1;document.getElementById("aPtDelete").checked=!1;document.getElementById("aPtActivate").checked=!1;document.getElementById("aPtSFP").checked=!1;document.getElementById("aPtUFP").checked=!1;$rootScope.aPtCreate=!1;$rootScope.aPtEdit=!1;$rootScope.aPtDelete=!1;$rootScope.aPtActivate=!1;$rootScope.aPtSFP=!1;$rootScope.aPtUFP=!1;$rootScope.partnerAccessArray=[]}}
$scope.aPartnerChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aPtView").checked=!0;$rootScope.aPtView=!0;if($rootScope.partnerAccessArray.indexOf("VIEW")==-1)
$rootScope.partnerAccessArray.push("VIEW")
if($rootScope.partnerAccessArray.indexOf(value)==-1)
$rootScope.partnerAccessArray.push(value)}else $rootScope.partnerAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.partnerAccessArray.indexOf(value);$rootScope.partnerAccessArray.splice(index,1)}else{document.getElementById("aPtView").checked=!1;$rootScope.aPtView=!1;$rootScope.partnerAccessArray.splice($rootScope.partnerAccessArray.indexOf(value),1)}}
if($rootScope.partnerAccessArray.indexOf('VIEW')>=0&&$rootScope.partnerAccessArray.length>1){$rootScope.aPtViewCheck=!0}else{$rootScope.aPtViewCheck=!1}
if($rootScope.partnerAccessArray.length<'7'){document.getElementById("aPtCheck").checked=!1;$rootScope.aPtCheck=!1}else if($rootScope.partnerAccessArray.length=='7'){document.getElementById("aPtCheck").checked=!0;$rootScope.aPtCheck=!0}}
$scope.aVendorCheckAll=function(chk,VIEW,CREATE,EDIT,DEL,activate){$rootScope.vendorAccessArray=[];if(chk.target.checked){document.getElementById("aVdView").checked=!0;document.getElementById("aVdCreate").checked=!0;document.getElementById("aVdEdit").checked=!0;document.getElementById("aVdDelete").checked=!0;document.getElementById("aVdActivate").checked=!0;if($rootScope.aVdView=!0){if($rootScope.vendorAccessArray.indexOf("VIEW")==-1)
$rootScope.vendorAccessArray.push("VIEW")}
if($rootScope.aVdCreate=!0)
$rootScope.vendorAccessArray.push(CREATE);if($rootScope.aVdEdit=!0)
$rootScope.vendorAccessArray.push(EDIT);if($rootScope.aVdDelete=!0)
$rootScope.vendorAccessArray.push(DEL);if($rootScope.aVdActivate=!0)
$rootScope.vendorAccessArray.push(activate)}else{document.getElementById("aVdCreate").checked=!1;document.getElementById("aVdEdit").checked=!1;document.getElementById("aVdDelete").checked=!1;document.getElementById("aVdActivate").checked=!1;$rootScope.aVdCreate=!1;$rootScope.aVdEdit=!1;$rootScope.aVdDelete=!1;$rootScope.aVdActivate=!1;$rootScope.vendorAccessArray=[]}}
$scope.aVendorChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aVdView").checked=!0;$rootScope.aVdView=!0;if($rootScope.vendorAccessArray.indexOf("VIEW")==-1)
$rootScope.vendorAccessArray.push("VIEW")
if($rootScope.vendorAccessArray.indexOf(value)==-1)
$rootScope.vendorAccessArray.push(value)}else $rootScope.vendorAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.vendorAccessArray.indexOf(value);$rootScope.vendorAccessArray.splice(index,1)}else{document.getElementById("aVdView").checked=!1;$rootScope.aVdView=!1;$rootScope.vendorAccessArray.splice($rootScope.vendorAccessArray.indexOf(value),1)}}
if($rootScope.vendorAccessArray.indexOf('VIEW')>=0&&$rootScope.vendorAccessArray.length>1){$rootScope.aVdViewCheck=!0}else{$rootScope.aVdViewCheck=!1}
if($rootScope.vendorAccessArray.length<'5'){document.getElementById("aVdCheck").checked=!1;$rootScope.aVdCheck=!1}else if($rootScope.vendorAccessArray.length=='5'){document.getElementById("aVdCheck").checked=!0;$rootScope.aVdCheck=!0}}
$scope.aNotificationCheckAll=function(chk,VIEW,CREATE,EDIT,DEL){$rootScope.notificationAccess=[];if(chk.target.checked){document.getElementById("aNFView").checked=!0;document.getElementById("aNFCreate").checked=!0;document.getElementById("aNFEdit").checked=!0;document.getElementById("aNFDelete").checked=!0;if($rootScope.aNFView=!0){if($rootScope.notificationAccess.indexOf("VIEW")==-1)
$rootScope.notificationAccess.push("VIEW")}
if($rootScope.aNFCreate=!0)
$rootScope.notificationAccess.push(CREATE);if($rootScope.aNFEdit=!0)
$rootScope.notificationAccess.push(EDIT);if($rootScope.aNFDelete=!0)
$rootScope.notificationAccess.push(DEL)}else{document.getElementById("aNFCreate").checked=!1;document.getElementById("aNFEdit").checked=!1;document.getElementById("aNFDelete").checked=!1;$rootScope.aNFCreate=!1;$rootScope.aNFEdit=!1;$rootScope.aNFDelete=!1;$rootScope.notificationAccess=[]}}
$scope.aNotificationChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aNFView").checked=!0;$rootScope.aNFView=!0;if($rootScope.notificationAccess.indexOf("VIEW")==-1)
$rootScope.notificationAccess.push("VIEW")
if($rootScope.notificationAccess.indexOf(value)==-1)
$rootScope.notificationAccess.push(value)}else $rootScope.notificationAccess.push(value)}else{if(value!="VIEW"){var index=$rootScope.notificationAccess.indexOf(value);$rootScope.notificationAccess.splice(index,1)}else{document.getElementById("aNFView").checked=!1;$rootScope.aNFView=!1;$rootScope.notificationAccess.splice($rootScope.notificationAccess.indexOf(value),1)}}
if($rootScope.notificationAccess.indexOf('VIEW')>=0&&$rootScope.notificationAccess.length>1){$rootScope.aNFViewCheck=!0}else{$rootScope.aNFViewCheck=!1}
if($rootScope.notificationAccess.length<'4'){document.getElementById("aNFCheck").checked=!1;$rootScope.aNFCheck=!1}else if($rootScope.notificationAccess.length=='4'){document.getElementById("aNFCheck").checked=!0;$rootScope.aNFCheck=!0}}
$scope.aSDCheckAll=function(chk,VIEW,CREATE,EDIT){$rootScope.stdDashboardAccessArray=[];if(chk.target.checked){document.getElementById("aSDView").checked=!0;document.getElementById("aSDCreate").checked=!0;document.getElementById("aSDEdit").checked=!0;if($rootScope.aSDView=!0){if($rootScope.stdDashboardAccessArray.indexOf("VIEW")==-1)
$rootScope.stdDashboardAccessArray.push("VIEW")}
if($rootScope.aSDCreate=!0)
$rootScope.stdDashboardAccessArray.push(CREATE);if($rootScope.aSDEdit=!0)
$rootScope.stdDashboardAccessArray.push(EDIT)}else{document.getElementById("aSDCreate").checked=!1;document.getElementById("aSDEdit").checked=!1;$rootScope.aSDCreate=!1;$rootScope.aSDEdit=!1;$rootScope.stdDashboardAccessArray=[]}}
$scope.aSDChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("aSDView").checked=!0;$rootScope.aSDView=!0;if($rootScope.stdDashboardAccessArray.indexOf("VIEW")==-1)
$rootScope.stdDashboardAccessArray.push("VIEW")
if($rootScope.stdDashboardAccessArray.indexOf(value)==-1)
$rootScope.stdDashboardAccessArray.push(value)}else $rootScope.stdDashboardAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.stdDashboardAccessArray.indexOf(value);$rootScope.stdDashboardAccessArray.splice(index,1)}else{document.getElementById("aSDView").checked=!1;$rootScope.aSDView=!1;$rootScope.stdDashboardAccessArray.splice($rootScope.stdDashboardAccessArray.indexOf(value),1)}}
if($rootScope.stdDashboardAccessArray.indexOf('VIEW')>=0&&$rootScope.stdDashboardAccessArray.length>1){$rootScope.aSDViewCheck=!0}else{$rootScope.aSDViewCheck=!1}
if($rootScope.stdDashboardAccessArray.length<'3'){document.getElementById("aSDCheck").checked=!1;$rootScope.aSDCheck=!1}else if($rootScope.stdDashboardAccessArray.length=='3'){document.getElementById("aSDCheck").checked=!0;$rootScope.aSDCheck=!0}}
$scope.wdAccessChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("wdView").checked=!0;$rootScope.wdView=!0;if($rootScope.widgetAccessArray.indexOf("VIEW")==-1)
$rootScope.widgetAccessArray.push("VIEW")
if($rootScope.widgetAccessArray.indexOf(value)==-1)
$rootScope.widgetAccessArray.push(value)}else $rootScope.widgetAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.widgetAccessArray.indexOf(value);$rootScope.widgetAccessArray.splice(index,1)}else{document.getElementById("wdView").checked=!1;$rootScope.wdView=!1;$rootScope.widgetAccessArray.splice($rootScope.widgetAccessArray.indexOf(value),1)}}
if($rootScope.widgetAccessArray.indexOf('VIEW')>=0&&$rootScope.widgetAccessArray.length>1){$rootScope.wdViewCheck=!0}else{$rootScope.wdViewCheck=!1}
if($rootScope.widgetAccessArray.length<'5'){document.getElementById("widgetCheck").checked=!1;$rootScope.widgetCheck=!1}else if($rootScope.widgetAccessArray.length=='5'){document.getElementById("widgetCheck").checked=!0;$rootScope.widgetCheck=!0}}
$scope.catgAccessChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("catgView").checked=!0;$rootScope.catgView=!0;if($rootScope.catalogueAccessArray.indexOf("VIEW")==-1)
$rootScope.catalogueAccessArray.push("VIEW")
if($rootScope.catalogueAccessArray.indexOf(value)==-1)
$rootScope.catalogueAccessArray.push(value)}else $rootScope.catalogueAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.catalogueAccessArray.indexOf(value);$rootScope.catalogueAccessArray.splice(index,1)}else{document.getElementById("catgView").checked=!1;$rootScope.catgView=!1;$rootScope.catalogueAccessArray.splice($rootScope.catalogueAccessArray.indexOf(value),1)}}
if($rootScope.catalogueAccessArray.indexOf('VIEW')>=0&&$rootScope.catalogueAccessArray.length>1){$rootScope.catgViewCheck=!0}else{$rootScope.catgViewCheck=!1}
if($rootScope.catalogueAccessArray.length<'4'){document.getElementById("ctlgCheck").checked=!1;$rootScope.ctlgCheck=!1}else if($rootScope.catalogueAccessArray.length=='4'){document.getElementById("ctlgCheck").checked=!0;$rootScope.ctlgCheck=!0}}
$scope.cConChecked=function(value,checked){if(checked.target.checked){if(value!="VIEW"){document.getElementById("cConView").checked=!0;$rootScope.cConView=!0;if($rootScope.conversionAccessArray.indexOf("VIEW")==-1)
$rootScope.conversionAccessArray.push("VIEW")
if($rootScope.conversionAccessArray.indexOf(value)==-1)
$rootScope.conversionAccessArray.push(value)}else $rootScope.conversionAccessArray.push(value)}else{if(value!="VIEW"){var index=$rootScope.conversionAccessArray.indexOf(value);$rootScope.conversionAccessArray.splice(index,1)}else{document.getElementById("cConView").checked=!1;$rootScope.cConView=!1;$rootScope.conversionAccessArray.splice($rootScope.conversionAccessArray.indexOf(value),1)}}
if($rootScope.conversionAccessArray.indexOf('VIEW')>=0&&$rootScope.conversionAccessArray.length>1){$rootScope.cConViewCheck=!0}else{$rootScope.cConViewCheck=!1}
if($rootScope.conversionAccessArray.length<'4'){document.getElementById("conCheck").checked=!1;$rootScope.conCheck=!1}else if($rootScope.conversionAccessArray.length=='4'){document.getElementById("conCheck").checked=!0;$rootScope.conCheck=!0}}
$scope.cDRMChecked=function(value,checked){if(checked.target.checked){$rootScope.DRMAccessArray.push(value)}else{var index=$rootScope.DRMAccessArray.indexOf(value);$rootScope.DRMAccessArray.splice(index,1)}
if($rootScope.DRMAccessArray.length<'4'){document.getElementById("drmCheck").checked=!1;$rootScope.drmCheck=!1}else if($rootScope.DRMAccessArray.length=='4'){document.getElementById("drmCheck").checked=!0;$rootScope.drmCheck=!0}}
$scope.cAFSCChecked=function(value,checked){if(checked.target.checked){$rootScope.cAFSCAccess.push(value)}else{var index=$rootScope.cAFSCAccess.indexOf(value);$rootScope.cAFSCAccess.splice(index,1)}}
$scope.ADAChecked=function(value,checked){if(checked.target.checked){$rootScope.cADAAccess.push(value)}else{var index=$rootScope.cADAAccess.indexOf(value);$rootScope.cADAAccess.splice(index,1)}}
$scope.MDAChecked=function(value,checked){if(checked.target.checked){$rootScope.cMDAAccess.push(value)}else{var index=$rootScope.cMDAAccess.indexOf(value);$rootScope.cMDAAccess.splice(index,1)}}
$scope.cDefaultChecked=function(value,checked){if(checked.target.checked){$rootScope.miscellaneousArray.push(value)}else{var index=$rootScope.miscellaneousArray.indexOf(value);$rootScope.miscellaneousArray.splice(index,1)}}
$scope.cwmChecked=function(value,checked){if(checked.target.checked){$rootScope.waterMarkArray.push(value)}else{var index=$rootScope.waterMarkArray.indexOf(value);$rootScope.waterMarkArray.splice(index,1)}
if($rootScope.waterMarkArray.length<'5'){document.getElementById("wmCheck").checked=!1;$rootScope.wmCheck=!1}else if($rootScope.waterMarkArray.length=='5'){document.getElementById("wmCheck").checked=!0;$rootScope.wmCheck=!0}}
$scope.createRole=function(role){var accessId="";$scope.roledetails=[];$scope.roledetails.module=[]
$scope.roledetails.module.submoudule=[];angular.forEach($scope.roleModuleList,function(module){if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00001'){$scope.submoudule=[];$scope.module=[];if($rootScope.customDashboardArray.length>0){$scope.submoudule.push({accessId:"CUSTOM_DASHBOARD",activityAccess:$rootScope.customDashboardArray})}
if($rootScope.customWidgetdArray.length>0){$scope.submoudule.push({accessId:"CUSTOM_WIDGET",activityAccess:$rootScope.customWidgetdArray})}
if($rootScope.dWidgetAccessArray.length>0){$scope.submoudule.push({accessId:"WIDGET_LIST",activityAccess:$rootScope.dWidgetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00002'){$scope.submoudule=[];$scope.module=[];if($rootScope.assetAccessArray.length>0){$scope.submoudule.push({accessId:"ASSET_ACTIVITY",activityAccess:$rootScope.assetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00003'){$scope.submoudule=[];$scope.module=[];if($rootScope.metaDataAccessArray.length>0){$scope.submoudule.push({accessId:"META_ACTIVITY",activityAccess:$rootScope.metaDataAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00004'){$scope.submoudule=[];$scope.module=[];if($rootScope.dReportAccessArray.length>0){$scope.submoudule.push({accessId:"REPORT_LIST",activityAccess:$rootScope.dReportAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00005'){$scope.submoudule=[];$scope.module=[];if($rootScope.shelfAccessArray.length>0){$scope.submoudule.push({accessId:"SHELF_ACTIVITY",activityAccess:$rootScope.shelfAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00007'){$scope.submoudule=[];$scope.module=[];if($rootScope.widgetAccessArray.length>0){$scope.submoudule.push({accessId:"WIDGET_ACTIVITY",activityAccess:$rootScope.widgetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00008'){$scope.submoudule=[];$scope.module=[];if($rootScope.catalogueAccessArray.length>0){$scope.submoudule.push({accessId:"CATALOUGE_ACTIVITY",activityAccess:$rootScope.catalogueAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00009'){$scope.submoudule=[];$scope.module=[];if($rootScope.conversionAccessArray.length>0){$scope.submoudule.push({accessId:"CONVERSION_ACTIVITY",activityAccess:$rootScope.conversionAccessArray})}
if($rootScope.cAFSCAccess.length>0){$scope.submoudule.push({accessId:"AFSC_ACTIVITY",activityAccess:$rootScope.cAFSCAccess})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00010'){$scope.submoudule=[];$scope.module=[];if($rootScope.DRMAccessArray.length>0){$scope.submoudule.push({accessId:"DRM_ACTIVITY",activityAccess:$rootScope.DRMAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00011'){$scope.submoudule=[];$scope.module=[];if($rootScope.cADAAccess.length>0){$scope.submoudule.push({accessId:"ASSET_DIST_ACTIVITY",activityAccess:$rootScope.cADAAccess})}
if($rootScope.cMDAAccess.length>0){$scope.submoudule.push({accessId:"META_DIST_ACTIVITY",activityAccess:$rootScope.cMDAAccess})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00012'){$scope.submoudule=[];$scope.module=[];if($rootScope.miscellaneousArray.length>0){$scope.submoudule.push({accessId:"DEFAULT_ACTIVITY",activityAccess:$rootScope.miscellaneousArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00013'){$scope.submoudule=[];$scope.module=[];if($rootScope.waterMarkArray.length>0){$scope.submoudule.push({accessId:"WM_ACTIVITY",activityAccess:$rootScope.waterMarkArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}});angular.forEach($scope.roleModuleList,function(module){$scope.submoudule=[];$scope.module=[];if(document.getElementById("module_"+module.moduleId).checked=!0&&module.moduleId=='MOD00006'){if($rootScope.accoutAccessArray.length>0){$scope.submoudule.push({accessId:"ACCOUNT",activityAccess:$rootScope.accoutAccessArray})}
if($rootScope.metaAccessArray.length>0){$scope.submoudule.push({accessId:"METADATA",activityAccess:$rootScope.metaAccessArray})}
if($rootScope.pCAccessArray.length>0){$scope.submoudule.push({accessId:"PRODUCT_CATEGORY",activityAccess:$rootScope.pCAccessArray})};if($rootScope.formatAccessArray.length>0){$scope.submoudule.push({accessId:"FORMAT",activityAccess:$rootScope.formatAccessArray})};if($rootScope.bRuleAccessArray.length>0){$scope.submoudule.push({accessId:"BUSINESS_RULE",activityAccess:$rootScope.bRuleAccessArray})};if($rootScope.reportAdminArray.length>0){$scope.submoudule.push({accessId:"REPORT",activityAccess:$rootScope.reportAdminArray})};if($rootScope.roleAccessArray.length>0){$scope.submoudule.push({accessId:"ROLE",activityAccess:$rootScope.roleAccessArray})};if($rootScope.userAccessArray.length>0){$scope.submoudule.push({accessId:"USER",activityAccess:$rootScope.userAccessArray})};if($rootScope.partnerAccessArray.length>0){$scope.submoudule.push({accessId:"PARTNER",activityAccess:$rootScope.partnerAccessArray})};if($rootScope.vendorAccessArray.length>0){$scope.submoudule.push({accessId:"VENDOR",activityAccess:$rootScope.vendorAccessArray})};if($rootScope.notificationAccess.length>0){$scope.submoudule.push({accessId:"NOTIFICATION",activityAccess:$rootScope.notificationAccess})}
if($rootScope.stdDashboardAccessArray.length>0){$scope.submoudule.push({accessId:"STANDARD_DASHBOARD",activityAccess:$rootScope.stdDashboardAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}});$http({method:'POST',url:'/createRole',data:{roleName:$scope.roleName,module:$scope.roledetails}}).then(function successCallback(response){$location.url('/role-master');$rootScope.getRoles();if(response.data.code=='200'){$rootScope.newRoleCreateSuccessMsg=response.data.statusMessage;$rootScope.showRoleSuccessCreateMsg=!0;setTimeout(function(){$rootScope.showRoleSuccessCreateMsg=!1;$rootScope.$apply()},$rootScope.alertTimeoutInterval)}else{$rootScope.newRoleCreateErrorMsg=response.data.statusMessage;$rootScope.showRoleErrorCreateMsg=!0;setTimeout(function(){$rootScope.showRoleErrorCreateMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}},function errorCallback(response){console.log('Error status: '+response.status)})}
$scope.editRoleDetails=function(role){$rootScope.roleName='';$rootScope.customDashboardArray=[];$rootScope.customWidgetdArray=[];$rootScope.dWidgetAccessArray=[];$rootScope.assetAccessArray=[];$rootScope.metaDataAccessArray=[];$rootScope.shelfAccessArray=[];$rootScope.dReportAccessArray=[];$rootScope.accoutAccessArray=[];$rootScope.metaAccessArray=[];$rootScope.pCAccessArray=[];$rootScope.formatAccessArray=[];$rootScope.bRuleAccessArray=[];$rootScope.reportAdminArray=[];$rootScope.roleAccessArray=[];$rootScope.userAccessArray=[];$rootScope.partnerAccessArray=[];$rootScope.vendorAccessArray=[];$rootScope.widgetAccessArray=[];$rootScope.catalogueAccessArray=[];$rootScope.conversionAccessArray=[];$rootScope.DRMAccessArray=[];$rootScope.notificationAccess=[];$rootScope.cAFSCAccess=[];$rootScope.cADAAccess=[];$rootScope.cMDAAccess=[];$rootScope.miscellaneousArray=[];$rootScope.stdDashboardAccessArray=[];$rootScope.waterMarkArray=[];$scope.editParameterEmpty();$scope.checkAdministrator('EDIT');$rootScope.roleEditButton=!0;$rootScope.roleCreateButton=!1;$scope.editRole=angular.copy(role);$rootScope.roleName=$scope.editRole.roleName;$rootScope.editRoleId=$scope.editRole.roleId;var checkCount=0;angular.forEach($scope.editRole.module,function(mod){angular.forEach($scope.roleModuleList,function(module){if(mod.moduleId==module.moduleId){checkCount++;$timeout(function(){document.getElementById("module_"+module.moduleId).checked=!0;$scope.moduleToggled(module,document.getElementById("module_"+module.moduleId).checked)},500)}});angular.forEach(mod.submodule,function(sModule){angular.forEach(sModule.activityAccess,function(acAccess){if(sModule.accessId=="CUSTOM_DASHBOARD"){if(acAccess=="ALL"){$rootScope.cDashboradView=!0;$rootScope.customDashboardArray.push(acAccess)}}
if(sModule.accessId=="CUSTOM_WIDGET"){if(acAccess=="ALL"){$rootScope.cWidgetView=!0;$rootScope.customWidgetdArray.push(acAccess)}}
if(sModule.accessId=="WIDGET_LIST"){angular.forEach($rootScope.widgetList,function(value){if(value.widgetId===acAccess){$rootScope.dWidgetAccessArray.push(acAccess);var test='dwidget_'+acAccess;$rootScope[test]=!0}})}
if(sModule.accessId=="ASSET_ACTIVITY"){if(acAccess=="VIEW"){$rootScope.assetView=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="MANUAL_UPLOAD"){$rootScope.assetMU=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="BULK_UPLOAD"){$rootScope.assetBU=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="DOWNLOAD_SHARE"){$rootScope.downloadShare=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="BULKUPLOAD_SHARE"){$rootScope.BUShare=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="DISTRIBUTION"){$rootScope.assetDistribution=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="CONVERSION"){$rootScope.assetConversion=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.assetDelete=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="APPROVAL"){$rootScope.assetApproval=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="DOWNLOAD"){$rootScope.assetDownload=!0;$rootScope.assetAccessArray.push(acAccess)}
if(acAccess=="DELETEAPPROVAL"){$rootScope.assetDeleteApproval=!0;$rootScope.assetAccessArray.push(acAccess)}}
if(sModule.accessId=="META_ACTIVITY"){if(acAccess=="VIEW"&&$rootScope.metaDataAccessArray.indexOf("VIEW")==-1){$rootScope.mtView=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="CREATE"&&$rootScope.metaDataAccessArray.indexOf("CREATE")==-1){$rootScope.mtCreate=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="EDIT"&&$rootScope.metaDataAccessArray.indexOf("EDIT")==-1){$rootScope.mtEdit=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="BULK_UPLOAD"&&$rootScope.metaDataAccessArray.indexOf("BULK_UPLOAD")==-1){$rootScope.mtBU=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="DOWNLOAD"&&$rootScope.metaDataAccessArray.indexOf("DOWNLOAD")==-1){$rootScope.mtDownload=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="SHARE"&&$rootScope.metaDataAccessArray.indexOf("SHARE")==-1){$rootScope.mtShare=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="DISTRIBUTION"&&$rootScope.metaDataAccessArray.indexOf("DISTRIBUTION")==-1){$rootScope.mtDistribution=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="DELETE"&&$rootScope.metaDataAccessArray.indexOf("DELETE")==-1){$rootScope.mtDelete=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="APPROVAL"&&$rootScope.metaDataAccessArray.indexOf("APPROVAL")==-1){$rootScope.mtApproval=!0;$rootScope.metaDataAccessArray.push(acAccess)}
if(acAccess=="EXPORT"&&$rootScope.metaDataAccessArray.indexOf("EXPORT")==-1){$rootScope.mtExport=!0;$rootScope.metaDataAccessArray.push(acAccess)}}
if(sModule.accessId=="REPORT_LIST"){angular.forEach($rootScope.reportList,function(value){if(value.reportId===acAccess){$rootScope.dReportAccessArray.push(value.reportId);var checkReoprt="cReport_"+value.reportId;$rootScope[checkReoprt]=!0}})}
if(sModule.accessId=="SHELF_ACTIVITY"){if(acAccess=="VIEW"){$rootScope.cShelfView=!0;$rootScope.shelfAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.cShelfCreate=!0;$rootScope.shelfAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.cShelfEdit=!0;$rootScope.shelfAccessArray.push(acAccess)}
if(acAccess=="DOWNLOAD"){$rootScope.cShelfDownload=!0;$rootScope.shelfAccessArray.push(acAccess)}
if(acAccess=="SHARE"){$rootScope.cShelfShare=!0;$rootScope.shelfAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.cShelfDelete=!0;$rootScope.shelfAccessArray.push(acAccess)}}
if(sModule.accessId=="ACCOUNT"){if(acAccess=="VIEW"){$rootScope.aAccountView=!0;$rootScope.accoutAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aAccountCreate=!0;$rootScope.accoutAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aAccountEdit=!0;$rootScope.accoutAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aAccountDelete=!0;$rootScope.accoutAccessArray.push(acAccess)}}
if(sModule.accessId=="METADATA"){if(acAccess=="VIEW"){$rootScope.aMtView=!0;$rootScope.metaAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aMtCreate=!0;$rootScope.metaAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aMtEdit=!0;$rootScope.metaAccessArray.push(acAccess)}
if(acAccess=="SHARE"){$rootScope.aMtShare=!0;$rootScope.metaAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aMtDelete=!0;$rootScope.metaAccessArray.push(acAccess)}}
if(sModule.accessId=="PRODUCT_CATEGORY"){if(acAccess=="VIEW"){$rootScope.aPcView=!0;$rootScope.pCAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aPcCreate=!0;$rootScope.pCAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aPcEdit=!0;$rootScope.pCAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aPcDelete=!0;$rootScope.pCAccessArray.push(acAccess)}}
if(sModule.accessId=="FORMAT"){if(acAccess=="VIEW"){$rootScope.aFmtView=!0;$rootScope.formatAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aFmtCreate=!0;$rootScope.formatAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aFmtEdit=!0;$rootScope.formatAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aFmtDelete=!0;$rootScope.formatAccessArray.push(acAccess)}}
if(sModule.accessId=="BUSINESS_RULE"){if(acAccess=="VIEW"){$rootScope.aBrView=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aBrCreate=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aBrEdit=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aBrDelete=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="APPROVE"){$rootScope.aBrApprove=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="DEACTIVATE"){$rootScope.aBrDeactivate=!0;$rootScope.bRuleAccessArray.push(acAccess)}
if(acAccess=="DUPLICATE"){$rootScope.aBrDuplicate=!0;$rootScope.bRuleAccessArray.push(acAccess)}}
if(sModule.accessId=="REPORT"){if(acAccess=="VIEW"){$rootScope.aRpView=!0;$rootScope.reportAdminArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aRpCreate=!0;$rootScope.reportAdminArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aRpEdit=!0;$rootScope.reportAdminArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aRpDelete=!0;$rootScope.reportAdminArray.push(acAccess)}}
if(sModule.accessId=="ROLE"){if(acAccess=="VIEW"){$rootScope.aRoleView=!0;$rootScope.roleAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aRoleCreate=!0;$rootScope.roleAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aRoleEdit=!0;$rootScope.roleAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aRoleDelete=!0;$rootScope.roleAccessArray.push(acAccess)}
if(acAccess=="ACTIVATE"){$rootScope.aRoleActivate=!0;$rootScope.roleAccessArray.push(acAccess)}
if(acAccess=="DEACTIVATE"){$rootScope.aRoleDeactivate=!0;$rootScope.roleAccessArray.push(acAccess)}}
if(sModule.accessId=="USER"){if(acAccess=="VIEW"){$rootScope.aUserView=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aUserCreate=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aUserEdit=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aUserDelete=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="ACTIVATE"){$rootScope.aUserActivate=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="DEACTIVATE"){$rootScope.aUserDeactivate=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="RESEND"){$rootScope.aUserResend=!0;$rootScope.userAccessArray.push(acAccess)}
if(acAccess=="UNLOCK"){$rootScope.aUserUnlock=!0;$rootScope.userAccessArray.push(acAccess)}}
if(sModule.accessId=="PARTNER"){if(acAccess=="VIEW"){$rootScope.aPtView=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aPtCreate=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aPtEdit=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aPtDelete=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="SHOW_FTP_PASSWORD"){$rootScope.aPtSFP=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="UPDATE_FTP_PASSWORD"){$rootScope.aPtUFP=!0;$rootScope.partnerAccessArray.push(acAccess)}
if(acAccess=="ACTIVATE"){$rootScope.aPtActivate=!0;$rootScope.partnerAccessArray.push(acAccess)}}
if(sModule.accessId=="VENDOR"){if(acAccess=="VIEW"){$rootScope.aVdView=!0;$rootScope.vendorAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aVdCreate=!0;$rootScope.vendorAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aVdEdit=!0;$rootScope.vendorAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aVdDelete=!0;$rootScope.vendorAccessArray.push(acAccess)}
if(acAccess=="ACTIVATE"){$rootScope.aVdActivate=!0;$rootScope.vendorAccessArray.push(acAccess)}}
if(sModule.accessId=="NOTIFICATION"){if(acAccess=="VIEW"){$rootScope.aNFView=!0;$rootScope.notificationAccess.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aNFCreate=!0;$rootScope.notificationAccess.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aNFEdit=!0;$rootScope.notificationAccess.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.aNFDelete=!0;$rootScope.notificationAccess.push(acAccess)}}
if(sModule.accessId=="STANDARD_DASHBOARD"){if(acAccess=="VIEW"){$rootScope.aSDView=!0;$rootScope.stdDashboardAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.aSDCreate=!0;$rootScope.stdDashboardAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.aSDEdit=!0;$rootScope.stdDashboardAccessArray.push(acAccess)}}
if(sModule.accessId=="WIDGET_ACTIVITY"){if(acAccess=="VIEW"){$rootScope.wdView=!0;$rootScope.widgetAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.wdCreate=!0;$rootScope.widgetAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.wdEdit=!0;$rootScope.widgetAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.wdDelete=!0;$rootScope.widgetAccessArray.push(acAccess)}
if(acAccess=="ACTIVATE"){$rootScope.wdActivate=!0;$rootScope.widgetAccessArray.push(acAccess)}
if(acAccess=="DEACTIVATE"){$rootScope.wdDeactivate=!0;$rootScope.widgetAccessArray.push(acAccess)}}
if(sModule.accessId=="CATALOUGE_ACTIVITY"){if(acAccess=="VIEW"){$rootScope.catgView=!0;$rootScope.catalogueAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.catgCreate=!0;$rootScope.catalogueAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.catgEdit=!0;$rootScope.catalogueAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.catgDelete=!0;$rootScope.catalogueAccessArray.push(acAccess)}}
if(sModule.accessId=="CONVERSION_ACTIVITY"){if(acAccess=="VIEW"){$rootScope.cConView=!0;$rootScope.conversionAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.cConCreate=!0;$rootScope.conversionAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.cConEdit=!0;$rootScope.conversionAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.cConDelete=!0;$rootScope.conversionAccessArray.push(acAccess)}}
if(sModule.accessId=="AFSC_ACTIVITY"){if(acAccess=="APPROVAL"){$rootScope.cAFSCApproval=!0;$rootScope.cAFSCAccess.push(acAccess)}}
if(sModule.accessId=="DRM_ACTIVITY"){if(acAccess=="RE-ORDER"){$rootScope.cDRMOrder=!0;$rootScope.DRMAccessArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.cDRMCreate=!0;$rootScope.DRMAccessArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.cDRMEdit=!0;$rootScope.DRMAccessArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.cDRMDelete=!0;$rootScope.DRMAccessArray.push(acAccess)}}
if(sModule.accessId=="ASSET_DIST_ACTIVITY"){if(acAccess=="CHANGE_PRIORITY"){$rootScope.aCPaccess=!0;$rootScope.cADAAccess.push(acAccess)}
if(acAccess=="CHANGE_DISTRIBUTION_STATUS"){$rootScope.aCDSaccess=!0;$rootScope.cADAAccess.push(acAccess)}}
if(sModule.accessId=="META_DIST_ACTIVITY"){if(acAccess=="CHANGE_PRIORITY"){$rootScope.mCPaccess=!0;$rootScope.cMDAAccess.push(acAccess)}
if(acAccess=="CHANGE_DISTRIBUTION_STATUS"){$rootScope.mCDSaccess=!0;$rootScope.cMDAAccess.push(acAccess)}}
if(sModule.accessId=="DEFAULT_ACTIVITY"){if(acAccess=="INACTIVE_TITLES"){$rootScope.inactiveTitles=!0;$rootScope.miscellaneousArray.push(acAccess)}
if(acAccess=="SPOC"){$rootScope.sPOC=!0;$rootScope.miscellaneousArray.push(acAccess)}}
if(sModule.accessId=="WM_ACTIVITY"){if(acAccess=="RE-ORDER"){$rootScope.cWMOrder=!0;$rootScope.waterMarkArray.push(acAccess)}
if(acAccess=="CREATE"){$rootScope.cWMCreate=!0;$rootScope.waterMarkArray.push(acAccess)}
if(acAccess=="EDIT"){$rootScope.cWMEdit=!0;$rootScope.waterMarkArray.push(acAccess)}
if(acAccess=="DELETE"){$rootScope.cWMDelete=!0;$rootScope.waterMarkArray.push(acAccess)}
if(acAccess=="EXTRACT"){$rootScope.cWMExtract=!0;$rootScope.waterMarkArray.push(acAccess)}}})})})
if($rootScope.dWidgetAccessArray.length>0){$rootScope.dWidgetCheck=($rootScope.dWidgetAccessArray.length===$rootScope.widgetList.length)}
if($rootScope.dReportAccessArray.length>0){$rootScope.dReportCheck=($rootScope.dReportAccessArray.length===$rootScope.reportList.length)}
if($rootScope.assetAccessArray.length===11){$rootScope.atCheck=!0}
if($rootScope.metaDataAccessArray.length==10){$rootScope.mtCheck=!0}
if($rootScope.shelfAccessArray.length==6){$rootScope.shelfCheck=!0}
if($rootScope.widgetAccessArray.length==5){$rootScope.widgetCheck=!0}
if($rootScope.catalogueAccessArray.length==4){$rootScope.ctlgCheck=!0}
if($rootScope.conversionAccessArray.length==4){$rootScope.conCheck=!0}
if($rootScope.DRMAccessArray.length==4){$rootScope.drmCheck=!0}
if($rootScope.waterMarkArray.length==5){$rootScope.wmCheck=!0}
if($rootScope.accoutAccessArray.length==4){$rootScope.aAccountCheck=!0}
if($rootScope.metaAccessArray.length==5){$rootScope.aMtCheck=!0}
if($rootScope.pCAccessArray.length===4){$rootScope.aPcCheck=!0}
if($rootScope.formatAccessArray.length===4){$rootScope.aFmtCheck=!0}
if($rootScope.bRuleAccessArray.length===6){$rootScope.aBrCheck=!0}
if($rootScope.roleAccessArray.length==5){$rootScope.aRoleCheck=!0}
if($rootScope.userAccessArray.length==7){$rootScope.aUserCheck=!0}
if($rootScope.partnerAccessArray.length==7){$rootScope.aPtCheck=!0}
if($rootScope.vendorAccessArray.length==5){$rootScope.aVdCheck=!0}
if($rootScope.notificationAccess.length==4){$rootScope.aNFCheck=!0}
if($rootScope.stdDashboardAccessArray.length==3){$rootScope.aSDCheck=!0}
if($rootScope.accoutAccessArray.indexOf('VIEW')>=0&&$rootScope.accoutAccessArray.length>1){$rootScope.aActViewCheck=!0}else{$rootScope.aActViewCheck=!1}
if($rootScope.metaAccessArray.indexOf('VIEW')>=0&&$rootScope.metaAccessArray.length>1){$rootScope.aMtViewCheck=!0}else{$rootScope.aMtViewCheck=!1}
if($rootScope.pCAccessArray.indexOf('VIEW')>=0&&$rootScope.pCAccessArray.length>1){$rootScope.aPcViewCheck=!0}else{$rootScope.aPcViewCheck=!1}
if($rootScope.formatAccessArray.indexOf('VIEW')>=0&&$rootScope.formatAccessArray.length>1){$rootScope.aFmtViewCheck=!0}else{$rootScope.aFmtViewCheck=!1}
if($rootScope.bRuleAccessArray.indexOf('VIEW')>=0&&$rootScope.bRuleAccessArray.length>1){$rootScope.aBrViewCheck=!0}else{$rootScope.aBrViewCheck=!1}
if($rootScope.roleAccessArray.indexOf('VIEW')>=0&&$rootScope.roleAccessArray.length>1){$rootScope.aRoleViewCheck=!0}else{$rootScope.aRoleViewCheck=!1}
if($rootScope.userAccessArray.indexOf('VIEW')>=0&&$rootScope.userAccessArray.length>1){$rootScope.aUserViewCheck=!0}else{$rootScope.aUserViewCheck=!1}
if($rootScope.partnerAccessArray.indexOf('VIEW')>=0&&$rootScope.partnerAccessArray.length>1){$rootScope.aPtViewCheck=!0}else{$rootScope.aPtViewCheck=!1}
if($rootScope.vendorAccessArray.indexOf('VIEW')>=0&&$rootScope.vendorAccessArray.length>1){$rootScope.aVdViewCheck=!0}else{$rootScope.aVdViewCheck=!1}
if($rootScope.notificationAccess.indexOf('VIEW')>=0&&$rootScope.notificationAccess.length>1){$rootScope.aNFViewCheck=!0}else{$rootScope.aNFViewCheck=!1}
if($rootScope.stdDashboardAccessArray.indexOf('VIEW')>=0&&$rootScope.stdDashboardAccessArray.length>1){$rootScope.aSDViewCheck=!0}else{$rootScope.aSDViewCheck=!1}}
$scope.editRole=function(roleID){var accessId="";$scope.roledetails=[];$scope.roledetails.module=[]
$scope.roledetails.module.submoudule=[];angular.forEach($scope.roleModuleList,function(module){if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00001'){$scope.submoudule=[];$scope.module=[];if($rootScope.customDashboardArray.length>0){$scope.submoudule.push({accessId:"CUSTOM_DASHBOARD",activityAccess:$rootScope.customDashboardArray})}
if($rootScope.customWidgetdArray.length>0){$scope.submoudule.push({accessId:"CUSTOM_WIDGET",activityAccess:$rootScope.customWidgetdArray})}
if($rootScope.dWidgetAccessArray.length>0){$scope.submoudule.push({accessId:"WIDGET_LIST",activityAccess:$rootScope.dWidgetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00002'){$scope.submoudule=[];$scope.module=[];if($rootScope.assetAccessArray.length>0){$scope.submoudule.push({accessId:"ASSET_ACTIVITY",activityAccess:$rootScope.assetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00003'){$scope.submoudule=[];$scope.module=[];if($rootScope.metaDataAccessArray.length>0){$scope.submoudule.push({accessId:"META_ACTIVITY",activityAccess:$rootScope.metaDataAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00004'){$scope.submoudule=[];$scope.module=[];if($rootScope.dReportAccessArray.length>0){$scope.submoudule.push({accessId:"REPORT_LIST",activityAccess:$rootScope.dReportAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00005'){$scope.submoudule=[];$scope.module=[];if($rootScope.shelfAccessArray.length>0){$scope.submoudule.push({accessId:"SHELF_ACTIVITY",activityAccess:$rootScope.shelfAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00007'){$scope.submoudule=[];$scope.module=[];if($rootScope.widgetAccessArray.length>0){$scope.submoudule.push({accessId:"WIDGET_ACTIVITY",activityAccess:$rootScope.widgetAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00008'){$scope.submoudule=[];$scope.module=[];if($rootScope.catalogueAccessArray.length>0){$scope.submoudule.push({accessId:"CATALOUGE_ACTIVITY",activityAccess:$rootScope.catalogueAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00009'){$scope.submoudule=[];$scope.module=[];if($rootScope.conversionAccessArray.length>0){$scope.submoudule.push({accessId:"CONVERSION_ACTIVITY",activityAccess:$rootScope.conversionAccessArray})}
if($rootScope.cAFSCAccess.length>0){$scope.submoudule.push({accessId:"AFSC_ACTIVITY",activityAccess:$rootScope.cAFSCAccess})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00010'){$scope.submoudule=[];$scope.module=[];if($rootScope.DRMAccessArray.length>0){$scope.submoudule.push({accessId:"DRM_ACTIVITY",activityAccess:$rootScope.DRMAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00011'){$scope.submoudule=[];$scope.module=[];if($rootScope.cADAAccess.length>0){$scope.submoudule.push({accessId:"ASSET_DIST_ACTIVITY",activityAccess:$rootScope.cADAAccess})}
if($rootScope.cMDAAccess.length>0){$scope.submoudule.push({accessId:"META_DIST_ACTIVITY",activityAccess:$rootScope.cMDAAccess})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00012'){$scope.submoudule=[];$scope.module=[];if($rootScope.miscellaneousArray.length>0){$scope.submoudule.push({accessId:"DEFAULT_ACTIVITY",activityAccess:$rootScope.miscellaneousArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}
if(document.getElementById("module_"+module.moduleId).checked&&module.moduleId=='MOD00013'){$scope.submoudule=[];$scope.module=[];if($rootScope.waterMarkArray.length>0){$scope.submoudule.push({accessId:"WM_ACTIVITY",activityAccess:$rootScope.waterMarkArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}});angular.forEach($scope.roleModuleList,function(module){$scope.submoudule=[];$scope.module=[];if(document.getElementById("module_"+module.moduleId).checked==!0&&module.moduleId=='MOD00006'){if($rootScope.accoutAccessArray.length>0){if($rootScope.accoutAccessArray.indexOf('VIEW')==-1)
$rootScope.accoutAccessArray.push("VIEW");$scope.submoudule.push({accessId:"ACCOUNT",activityAccess:$rootScope.accoutAccessArray})}
if($rootScope.metaAccessArray.length>0){if($rootScope.metaAccessArray.indexOf('VIEW')==-1)
$rootScope.metaAccessArray.push("VIEW");$scope.submoudule.push({accessId:"METADATA",activityAccess:$rootScope.metaAccessArray})}
if($rootScope.pCAccessArray.length>0){if($rootScope.pCAccessArray.indexOf('VIEW')==-1)
$rootScope.pCAccessArray.push("VIEW");$scope.submoudule.push({accessId:"PRODUCT_CATEGORY",activityAccess:$rootScope.pCAccessArray})}
if($rootScope.formatAccessArray.length>0){if($rootScope.bRuleAccessArray.indexOf('VIEW')==-1)
$rootScope.bRuleAccessArray.push("VIEW")
$scope.submoudule.push({accessId:"FORMAT",activityAccess:$rootScope.formatAccessArray})}
if($rootScope.bRuleAccessArray.length>0){if($rootScope.bRuleAccessArray.indexOf('VIEW')==-1)
$rootScope.bRuleAccessArray.push("VIEW");$scope.submoudule.push({accessId:"BUSINESS_RULE",activityAccess:$rootScope.bRuleAccessArray})}
if($rootScope.reportAdminArray.length>0){if($rootScope.reportAdminArray.indexOf('VIEW')==-1)
$rootScope.reportAdminArray.push("VIEW");$scope.submoudule.push({accessId:"REPORT",activityAccess:$rootScope.reportAdminArray})}
if($rootScope.roleAccessArray.length>0){if($rootScope.roleAccessArray.indexOf('VIEW')==-1)
$rootScope.roleAccessArray.push("VIEW");$scope.submoudule.push({accessId:"ROLE",activityAccess:$rootScope.roleAccessArray})}
if($rootScope.userAccessArray.length>0){if($rootScope.userAccessArray.indexOf('VIEW')==-1)
$rootScope.userAccessArray.push("VIEW");$scope.submoudule.push({accessId:"USER",activityAccess:$rootScope.userAccessArray})}
if($rootScope.partnerAccessArray.length>0){if($rootScope.partnerAccessArray.indexOf('VIEW')==-1)
$rootScope.partnerAccessArray.push("VIEW")
$scope.submoudule.push({accessId:"PARTNER",activityAccess:$rootScope.partnerAccessArray})}
if($rootScope.vendorAccessArray.length>0){if($rootScope.vendorAccessArray.indexOf('VIEW')==-1)
$rootScope.vendorAccessArray.push("VIEW");$scope.submoudule.push({accessId:"VENDOR",activityAccess:$rootScope.vendorAccessArray})}
if($rootScope.notificationAccess.length>0){if($rootScope.notificationAccess.indexOf('VIEW')==-1)
$rootScope.notificationAccess.push("VIEW");$scope.submoudule.push({accessId:"NOTIFICATION",activityAccess:$rootScope.notificationAccess})}
if($rootScope.stdDashboardAccessArray.length>0){if($rootScope.stdDashboardAccessArray.indexOf('VIEW')==-1)
$rootScope.stdDashboardAccessArray.push("VIEW");$scope.submoudule.push({accessId:"STANDARD_DASHBOARD",activityAccess:$rootScope.stdDashboardAccessArray})}
$scope.module={'moduleId':module.moduleId,'submodule':$scope.submoudule};$scope.roledetails.push($scope.module)}});$http({method:'POST',url:'/editRole/'+roleID,data:{roleName:$scope.roleName,module:$scope.roledetails}}).then(function successCallback(response){$location.url('/role-master');$rootScope.getRoles();if(response.data.code=='200'){$rootScope.roleEditSuccessMsg=response.data.statusMessage;$rootScope.showRoleSuccessEditMsg=!0;setTimeout(function(){$rootScope.showRoleSuccessEditMsg=!1;$rootScope.$apply()},$rootScope.alertTimeoutInterval)}else{$rootScope.roleEditErrorMsg=response.data.statusMessage;$rootScope.showRoleErrorEditMsg=!0;setTimeout(function(){$rootScope.showRoleErrorEditMsg=!1;$rootScope.$apply()},$rootScope.alertTimeoutInterval)}},function errorCallback(response){console.log('Error status: '+response.status)})}
$scope.deleteRole=function(){$http({method:'POST',url:'/deleteRole/'+$scope.roleDelete.roleId,}).then(function successCallback(response){$scope.closeRoleDelete();$rootScope.getRoles();if(response.data.code=='204'||response.data.code=='200'){$scope.showRoleSuccessDeleteMsg=!0;setTimeout(function(){$scope.showRoleSuccessDeleteMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}else{$scope.showRoleErrorDeleteMsg=!0;setTimeout(function(){$scope.showRoleErrorDeleteMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)
$rootScope.getRoles()}},function errorCallback(response){console.log('Error status: '+response.status)})}
$scope.activateDeactivateRole=function(){var actVal;if($scope.roleActDeact.isActive==!0)
actVal=1;else actVal=0;$http({method:'POST',url:'/roleActivate/'+actVal+'/'+$scope.roleActDeact.roleId}).then(function successCallback(response){$rootScope.getRoles();$scope.closeRoleDeactivateModal();if(response.data.code=='200'){if(actVal==0){$scope.showRoleSuccessDeactivateMsg=!0;setTimeout(function(){$scope.showRoleSuccessDeactivateMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}else{$scope.showRoleSuccessActivateMsg=!0;setTimeout(function(){$scope.showRoleSuccessActivateMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}}else{if(actVal==0){$scope.showRoleSuccessDeactivateMsg=!0;setTimeout(function(){$scope.showRoleSuccessDeactivateMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}else{$scope.showRoleErrorDeactivateMsg=!0;setTimeout(function(){$scope.showRoleErrorDeactivateMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}}},function errorCallback(response){console.log('Error status: '+response.status)})}
$scope.checkForDuplicateRole=function($event){var roleId=null;if($rootScope.roleEditButton)
roleId=$rootScope.editRoleId;if($event.target.value!=""||$event.target.value!=null||$event.target.value!=undefined){var roleName=$event.target.value;$http({method:'POST',url:'/checkForDuplicateRole',data:{roleName:roleName,roleId:roleId}}).then(function successCallback(response){if(response.data.code!='404'){$scope.showDuplicateRoleErrorMsg=!0;$scope.duplicateRoleErrorMsg=response.data.statusMessage}},function errorCallback(response){console.log('Error status: '+response.status)})}}}])