app.controller('supportController',['$scope','$http','$timeout','$filter','$rootScope','$location',"$route","$window","$compile",function($scope,$http,$timeout,$filter,$rootScope,$location,$route,$window,$compile){$timeout(function(){$rootScope.duplicatePartnerList=angular.copy($rootScope.distColumnPartners);$rootScope.dummyPartnerList=angular.copy($rootScope.distColumnPartners);angular.forEach($scope.duplicatePartnerList,function(list){list.selected=!1});angular.forEach($scope.dummyPartnerList,function(list){list.selected=!1})},1500)
$scope.showNotificationInput=!0;$scope.searchISBNValue="";$scope.partnerFilterList=[];$scope.isbnFilterList=[];$scope.selectedRadio="Completed";$scope.to_emailid="";$scope.ccto_emailid="";$scope.errorMSG=!1;$scope.errorMsg="";$scope.errorMsgForPartner="";$scope.errorMSGforPartner=!1;$scope.remarks="";$scope.checkCountForISBN=0;$scope.userNameLoggedInForSupport=$rootScope.loggedUser.firstName;$scope.partnerListFilterSearch;$scope.statusListforPartner=angular.copy($rootScope.statusList);$scope.rowForSupport=0;$scope.rowPerPageForSupport=30;$scope.buttonText="Load More";$scope.showLoadMoreRows=!1;$scope.selectedMailRadio="Internal";$scope.emailerrorMSG=!1;$scope.emailccerrorMSG=!1;$scope.emailInvaliderrorMSG=!1;$scope.emailccInvaliderrorMSG=!1;$scope.emailISBNerrorMSG=!1;$scope.countCheck=0;$scope.externalChecked=!1;$scope.completedChecked=!0;$scope.disableSubmitButtonForSupport=!1;$scope.supportpartnerAllSelected=!1;$scope.errorMessageForUpdate='';$scope.partnerSearch=[];$scope.showSupportTable=!1;$scope.completedSupportDate='';$scope.populateSelectedField=function()
{angular.forEach($scope.duplicatePartnerList,function(list){list.selected=!1});angular.forEach($scope.dummyPartnerList,function(list){list.selected=!1})}
$scope.partnerAllSelect=function($event){$scope.errorMsgForPartner="";var checkbox=$event.target;var action=(checkbox.checked?'add':'remove');if(action==='add'){angular.forEach($scope.duplicatePartnerList,function(imp){document.getElementById("partner_"+imp.partnerName).checked=!0;if(imp.selected==!1){$scope.partnerFilterList.push(imp.partnerId);imp.selected=!0}
angular.forEach($scope.dummyPartnerList,function(item){if(angular.equals(imp.partnerId,item.partnerId))
item.selected=!0})})}else if(action==='remove'){angular.forEach($scope.duplicatePartnerList,function(imp){document.getElementById("partner_"+imp.partnerName).checked=!1;$scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(imp.partnerId),1);angular.forEach($scope.dummyPartnerList,function(item){if(angular.equals(imp.partnerId,item.partnerId))
{item.selected=!1}});imp.selected=!1})}
if($scope.duplicatePartnerList.length==0)
$scope.supportpartnerAllSelected=!1}
$scope.partnerTags=function(input,checkPartner){var checkCount=0;$scope.errorMsgForPartner="";angular.forEach($scope.duplicatePartnerList,function(item){if(null!=document.getElementById("partner_"+item.partnerName))
if(document.getElementById("partner_"+item.partnerName).checked){document.getElementById("partner_"+item.partnerName).checked=!0;checkCount++}});if(checkPartner){document.getElementById("partner_"+input.partnerName).checked=!0;$scope.partnerFilterList.push(input.partnerId);angular.forEach($scope.dummyPartnerList,function(item){if(angular.equals(item.partnerId,input.partnerId))
{item.selected=!0;document.getElementById("partner_"+item.partnerName).checked=!0}
input.selected=!0})}else{$scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(input.partnerId),1);input.selected=!1;angular.forEach($scope.dummyPartnerList,function(item){if(angular.equals(item.partnerId,input.partnerId))
item.selected=!1})}
$timeout(function(){$scope.supportpartnerAllSelected=(checkCount===$scope.duplicatePartnerList.length);document.getElementById("supportpartnerAllSelected").checked=(checkCount===$scope.duplicatePartnerList.length)},100)};$scope.refreshPartnerSelectList=function(){var checkAllSelected=0;document.getElementById("supportpartnerAllSelected").checked=!1;var filteredList=$filter('filter')($scope.dummyPartnerList,function(data){var re=new RegExp($scope.partnerListFilterSearch,'gi');return data.partnerName.match(re)});$scope.duplicatePartnerList=angular.copy(filteredList);angular.forEach($scope.duplicatePartnerList,function(imp){if(imp.selected==!0)
checkAllSelected++});if(checkAllSelected==$scope.duplicatePartnerList.length&&$scope.duplicatePartnerList.length>0)
{document.getElementById("supportpartnerAllSelected").checked=!0}
else document.getElementById("supportpartnerAllSelected").checked=!1};$scope.validateISBN=function(isbns){var checkCountforISBN=0;var arrayIsbn=isbns.replace(/\s/g,"").split(',');angular.forEach(arrayIsbn,function(key,value){if(key.length==13&&/^\d+$/.test(key))
{isValid=!0}
else{checkCountforISBN++}});if(checkCountforISBN>0)
{$scope.showSupportTable=!1;$scope.errorMSG=!0;$scope.errorMsg="Please enter valid isbn(s)"}
else{$scope.errorMSG=!1}}
$scope.updateAllISBNs=function($event){$scope.isbnFilterList=[];var checkbox=$event.target;var action=(checkbox.checked?'add':'remove');if(action==='add'){angular.forEach($scope.partnerSearch,function(imp){document.getElementById("checkbox_"+imp._id).checked=!0;$scope.isbnFilterList.push(imp._id)});$scope.checkCountForISBN=$scope.isbnFilterList.length}else if(action==='remove'){angular.forEach($scope.partnerSearch,function(imp){document.getElementById("checkbox_"+imp._id).checked=!1})
$scope.checkCountForISBN=0;$scope.isbnFilterList=[]}}
$scope.updateISBN=function($event,partnerResult,partnerFormat){var checkbox=$event.target;var action=(checkbox.checked?'add':'remove');if(action==='add'){document.getElementById("checkbox_"+partnerResult._id).checked=!0
$scope.isbnFilterList.push(partnerResult._id);$scope.checkCountForISBN++}
else if(action==='remove'){document.getElementById("checkbox_"+partnerResult._id).checked=!1;$scope.isbnFilterList.splice($scope.isbnFilterList.indexOf(partnerResult._id),1);$scope.checkCountForISBN--}
$timeout(function(){document.getElementById("checkAllISBN").checked=($scope.checkCountForISBN===$scope.rowForSupport||$scope.checkCountForISBN==$scope.supportSearchCount)},100);if($scope.isbnFilterList!=0)
{$scope.emailISBNerrorMSG=!1}};$scope.clearFilterValueForSupport=function(input,chk,input1){if(chk==='par'){if($scope.partnerFilterList.length>'0'){angular.forEach($scope.duplicatePartnerList,function(imp){if(angular.equals(imp.partnerId,input1))
{imp.selected=!1}});angular.forEach($scope.dummyPartnerList,function(item){if(angular.equals(item.partnerId,input1))
{item.selected=!1}});$scope.partnerFilterList.splice($scope.partnerFilterList.indexOf(input1),1);$scope.supportpartnerAllSelected=!1;$scope.searchPartners();document.getElementById("supportpartnerAllSelected").checked=!1}if($scope.partnerFilterList.length=='0'){$scope.partnerAllSelect=!1}}
else if(chk==='searchKey'){$scope.searchISBNValue="";angular.element($("#searchISBNValue")).val('')}
if($scope.searchISBNValue===''||$scope.partnerSearch.length===0||$scope.partnerSearch==''||$scope.partnerSearch==null)
{$scope.showSupportTable=!1;$scope.errorMSG=!0}}
$scope.clearReport=function(chk){$scope.searchISBNValue="";angular.element($("#searchISBNValue")).val('');angular.forEach($scope.duplicatePartnerList,function(imp){imp.selected=!1});angular.forEach($scope.dummyPartnerList,function(item){item.selected=!1});$scope.partnerFilterList=[];$scope.supportpartnerAllSelected=!1;document.getElementById("supportpartnerAllSelected").checked=!1}
$scope.validateEmailIds=function(flag,emailValue)
{if(flag==='TO')
{$scope.to_emailid=emailValue;if($scope.to_emailid==='')
$scope.emailInvaliderrorMSG=!1;else{var result=$scope.to_emailid.split(',');for(var i=0;i<result.length;i++){if(result[i]!=''){var regex=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;if(!regex.test(result[i]))
{$scope.emailInvaliderrorMSG=!0}
else{$scope.countCheck++;$scope.emailerrorMSG=!1;$scope.emailInvaliderrorMSG=!1}}}}}
else if(flag==='CC')
{$scope.ccto_emailid=emailValue;if($scope.ccto_emailid==='')
$scope.emailccInvaliderrorMSG=!1;else{var result=$scope.ccto_emailid.split(',');for(var i=0;i<result.length;i++){if(result[i]!=''){var regex=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;if(!regex.test(result[i]))
{$scope.emailccInvaliderrorMSG=!0}
else{$scope.countCheck++;$scope.emailerrorMSG=!1;$scope.emailccInvaliderrorMSG=!1}}}}}}
$scope.getSupportPosts=function(){$rootScope.showLoader($('.support-table-loader'),1,'win8_linear');if(document.getElementById("checkAllISBN").checked)
document.getElementById("checkAllISBN").checked=!1;if($scope.searchISBNValue!=''&&$scope.partnerFilterList.length>0)
{$scope.emailISBNerrorMSG=!1;$scope.errorMSG=!1;$scope.showSupportTable=!0;$http({method:'POST',url:'/searchPartnersforSupport',data:{skipCountforSupport:$scope.rowForSupport,permission:$scope.searchISBNValue.replace(/\s/g,""),format:$scope.partnerFilterList,}}).then(function(response){if($scope.partnerSearch.length<=$scope.supportSearchCount){if(response.data.data!=''){$scope.rowForSupport+=response.data.data.length;if($scope.partnerSearch!=undefined){setTimeout(function(){$scope.$apply(function(){angular.forEach(response.data.data,function(item){$scope.partnerSearch.push(item)});if($scope.partnerSearch.length>=$scope.supportSearchCount){$scope.showLoadMoreRows=!1;$scope.partnerSearch.length=$scope.supportSearchCount}else{$scope.showLoadMoreRows=!0}
$rootScope.hideLoader('support-table-loader')})},500)}else{$scope.partnerSearch=response.data.data}}else{$scope.showLoadMoreRows=!1}}else{$scope.showLoadMoreRows=!1;$scope.partnerSearch.length=$scope.supportSearchCount}})}
else{$scope.errorMSG=!0;$scope.errorMsg="Please select values from both fields"}
$scope.buttonText="Load More"}
$scope.searchPartners=function(){$scope.isbnFilterList=[];var checkCountforISBN=0;var arrayIsbn=$scope.searchISBNValue.replace(/\s/g,"").split(',');angular.forEach(arrayIsbn,function(key,value){if(key.length==13&&/^\d+$/.test(key))
{isValid=!0}
else{checkCountforISBN++}})
if($scope.searchISBNValue!=''&&$scope.partnerFilterList.length>0&&checkCountforISBN==0)
{if(document.getElementById("checkAllISBN").checked)
document.getElementById("checkAllISBN").checked=!1;$scope.emailISBNerrorMSG=!1;$scope.disableSearchButtonForSupport=!0;$scope.emailISBNerrorMSG=!1;$scope.errorMSG=!1;$scope.showSupportTable=!0;$rootScope.showLoader($('.support-master'),1,'win8_linear');$http({method:'POST',url:'/searchPartnersforSupport',data:{skipCountforSupport:0,permission:$scope.searchISBNValue.replace(/\s/g,""),format:$scope.partnerFilterList,}}).then(function(response){$scope.partnerSearch=response.data.data;$scope.supportSearchCount=response.data.searchCount;$scope.checkCountForISBN=0;if(response.data.data!=null)
$scope.rowForSupport=$scope.partnerSearch.length;$scope.disableSearchButtonForSupport=!1;var container=document.getElementById("assetdivTableBody");angular.element("#assetdivTableBody").trigger('scroll');container.scrollTop=0;container.scrollLeft=0;if(response.data.data!=null)
if($scope.supportSearchCount>response.data.data.length)
{$scope.showLoadMoreRows=!0}
$rootScope.hideLoader('support-master')})}
else{if($scope.searchISBNValue.length==0||checkCountforISBN>0)
{$scope.showSupportTable=!1;$scope.errorMSG=!0;$scope.errorMsg="Please enter valid isbn(s)"}
else{$scope.errorMSG=!1;$scope.showSupportTable=!1;$scope.errorMSGforPartner=!0;$scope.errorMsgForPartner="Please select partner(s)"}}}
$scope.updateAndSend=function(){if($scope.showSupportTable==!1||($scope.partnerFilterList.length==0||$scope.searchISBNValue=='')&&($scope.isbnFilterList.length===0||$scope.isbnFilterList===''||$scope.isbnFilterList===null))
{if($scope.searchISBNValue=='')
{$scope.errorMSG=!0;$scope.errorMsg="Please enter valid isbn(s)"}
else if($scope.partnerFilterList.length==0)
{$scope.errorMSGforPartner=!0;$scope.errorMsgForPartner="Please select partner(s)"}
$scope.emailISBNerrorMSG=!0;$scope.errorMessageForUpdate="Please click search and proceed"}
else if($scope.partnerSearch!=null&&$scope.isbnFilterList.length===0){$scope.errorMessageForUpdate="Please select records to update";$scope.emailISBNerrorMSG=!0}
else if($scope.isbnFilterList.length==0)
{$scope.errorMessageForUpdate="No records found to update";$scope.emailISBNerrorMSG=!0}
if($scope.isbnFilterList.length!=0&&$scope.isbnFilterList!=''&&$scope.isbnFilterList!=null&&$scope.partnerSearch.length!=0&&$scope.partnerSearch!=''&&$scope.partnerSearch!=null&&$scope.searchISBNValue!=''&&$scope.partnerFilterList.length>0&&$scope.emailerrorMSG===!1&&$scope.emailccInvaliderrorMSG===!1&&$scope.emailInvaliderrorMSG===!1)
{$scope.disableSubmitButtonForSupport=!0;$http({method:'POST',url:'/updateAndSendEmail',data:{permission:$scope.selectedRadio,format:$scope.isbnFilterList,to_emailid:$scope.to_emailid,ccto_emailid:$scope.ccto_emailid,remarks:$scope.remarks,userName:$scope.userNameLoggedInForSupport,mailGroup:$scope.selectedMailRadio,completedOnDate:$scope.completedSupportDate}}).then(function(response){$scope.updatedList=response.data.data;if(response.data.code=="200")
{$scope.showeditSaveSupportDetails=!0;$scope.editSaveSupportSuccessMsg=response.data.statusMessage}
else if(response.data.code=="500")
{$scope.showfailureSupportDetails=!0;$scope.editSaveSupportSuccessMsg=response.data.statusMessage;$scope.disableSubmitButtonForSupport=!1;setTimeout(function(){$scope.showfailureSupportDetails=!1;$scope.editSaveSupportSuccessMsg="";$rootScope.$apply()},$rootScope.alertTimeoutInterval)}
else{$scope.showfailureSupportDetails=!0;$scope.editSaveSupportSuccessMsg="Service Unresponsive";$scope.disableSubmitButtonForSupport=!1;setTimeout(function(){$scope.showfailureSupportDetails=!1;$scope.editSaveSupportSuccessMsg="";$rootScope.$apply()},$rootScope.alertTimeoutInterval)}
$scope.disableSubmitButtonForSupport=!1;setTimeout(function(){$scope.showeditSaveSupportDetails=!1;$rootScope.$apply()},$rootScope.alertTimeoutInterval)
$scope.searchISBNValue="";$scope.partnerFilterList=[];$scope.isbnFilterList=[];$scope.to_emailid="";$scope.remarks="";$scope.completedSupportDate=''
$scope.ccto_emailid="";$scope.selectedRadio="Completed";$scope.selectedMailRadio="Internal";$scope.populateSelectedField();$scope.supportpartnerAllSelected=!1;$scope.showSupportTable=!1;$scope.checkCountForISBN=0;$scope.completedChecked=!0;$scope.externalChecked=!1;document.getElementById("checkAllISBN").checked=!1;if($scope.to_emailid!=null)
document.getElementById("to_emailid").value="";if($scope.ccto_emailid!=null)
document.getElementById("ccto_emailid").value="";$scope.partnerListFilterSearch='';$scope.refreshPartnerSelectList();angular.forEach($scope.duplicatePartnerList,function(imp){document.getElementById("partner_"+imp.partnerName).checked=!1})})}}
$scope.checkWidgetItems=function(chk){if(chk==='CAN')
{$scope.selectedRadio="Cancelled";$scope.completedChecked=!1}
else if(chk==='COM')
{$scope.selectedRadio="Completed";$scope.completedChecked=!0}
else if(chk=='EXT')
{$scope.selectedMailRadio="External";$scope.showNotificationInput=!1;$scope.externalChecked=!0}
else if(chk=='INT')
{$scope.selectedMailRadio="Internal"}}
$scope.completionDateForSupport=function(date){$scope.completedSupportDate=date;console.log($scope.completedSupportDate)}
$scope.maxDate=new Date().toString()}])