/**********************************************************************************************************************
Date                Version         Modified By             Description
***********         ********        *************           *************
07-09-2017            1.0           Shahid ul Islam         Initial Version.
***********************************************************************************************************************/


'use strict';
app.controller('PartnerConfigController', ['$scope', '$window', '$http', '$rootScope', '$filter', '$location', '$timeout', "Upload", "$compile", function ($scope, $window, $http, $rootScope, $filter, $location, $timeout, Upload, $compile) {

   


    //$rootScope.duplicateMetaList = [];
    /*  
       $rootScope.duplicateMetaListForExcel = [];
       $rootScope.duplicateMetaListForCSV = [];
       $rootScope.duplicateMetaListForExclude = [];
       $rootScope.duplicateMetaListForTransform = [];
   */
    //$rootScope.partnerConfigAction = 'Clone';
    $rootScope.pCbrowsefiles = null;


    $rootScope.pCdata = {};
    $rootScope.pCdata.excelFieldDetails = [];
    $rootScope.pCdata.ftpDetails = [];
    $rootScope.pCdata.formatDetails = [];
    $rootScope.pCdata.transformFieldList = [];
    $rootScope.pCdata.coverFormat = [];
    $rootScope.pCdata.excludeFieldList = [];
    $rootScope.pCdata.metadataType = null;//='Select';
    $rootScope.pCdata.onixType = null;//='Select';
    $rootScope.pCdata.partnerId = null;
    $rootScope.pCdata.metadataRequired = false;
    $rootScope.pCdata.isSimulation = false;
    $rootScope.pCdata.coverRequired = false;
    $rootScope.pCdata.cDATARequired = false;
    $rootScope.pCdata.excelTempateRowStartAt = null;
    $rootScope.pCdata.excelTempate = null;
    $rootScope.mUploadData = null;
    $rootScope.partnerListForGds = [];
    $rootScope.pCdata.transferFolderStructure = false;
    $rootScope.pCdata.shortTag = false;
    $rootScope.pCdata.sheetNames = null;
    $rootScope.pCdata.cancelRequestOnEpubFailure = false;
    $rootScope.pCdata.partnerConfigId = null;
    $rootScope.pCdata.sheetNames = [];
    $rootScope.pCdata.metadataTransferMedium = null;
    $rootScope.pCdata.metaRefreshInterval = null;

    $rootScope.formatSelectedList = [];
    $scope.coverformatSelectedList = [];
    // $scope.pCExcludeFieldList=[];
    $rootScope.pCExcelFieldList = [];
    $scope.pCTransformFieldList = [];
    $rootScope.pCFtpFieldList = [];
    $scope.pMetadataRequiredExcel = false;
    $scope.pMetadataRequiredOnix = false;
    $scope.operationList = ["JOIN", "REPLACE", "CONCAT_PREFIX", "CONCAT_SUFFIX"];
    $scope.pCmetadataTypeList = ["ONIX", "Excel", 'CSV'];
    $scope.pCtransferTypeList = ["FTP", "Email"];
    $scope.pCFtpProtocolTypeList = ["FTP", "FTPS", "SFTP"];
    //$scope.pCDateFormatList = ["MM/dd/yyyy","MMMMdd,yyyy","yyyyMMdd","yyyy"];
    $rootScope.pCDateFormatList = [{ "type": "MM/dd/yyyy", "value": "MM/dd/yyyy" },
    { "type": "MMMMdd,yyyy", "value": "MMMMdd,yyyy" },
    { "type": "yyyyMMdd", "value": "yyyyMMdd" },
    { "type": "yyyy", "value": "yyyy" },
    { "type": "dd-MM-yyyy", "value": "dd-MM-yyyy" },
    { "type": "dd/MM/yyyy", "value": "dd/MM/yyyy" },
    { "type": "MM-dd-yyyy", "value": "MM-dd-yyyy" }];
    $scope.pConixTypeList = ["2.1", "3.0"];
    $scope.pConixTageType = ["Long Tag", "Short Tag"];
    $scope.pCepubVersionList = ["4.0.2", "3.0.1"];

    //$scope.pCFtpTypes=["DEFAULT","ASSET","COVER"];
    $rootScope.pCFtpTypes = [{ 'ftpType': 'DEFAULT' ,'selected' : false}, { 'ftpType': 'ASSET' ,'selected' : false}, 
                                    { 'ftpType': 'COVER' ,'selected' : false} , { 'ftpType': 'METADATA' ,'selected' : false}];
    $rootScope.pCrefreshIntervalTypes = [{ 'type': 'Daily', 'days': 1 }, { 'type': 'Weekly', 'days': 7 }, { 'type': 'Monthly', 'days': 30 }];
    $rootScope.pCjoinByType = [{ 'type': 'Whitespace', 'value': ' ' }, { 'type': 'Comma', 'value': ',' },
    { 'type': 'SemiColon', 'value': ';' }, { 'type': 'Colon', 'value': ':' }];
    $rootScope.pCapplefileTypes = [{ 'type': 'Full', 'value': 'full' }, { 'type': 'Artwork', 'value': 'Artwork' }, { 'type': 'Ipad_screen_shot', 'value': 'Ipad_screen_shot' }];
    $rootScope.pCconditionForFormats = [{ 'type': 'Prefix', 'value': 'Prefix', 'path': 'formatNamingPrefix' }, { 'type': 'Suffix', 'value': 'Suffix', 'path': 'formatNamingSuffix' },
    { 'type': 'Stop distribution', 'value': 'Stop distribution', 'path': 'epubValidator' }, { 'type': 'File compress', 'value': 'File compress', 'path': 'compressedIfMultiple' }];

    $rootScope.pCconditionForMetadata = [{ 'type': 'Value Seperator', 'value': 'JOIN', 'path': 'formatNamingPrefix' },
    { 'type': 'Join', 'value': 'JOIN_METADATA', 'path': 'formatNamingSuffix' },
    { 'type': 'Replace', 'value': 'REPLACE', 'path': 'ePubVersion' },
    { 'type': 'Lookup mapping', 'value': 'Lookup_mapping', 'path': 'ePubValidator' },
    { 'type': 'Date format', 'value': 'Date_format', 'path': 'compressedIfMultiple' },
    { 'type': 'Uppercase', 'value': 'Uppercase', 'path': 'formatNamingPrefix' },
    { 'type': 'Lowercase', 'value': 'Lowercase', 'path': 'formatNamingSuffix' },
    { 'type': 'Prefix', 'value': 'CONCAT_PREFIX', 'path': 'ePubVersion' },
    { 'type': 'Suffix', 'value': 'CONCAT_SUFFIX', 'path': 'ePubValidator' },
    { 'type': 'Arithmetic', 'value': 'Arithmetic', 'path': 'compressedIfMultiple' },
    { 'type': 'Mid', 'value': 'Mid', 'path': 'Mid' },
    { 'type': 'Left', 'value': 'Left', 'path': 'Left' },
    { 'type': 'Right', 'value': 'Right', 'path': 'Right' },
    { 'type': 'Substitute', 'value': 'Substitute', 'Substitute': 'ePubValidator' },
    { 'type': 'Reverse', 'value': 'Reverse', 'path': 'Reverse' },
    { 'type': 'Custom_fields', 'value': 'Custom_fields', 'path': 'Custom' }
   ];

    $rootScope.pCCustomFieldsCondition = [{'type':'Mid','value':'Mid'},
                                          {'type':'Left','value':'Left'},
                                          {'type':'Right','value':'Right'}]
    $rootScope.pCwithSepratorList = [{ "type": 'with seperator', "value": true },
    { "type": 'without seperator', "value": false }];
    $rootScope.pCreplaceCondition = [{ "type": "Default", "value": "Default" },
    { "type": "Word", "value": "Word" }];
    $rootScope.pCfilterTypeList = ["Transformation", "Included", "Excluded"];
    $scope.partnerConfigOperationSelected = "Select";
    $rootScope.pCbrowsefilesExcel = {};
    $rootScope.pCmetadataMappingbrowsefilesExcel={};
    //$scope.coverformatDetailsForCreate=[];
    //$scope.FormatDetailsEntity=new Array();
    //$scope.excelFieldDetailsForCreate=[];
    //$scope.transFormFieldDetailsForCreate=[];
    //$scope.ftpFieldDetailsForCreate=[];
    //$scope.lookupList=[];
    //$scope.lookupListConcatPre=[];
    //$scope.lookupListConcatSuf=[];
    $scope.selectedMetaType = '';
    $scope.onixVersion = null;
    $scope.metadataRequiredpC = false;
    //$scope.pCemailId=null;
    //$scope.isCdata=false;
    //$scope.isSimulation=false;
    $scope.partnerConfigDelete;
    $scope.showErrorForPConfig = false;


    $rootScope.disableDeleteButtonForGds = false;
    $rootScope.disableCreateButtonForGds = false;

    $rootScope.disableBrowseButtonForGds = false;

    $scope.partnerSelected = 'Select';
    $rootScope.formats = [];
    //   $rootScope.formats = angular.copy($rootScope.formatList);
    $rootScope.listForCoverFormats = angular.copy($rootScope.formatList);
    //   $rootScope.duplicateMetaList = angular.copy($rootScope.metadataFieldList);
    angular.forEach($rootScope.formatList, function (item) {
        item.selected = false;
    });

    $rootScope.disableUpdateButtonForGds = {};
    $rootScope.disableUpdateButtonForGds = false;
    $scope.getPartnerGroups = function () {

        $http({
            method: 'GET',
            url: '/getPartnerGroups'
        }).then(function successCallback(response) {

            $scope.partnerGroupList = response.data.data;
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
            //    $window.alert('Error status: ' + response.status);
        });
    };

    $scope.getMetadataFieldForPartnerConfig = function () {
        $rootScope.duplicateMetaListForExcel = [];
        $rootScope.duplicateMetaListForCSV = [];
        $rootScope.duplicateMetaListForExclude = [];
        $rootScope.duplicateMetaListForTransform = [];
        $http({
            method: 'GET',
            url: '/getMetadataFields'
        }).then(function successCallback(response) {

            $rootScope.duplicateMetaList = response.data.data;
            $rootScope.duplicateMetaListForExcel = angular.copy($rootScope.duplicateMetaList);
            $rootScope.duplicateMetaListForCSV = angular.copy($rootScope.duplicateMetaList);
            $rootScope.metadataFieldMapping = angular.copy($rootScope.duplicateMetaList);
            /*        angular.forEach($rootScope.duplicateMetaListForExcel,function(data){
                        if(data.jsonPathTransform != null)
                            $rootScope.duplicateMetaListForTransform.push(data);
                    });
                    jsonPathRemove
             */
            $rootScope.duplicateMetaListForExclude = $filter('filter')($rootScope.duplicateMetaListForExcel, function (value) {
                return (value.jsonPathRemove != null || value.jsonPathRemoveParent != null);
            });

            $rootScope.duplicateMetaListForTransform = angular.copy($rootScope.duplicateMetaList);

            $rootScope.duplicateMetaListForOnix = angular.copy($rootScope.duplicateMetaList);
            angular.forEach($rootScope.duplicateMetaListForOnix ,function(obj){
                obj.moveToExclude = true;
            })

            $rootScope.duplicateMetaListForOnixExclude = angular.copy($rootScope.duplicateMetaList);
            angular.forEach($rootScope.duplicateMetaListForOnixExclude,function(obj){
                obj.moveToExclude = false;
            })

            $rootScope.duplicateMetaListForTransform = $filter('filter')($rootScope.duplicateMetaListForTransform, function (value) {
                return value.jsonPathTransform != null;
            });
            //         console.log($rootScope.duplicateMetaListForExclude);
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
            //    $window.alert('Error status: ' + response.status);
        });
    };

    $scope.getMetadataFieldForPartnerConfig();

    $scope.pCdataSwichToInclude = function (chk,obj) {
        $rootScope.pCdata.excludeFieldList.splice($rootScope.pCdata.excludeFieldList.indexOf(obj.metaDataFieldName),1);
        obj.moveToExclude = true;
        $rootScope.duplicateMetaListForOnix.push(obj);
    }

    $scope.pCdataSwichToExclude = function (chk, obj, flag) {
        $rootScope.duplicateMetaListForOnix.splice($rootScope.duplicateMetaListForOnix
            .findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
        if ($rootScope.pCdata.excludeFieldList == null)
            $rootScope.pCdata.excludeFieldList = [];
        $rootScope.pCdata.excludeFieldList.push(obj.metaDataFieldName);
    }

    $scope.setRefreshIntervalType = function (val, key) {
        $rootScope.pCdata.metaRefreshInterval = val.days;
    }

    $scope.setJoinBySelected = function (pIndex, val) {
        $rootScope.pCdata.transformFieldList[pIndex].joinBy = val.value;
    }

    $scope.showpCFtpPassword = function (ftpType) {
        //   if(!$scope.showCreatePartnerButton)
        //       $scope.data.ftpPassword = $scope.editPartner.erpepswr;

        var p = document.getElementById('password_' + ftpType);
        p.setAttribute('type', 'text');
    }

    $scope.hidepCFtpPassword = function (ftpType) {
        //   if(!$scope.showCreatePartnerButton)
        //       $scope.data.ftpPassword = $scope.editPartner.ftpPassword;

        var p = document.getElementById('password_' + ftpType);
        p.setAttribute('type', 'password');
    }

    $scope.passDataToPartnerConfigDeleteModal = function (obj) {
        $scope.partnerConfigDelete = obj;
    }

    $scope.closePartnerConfigDelete = function () {
        $scope.partnerConfigDelete = null;
        $('#partner-config-delete').modal('toggle');
        $rootScope.disabledBtnClick();
        //location.reload();    
    }


    $scope.simulationCheck = function (chk) {
        if (!chk) {
            $rootScope.pCdata.simulationEmail = null;
        }
    }

    $scope.formatNamingChk = function (data, chk) {
        if (chk) {
            //$rootScope.pCdata.formatDetails.splice($rootScope.pCdata.formatDetails
            //                          .findIndex(obj => obj['formatId'] === data.formatId),1); 
            $rootScope.pCdata.formatDetails[$rootScope.pCdata.formatDetails
                .findIndex(obj => obj['formatId'] === data.formatId)].formatNaming = null;
        }
        else {
            $rootScope.pCdata.formatDetails[$rootScope.pCdata.formatDetails
                .findIndex(obj => obj['formatId'] === data.formatId)].formatNaming = "*";
            $rootScope.pCdata.formatDetails[$rootScope.pCdata.formatDetails
                .findIndex(obj => obj['formatId'] === data.formatId)].fieldDisplayName = null;
        }

    }

    $scope.toggleCoverResizeRequired = function (chk) {
        if (!chk) {
            $rootScope.pCdata.coverMaxHeight = null;
            $rootScope.pCdata.coverMaxWidth = null;
        }
    }

    $rootScope.disableDeleteButtonForGds = false;

    $scope.deletePartnerConfig = function () {
        $rootScope.disableDeleteButtonForGds = true;
        angular.element('#partner-config-delete').modal('toggle');
        $rootScope.disabledBtnClick();
        $http({
            method: 'POST',
            url: '/deletePartnerConfig/' + $scope.partnerConfigDelete._id,
        }).then(function successCallback(response) {
            //$scope.closePartnerConfigDelete();
            if (response.data.code == '204' || response.data.code == '200') {
                // $scope.getPartners(false);
                $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                $rootScope.partnerConfigSuccessMsg = response.data.statusMessage;
                setTimeout(function () {
                    $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                    $rootScope.$apply();
                    $scope.partnerConfigs();
                    //location.reload();
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.msg.showPartnerConfigErrorMsg = true;
                $rootScope.partnerConfigErrorMsg = response.data.statusMessage;
                setTimeout(function () {
                    $rootScope.msg.showPartnerConfigErrorMsg = false;
                    $rootScope.$apply();
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
            //$window.alert('Error status: ' + response.status);
        });
    }
    /*
        $scope.savePartnerConfig=function(){
            var simulation=$scope.isSimulation;
            var cData=$scope.isCdata;
            var pCemail=$scope.pCemailId;
            var formatId;
            var formatNaming;
            var formatNamingPrefix;
            var formatNamingSuffix;
            var epubValidator;
            var epubVersion;
            var metadataRequired=$scope.metadataRequiredpC;
            var metadataNaming;
            var partnerId=$scope.partnerIdForCreate;
            var metadataType;
            var onixType;
            var excludeFieldList=[];
            var formatDetails=[];
            angular.forEach($rootScope.formatSelectedList,function(obj){
                formatId=obj.formatId;
                formatNaming=document.getElementById(obj.formatId+'_naming').value;
                formatNamingPrefix=document.getElementById(obj.formatId+'_prefix').value;
                formatNamingSuffix=document.getElementById(obj.formatId+'_suffix').value;
                epubValidator=obj.isEpubValidator;
                epubVersion=document.getElementById(obj.formatId+'_epubVersion').value;
                $scope.FormatDetailsEntity.push({
                    'formatId':formatId,
                    'formatNaming':formatNaming,
                    'formatNamingPrefix':formatNamingPrefix,
                    'formatNamingSuffix':formatNamingSuffix,
                    'epubValidator':true,
                    'ePubVersion':epubVersion
                });
                formatId='';
                formatNaming='';
                formatNamingPrefix='';
                formatNamingSuffix='';
                epubValidator=false;
                epubVersion='';
            });
            if($scope.pCoverformat){
                var coverId;
                var coverOrder;
                angular.forEach($scope.coverformatSelectedList,function(obj){
                    coverId=obj.formatId;
                    coverOrder=document.getElementById(obj.formatId+'_order');
                    $scope.coverformatDetailsForCreate.push({
                        'formatId':coverId,
                        'formatOrder':2
                    })
                    coverId='';
                    coverOrder='';
                })
            }
            var covHeight=null;
            var covWidth=null;
            if($scope.pCoverformat){
                covHeight=document.getElementById('pCoverMaxHeight').value;
                covWidth=document.getElementById('pCoverMaxWidth').value;
            }
            if(metadataRequired!=false)
            {
                metadataNaming=document.getElementById('pMetadataNaming').value;
                if($scope.selectedMetaType!='' && $scope.selectedMetaType=='Onix'){
                    metadataType='Onix';
                    if($scope.onixVersion!='' && $scope.onixVersion=='2.1')
                        onixType='2.1'
                    else if($scope.onixVersion!='' && $scope.onixVersion=='3.0')
                        onixType='3.0'
                }
                else if($scope.selectedMetaType!='' && $scope.selectedMetaType=='Excel')
                    metadataType='Excel';
             
            }
           
            excludeFieldList=$scope.pCExcludeFieldList;
        
            if(metadataType=='Excel')
            {
                var metaDataFieldNameExcel;
                var prefix;
                var prefix1;
                var suffix;
                var suffix1;
                var sheetName;
                var displayOrderNo;
                var dateFormat;
                var isActive;
                var lookupForExcel;
                var defaultForExcel;
                angular.forEach($rootScope.pCExcelFieldList,function(value,key){
                metaDataFieldNameExcel=value.metaDataFieldName;
                prefix=document.getElementById(key+"_"+value.metaDataFieldName+'_prefix').value;
                prefix1=document.getElementById(key+"_"+value.metaDataFieldName+'_prefix1').value;
                suffix=document.getElementById(key+"_"+value.metaDataFieldName+'_suffix').value;
                suffix1=document.getElementById(key+"_"+value.metaDataFieldName+'_suffix1').value;
                sheetName=document.getElementById(key+"_"+value.metaDataFieldName+'_sheetName').value;
                displayOrderNo=document.getElementById(key+"_"+value.metaDataFieldName+'_displayOrder').value;
                if(value.fieldType=='Date')
                    dateFormat=document.getElementById(key+"_"+value.metaDataFieldName+'_dateFormat').value;
                isActive=value.isMetaActiveField;
                lookupForExcel=document.getElementById(key+"_"+value.metaDataFieldName+'_lookup').value;
                defaultForExcel=document.getElementById(key+"_"+value.metaDataFieldName+'_default').value;
    
                $scope.excelFieldDetailsForCreate.push({
                    'metaDataFieldName':metaDataFieldNameExcel,
                    'prefix':prefix,
                    'prefix1':prefix1,
                    'suffix':suffix,
                    'suffix1':suffix1,
                    'sheetName':sheetName,
                    'displayOrderNo':displayOrderNo,
                    'dateFormat':dateFormat,
                    'isActive':isActive,
                    'lookup':lookupForExcel,
                    'defaultValue':defaultForExcel
                });
                metaDataFieldNameExcel='';
                prefix='';
                prefix1='';
                suffix='';
                suffix1='';
                sheetName='';
                displayOrderNo=null;
                dateFormat='';
                isActive=false;
                lookupForExcel='';
                defaultForExcel='';
            });
            excelRowStartsAt=document.getElementById('excelRowStart').value;    
            }
           
            var excelRowStartsAt=null;
            excelRowStartsAt=document.getElementById('excelRowStart').value;
             if($scope.pCTransformFieldList!=[]){
                var metaDataFieldNameTransform;
                var operationTransform;
                var joinBy;
                var lookup={};
                var keyLookup;
                var valueLookup;
                angular.forEach($scope.pCTransformFieldList,function(obj){
                    metaDataFieldNameTransform=obj.metaDataFieldName;
                    operationTransform=obj.partnerConfigOperationSelected;
                    if(operationTransform=='JOIN')
                        joinBy=document.getElementById(obj.metaDataFieldName+'_joinBy').value;
                    if(operationTransform=='CONCAT_PREFIX'){
                        if(obj.lookupListConcatPre!=[]){
                            angular.forEach(obj.lookupListConcatPre,function(data){
                                keyLookup=document.getElementById(data+'_concatPreKeyForTransform_'+obj.metaDataFieldName).value;
                                valueLookup=document.getElementById(data+'_concatPreValueForTransform_'+obj.metaDataFieldName).value;
                                lookup[keyLookup]=valueLookup;
                                keyLookup='';
                                valueLookup='';
                            })
                        }
                    }
                    if(operationTransform=='CONCAT_SUFFIX'){
                        if(obj.lookupListConcatSuf!=[]){
                            angular.forEach(obj.lookupListConcatSuf,function(data){
                                keyLookup=document.getElementById(data+'_concatSufKeyForTransform_'+obj.metaDataFieldName).value;
                                valueLookup=document.getElementById(data+'_concatSufValueForTransform_'+obj.metaDataFieldName).value;
                                lookup[keyLookup]=valueLookup;
                                keyLookup='';
                                valueLookup='';
                            })
                        }
                    }
                    if(operationTransform=='REPLACE')
                    {
                        if(obj.lookupList!=[]){
                            angular.forEach(obj.lookupList,function(data){
                                keyLookup=document.getElementById(data+'_lookUpKeyForTransform_'+obj.metaDataFieldName).value;
                                valueLookup=document.getElementById(data+'_lookUpValueForTransform_'+obj.metaDataFieldName).value;
                                lookup[keyLookup]=valueLookup;
                                keyLookup='';
                                valueLookup='';
                            })
                        }
                    }
                    $scope.transFormFieldDetailsForCreate.push({
                        'metaDataFieldName':metaDataFieldNameTransform,
                        'operation':operationTransform,
                        'joinBy':joinBy,
                        'lookUp':lookup,
                        
                    })
                    metaDataFieldNameTransform='';
                    operationTransform='';
                    joinBy='';
                    keyLookup='';
                    valueLookup='';
                    lookup={};
                })
            }
            if($rootScope.pCFtpFieldList!=[]){
                var ftpTypePC;
                var ftpProtocol;
                var ftpHost;
                var ftpPort;
                var ftpUsername;
                var ftpPassword='';
                var ftpPath;
                var ftpConnectionTimeout;
                var ftpDataTimeout;
                var ftp_isPassive;
                angular.forEach($rootScope.pCFtpFieldList,function(obj){
                    ftpTypePC=obj.ftpType;
                    ftpProtocol=document.getElementById('protocol_'+obj.ftpType).value;
                    ftpHost=document.getElementById('host_'+obj.ftpType).value;
                    ftpPort=document.getElementById('port_'+obj.ftpType).value;
                    ftpUsername=document.getElementById('userName_'+obj.ftpType).value;
                    ftpPassword=document.getElementById('password_'+obj.ftpType).value;
                    ftpPath=document.getElementById('ftpPath_'+obj.ftpType).value;
                    ftpConnectionTimeout=document.getElementById('connectionTimeout_'+obj.ftpType).value;
                    ftpDataTimeout=document.getElementById('dataTimeout_'+obj.ftpType).value;
                    ftp_isPassive=obj.isPassive;
                    $scope.ftpFieldDetailsForCreate.push({
                        'ftpType':ftpTypePC,
                        'protocol':ftpProtocol,
                        'host':ftpHost,
                        'port':ftpPort,
                        'userName':ftpUsername,// FIELDNAME TO BE CHECKED IN  POJO
                        'password':ftpPassword,
                        'ftpPath':ftpPath,
                        'connectionTimeout':ftpConnectionTimeout,
                        'dataTimeout':ftpDataTimeout,
                        'isPassive':true// FIELDNAME TO BE CHECKED IN  POJO
                    });
                });
                ftpTypePC='';
                ftpProtocol='';
                ftpHost='';
                ftpPort='';
                ftpUsername='';
                ftpPassword='';
                ftpPath='';
                ftpConnectionTimeout=null;
                ftpDataTimeout=null;
                ftp_isPassive=false;
            }
            console.log($scope.coverformatDetailsForCreate);
            console.log($scope.FormatDetailsEntity);
            console.log($scope.ftpFieldDetailsForCreate);
            console.log($scope.transFormFieldDetailsForCreate);
            console.log($scope.excelFieldDetailsForCreate);
            console.log($scope.pCExcludeFieldList);
    
            var data = {
                    partnerId: $scope.partnerIdForCreate,
                    formatDetails: $scope.FormatDetailsEntity,
                    coverRequired: $scope.pCoverformat,
                    coverFormat: $scope.coverformatDetailsForCreate,
                    coverResizeRequired: $scope.pCoverResize,
                    coverMaxHeight : covHeight,                
                    coverMaxWidth : covWidth,
                    metadataRequired : $scope.pMetadataRequired,
                    metadataNaming : $scope.pMetadataNaming,
                    metadataType : $scope.selectedMetaType,
                    onixType : $scope.onixVersion,
                    excelTempateRowStartAt : excelRowStartsAt,
                    ftpDetails : $scope.ftpFieldDetailsForCreate,
                    excelFieldDetails : $rootScope.pCdata.excelFieldDetails,
                    excludeFieldList : $scope.pCExcludeFieldList,
                    transformFieldList : $scope.transFormFieldDetailsForCreate,
                    isSimulation : $scope.isSimulation,
                    cDATARequired : $scope.isCdata,
                    emailId: $scope.pCemailId,
                    excelTemplateFile : $rootScope.pCbrowsefilesExcel
                };
                            console.log(data);
      
           $http({
                method: 'POST',
                url: '/savePartnerConfiguration',
                data: {
                    partnerId: $scope.partnerIdForCreate,
                    formatDetails: $scope.FormatDetailsEntity,
                    coverRequired: $scope.pCoverformat,
                    coverFormat: $scope.coverformatDetailsForCreate,
                    coverResizeRequired: $scope.pCoverResize,
                    coverMaxHeight : covHeight,                
                    coverMaxWidth : covWidth,
                    metadataRequired : $scope.pMetadataRequired,
                    metadataNaming : $scope.pMetadataNaming,
                    metadataType : $scope.selectedMetaType,
                    onixType : $scope.onixVersion,
                    excelTempateRowStartAt : excelRowStartsAt,
                    ftpDetails : $scope.ftpFieldDetailsForCreate,
                    excelFieldDetails : $rootScope.pCdata.excelFieldDetails,
                    excludeFieldList : $scope.pCExcludeFieldList,
                    transformFieldList : $scope.transFormFieldDetailsForCreate,
                    isSimulation : $scope.isSimulation,
                    cDATARequired : $scope.isCdata,
                    emailId: $scope.pCemailId,
                    excelTemplateFile : $rootScope.pCbrowsefilesExcel
                }
    
            })
            .then(function(response) {
                if (response.data.code == '200') {
                    $rootScope.showPartnerConfigSuccessCreateMsg = true;
                    $rootScope.partnerConfigSuccessMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.showPartnerConfigSuccessCreateMsg = false;
                        $scope.$apply();
                    }, $rootScope.alertTimeoutInterval)
    
                } else {
                    $rootScope.showPartnerConfigErrorMsg = true;
                    $rootScope.partnerConfigErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.showPartnerConfigErrorMsg = false;
                        $scope.$apply();
                    }, $rootScope.alertTimeoutInterval)
                }
            });
        }
    */

    $scope.showeditformatCondition = false;

    /*
        $rootScope.pCdata.excelFieldDetails=[];
        $rootScope.pCdata.ftpDetails=[];
        $rootScope.pCdata.formatDetails=[];
        $rootScope.pCdata.transformFieldList=[];
        $rootScope.pCdata.formatDetails=[];
        $rootScope.pCdata.coverFormat=[];
        $rootScope.pCdata.metadataType;//='Select';
        $rootScope.pCdata.onixType;//='Select';
        $rootScope.pCdata.excludeFieldList=[];
        $rootScope.pCdata.partnerId=null;
        $rootScope.pCdata.metadataRequired = false;
        $rootScope.pCdata.isSimulation = false;
        $rootScope.pCdata.coverRequired = false;
        $rootScope.pCdata.cDATARequired = false;
    */
    $scope.exportGds = function () {
        $rootScope.showLoader($('.app-content'), 1, 'win8_linear');

        $scope.showPartnerSuccessMsgExport = true;
        $scope.partnerSuccessMsgExport = "EXPORT_REQUEST_SUCCESS";
        setTimeout(function () {
            $scope.showPartnerSuccessMsgExport = false;
            $scope.$apply();
        }, $rootScope.alertTimeoutInterval)

        $http({
            method: 'GET',
            url: '/exportGds'
        }).then(function successCallback(response) {
            //  if(exportFlg){
            $rootScope.getDownloadNotification();
            angular.element("#getDownloadNotification").addClass('open');
            angular.element(".download-up").addClass("flashit");
            //$rootScope.downloadcompleted = true;
            /* $scope.partnerExport = false;
            if (response.data.code == '200') {
                $scope.showPartnerSuccessMsg = true;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = false;
                    $scope.$apply();
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = true;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = false;
                    $scope.$apply();
                }, $rootScope.alertTimeoutInterval)
            }*/
            //   }
            //   $scope.partnerList = response.data.data;
            //   $scope.data.pgPartnerList = angular.copy(response.data.data);

        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
            //    $window.alert('Error status: ' + response.status);
        });

        $rootScope.hideLoader('app-content');
    }


    $scope.savePartnerConfigForGds = function () {
        $rootScope.disableCreateButtonForGds = true;
        angular.element('#createButtonForgds').addClass('disabled');
        var emailIds = null;
        var simulationEmailIds = null;
        $scope.showErrorForPConfig = false;
    /*    if($rootScope.pCdata.formatDetails.length == 0 || $rootScope.pCdata.formatDetails==[] || $rootScope.pCdata.formatDetails==null)
            $scope.showErrorForPConfig=true;
        if($rootScope.pCdata.metadataType=='Excel' && $rootScope.pCdata.excelFieldDetails.length == 0)
            $scope.showErrorForPConfig=true;
        if($rootScope.pCdata.metadataType=='Onix' || $rootScope.pCdata.metadataType==null)
            $rootScope.pCdata.excelTempate = 'empty';
    */    if (!$scope.showErrorForPConfig) {
            if ($rootScope.pCdata.coverMaxHeight != '' && $rootScope.pCdata.coverMaxHeight != null)
                $rootScope.pCdata.coverMaxHeight += 'px';
            if ($rootScope.pCdata.coverMaxWidth != '' && $rootScope.pCdata.coverMaxWidth != null)
                $rootScope.pCdata.coverMaxWidth += 'px';
        }

        if ($rootScope.pCdata.simulationEmail != null)
            simulationEmailIds = $rootScope.pCdata.simulationEmail.replace(/\s/g, "");
        if ($rootScope.pCdata.emailId != null)
            emailIds = $rootScope.pCdata.emailId.replace(/\s/g, "");
        /*    console.log({
                    partnerId: $rootScope.pCdata.partnerId,
                    formatDetails: $rootScope.pCdata.formatDetails,
                    coverRequired: $rootScope.pCdata.coverRequired,
                    coverFormat: $rootScope.pCdata.coverFormat,
                    coverResizeRequired: $rootScope.pCdata.coverResizeRequired,
                    coverMaxHeight : $rootScope.pCdata.coverMaxHeight,                
                    coverMaxWidth : $rootScope.pCdata.coverMaxWidth,
                    metadataRequired : $rootScope.pCdata.metadataRequired,
                    metadataNaming : $rootScope.pCdata.metadataNaming,
                    metadataType : $rootScope.pCdata.metadataType,
                    onixType : $rootScope.pCdata.onixType,
                    excelTempateRowStartAt : $rootScope.pCdata.excelTempateRowStartAt,
                    ftpDetails : $rootScope.pCdata.ftpDetails,
                    excelFieldDetails : $rootScope.pCdata.excelFieldDetails,
                    excludeFieldList : $rootScope.pCdata.excludeFieldList,
                    transformFieldList : $rootScope.pCdata.transformFieldList,
                    isSimulation : $rootScope.pCdata.isSimulation,
                    cDATARequired : $rootScope.pCdata.cDATARequired,
                    emailId: $rootScope.pCdata.emailId.replace(/\s/g,""),
                    excelTempate : $rootScope.pCdata.excelTempate
                });   
         */
        if (!$scope.showErrorForPConfig) {
            $http({
                method: 'POST',
                url: '/savePartnerConfiguration',
                data: {
                    partnerId: $rootScope.pCdata.partnerId,
                    formatDetails: $rootScope.pCdata.formatDetails,
                    coverRequired: $rootScope.pCdata.coverRequired,
                    coverFormat: $rootScope.pCdata.coverFormat,
                    coverResizeRequired: $rootScope.pCdata.coverResizeRequired,
                    coverMaxHeight: $rootScope.pCdata.coverMaxHeight,
                    coverMaxWidth: $rootScope.pCdata.coverMaxWidth,
                    metadataRequired: $rootScope.pCdata.metadataRequired,
                    metadataNaming: $rootScope.pCdata.metadataNaming,
                    metadataType: $rootScope.pCdata.metadataType,
                    onixType: $rootScope.pCdata.onixType,
                    excelTempateRowStartAt: $rootScope.pCdata.excelTempateRowStartAt,
                    ftpDetails: $rootScope.pCdata.ftpDetails,
                    excelFieldDetails: $rootScope.pCdata.excelFieldDetails,
                    csvFieldDetails: $rootScope.pCdata.csvFieldDetails,
                    excludeFieldList: $rootScope.pCdata.excludeFieldList,
                    transformFieldList: $rootScope.pCdata.transformFieldList,
                    isSimulation: $rootScope.pCdata.isSimulation,
                    cDATARequired: $rootScope.pCdata.cDATARequired,
                    emailId: emailIds,
                    excelTempate: $rootScope.pCdata.excelTempate,
                    simulationEmail: simulationEmailIds,
                    transferFolderStructure: $rootScope.pCdata.transferFolderStructure,
                    shortTag: $rootScope.pCdata.shortTag,
                    sheetNames: $rootScope.pCdata.sheetNames,
                    cancelRequestOnEpubFailure: $rootScope.pCdata.cancelRequestOnEpubFailure,
                    metaRefreshInterval: $rootScope.pCdata.metaRefreshInterval,
                    metadataTransferMedium: $rootScope.pCdata.metadataTransferMedium
                }

            })
                .then(function (response) {
                    if (response.data.code == '200') {
                        $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                        $rootScope.partnerConfigSuccessMsg = response.data.statusMessage;
                        setTimeout(function () {
                            $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                            $rootScope.$apply();
                        }, $rootScope.alertTimeoutInterval)
                        angular.element('#createButtonForgds').addClass('disabled');
                        $location.url('/partner-configuration');
                    } else {
                        $rootScope.msg.showPartnerConfigErrorMsg = true;
                        $rootScope.partnerConfigErrorMsg = response.data.statusMessage;
                        setTimeout(function () {
                            $rootScope.msg.showPartnerConfigErrorMsg = false;
                            $rootScope.$apply();
                        }, $rootScope.alertTimeoutInterval)
                        angular.element('#createButtonForgds').removeClass('disabled');
                    }
                });
        }
        $rootScope.disableCreateButtonForGds = false;
    }


    $scope.savePartnerConfigForGdsClone = function () {
        $rootScope.disableCreateButtonForGds = true;
        angular.element('#createButtonForgds').addClass('disabled');
        var emailIds = null;
        var simulationEmailIds = null;
        $scope.showErrorForPConfig = false;
    /*    if($rootScope.pCdata.formatDetails.length == 0 || $rootScope.pCdata.formatDetails==[] || $rootScope.pCdata.formatDetails==null)
            $scope.showErrorForPConfig=true;
        if($rootScope.pCdata.metadataType=='Excel' && $rootScope.pCdata.excelFieldDetails.length == 0)
            $scope.showErrorForPConfig=true;
        if($rootScope.pCdata.metadataType=='Onix' || $rootScope.pCdata.metadataType==null)
            $rootScope.pCdata.excelTempate = 'empty';
    */    if (!$scope.showErrorForPConfig) {
            if ($rootScope.pCdataColne.coverMaxHeight != '' && $rootScope.pCdataColne.coverMaxHeight != null)
                $rootScope.pCdataColne.coverMaxHeight += 'px';
            if ($rootScope.pCdataColne.coverMaxWidth != '' && $rootScope.pCdataColne.coverMaxWidth != null)
                $rootScope.pCdataColne.coverMaxWidth += 'px';
        }

        if ($rootScope.pCdataColne.simulationEmail != null)
            simulationEmailIds = $rootScope.pCdataColne.simulationEmail.replace(/\s/g, "");
        if ($rootScope.pCdataColne.emailId != null)
            emailIds = $rootScope.pCdataColne.emailId.replace(/\s/g, "");
        /*    console.log({
                    partnerId: $rootScope.pCdata.partnerId,
                    formatDetails: $rootScope.pCdata.formatDetails,
                    coverRequired: $rootScope.pCdata.coverRequired,
                    coverFormat: $rootScope.pCdata.coverFormat,
                    coverResizeRequired: $rootScope.pCdata.coverResizeRequired,
                    coverMaxHeight : $rootScope.pCdata.coverMaxHeight,                
                    coverMaxWidth : $rootScope.pCdata.coverMaxWidth,
                    metadataRequired : $rootScope.pCdata.metadataRequired,
                    metadataNaming : $rootScope.pCdata.metadataNaming,
                    metadataType : $rootScope.pCdata.metadataType,
                    onixType : $rootScope.pCdata.onixType,
                    excelTempateRowStartAt : $rootScope.pCdata.excelTempateRowStartAt,
                    ftpDetails : $rootScope.pCdata.ftpDetails,
                    excelFieldDetails : $rootScope.pCdata.excelFieldDetails,
                    excludeFieldList : $rootScope.pCdata.excludeFieldList,
                    transformFieldList : $rootScope.pCdata.transformFieldList,
                    isSimulation : $rootScope.pCdata.isSimulation,
                    cDATARequired : $rootScope.pCdata.cDATARequired,
                    emailId: $rootScope.pCdata.emailId.replace(/\s/g,""),
                    excelTempate : $rootScope.pCdata.excelTempate
                });   
         */
        if (!$scope.showErrorForPConfig) {
            $http({
                method: 'POST',
                url: '/savePartnerConfiguration',
                data: {
                    partnerId: $rootScope.pCdataColne.partnerId,
                    formatDetails: $rootScope.pCdataColne.formatDetails,
                    coverRequired: $rootScope.pCdataColne.coverRequired,
                    coverFormat: $rootScope.pCdataColne.coverFormat,
                    coverResizeRequired: $rootScope.pCdataColne.coverResizeRequired,
                    coverMaxHeight: $rootScope.pCdataColne.coverMaxHeight,
                    coverMaxWidth: $rootScope.pCdataColne.coverMaxWidth,
                    metadataRequired: $rootScope.pCdataColne.metadataRequired,
                    metadataNaming: $rootScope.pCdataColne.metadataNaming,
                    metadataType: $rootScope.pCdataColne.metadataType,
                    onixType: $rootScope.pCdataColne.onixType,
                    excelTempateRowStartAt: $rootScope.pCdataColne.excelTempateRowStartAt,
                    ftpDetails: $rootScope.pCdataColne.ftpDetails,
                    excelFieldDetails: $rootScope.pCdataColne.excelFieldDetails,
                    csvFieldDetails: $rootScope.pCdataColne.csvFieldDetails,
                    excludeFieldList: $rootScope.pCdataColne.excludeFieldList,
                    transformFieldList: $rootScope.pCdataColne.transformFieldList,
                    isSimulation: $rootScope.pCdataColne.isSimulation,
                    cDATARequired: $rootScope.pCdataColne.cDATARequired,
                    emailId: emailIds,
                    excelTempate: $rootScope.pCdataColne.excelTempate,
                    simulationEmail: simulationEmailIds,
                    transferFolderStructure: $rootScope.pCdataColne.transferFolderStructure,
                    shortTag: $rootScope.pCdataColne.shortTag,
                    sheetNames: $rootScope.pCdataColne.sheetNames,
                    cancelRequestOnEpubFailure: $rootScope.pCdataColne.cancelRequestOnEpubFailure,
                    metaRefreshInterval: $rootScope.pCdataColne.metaRefreshInterval,
                    metadataTransferMedium: $rootScope.pCdataColne.metadataTransferMedium
                }

            })
                .then(function (response) {
                    if (response.data.code == '200') {
                        $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                        $rootScope.partnerConfigSuccessMsg = response.data.statusMessage;
                        setTimeout(function () {
                            $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                            $rootScope.$apply();
                        }, $rootScope.alertTimeoutInterval)
                        angular.element('#createButtonForgds').addClass('disabled');
                        $scope.partnerConfigs();
                        $location.url('/partner-configuration');
                    } else {
                        $rootScope.msg.showPartnerConfigErrorMsg = true;
                        $rootScope.partnerConfigErrorMsg = response.data.statusMessage;
                        setTimeout(function () {
                            $rootScope.msg.showPartnerConfigErrorMsg = false;
                            $rootScope.$apply();
                        }, $rootScope.alertTimeoutInterval)
                        angular.element('#createButtonForgds').removeClass('disabled');
                    }
                });
        }
        $rootScope.disableCreateButtonForGds = false;
    }


    angular.element('#createButtonForgds').removeClass('disabled');
    angular.element('#gdsupdate').removeClass('disabled');

    $scope.updatePartnerConfigForGds = function () {

        if ($rootScope.pCdata._id) {
            angular.element('#gdsupdate').addClass('disabled');

            //      console.log($rootScope.disableUpdateButtonForGds)
            var emailIds = null;
            var simulationEmailIds = null;
            if ($rootScope.pCdata.coverMaxHeight != null && $rootScope.pCdata.coverMaxHeight != '')
                $rootScope.pCdata.coverMaxHeight += 'px';
            if ($rootScope.pCdata.coverMaxWidth != null && $rootScope.pCdata.coverMaxWidth != '')
                $rootScope.pCdata.coverMaxWidth += 'px';
            if ($rootScope.pCdata.simulationEmail != null)
                simulationEmailIds = $rootScope.pCdata.simulationEmail.replace(/\s/g, "");
            if ($rootScope.pCdata.emailId != null)
                emailIds = $rootScope.pCdata.emailId.replace(/\s/g, ""),

                    $http({
                        method: 'POST',
                        url: '/updatePartnerConfiguration/' + $rootScope.pCdata._id,
                        data: {
                            _id: $rootScope.pCdata._id,
                            partnerId: $rootScope.pCdata.partnerId,
                            partnerConfigId: $rootScope.pCdata.partnerConfigId,
                            formatDetails: $rootScope.pCdata.formatDetails,
                            coverRequired: $rootScope.pCdata.coverRequired,
                            coverFormat: $rootScope.pCdata.coverFormat,
                            coverResizeRequired: $rootScope.pCdata.coverResizeRequired,
                            coverMaxHeight: $rootScope.pCdata.coverMaxHeight,
                            coverMaxWidth: $rootScope.pCdata.coverMaxWidth,
                            metadataRequired: $rootScope.pCdata.metadataRequired,
                            metadataNaming: $rootScope.pCdata.metadataNaming,
                            metadataType: $rootScope.pCdata.metadataType,
                            onixType: $rootScope.pCdata.onixType,
                            excelTempateRowStartAt: $rootScope.pCdata.excelTempateRowStartAt,
                            ftpDetails: $rootScope.pCdata.ftpDetails,
                            excelFieldDetails: $rootScope.pCdata.excelFieldDetails,
                            csvFieldDetails: $rootScope.pCdata.csvFieldDetails,
                            excludeFieldList: $rootScope.pCdata.excludeFieldList,
                            transformFieldList: $rootScope.pCdata.transformFieldList,
                            isSimulation: $rootScope.pCdata.isSimulation,
                            cDATARequired: $rootScope.pCdata.cDATARequired,
                            emailId: emailIds,
                            excelTempate: $rootScope.pCdata.excelTempate,
                            simulationEmail: simulationEmailIds,
                            transferFolderStructure: $rootScope.pCdata.transferFolderStructure,
                            shortTag: $rootScope.pCdata.shortTag,
                            sheetNames: $rootScope.pCdata.sheetNames,
                            cancelRequestOnEpubFailure: $rootScope.pCdata.cancelRequestOnEpubFailure,
                            metaRefreshInterval: $rootScope.pCdata.metaRefreshInterval,
                            metadataTransferMedium: $rootScope.pCdata.metadataTransferMedium
                        }

                    })
                        .then(function (response) {
                            if (response.data.code == '200') {
                                $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                                $rootScope.partnerConfigSuccessMsg = response.data.statusMessage;
                                setTimeout(function () {
                                    $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                                    $rootScope.$apply();
                                }, $rootScope.alertTimeoutInterval)
                                $rootScope.disableUpdateButtonForGds = false;
                                angular.element('#gdsupdate').removeClass('disabled');
                                $location.url('/partner-configuration');
                            } else {
                                $rootScope.msg.showPartnerConfigErrorMsg = true;
                                $rootScope.partnerConfigErrorMsg = response.data.statusMessage;
                                setTimeout(function () {
                                    $rootScope.msg.showPartnerConfigErrorMsg = false;
                                    $rootScope.$apply();
                                }, $rootScope.alertTimeoutInterval)
                                $rootScope.disableUpdateButtonForGds = false;
                                angular.element('#gdsupdate').removeClass('disabled');
                                $location.url('/partner-configuration');
                            }
                        });
        }
        else if (!$rootScope.pCdata._id)
            $scope.savePartnerConfigForGds();
        angular.element('#gdsupdate').removeClass('disabled');
    }

    $scope.toggleCoverRequired = function (chk) {
        if (!chk) {
            $rootScope.pCdata.coverResizeRequired = false;
            angular.forEach($rootScope.listForCoverFormats, function (obj) {
                obj.selected = false;
            })
            $rootScope.pCdata.coverMaxHeight = null;
            $rootScope.pCdata.coverMaxWidth = null;
            $rootScope.pCdata.coverFormat = null;
            $rootScope.pCdata.metadataTransferMedium = 'Email';
            if (!$rootScope.pCdata.formatDetails) {
                angular.forEach($rootScope.pCFtpTypes, function (obj) {
                    if (obj.selected)
                        obj.selected = false;
                });
                $rootScope.pCdata.ftpDetails = null;
            }
        }
    }

    $scope.pCRemoveFormatCondition = function(){
        if($rootScope.pCdata.formatDetails)
        {
            angular.forEach($rootScope.pCdata.formatDetails,function(obj){
                if(obj.formatId == $rootScope.pCcurrentFormat.formatId)
                {
                    obj.formatNamingPrefix = null;
                    obj.formatNamingSuffix = null;
                    obj.compressedIfMultiple = false;
                    obj.ePubVersion = null;
                    if(obj.epubValidator)
                        obj.epubValidator = false;
                }
            })
        }
    }

    $scope.addDefaultExcelFields = function (chk) {
        if (chk) {
            $rootScope.pCdata.excelFieldDetails.push({
                'metaDataFieldName': '',
                'isActive': false
            })
        }
        else {
            $rootScope.pCdata.excelFieldDetails
                .splice($rootScope.pCdata.excelFieldDetails.lastIndexOf(data => data['metaDataFieldName'] === ''), 1);
        }
    }

    $scope.pCAddDefaultMetadata = function(){
        if($rootScope.pCdata.metadataType == "Excel" || $rootScope.pCdata.metadataType == 'excel'){
            $rootScope.pCdata.excelFieldDetails.push({
                'metaDataFieldName': '',
                'isActive': false
            })
        }
        if($rootScope.pCdata.metadataType == "csv" || $rootScope.pCdata.metadataType == 'CSV'){
            $rootScope.pCdata.csvFieldDetails.push({
                'metaDataFieldName': '',
                'isActive': false
            })
        }
    }
    $rootScope.assetValidate = function(){
        var assetCondition = false;
        if ($rootScope.pCdata.formatDetails != null)
        if ($rootScope.pCdata.formatDetails.length == 0) {
            assetCondition = true;
        }

    if ($rootScope.pCdata.formatDetails != null) {
        if ($rootScope.pCdata.formatDetails.length > 0) {
            angular.forEach($rootScope.pCdata.formatDetails, function (obj) {
                if (obj.formatNaming == null || obj.formatNaming == '') {
                    assetCondition = true;
                }
            });
        }
    }
    if ($rootScope.pCdata.coverRequired) {
        if ($rootScope.pCdata.coverFormat == null || $rootScope.pCdata.coverFormat.length === 0) {
            assetCondition = true;
        }
    }
    if($rootScope.pCdata.coverResizeRequired == true){
        if ( $rootScope.pCdata.coverMaxHeight == '' || $rootScope.pCdata.coverMaxHeight == undefined || $rootScope.pCdata.coverMaxWidth == '' || $rootScope.pCdata.coverMaxWidth == undefined) {
            assetCondition = true;
        }
    }
    angular.forEach($rootScope.pCdata.coverFormat,function(data){
     if(data.formatOrder == undefined)
        assetCondition = true;
    });

    return assetCondition;
    }
   
    $scope.metadataValidate = function(){
        var condition = false;
        
        if (($rootScope.pCdata.metadataType == null || $rootScope.pCdata.metadataType == '') && $rootScope.pCdata.metadataRequired) {
            condition = true;
        }
        if (($rootScope.pCdata.metadataType == 'ONIX' || $rootScope.pCdata.metadataType == 'onix') && $rootScope.pCdata.onixType == null) {
            condition = true;
        }
        if (($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel') && (($rootScope.pCdata.excelFieldDetails == null || $rootScope.pCdata.excelFieldDetails.length == 0) || ($rootScope.pCdata.excelTempateRowStartAt == null || $rootScope.pCdata.excelTempateRowStartAt == ''))) {
            condition = true;
        }
        if (($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv') && ($rootScope.pCdata.csvFieldDetails == null || $rootScope.pCdata.csvFieldDetails.length == 0)) {
            condition = true;
        }
        if ($rootScope.pCdata.partnerId == null || $rootScope.pCdata.partnerId == '') {
            condition = true;
        }
        if($rootScope.pCdata.metadataNaming == '' || $rootScope.pCdata.metadataNaming == null){
            condition = true; 
        }
        
        if ($rootScope.pCdata.transformFieldList != null) {
            if ($rootScope.pCdata.transformFieldList.length > 0) {
                angular.forEach($rootScope.pCdata.transformFieldList, function (obj) {
                    if (obj.operation == null || obj.operation == '') {
                        condition = true;
                    }
                    else if (obj.operation == 'JOIN' && obj.joinBy == null) {
                        condition = true;
                    } 
                });
            }
        }
        if ($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel')
            if ($rootScope.pCdata.excelFieldDetails != null && $rootScope.pCdata.excelFieldDetails.length > 0) {
                angular.forEach($rootScope.pCdata.excelFieldDetails, function (obj) {
                    if (obj.sheetName == null || obj.displayOrderNo == '' || obj.displayOrderNo == null)
                    condition = true;
                })
            }
        if ($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv')
            if ($rootScope.pCdata.csvFieldDetails != null && $rootScope.pCdata.csvFieldDetails.length > 0) {
                angular.forEach($rootScope.pCdata.csvFieldDetails, function (obj) {
                    if (obj.sheetName == null || obj.displayOrderNo == null || obj.displayOrderNo == '' 
                   || obj.headerDisplayName == null || obj.headerDisplayName == '')
                   condition = true;
                })
            }
      return condition;     
    }



    $rootScope.createDisableChkForPartnerConfig = function () {
        var addCondition = false;
        if($rootScope.pCdata.formatDetails == null && ($rootScope.pCdata.metadataRequired == null || !$rootScope.pCdata.metadataRequired))
            addCondition = true;

        if($rootScope.pCdata.formatDetails != null && $rootScope.pCdata.formatDetails.length > 0){
                if(($rootScope.pCdata.ftpDetails == null || $rootScope.pCdata.ftpDetails.length == 0 ) && !$rootScope.pCdata.isSimulation){
                    addCondition = true;
                }
                else{
                    addCondition = false; 
                }

        }
        if($rootScope.pCdata.metadataTransferMedium == null && $rootScope.pCdata.metadataTransferMedium != 'Email'){
            if(($rootScope.pCdata.ftpDetails == null || $rootScope.pCdata.ftpDetails.length == 0 ) && !$rootScope.pCdata.isSimulation){
                addCondition = true;
            }
            else{
                addCondition = false; 
            }
        }

        //        if($rootScope.formatListForGdsPartner){
        if ($rootScope.pCdata.formatDetails != null)
            if ($rootScope.pCdata.formatDetails.length == 0) {
                addCondition = true;
            }

        if ($rootScope.pCdata.formatDetails != null) {
            if ($rootScope.pCdata.formatDetails.length > 0) {
                angular.forEach($rootScope.pCdata.formatDetails, function (obj) {
                    if (obj.formatNaming == null || obj.formatNaming == '') {
                        addCondition = true;
                    }
                });
            }
        }
        //        }
        if ($rootScope.pCdata.coverRequired) {
            if ($rootScope.pCdata.coverFormat == null || $rootScope.pCdata.coverFormat.length === 0) {
                addCondition = true;
            }
        }
        if (($rootScope.pCdata.metadataType == null || $rootScope.pCdata.metadataType == '') && $rootScope.pCdata.metadataRequired) {
            addCondition = true;
        }
        if (($rootScope.pCdata.metadataType == 'ONIX' || $rootScope.pCdata.metadataType == 'onix') && $rootScope.pCdata.onixType == null) {
            addCondition = true;
        }
        if (($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel') && ($rootScope.pCdata.excelFieldDetails == null || $rootScope.pCdata.excelFieldDetails.length == 0)) {
            addCondition = true;
        }
        if (($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv') && ($rootScope.pCdata.csvFieldDetails == null || $rootScope.pCdata.csvFieldDetails.length == 0)) {
            addCondition = true;
        }
        if ($rootScope.pCdata.partnerId == null || $rootScope.pCdata.partnerId == '') {
            addCondition = true;
        }
      /*          if($rootScope.pCdata.transformFieldList==null || $rootScope.pCdata.transformFieldList.length === 0){
                    addCondition = true;
                }
      */      
     
     
      if ($rootScope.pCdata.transformFieldList != null) {
            if ($rootScope.pCdata.transformFieldList.length > 0) {
                angular.forEach($rootScope.pCdata.transformFieldList, function (obj) {
                    if (obj.operation == null || obj.operation == '') {
                        addCondition = true;
                    }
                    else if (obj.operation == 'JOIN' && obj.joinBy == null) {
                        addCondition = true;
                    }
                /*    else if (obj.operation != 'JOIN' && (angular.equals({}, obj.lookUp) || obj.lookUp == null))
                        addCondition = true;
                */        
                });
            }
        }
        if ($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel')
            if ($rootScope.pCdata.excelFieldDetails != null && $rootScope.pCdata.excelFieldDetails.length > 0) {
                angular.forEach($rootScope.pCdata.excelFieldDetails, function (obj) {
                    if (obj.sheetName == null || obj.displayOrderNo == '' || obj.displayOrderNo == null)
                        addCondition = true;
                })
            }
        if ($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv')
            if ($rootScope.pCdata.csvFieldDetails != null && $rootScope.pCdata.csvFieldDetails.length > 0) {
                angular.forEach($rootScope.pCdata.csvFieldDetails, function (obj) {
                    if (obj.sheetName == null || obj.displayOrderNo == null || obj.displayOrderNo == '' 
                   || obj.headerDisplayName == null || obj.headerDisplayName == '')
                        addCondition = true;
                })
            }
        /*        if((($rootScope.pCdata.coverFormat!=null && $rootScope.pCdata.coverFormat.length>0) 
                    || ($rootScope.pCdata.formatDetails!=null && $rootScope.pCdata.formatDetails.length>0)) 
                    && !$rootScope.pCdata.ftpDetails)
                    addCondition=true;

                if($rootScope.pCdata.metadataTransferMedium=='FTP'){
                    if(!$rootScope.pCdata.ftpDetails){
                        addCondition = true;
                    }
                }
        */        if ($rootScope.pCdata.ftpDetails) {
            angular.forEach($rootScope.pCdata.ftpDetails, function (obj) {
                if (obj.protocol == null) {
                    addCondition = true;
                }
            })
        }
       /* if ($rootScope.pCdata.metaRefreshInterval == null)
            addCondition = true;
       */
            /*        if(!$rootScope.pCdata.metadataTransferMedium)
                    addCondition=true;      
        */        return addCondition;
    }
    //   console.log($rootScope.createDisableChkForPartnerConfig());
    $rootScope.formatListForGdsPartner = [];
     
    
    $rootScope.populateConfigPartnerForEdit = function (partnerConfig, flg , chk) {
        $rootScope.partnerConfigEdits = 'click';
        $timeout(function(){
            $rootScope.showLoader($('.configuration-copy-modal-content'), 1, 'win8_linear');
        },10)
        
        localStorage.setItem('gdsSelected', JSON.stringify(partnerConfig));
        localStorage.setItem('actionForGds', flg);
        $rootScope.selectedPartnerDetail = partnerConfig;
        //$rootScope.partnerConfigAction=flg;
        setTimeout(function () {

            //      $rootScope.showLoader($('.user-master'), 1, 'win8_linear');
            //      $rootScope.formatSelectedListforEdit = partnerConfig.formatDetails;
            //      $rootScope.formatSelectedList = $rootScope.formatSelectedListforEdit;
            //      console.log(JSON.stringify(partnerConfig));
            // $rootScope.showLoader($('.partner-config'), 1, 'win8_linear');
            $rootScope.formats = [];
            $rootScope.pCdata = partnerConfig;

            //      console.log($rootScope.pCdata);
            $rootScope.pCdata._id = partnerConfig._id;
            $rootScope.pCdata.partnerId = partnerConfig.partnerId;
            $rootScope.partnerConfigAction = 'Update';


            if ($rootScope.pCdata.partnerId) {
                var index = $rootScope.distColumnPartners.findIndex(data => data['partnerId'] === partnerConfig.partnerId);
                $rootScope.formatListForGdsPartner = $rootScope.distColumnPartners[index].formatId;
            }
            for (var i = 0; i < $rootScope.formatListForGdsPartner.length; i++) {
                var index = $rootScope.formatList.findIndex(data => data['formatId'] === $rootScope.formatListForGdsPartner[i]);
                if (index != -1)
                    $rootScope.formats.push($rootScope.formatList[index]);
            }
            //      console.log($rootScope.formatList);
            //      console.log($rootScope.formats);
            $rootScope.pCdata.partnerConfigId = partnerConfig.partnerConfigId;

            $rootScope.pCdata.coverFormat = partnerConfig.coverFormat;

            if (partnerConfig.coverMaxHeight)
                $rootScope.pCdata.coverMaxHeight = partnerConfig.coverMaxHeight.substring(0, partnerConfig.coverMaxHeight.length - 2);
            if (partnerConfig.coverMaxWidth)
                $rootScope.pCdata.coverMaxWidth = partnerConfig.coverMaxWidth.substring(0, partnerConfig.coverMaxWidth.length - 2);

            $rootScope.pCdata.coverRequired = partnerConfig.coverRequired;
            if (!$rootScope.pCdata.coverRequired)
                $rootScope.pCdata.coverRequired = false;

            $rootScope.pCdata.coverResizeRequired = partnerConfig.coverResizeRequired;
            if (!$rootScope.pCdata.coverResizeRequired)
                $rootScope.pCdata.coverResizeRequired = false;

            $rootScope.pCdata.emailId = partnerConfig.emailId;

            $rootScope.pCdata.excelFieldDetails = partnerConfig.excelFieldDetails;

            $rootScope.pCdata.csvFieldDetails = partnerConfig.csvFieldDetails;

            $rootScope.pCdata.excelTempate = partnerConfig.excelTempate;

            if ($rootScope.pCdata.excelTempateRowStartAt)
                $rootScope.pCdata.excelTempateRowStartAt = parseInt(partnerConfig.excelTempateRowStartAt, 10);

            $rootScope.pCdata.excludeFieldList = partnerConfig.excludeFieldList;

            $rootScope.pCdata.formatDetails = partnerConfig.formatDetails;

            $rootScope.pCdata.ftpDetails = partnerConfig.ftpDetails;

            $rootScope.pCdata.cDATARequired = partnerConfig.cDATARequired;
            if (!$rootScope.pCdata.cDATARequired)
                $rootScope.pCdata.cDATARequired = false;

            $rootScope.pCdata.isSimulation = partnerConfig.isSimulation;
            if (!$rootScope.pCdata.isSimulation)
                $rootScope.pCdata.isSimulation = false;

            $rootScope.pCdata.transferFolderStructure = partnerConfig.transferFolderStructure;
            if (!$rootScope.pCdata.transferFolderStructure)
                $rootScope.pCdata.transferFolderStructure = false;

            if ($rootScope.pCdata.transferFolderStructure == false) {
                $rootScope.cpFolderStructureDefault = true;
                $rootScope.cpTransferFolderStructure = false;
            }
            else {
                $rootScope.cpFolderStructureDefault = false;
                $rootScope.cpTransferFolderStructure = true;
            }

            $rootScope.pCdata.transformFieldList = partnerConfig.transformFieldList;

            $rootScope.pCdata.metadataNaming = partnerConfig.metadataNaming;

            $rootScope.pCdata.metadataRequired = partnerConfig.metadataRequired;
            if (!$rootScope.pCdata.metadataRequired)
                $rootScope.pCdata.metadataRequired = false;

            $rootScope.pCdata.metadataType = partnerConfig.metadataType;

            $rootScope.pCdata.shortTag = partnerConfig.shortTag;
            if (!$rootScope.pCdata.shortTag)
                $rootScope.pCdata.shortTag = false;

            if ($rootScope.pCdata.sheetNames)
                $rootScope.pCdata.sheetNames = partnerConfig.sheetNames;

            if ($rootScope.pCdata.excelFieldDetails && !$rootScope.pCdata.sheetNames) {
                $rootScope.pCdata.sheetNames = [];
                angular.forEach($rootScope.pCdata.excelFieldDetails, function (obj) {
                    if ($rootScope.pCdata.sheetNames.indexOf(obj.sheetName) == -1)
                        $rootScope.pCdata.sheetNames.push(obj.sheetName);
                })
            }
            //      console.log($rootScope.pCdata.sheetNames);

            $rootScope.pCdata.cancelRequestOnEpubFailure = partnerConfig.cancelRequestOnEpubFailure;
            if (!$rootScope.pCdata.cancelRequestOnEpubFailure)
                $rootScope.pCdata.cancelRequestOnEpubFailure = false;

            if (partnerConfig.metadataType && (partnerConfig.metadataType == 'onix' || partnerConfig.metadataType == 'ONIX')) {
                $rootScope.pCdata.onixMetadataRequired = true;
                $rootScope.pCdata.onixType = partnerConfig.onixType;
            }
            else if (partnerConfig.metadataType && partnerConfig.metadataType == 'excel' || partnerConfig.metadataType == 'Excel')
                $rootScope.pCdata.excelMetadataRequired = true;

            $rootScope.pCdata.simulationEmail = partnerConfig.simulationEmail;

            $rootScope.pCdata.excelTempateRowStartAt = partnerConfig.excelTempateRowStartAt;


            /*       $scope.pCExcludeFieldList = partnerConfig.excludeFieldList;
                   if($scope.pCExcludeFieldList){
                       angular.forEach($scope.pCExcludeFieldList,function(key,value){
                           angular.forEach($rootScope.duplicateMetaList,function(obj){
                               if(obj.metaDataFieldName == key)
                                   obj.selected=true;
                           });
                       });
                   }    
             */      //console.log($rootScope.duplicateMetaList);
            // console.log($rootScope.formats);


            //$rootScope.duplicateMetaListForTransform
            if ($rootScope.pCdata.transformFieldList) {
                angular.forEach($rootScope.duplicateMetaListForTransform, function (obj) {
                    angular.forEach($rootScope.pCdata.transformFieldList, function (subObj) {
                        if (subObj.metaDataFieldName == obj.metaDataFieldName)
                            obj.selected = true;
                    });
                });
            }
            //$rootScope.duplicateMetaListForExcel
            $timeout(function () {
                if ($rootScope.pCdata.excelFieldDetails) {
                    angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                        angular.forEach($rootScope.pCdata.excelFieldDetails, function (subObj) {
                            if (subObj.metaDataFieldName == obj.metaDataFieldName)
                                obj.selected = false;
                        });
                    });
                }
            }, 3000)


            if ($rootScope.pCdata.csvFieldDetails) {
                angular.forEach($rootScope.duplicateMetaListForCSV, function (obj) {
                    angular.forEach($rootScope.pCdata.csvFieldDetails, function (subObj) {
                        if (subObj.metaDataFieldName == obj.metaDataFieldName)
                            obj.selected = true;
                    });
                });
            }

            if ($rootScope.pCdata.ftpDetails) {
                angular.forEach($rootScope.pCFtpTypes, function (obj) {
                    angular.forEach($rootScope.pCdata.ftpDetails, function (subObj) {
                        if (subObj.ftpType == obj.ftpType)
                            obj.selected = true;
                    });
                });
            }
            if ($rootScope.pCdata.excludeFieldList) {
                angular.forEach($rootScope.duplicateMetaListForExclude, function (obj) {
                    if ($rootScope.pCdata.excludeFieldList.indexOf(obj.metaDataFieldName) > -1)
                        obj.selected = true;
                });

            }

            if ($rootScope.pCdata.formatDetails) {
                $rootScope.partnerConfigShow = true;
                $rootScope.formatDetailsEmpty = true;
                $rootScope.partnerConfigAsset = 'Switch if asset not required';
            }
            else {
                $rootScope.partnerConfigShow = false;
                $rootScope.formatDetailsEmpty = false;
                $rootScope.partnerConfigAsset = 'Switch if asset required';
            }
            if ($rootScope.pCdata.formatDetails) {
                angular.forEach($rootScope.pCdata.formatDetails, function (data) {
                    angular.forEach($rootScope.duplicateMetaList, function (obj) {
                        //     if(obj.jsonPath==data.formatNaming)
                        if (data.fieldDisplayName == null && data.formatNaming != '*') {
                            if ((obj.jsonPath).toLowerCase() == (data.formatNaming).toLowerCase())
                                data.fieldDisplayName = obj.fieldDisplayName;
                        }
                    });
                    //    console.log($rootScope.pCdata.formatDetails);
                });
            }

            if (partnerConfig.formatDetails) {
                angular.forEach(partnerConfig.formatDetails, function (data) {
                    angular.forEach($rootScope.formats, function (obj) {
                        if ((data.formatId) == (obj.formatId))
                            obj.selected = true;
                        if (data.formatNaming == "*") {
                            data.formatNamingRequired = false;
                            data.fieldDisplayName = null;
                        }
                        else
                            data.formatNamingRequired = true;
                    });
                });
            }

            $rootScope.pCExcelFieldList = partnerConfig.excelFieldDetails;

            if (partnerConfig.coverFormat) {
                angular.forEach(partnerConfig.coverFormat, function (data) {
                    angular.forEach($rootScope.listForCoverFormats, function (obj) {
                        if ((data.formatId) == (obj.formatId))
                            obj.selected = true;
                    });
                });
            }
            
            if (flg == 'Clone') {
                $rootScope.partnerConfigAction = 'Clone';
                $rootScope.pCdata.partnerId = null;
                $rootScope.formatListForGdsPartner = [];
                $rootScope.pCdata.formatDetails = null;
                if ($rootScope.formats) {
                    angular.forEach($rootScope.formats, function (obj) {
                        if (obj.selected)
                            obj.selected = false;
                    });
                }
            }
            // console.log($rootScope.pCdata.partnerId);


            /*     $scope.pcFormatAppleShowColumn = function(){
                    var flag = false;
                    var pcFormatAppleShow = $filter('filter')($rootScope.distColumnPartners, function (data) {
                        if( (data.partnerId == $rootScope.pCdata.partnerId ) && data.isApplePartner == true ){
                            flag = true;  
                        }
                        return flag;
                    }); 
                    return flag;
                } */

            

            if(chk == 'Dont_Redirect'){
                $rootScope.pCdataColne = angular.copy($rootScope.pCdata);
                $rootScope.pCdataColne.partnerId = null;
                $rootScope.pCIneligibleFormatList = [];
            }
            //     console.log($rootScope.pCdata);
            $rootScope.$apply();
        }, 3000)
        /*    $rootScope.selectedFormatDetails = $rootScope.selectedPartnerDetail.formatDetails.map(function(item) {
                return item;
            });
            if( $rootScope.selectedFormatDetails.length >0 ){
                $rootScope.partnerConfigShow = true;
                $rootScope.formatDetailsEmpty = true;
                $rootScope.partnerConfigAsset = 'Asset not required';
            } 
            else{
                $rootScope.partnerConfigShow = false;
                $rootScope.formatDetailsEmpty = false;
                $rootScope.partnerConfigAsset = 'Asset required';
            }
        */    // if($rootScope.selectedFormatDetails.length >0){
        //     console.log('sas');
        //     $scope.partnerConfigShow = true;
        //     $rootScope.formatDetailsEmpty = true;
        //     $scope.partnerConfigAsset = 'Asset not required';
        // } 
        // else{
        //     $scope.partnerConfigShow = false;
        //     $scope.partnerConfigAsset = 'Asset required';
        // }
        // $rootScope.distColumnPartners
        $timeout(function(){
            $rootScope.hideLoader('configuration-copy-modal-content');
        },3000)
        
        if(chk != 'Dont_Redirect')
            $location.url('/create-new-partner-config');

        if ($location.$$url === '/create-new-partner-config') {
            $timeout(function () {
                //alert('test');
                $rootScope.hideLoader('partner-config');
            }, 4000)
        }
        
    }
    /*
       $scope.hideLoaderForUpdatePage=function(){ 
          setTimeout(function(){
                    $rootScope.hideLoader('partner-config');
                },3000)
        }
    */
    $scope.setOnixType = function (val) {
        $rootScope.pCdata.onixType = val;
    }
    $scope.pcFormatAppleShowColumn = function () {
        return ($rootScope.distColumnPartners[$rootScope.distColumnPartners.findIndex(obj => obj['partnerId'] === $rootScope.pCdata.partnerId)].isApplePartner);
    }
    $rootScope.cPmetadaMappingExcel = angular.copy($rootScope.pCdata.excelFieldDetails);
    $scope.cPexcelFiled = function () {
        $rootScope.cPmetadaMappingExcel = angular.copy($rootScope.pCdata.excelFieldDetails);
    }
    $scope.setMetadataType = function (val) {
        $rootScope.pCdata.metadataType = val;
        if (val == 'ONIX') {
            $rootScope.pCdata.excelFieldDetails = null;
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
            $rootScope.pCdata.excelTempate = null;
            $rootScope.pCdata.excelTempateRowStartAt = null;
            $rootScope.pCdata.onixType = null;
            $rootScope.pCdata.sheetNames = null;
            $rootScope.pCdata.csvFieldDetails = null;
            angular.forEach($rootScope.duplicateMetaListForCSV, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
            $rootScope.pCdata.transformFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForTransform, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
        }
        if (val == 'Excel') {
            $rootScope.pCdata.onixType = null;
            if (!$rootScope.pCdata.excelFieldDetails)
                $rootScope.pCdata.excelFieldDetails = [];
            $rootScope.pCdata.shortTag = false;
            $rootScope.pCdata.csvFieldDetails = null;
            angular.forEach($rootScope.duplicateMetaListForCSV, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });

            $rootScope.pCdata.excludeFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForExclude, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });

            $rootScope.pCdata.transformFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForTransform, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
        }
        if (val == 'CSV') {
            $rootScope.pCdata.excelFieldDetails = null;
            $rootScope.pCdata.excelTempate = null;
            $rootScope.pCdata.excelTempateRowStartAt = null;
            $rootScope.pCdata.onixType = null;
            if (!$rootScope.pCdata.csvFieldDetails)
                $rootScope.pCdata.csvFieldDetails = [];
            $rootScope.pCdata.shortTag = false;
            $rootScope.pCdata.excelFieldDetails = null;
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
            $rootScope.pCdata.excludeFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForExclude, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });

            $rootScope.pCdata.transformFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForTransform, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
        }
    }

    $scope.setTransferType = function (val) {
        $rootScope.pCdata.metadataTransferMedium = val;
        if (val == 'Email' && (!$rootScope.pCdata.formatDetails && !$rootScope.pCdata.coverFormat)) {
            $rootScope.pCdata.ftpDetails = null;
            angular.forEach($rootScope.pCFtpTypes, function (obj) {
                obj.selected = false;
            })
        }
    }

    $scope.setProtocolType = function (val, index) {
        $rootScope.pCdata.ftpDetails[index].protocol = val;
    }

    $scope.printpCdata = function () {
        console.log($rootScope.pCdata);
    }

    $scope.alphaOnly = function ($event) {
        var key = $event.keyCode;
        return ((key >= 65 && key <= 90) || key == 8);
    };



    $scope.setSheetSelected = function (pIndex, obj, val) {
        $rootScope.pCdata.excelFieldDetails[pIndex].sheetName = val;
    }

    $scope.setDateFormatSelected = function (pIndex, obj, val) {
        $rootScope.pCdata.excelFieldDetails[pIndex].dateFormat = val;
    }

    $scope.setCSVDateFormatSelected = function (pIndex, obj, val) {
        $rootScope.pCdata.csvFieldDetails[pIndex].dateFormat = val;
    }

    $scope.setOperationSelected = function (index, obj, opt) {
        //  $scope.partnerConfigOperationSelected=opt;

        //console.log($rootScope.pCdata.transformFieldList.indexOf(obj));
        $rootScope.pCdata.transformFieldList[index].operation = opt;
        if (opt != 'JOIN') {
            $rootScope.pCdata.transformFieldList[index].joinBy = null;
            var key = 'DEFAULT';
            var value = '';
            $rootScope.pCdata.transformFieldList[index].lookUp = {};
            $rootScope.pCdata.transformFieldList[index].lookUp[key] = value;
            // $rootScope.pCdata.transformFieldList[index].lookUp['']='';
        }
        else
            $rootScope.pCdata.transformFieldList[index].lookUp = null;
        /*      if(opt=='REPLACE'){
                  obj.partnerConfigOperationSelected=opt;
                  obj.lookupList = [0];
              }
              if(opt=='CONCAT_PREFIX'){
                  obj.partnerConfigOperationSelected=opt;
                  obj.lookupListConcatPre = [0];
              }
              if(opt=='CONCAT_SUFFIX'){
                  obj.partnerConfigOperationSelected=opt;
                  obj.lookupListConcatSuf = [0];
              }
              console.log($scope.partnerConfigOperationSelected);
              obj.transformOperation=opt;
              console.log($scope.pCTransformFieldList);
      */
    }

    $scope.formatFieldEpubValidChk = function ($event, obj) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action == 'add')
            obj.isEpubValidator = true;
        else if (action == 'remove')
            obj.isEpubValidator = false
        //    console.log($rootScope.formatSelectedList);
    }

    $scope.ftpFieldPassive = function ($event, obj) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action == 'add')
            obj.isPassive = true;
        else if (action == 'remove')
            obj.isPassive = false
        //    console.log($rootScope.pCFtpFieldList);
    }

    $scope.excelFieldActiveDeactive = function ($event, obj, index) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action == 'add')
            $rootScope.pCExcelFieldList[index]['isMetaActiveField'] = true;
        else if (action == 'remove')
            $rootScope.pCExcelFieldList[index]['isMetaActiveField'] = false;
        // obj.isMetaActiveField=false
        //    console.log($rootScope.pCExcelFieldList);
    }

    $scope.pConfigMetadataRequired = function (chk) {
        if (!chk) {
            $rootScope.pCdata.metadataType = null;
            $rootScope.pCdata.metadataNaming = null;
            $rootScope.pCdata.metadataType = null;
            $rootScope.pCdata.onixType = null;
            $rootScope.pCdata.excelFieldDetails = null;
            $rootScope.pCdata.excelTempateRowStartAt = null;
            $rootScope.pCdata.excelTempate = null;
            $rootScope.pCdata.sheetNames = null;
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
            $rootScope.pCdata.excludeFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForExclude, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
            $rootScope.pCdata.transformFieldList = null;
            angular.forEach($rootScope.duplicateMetaListForTransform, function (obj) {
                if (obj.selected)
                    obj.seletced = false;
            });
        }
        //  $rootScope.pCdata.metadataRequired=true;
    }

    $scope.pConfigMetadataTypeRequired = function (type, chk) {
        if (chk) {
            if (type == 'ONIX') {
                $scope.selectedMetaType = 'ONIX';
                $rootScope.pCExcelFieldList = [];
                document.getElementById('pMetadataRequiredExcel').checked = false;
            }
            if (type == 'Excel') {
                $scope.selectedMetaType = 'Excel';
                $scope.pMetadataRequiredExcel = true;
                $scope.pMetadataRequiredOnix = false;
                document.getElementById('pMetadataRequiredOnix').checked = false;
            }
        }
        else {
            if (type == 'ONIX') {
                $scope.selectedMetaType = null;
                $scope.pMetadataRequiredOnix = false;
            }
            if (type == 'Excel') {
                $scope.selectedMetaType = null;
                $scope.pMetadataRequiredExcel = false;
            }
        }
    }

    $scope.pConfigOnixVersion = function (version) {
        if (version == '2.1') {
            $scope.onixVersion = '2.0';
            document.getElementById('pConix3').checked = false;
        }
        if (version == '3.0') {
            $scope.onixVersion = '3.0';
            document.getElementById('pConix2').checked = false;
        }
    }

    $scope.pConfigMetadataRequiredExcel = function () {
        $scope.pMetadataRequiredExcel = !$scope.pMetadataRequiredExcel;
    }

    $scope.pCbrowseExcelFile = function (file) {
        
        var filename = file.name;
        var index = filename.lastIndexOf(".");
        var extension = filename.substring(index, filename.length);

        if (extension != ".xlsx" && extension != ".xls") {
            alert("Please select only xlsx files to upload");
            $rootScope.pCbrowsefilesExcel = {};
        }
        else {
            $rootScope.pCbrowsefilesExcel = file;
            $rootScope.disableBrowseButtonForGds = true;
            Upload.upload({
                method: 'POST',
                url: '/uploadExcelTemplateForGds',
                data: {
                    permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                    metadataUpload: $rootScope.pCbrowsefilesExcel
                }
            }).then(function (response) {
                $rootScope.pCdata.excelTempate = response.data.Path;
                $rootScope.pCdata.sheetNames = response.data.sheetNames;

                //   console.log($rootScope.pCdata.excelTempate);
                $rootScope.disableBrowseButtonForGds = false;
                $rootScope.pCdata.excelFieldDetails = null;
                angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                    if (obj.selected)
                        obj.selected = false;
                });
                // $rootScope.pCdata.transformFieldList = null;
                //$scope.mfiles=null;
            });

        }
        $rootScope.pCbrowsefiles = null;

    }

    $scope.clearAllPConfig = function () {
        $location.url('/partner-configuration');
    }
   
    $scope.coverpCAllFormatSelected = function (chk) {
        if (chk) {
            angular.forEach($rootScope.formats, function (data) {
                if (data.formatName == 'Front cover') {
                    data.selected = true;
                    $scope.coverformatSelectedList.push(data);
                }

            })
        }
        else {
            angular.forEach($rootScope.formats, function (data) {
                if (data.formatName == 'Front cover') {
                    data.selected = false;
                    $scope.coverformatSelectedList.splice($scope.coverformatSelectedList.indexOf(data), 1);
                }
            })
        }
    }


    /*  $scope.getMetadataFieldForPartnerConfig=function(){
              $http({
                         method : 'GET',
                         url : '/getMetadataConfigDetails',
                         data : null
                     }).then(function(response) {
                         $rootScope.duplicateMetaList = response.data.data;
                         
       }
      }
  */
    $scope.pConfigFTPAllSelected = function (chk) {
        if (chk) {
            angular.forEach($rootScope.pCFtpTypes, function (data) {
                data.selected = true;
                $rootScope.pCFtpFieldList.push(data);
            })
        }
        else {
            angular.forEach($rootScope.pCFtpTypes, function (data) {
                data.selected = false;
                $rootScope.pCFtpFieldList.splice($rootScope.pCFtpFieldList.indexOf(data), 1);
            })
        }

    }

    $scope.refreshPartnerConfigExcludeFieldList = function () {
        var filteredList = $filter('filter')($rootScope.duplicateMetaListForExclude, function (data) { var re = new RegExp($scope.pCExcludeFieldSearch, 'gi'); return data.fieldDisplayName.match(re); });

        $timeout(function () {
            $scope.pCExcludeAllSelected = filteredList.every(function (itm) { return itm.selected; }) && filteredList.length > 0;
        }, 10);
    };

    $scope.pConfigExcludeAllSelected = function (chk) {
        var filteredList = $filter('filter')($rootScope.duplicateMetaListForExclude, function (data) {
            var re = new RegExp($scope.pCExcludeFieldSearch, 'gi');
            return data.fieldDisplayName.match(re);
        });
        if (chk) {
            /*        var filteredList = $filter('filter')($scope.data.formatListLocal, function(data)
                            { var re = new RegExp($scope.data.formatSearch, 'gi');
                                return data.formatName.match(re); });
                       $scope.data.formatNames = [];
                var toggleStatus = $scope.data.formatAllSelected;
                angular.forEach(filteredList, function(itm) { itm.selected = toggleStatus; });
            */
            if ($rootScope.pCdata.excludeFieldList == null)
                $rootScope.pCdata.excludeFieldList = [];

            angular.forEach(filteredList, function (itm) {
                itm.selected = true;
                $rootScope.pCdata.excludeFieldList.push(itm.metaDataFieldName);
            });

        /*    angular.forEach($rootScope.duplicateMetaList,function(data){
                data.selected=true;
                $scope.pCExcludeFieldList.push(data.metaDataFieldName);
                $rootScope.pCdata.excludeFieldList.push(data.metaDataFieldName);
            })
        */}
        else {
            angular.forEach(filteredList, function (itm) {
                itm.selected = false;
                $rootScope.pCdata.excludeFieldList.splice($rootScope.pCdata.excludeFieldList.indexOf(itm.metaDataFieldName), 1);
            })
            /*angular.forEach($rootScope.duplicateMetaList,function(data){
                data.selected=false;
                $scope.pCExcludeFieldList.splice($scope.pCExcludeFieldList.indexOf(data.metaDataFieldName), 1);
                $scope.pCdata.excludeFieldList.splice($scope.pCdata.excludeFieldList.indexOf(data.metaDataFieldName), 1);
            })
            */
        }
        //  console.log($scope.pCExcludeFieldList);
    }

    $scope.partFtpFieldTags = function (obj, chk) {
        if (chk) {
            //   $rootScope.pCFtpFieldList.push(obj);
            if ($rootScope.pCdata.ftpDetails == null) {
                $rootScope.pCdata.ftpDetails = [];
            }
            $rootScope.pCdata.ftpDetails.push({
                'ftpType': obj.ftpType,
                'isPassive': false
            })
            //   obj.isPassive=false;
        }
        else {
            $rootScope.pCdata.ftpDetails
                .splice($rootScope.pCdata.ftpDetails.findIndex(data => data['ftpType'] === obj.ftpType), 1);
            //  $rootScope.pCFtpFieldList.splice($rootScope.pCFtpFieldList.indexOf(obj),1)
            //  obj.isPassive=false;
        }
        //     console.log($rootScope.pCFtpFieldList);
        //     console.log($rootScope.pCdata.ftpDetails);
    }

    $scope.transformFieldTags = function (obj, chk) {
        if (chk) {
            if ($rootScope.pCdata.transformFieldList == null) {
                $rootScope.pCdata.transformFieldList = [];
            }
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': obj.metaDataFieldName,
                'operation': null
            });
        }
        else {
            $rootScope.pCdata.transformFieldList
                .splice($rootScope.pCdata.transformFieldList.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
            $scope.pCTransformFieldList.splice($scope.pCTransformFieldList.indexOf(obj), 1)
        }
    }

    $scope.removeExcelFieldGroup = function (index, data) {
        $rootScope.pCdata.excelFieldDetails.splice(index, 1);
        if (data.metaDataFieldName != '') {
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (data.metaDataFieldName == obj.metaDataFieldName)
                    obj.selected = false;
            })
        }
        else
            $rootScope.pCdata.defaultExcelFields = false;
    }

    $scope.removeCSVFieldGroup = function (index, data) {
        $rootScope.pCdata.csvFieldDetails.splice(index, 1);
        if (data.metaDataFieldName != '') {
            angular.forEach($rootScope.duplicateMetaListForCSV, function (obj) {
                if (data.metaDataFieldName == obj.metaDataFieldName)
                    obj.selected = false;
            })
        }
        else
            $rootScope.pCdata.defaultCSVFields = false;
    }

    $scope.addDefaultCSVFields = function (chk) {
        if (chk) {
            $rootScope.pCdata.csvFieldDetails.push({
                'metaDataFieldName': '',
                'isActive': false
            })
        }
        else {
            $rootScope.pCdata.csvFieldDetails
                .splice($rootScope.pCdata.csvFieldDetails.lastIndexOf(data => data['metaDataFieldName'] === ''), 1);
        }
    }

   

    $scope.excelFieldTagsTemp = function (obj, chk, type) {
        if (type == 'Excel' || type == 'excel') {
            if (chk) {
                if ($rootScope.pCdata.excelTempFieldDetails == null) {
                    $rootScope.pCdata.excelTempFieldDetails = [];
                }
                if (obj.fieldType != 'Date') {
                    //$rootScope.pCExcelFieldList.push(obj);
                    $rootScope.pCdata.excelTempFieldDetails.push({
                        'metaDataFieldName': obj.metaDataFieldName,
                        'isActive': false,
                        'fieldType': obj.fieldType
                    })
                }
                else {
                    $rootScope.pCdata.excelTempFieldDetails.push({
                        'metaDataFieldName': obj.metaDataFieldName,
                        'isActive': false,
                        'fieldType': 'Date',
                    })
                }
            }
            else {
                /*     angular.forEach($rootScope.pCdata.excelFieldDetails,function(value,key){
                            if(value.metaDataFieldName==obj.metaDataFieldName){
                                $rootScope.pCdata.excelFieldDetails.splice(key,1);
            
                            }
                        })
                    */
                $rootScope.pCdata.excelTempFieldDetails
                    .splice($rootScope.pCdata.excelTempFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
                //   obj.selected=false;

                /*   $rootScope.pCdata.excelFieldDetails
                    .splice($rootScope.pCdata.excelFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName),1);
                    $rootScope.pCExcelFieldList.splice($rootScope.pCExcelFieldList.indexOf(obj),1)
                */
                // obj.isMetaActiveField=false;
            }
        }
        if (type == 'CSV') {
            if (chk) {
                if ($rootScope.pCdata.csvTempFieldDetails == null) {
                    $rootScope.pCdata.csvTempFieldDetails = [];
                }
                if (obj.fieldType != 'Date') {
                    //$rootScope.pCExcelFieldList.push(obj);
                    $rootScope.pCdata.csvTempFieldDetails.push({
                        'metaDataFieldName': obj.metaDataFieldName,
                        'isActive': false,
                        'fieldType': obj.fieldType
                    })
                }
                else {
                    $rootScope.pCdata.csvTempFieldDetails.push({
                        'metaDataFieldName': obj.metaDataFieldName,
                        'isActive': false,
                        'fieldType': 'Date',
                    })
                }
            }
            else {
                /*     angular.forEach($rootScope.pCdata.excelFieldDetails,function(value,key){
                         if(value.metaDataFieldName==obj.metaDataFieldName){
                             $rootScope.pCdata.excelFieldDetails.splice(key,1);
          
                         }
                     })
                 */
                $rootScope.pCdata.csvTempFieldDetails
                    .splice($rootScope.pCdata.csvTempFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
                //   obj.selected=false;

                /*   $rootScope.pCdata.excelFieldDetails
                   .splice($rootScope.pCdata.excelFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName),1);
                   $rootScope.pCExcelFieldList.splice($rootScope.pCExcelFieldList.indexOf(obj),1)
                 */
                // obj.isMetaActiveField=false;
            }
        }
    }
    // $scope.selectMetadataFieldMappingTags = function (obj, chk,index) {
    //     // $rootScope.metadataMappingIndex = index;
    //     if ($rootScope.pCcurrentMetadata.fieldsToMapJsonPath == null)
    //         $rootScope.pCcurrentMetadata.fieldsToMapJsonPath = [];
    //     if ($rootScope.pCcurrentMetadata.fieldsToMap  == null)
    //         $rootScope.pCcurrentMetadata.fieldsToMap  = [];
    //     if (chk) {
    //         $rootScope.pCcurrentMetadata.fieldsToMapJsonPath.push(obj.jsonPath);
    //         $rootScope.pCcurrentMetadata.fieldsToMap.push(obj.metaDataFieldName);
    //     }
    //     else {
    //         $rootScope.pCcurrentMetadata.fieldsToMapJsonPath.splice($rootScope.pCcurrentMetadata.fieldsToMapJsonPath.indexOf(obj.jsonPath), 1);
    //         $rootScope.pCcurrentMetadata.fieldsToMap.splice($rootScope.pCcurrentMetadata.fieldsToMap.indexOf(obj.metaDataFieldName), 1);
    //     }
        
    // }
    $scope.selectMetadataFieldMappingTags = function (obj, chk,index) {
        if ($rootScope.pCcurrentMetadata.fieldsToMap  == null)
            $rootScope.pCcurrentMetadata.fieldsToMap  = [];
        if (chk) {
            $rootScope.pCcurrentMetadata.fieldsToMap.push(obj.metaDataFieldName);
        }
        else {
            $rootScope.pCcurrentMetadata.fieldsToMap.splice($rootScope.pCcurrentMetadata.fieldsToMap.indexOf(obj.metaDataFieldName), 1);
        }
    }
    $scope.customTemDataRest = function () {

        if ($rootScope.pCdata.csvTempFieldDetails != null && $rootScope.pCdata.csvTempFieldDetails.length > 0)
            angular.forEach($rootScope.pCdata.csvTempFieldDetails, function (obj) {
                if ($rootScope.pCdata.csvFieldDetails == null)
                    $rootScope.pCdata.csvFieldDetails = [];
                $rootScope.pCdata.csvFieldDetails.push(obj);
            })
    }
    $scope.setwithSeperatorSelected = function (val) {
        $rootScope.pCcurrentMetadata.withSeperator = val.value;
        $rootScope.pCcurrentMetadata.fieldsToConcat = null;
        $rootScope.pCcurrentMetadata.joinBy = null;
        $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath = null;
        angular.forEach($rootScope.duplicateMetaList,function(obj){
            if(obj.selected == true)
                obj.selected = false;
        })
    }

    $scope.setJoinBySelected = function (val) {
        $rootScope.pCcurrentMetadata.joinBy = val.value;
    }
    $scope.pCcondionMetadataModal = function (metadata, index, val) {
        $scope.conditionAlreadySelected = false;
        $rootScope.currentIndexForMetadata = index;
        $rootScope.pCcurrentMetadata = angular.copy(metadata);
        $rootScope.currentMetadataConditionSelected = null;
        if ($rootScope.pCcurrentMetadata.fieldsToMap  == null){
        $rootScope.pCcurrentMetadata.fieldsToMap  = [];
        }
        if(!$rootScope.pCcurrentMetadata.fieldType){
            $rootScope.pCcurrentMetadata.fieldType =$rootScope.duplicateMetaList[$rootScope.duplicateMetaList
                .findIndex(obj => obj['metaDataFieldName'] === metadata.metaDataFieldName)].fieldType;
        }


        // if($rootScope.metadataMappingIndex == $rootScope.currentIndexForMetadata){
        //     if($rootScope.pCcurrentMetadata.fieldsToMap != null){
        //         angular.forEach($rootScope.metadataFieldMapping,function(data){
        //             data.fieldDisplayName_index = true;
        //         });
        //     }
        // }
        // else{
        //     angular.forEach($rootScope.metadataFieldMapping,function(data){
        //         data.fieldDisplayName_index = false;
        //     }); 
        // }
        // if($rootScope.pCdata.transformFieldList != null && $rootScope.pCdata.transformFieldList.length > 0){
        //     angular.forEach($rootScope.pCdata.transformFieldList,function(obj){
        //         if($rootScope.pCcurrentMetadata.metaDataFieldName == obj.metaDataFieldName)
        //             $rootScope.pCcurrentMetadata = {...$rootScope.pCcurrentMetadata, ...obj};
        //     })
        // }    
    }

    $rootScope.pCRemoveTransformCondition = function(data){
        // console.log(data.metaDataFieldName);
        // var a = $rootScope.pCdata.transformFieldList.length;
        if($rootScope.pCdata.transformFieldList){
        while($rootScope.pCdata.transformFieldList.findIndex(obj => obj['metaDataFieldName'] === data.metaDataFieldName) != -1){
        $rootScope.pCdata.transformFieldList.splice($rootScope.pCdata.transformFieldList.findIndex(obj => obj['metaDataFieldName'] === data.metaDataFieldName), 1);
        }
    }

    }

    $scope.addLookUp = function (index, opt, obj) {

        //   if(opt=='REPLACE'){
        $rootScope.pCcurrentMetadata.lookUp[''] = '';
        //obj.lookUp['']='';
        /*       $scope.countLookUpForReplace++;
           }
           if(opt=='CONCAT_PREFIX'){
               obj.lookupListConcatPre.push(val);
               $scope.countLookUpForConcatPre++;
           }
           if(opt=='CONCAT_SUFFIX'){
               obj.lookupListConcatSuf.push(val);
               $scope.countLookUpForConcatSuf++;
           }
       */
    }


    $scope.removeLookUp = function (index, key, obj, value, objj) {

        var elem = document.getElementById(index + '_lookupkey_' + obj).value;
        //   var a=$rootScope.pCdata.transformFieldList[parentindex].lookUp.indexOf();
        delete $rootScope.pCcurrentMetadata.lookUp[elem];
        var newLookup = new Map();
        newLookup = $rootScope.pCcurrentMetadata.lookUp;
        $rootScope.pCcurrentMetadata.lookUp = newLookup;
        //        console.log($rootScope.pCdata.transformFieldList[parentindex].lookUp);
    }

    $scope.changeKeyValue = (index, key, value, fieldName) => {
        //    delete $rootScope.pCdata.transformFieldList[index].lookUp['']; 
        //    $rootScope.pCdata.transformFieldList[index].lookUp[key] = value;
        var key = document.getElementById(index + '_lookupkey_' + fieldName).value;
        var val = document.getElementById(index + '_lookupval_' + fieldName).value;

        if (key == '') {
            //delete $rootScope.pCcurrentMetadata.lookUp[key];                        
            $rootScope.pCcurrentMetadata.lookUp = { '': '' };
            document.getElementById(index + '_lookupval_' + fieldName).value = '';
        }
        else {
            $rootScope.pCcurrentMetadata.lookUp[key] = val;

            delete $rootScope.pCcurrentMetadata.lookUp[''];
        }
        //    console.log($rootScope.pCdata.transformFieldList[parentindex].lookUp);
    }

    $scope.pCconditionCheckFunction = function(){
        var returnFlag = false;
        if($rootScope.pCcurrentMetadata != null){
            if($rootScope.pCcurrentMetadata.operation == 'JOIN'){
               if($rootScope.pCcurrentMetadata.joinBy == null)
                    returnFlag = true;
            }
            if($rootScope.pCcurrentMetadata.operation == 'JOIN_METADATA'){
               if(($rootScope.pCcurrentMetadata.withSeperator == true && $rootScope.pCcurrentMetadata.joinBy == null)
                || $rootScope.pCcurrentMetadata.fieldsToConcat ==null || $rootScope.pCcurrentMetadata.fieldsToConcat.length < 2)
                    returnFlag = true;
            }
            if($rootScope.pCcurrentMetadata.operation == 'REPLACE'){
               if($rootScope.pCcurrentMetadata.onCondition == null || 
                (angular.equals({'':''},$rootScope.pCcurrentMetadata.lookUp)))
                    returnFlag = true;
            }
            if($rootScope.pCcurrentMetadata.operation == 'Date_format'){
               if($rootScope.pCcurrentMetadata.dateFormat == null)
                    returnFlag = true;
            }
            if($rootScope.pCcurrentMetadata.operation == 'Lookup_mapping'){
                if($rootScope.metadataMappingLookupType == 'New lookup')
                    if($rootScope.pCcurrentMetadata.fieldsToMap == null || $rootScope.pCcurrentMetadata.mappingFilePath == null || $rootScope.pCcurrentMetadata.lookupName == null)
                        returnFlag = true;
                if($rootScope.metadataMappingLookupType == 'Existing lookup')   //mappingFilePath     
                    if($rootScope.pCcurrentMetadata.mappingFilePath == null || $rootScope.pCcurrentMetadata.lookupName == null)
                        returnFlag = true;    
            }
            if($rootScope.pCcurrentMetadata.operation == 'Custom_fields'){
                 if($rootScope.pCcurrentMetadata.customFieldsString == null || $rootScope.pCcurrentMetadata.customFieldsString.length < 1)
                    returnFlag = true;
                else if($rootScope.pCcurrentMetadata.customFieldsString.length > 0){
                    angular.forEach($rootScope.pCcurrentMetadata.customFieldsString,function(obj){
                        if(obj.operation != 'Value')
                            {
                                if(obj.metaDataFieldName == null || obj.operation == null || obj.operation == '')
                                    returnFlag = true;
                            }
                    })
                }
                //var empty = $filter('filter')($rootScope.pCcurrentMetadata.customFieldsString, function(data){ return data.operation == ''});
                //console.log(empty.length)
            }
        }
            return returnFlag;
    }

     $scope.clearpCCurrentMetadata = function(){
         $rootScope.pCcurrentMetadata.joinBy = null;
         if($rootScope.pCcurrentMetadata.lookUp){
                // $rootScope.pCcurrentMetadata.lookUp['DEFAULT'] = null;
                $rootScope.pCcurrentMetadata.lookUp = null
         }
         $rootScope.pCcurrentMetadata.operation = null;
         $rootScope.pCcurrentMetadata.joinBy = null;
         $rootScope.pCcurrentMetadata.withSeperator = null;
         $rootScope.pCcurrentMetadata.fieldsToConcat = null;
         $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath = null;
         $rootScope.pCcurrentMetadata.fieldsToMapJsonPath = null;
         $rootScope.pCcurrentMetadata.fieldsToMap = null;
         $rootScope.pCcurrentMetadata.arithmeticExpression = null; 
         $rootScope.pCcurrentMetadata.onCondition = null;
         $rootScope.pCcurrentMetadata.dateFormat = null;
         $rootScope.pCcurrentMetadata.lookupName = null;
         $rootScope.metadataMappingLookupType = null;
         $rootScope.pCcurrentMetadata.mappingFilePath = null;
         $rootScope.pCcurrentMetadata.startIndex = null;
         $rootScope.pCcurrentMetadata.endIndex = null;
         $rootScope.pCcurrentMetadata.substituteText = null;
         angular.forEach($rootScope.duplicateMetaList,function(obj){
            if(obj.selected)
                obj.selected = false;
         })
         angular.forEach($rootScope.metadataFieldMapping,function(obj){
            if(obj.selected)
                obj.selected = false;
            });

    }

    $scope.addFieldToCustomList = function(chk){
        if(chk == 'Field'){    
            if(!$rootScope.pCcurrentMetadata.customFieldsString)
                $rootScope.pCcurrentMetadata.customFieldsString = [];
            $rootScope.pCcurrentMetadata.customFieldsString.push({
                "operation":""
            })
        }
        else if(chk == 'Default'){    
            if(!$rootScope.pCcurrentMetadata.customFieldsString)
                $rootScope.pCcurrentMetadata.customFieldsString = [];
            $rootScope.pCcurrentMetadata.customFieldsString.push({
                "operation":"Value"
            })
        }    
    }
    $rootScope.errorMetaDataFieldName = [];
    $scope.setCustomFieldName = function(obj,index){
        $rootScope.pCcurrentMetadata.customFieldsString[index].metaDataFieldName = obj.metaDataFieldName;
        $rootScope.errorMetaDataFieldName[index] = false;
    }
    $scope.setCustomFieldOperation = function(obj,index){
        if($rootScope.pCcurrentMetadata.customFieldsString[index].metaDataFieldName != undefined){
        $rootScope.pCcurrentMetadata.customFieldsString[index].operation = obj.value;
        $rootScope.errorMetaDataFieldName[index] = false;
        }
        else{
            $rootScope.errorMetaDataFieldName[index] = true;
        }
    }
    $scope.removeCustomCondition = function(index){
        $rootScope.pCcurrentMetadata.customFieldsString.splice(index,1)
    }

    $scope.pCconditionForMetadataTags = function (slct, type) {
        $scope.conditionAlreadySelected = false;
        $scope.xlsUploadButton = true;
        if (type == 'Excel' || type == 'excel') {
            $scope.clearpCCurrentMetadata();

            if($rootScope.pCdata.transformFieldList){
                angular.forEach($rootScope.pCdata.transformFieldList,function(obj){
                    if($rootScope.pCcurrentMetadata.metaDataFieldName == obj.metaDataFieldName 
                        && obj.operation == slct.value){
                        $rootScope.pCcurrentMetadata = {...$rootScope.pCcurrentMetadata, ...obj};
                        if($rootScope.pCcurrentMetadata.operation == 'JOIN_METADATA'){
                            angular.forEach($rootScope.duplicateMetaList,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToConcat){
                                    if($rootScope.pCcurrentMetadata.fieldsToConcat.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                         else if($rootScope.pCcurrentMetadata.operation == 'Lookup_mapping'){
                            angular.forEach($rootScope.metadataFieldMapping,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToMap){
                                    if($rootScope.pCcurrentMetadata.fieldsToMap.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                        }
                   
                })
            }
            

            if ($rootScope.pCcurrentMetadata.condition == null)
                $rootScope.pCcurrentMetadata.condition = [];
            if (!$rootScope.pCdata.excelFieldDetails[$rootScope.currentIndexForMetadata].condition)
                $rootScope.pCdata.excelFieldDetails[$rootScope.currentIndexForMetadata].condition = [];
            if ($rootScope.pCcurrentMetadata.condition.findIndex(obj => obj['value'] === slct.value) == -1)
                $rootScope.pCdata.excelFieldDetails[$rootScope.currentIndexForMetadata].condition.push({ 'value': slct.value, 'type': slct.type });
            
            $rootScope.pCcurrentMetadata.operation = slct.value;
            
            //$rootScope.pCcurrentMetadata.lookUp = { '': '' };
            $rootScope.currentMetadataConditionSelected = slct.type;
        }
        if (type == 'CSV') {
            $scope.clearpCCurrentMetadata();

            if($rootScope.pCdata.transformFieldList){
                angular.forEach($rootScope.pCdata.transformFieldList,function(obj){
                    if($rootScope.pCcurrentMetadata.metaDataFieldName == obj.metaDataFieldName 
                        && obj.operation == slct.value){
                        $rootScope.pCcurrentMetadata = {...$rootScope.pCcurrentMetadata,...obj};
                        if($rootScope.pCcurrentMetadata.operation == 'JOIN_METADATA'){
                            angular.forEach($rootScope.duplicateMetaList,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToConcat){
                                    if($rootScope.pCcurrentMetadata.fieldsToConcat.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                         else if($rootScope.pCcurrentMetadata.operation == 'Lookup_mapping'){
                            angular.forEach($rootScope.metadataFieldMapping,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToMap){
                                    if($rootScope.pCcurrentMetadata.fieldsToMap.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                        }
                   
                })
            }
            

            if ($rootScope.pCcurrentMetadata.condition == null)
                $rootScope.pCcurrentMetadata.condition = [];
            if (!$rootScope.pCdata.csvFieldDetails[$rootScope.currentIndexForMetadata].condition)
                $rootScope.pCdata.csvFieldDetails[$rootScope.currentIndexForMetadata].condition = [];
            if ($rootScope.pCcurrentMetadata.condition.findIndex(obj => obj['value'] === slct.value) == -1)
                $rootScope.pCdata.csvFieldDetails[$rootScope.currentIndexForMetadata].condition.push({ 'value': slct.value, 'type': slct.type });
            $rootScope.pCcurrentMetadata.operation = slct.value;
          
            //$rootScope.pCcurrentMetadata.lookUp = { '': '' };
            $rootScope.currentMetadataConditionSelected = slct.type;
        }
        if (type == 'ONIX' || type == 'onix') {
            $scope.clearpCCurrentMetadata();

            if($rootScope.pCdata.transformFieldList){
                angular.forEach($rootScope.pCdata.transformFieldList,function(obj){
                    if($rootScope.pCcurrentMetadata.metaDataFieldName == obj.metaDataFieldName 
                        && obj.operation == slct.value){
                        $rootScope.pCcurrentMetadata = {...$rootScope.pCcurrentMetadata,...obj};
                        if($rootScope.pCcurrentMetadata.operation == 'JOIN_METADATA'){
                            angular.forEach($rootScope.duplicateMetaList,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToConcat){
                                    if($rootScope.pCcurrentMetadata.fieldsToConcat.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                         else if($rootScope.pCcurrentMetadata.operation == 'Lookup_mapping'){
                            angular.forEach($rootScope.metadataFieldMapping,function(obj){
                                if($rootScope.pCcurrentMetadata.fieldsToMap){
                                    if($rootScope.pCcurrentMetadata.fieldsToMap.indexOf(obj.metaDataFieldName) != -1)
                                        obj.selected = true;
                                }

                            })
                         }
                        }
                })
            }
                

            if ($rootScope.pCcurrentMetadata.condition == null)
                $rootScope.pCcurrentMetadata.condition = [];
            if ($rootScope.pCcurrentMetadata.condition.findIndex(obj => obj['value'] === slct.value) == -1)
                $rootScope.pCcurrentMetadata.operation = slct.value;
            $rootScope.currentMetadataConditionSelected = slct.type;

            }
        
    }

    $scope.cpRemoveMetadataCondition = function (rmv, field) {
        $scope.conditionAlreadySelected = false;
        $rootScope.pCdata.transformFieldList.splice($rootScope.pCdata.transformFieldList.indexOf(field), 1)
    }

    $scope.pCsetTransformCondition = function () {
        if ($rootScope.pCdata.transformFieldList == null)
            $rootScope.pCdata.transformFieldList = [];
        $scope.conditionAlreadySelected = false;
        angular.forEach($rootScope.pCdata.transformFieldList,function(obj){
            if(obj.metaDataFieldName == $rootScope.pCcurrentMetadata.metaDataFieldName 
                && obj.operation == $rootScope.pCcurrentMetadata.operation){
                $scope.conditionAlreadySelected = true;
            }
            if(obj.metaDataFieldName == $rootScope.pCcurrentMetadata.metaDataFieldName ){
                if(obj.operation == "Uppercase" || obj.operation == "Lowercase"){
                    if($rootScope.pCcurrentMetadata.operation =="Uppercase" || $rootScope.pCcurrentMetadata.operation =="Lowercase")
                        $scope.conditionAlreadySelected = true;  
                    else
                        $scope.conditionAlreadySelected = false;
                }
                else if(obj.operation == "CONCAT_PREFIX" || obj.operation == "CONCAT_SUFFIX"){
                    if($rootScope.pCcurrentMetadata.operation =="CONCAT_PREFIX" || $rootScope.pCcurrentMetadata.operation =="CONCAT_SUFFIX")
                        $scope.conditionAlreadySelected = true;  
                    else
                        $scope.conditionAlreadySelected = false;
                }
            }
        })
        if(!$scope.conditionAlreadySelected){
            if ($rootScope.pCcurrentMetadata.operation == 'JOIN')
                $rootScope.pCdata.transformFieldList.push({
                    'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                    'operation': $rootScope.pCcurrentMetadata.operation,
                    'joinBy': $rootScope.pCcurrentMetadata.joinBy,

            })
        else if ($rootScope.pCcurrentMetadata.operation == 'JOIN_METADATA')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                //   'lookUp':$rootScope.pCcurrentMetadata.lookUp,
                'joinBy': $rootScope.pCcurrentMetadata.joinBy,
                'dateFormat': $rootScope.pCcurrentMetadata.dateFormat,
                'withSeperator': $rootScope.pCcurrentMetadata.withSeperator,
                'fieldsToConcat': $rootScope.pCcurrentMetadata.fieldsToConcat,
                'fieldsToConcatJsonPath': $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'Date_format')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                'dateFormat': $rootScope.pCcurrentMetadata.dateFormat,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'Uppercase')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                // 'dateFormat':$rootScope.pCcurrentMetadata.dateFormat,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'CONCAT_PREFIX')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                'lookUp': $rootScope.pCcurrentMetadata.lookUp,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'CONCAT_SUFFIX')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                'lookUp': $rootScope.pCcurrentMetadata.lookUp,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'Lowercase')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                //'dateFormat':$rootScope.pCcurrentMetadata.dateFormat,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'Arithmetic')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                "fieldsToConcat": [$rootScope.pCcurrentMetadata.metaDataFieldName],
                'arithmeticExpression': $rootScope.pCcurrentMetadata.arithmeticExpression,
                //'dateFormat':$rootScope.pCcurrentMetadata.dateFormat,
            })
        else if ($rootScope.pCcurrentMetadata.operation == 'Mid')
        $rootScope.pCdata.transformFieldList.push({
            'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
            'operation': $rootScope.pCcurrentMetadata.operation,
            'startIndex': $rootScope.pCcurrentMetadata.startIndex,
            'endIndex':$rootScope.pCcurrentMetadata.endIndex
        })
        else if ($rootScope.pCcurrentMetadata.operation == 'Left')
        $rootScope.pCdata.transformFieldList.push({
            'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
            'operation': $rootScope.pCcurrentMetadata.operation,
            'endIndex':$rootScope.pCcurrentMetadata.endIndex
        })     
        else if ($rootScope.pCcurrentMetadata.operation == 'Right')
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                'startIndex': $rootScope.pCcurrentMetadata.startIndex,
         })
        else if ($rootScope.pCcurrentMetadata.operation == 'Substitute')
        $rootScope.pCdata.transformFieldList.push({
            'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
            'operation': $rootScope.pCcurrentMetadata.operation,
            'startIndex': $rootScope.pCcurrentMetadata.startIndex,
            'endIndex':$rootScope.pCcurrentMetadata.endIndex,
            'substituteText' : $rootScope.pCcurrentMetadata.substituteText
        })
        else if ($rootScope.pCcurrentMetadata.operation == 'Reverse')
        $rootScope.pCdata.transformFieldList.push({
            'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
            'operation': $rootScope.pCcurrentMetadata.operation,
        })     
        else if ($rootScope.pCcurrentMetadata.operation == 'Custom_fields')
        $rootScope.pCdata.transformFieldList.push({
            'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
            'operation': $rootScope.pCcurrentMetadata.operation,
            'customFieldsString' : $rootScope.pCcurrentMetadata.customFieldsString
        })  
        else if ($rootScope.pCcurrentMetadata.operation == 'Lookup_mapping'){
            
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                "fieldsToMap": $rootScope.pCcurrentMetadata.fieldsToMap,
                "fieldsToMapJsonPath":$rootScope.pCcurrentMetadata.fieldsToMapJsonPath,
                'sheetName' : $rootScope.pCcurrentMetadata.sheetName,
                'sheetNames' : $rootScope.pCcurrentMetadata.sheetNames,
                'lookupName' : $rootScope.pCcurrentMetadata.lookupName,
                'mappingFilePath' : $rootScope.pCcurrentMetadata.mappingFilePath
                
                //'dateFormat':$rootScope.pCcurrentMetadata.dateFormat,
            })
            var condition = true;
      /*      angular.forEach($rootScope.lookUpNameandPath,function(obj){
                if($rootScope.pCcurrentMetadata.lookupName == obj.lookupName)
                    condition = false;
            })
      */      if(condition == true){
                 $http({
                    method: 'POST',
                    url: '/readLookupExcel',
                    data: {
                        userId  :  $rootScope.loggedUser.userId,
                        filePath :  $rootScope.pCcurrentMetadata.mappingFilePath,
                        partnerId : $rootScope.pCdata.partnerId,
                        fieldsToMap : $rootScope.pCcurrentMetadata.fieldsToMap,
                        sheetName : $rootScope.pCcurrentMetadata.sheetName,
                        lookupName : $rootScope.pCcurrentMetadata.lookupName
                    }
    
                })
                    .then(function (response) {
                        if (response.data.code == '200') {
                            $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                            $rootScope.partnerConfigSuccessMsg = "Lookup data successfully stored";
                            $scope.getAllLookupNames();
                            setTimeout(function () {
                                $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                                $rootScope.$apply();
                            }, $rootScope.alertTimeoutInterval)
                         //   angular.element('#createButtonForgds').addClass('disabled');
                         //   $location.url('/partner-configuration');
                        }
                        else{
                            $rootScope.msg.showPartnerConfigErrorMsg = true;
                            $rootScope.partnerConfigErrorMsg = "Error in storing lookup data";
                            $scope.getAllLookupNames();
                            setTimeout(function () {
                                $rootScope.msg.showPartnerConfigErrorMsg = false;
                                $rootScope.$apply();
                            }, $rootScope.alertTimeoutInterval)
                        }
                    });
                }
        }
        
        
        else
            $rootScope.pCdata.transformFieldList.push({
                'metaDataFieldName': $rootScope.pCcurrentMetadata.metaDataFieldName,
                'operation': $rootScope.pCcurrentMetadata.operation,
                'lookUp': $rootScope.pCcurrentMetadata.lookUp,
                'joinBy': $rootScope.pCcurrentMetadata.joinBy,
                'dateFormat': $rootScope.pCcurrentMetadata.dateFormat,
                'withSeperator': $rootScope.pCcurrentMetadata.withSeperator,
                'fieldsToConcat': $rootScope.pCcurrentMetadata.fieldsToConcat,
                'fieldsToConcatJsonPath': $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath
            })
    }
}
    $scope.customTemDataRestExcel = function (type) {
        if (type == 'Excel' || type == 'excel') {
            if ($rootScope.pCdata.excelTempFieldDetails != null && $rootScope.pCdata.excelTempFieldDetails.length > 0)
                angular.forEach($rootScope.pCdata.excelTempFieldDetails, function (obj) {
                    if ($rootScope.pCdata.excelFieldDetails == null)
                        $rootScope.pCdata.excelFieldDetails = [];
                    $rootScope.pCdata.excelFieldDetails.push(obj);
                })
            $rootScope.pCdata.excelTempFieldDetails = [];
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (obj.selected == true)
                    obj.selected = false;
            })
        }
        if (type == 'CSV') {
            if ($rootScope.pCdata.csvTempFieldDetails != null && $rootScope.pCdata.csvTempFieldDetails.length > 0)
                angular.forEach($rootScope.pCdata.csvTempFieldDetails, function (obj) {
                    if ($rootScope.pCdata.csvFieldDetails == null)
                        $rootScope.pCdata.csvFieldDetails = [];
                    $rootScope.pCdata.csvFieldDetails.push(obj);
                })
            $rootScope.pCdata.csvTempFieldDetails = [];
            angular.forEach($rootScope.duplicateMetaListForExcel, function (obj) {
                if (obj.selected == true)
                    obj.selected = false;
            })
        }
    }

    $scope.selectMetadataForJoinTags = function (obj, chk) {
        if ($rootScope.pCcurrentMetadata.fieldsToConcatJsonPath == null)
            $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath = [];
        if ($rootScope.pCcurrentMetadata.fieldsToConcat == null)
            $rootScope.pCcurrentMetadata.fieldsToConcat = [];
        if (chk) {
            $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath.push(obj.jsonPath);
            $rootScope.pCcurrentMetadata.fieldsToConcat.push(obj.metaDataFieldName);
        }
        else {
            $rootScope.pCcurrentMetadata.fieldsToConcatJsonPath.splice($rootScope.pCcurrentMetadata.fieldsToConcatJsonPath.indexOf(obj.jsonPath), 1);
            $rootScope.pCcurrentMetadata.fieldsToConcat.splice($rootScope.pCcurrentMetadata.fieldsToConcat.indexOf(obj.metaDataFieldName), 1);
        }
    }

    $scope.setwithReplaceSelected = function (obj) {
        $rootScope.pCcurrentMetadata.onCondition = obj.value;
        if(obj.value == 'Word')
            $rootScope.pCcurrentMetadata.lookUp = { '': '' };
        else
            $rootScope.pCcurrentMetadata.lookUp = {};

    }

    $scope.setDateFormatSelected = function (obj) {
        $rootScope.pCcurrentMetadata.dateFormat = obj.value;

    }

    $scope.excelFieldTags = function (obj, chk) {
        if (chk) {
            if ($rootScope.pCdata.excelFieldDetails == null) {
                $rootScope.pCdata.excelFieldDetails = [];
            }
            if (obj.fieldType != 'Date') {
                //$rootScope.pCExcelFieldList.push(obj);
                $rootScope.pCdata.excelFieldDetails.push({
                    'metaDataFieldName': obj.metaDataFieldName,
                    'isActive': false,
                })
            }
            else {
                $rootScope.pCdata.excelFieldDetails.push({
                    'metaDataFieldName': obj.metaDataFieldName,
                    'isActive': false,
                    'fieldType': 'Date',
                    'dateFormat': ''
                })
            }

        }
        else {
            /*     angular.forEach($rootScope.pCdata.excelFieldDetails,function(value,key){
                     if(value.metaDataFieldName==obj.metaDataFieldName){
                         $rootScope.pCdata.excelFieldDetails.splice(key,1);
                         
                     }
                 })
             */
            $rootScope.pCdata.excelFieldDetails
                .splice($rootScope.pCdata.excelFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
            //   obj.selected=false;                  

            /*   $rootScope.pCdata.excelFieldDetails
               .splice($rootScope.pCdata.excelFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName),1); 
               $rootScope.pCExcelFieldList.splice($rootScope.pCExcelFieldList.indexOf(obj),1)
             */
            // obj.isMetaActiveField=false;
        }
    }

    $scope.csvFieldTags = function (obj, chk) {
        if (chk) {
            if ($rootScope.pCdata.csvFieldDetails == null) {
                $rootScope.pCdata.csvFieldDetails = [];
            }
            if (obj.fieldType != 'Date') {
                //$rootScope.pCExcelFieldList.push(obj);
                $rootScope.pCdata.csvFieldDetails.push({
                    'metaDataFieldName': obj.metaDataFieldName,
                    'isActive': false,
                })
            }
            else {
                $rootScope.pCdata.csvFieldDetails.push({
                    'metaDataFieldName': obj.metaDataFieldName,
                    'isActive': false,
                    'fieldType': 'Date',
                    'dateFormat': ''
                })
            }
        }
        else {
            /*     angular.forEach($rootScope.pCdata.excelFieldDetails,function(value,key){
                     if(value.metaDataFieldName==obj.metaDataFieldName){
                         $rootScope.pCdata.excelFieldDetails.splice(key,1);
                         
                     }
                 })
             */
            $rootScope.pCdata.csvFieldDetails
                .splice($rootScope.pCdata.csvFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName), 1);
            //   obj.selected=false;                  

            /*   $rootScope.pCdata.excelFieldDetails
               .splice($rootScope.pCdata.excelFieldDetails.findIndex(data => data['metaDataFieldName'] === obj.metaDataFieldName),1); 
               $rootScope.pCExcelFieldList.splice($rootScope.pCExcelFieldList.indexOf(obj),1)
             */
            // obj.isMetaActiveField=false;
        }
    }

    $scope.cloneCSVField = function (index, obj) {
      //  obj.isMetaActiveField=false;
        //$rootScope.pCExcelFieldList.push(obj);
  /*      $rootScope.pCdata.excelFieldDetails[index+1]={
            'metaDataFieldName':obj.metaDataFieldName,
            'isActive':false
        };
  */      $rootScope.pCdata.csvFieldDetails.splice(index + 1, 0, {
            'metaDataFieldName': obj.metaDataFieldName,
            'isActive': false,
            'dateFormat': obj.dateFormat
        });
        //var a=$rootScope.pCExcelFieldList.lastIndexOf(obj);
        //$rootScope.pCExcelFieldList[a].count=1;
        //console.log($rootScope.pCExcelFieldList);
    }

    $scope.cloneExcelField = function (index, obj) {
      //  obj.isMetaActiveField=false;
        //$rootScope.pCExcelFieldList.push(obj);
  /*      $rootScope.pCdata.excelFieldDetails[index+1]={
            'metaDataFieldName':obj.metaDataFieldName,
            'isActive':false
        };
  */      $rootScope.pCdata.excelFieldDetails.splice(index + 1, 0, {
            'metaDataFieldName': obj.metaDataFieldName,
            'isActive': false,
            'dateFormat': obj.dateFormat
        });
        //var a=$rootScope.pCExcelFieldList.lastIndexOf(obj);
        //$rootScope.pCExcelFieldList[a].count=1;
        //console.log($rootScope.pCExcelFieldList);
    }

    $scope.excludeFieldTags = function (obj, chk) {
        if (chk) {
            if ($rootScope.pCdata.excludeFieldList == null) {
                $rootScope.pCdata.excludeFieldList = [];
            }
            //   $scope.pCExcludeFieldList.push(obj.metaDataFieldName);
            $rootScope.pCdata.excludeFieldList.push(obj.metaDataFieldName);
        }
        else {
            //   $scope.pCExcludeFieldList.splice($scope.pCExcludeFieldList.indexOf(obj.metaDataFieldName),1);
            $rootScope.pCdata.excludeFieldList.splice($rootScope.pCdata.excludeFieldList.indexOf(obj.metaDataFieldName), 1);
            obj.selected = false;
        }
        $scope.refreshPartnerConfigExcludeFieldList();
    }

    $scope.pCAllFormatSelected = function (chk) {
        if (chk) {
            angular.forEach($rootScope.formats, function (data) {
                data.selected = true;
                $rootScope.formatSelectedList.push(data);
            })
        }
        else {
            angular.forEach($rootScope.formats, function (data) {
                data.selected = false;
                $rootScope.formatSelectedList.splice($rootScope.formatSelectedList.indexOf(data), 1);
            })
        }

    }

    $rootScope.removePartnerConfigFtpGroup = function (count) {
        var c;
        var elem;
        for (var b = 0; b < countForFtp; b++) {
            elem = document.getElementById("ftp_details_" + b).remove();
        }
        countForFtp--;
        var finalDivForFtp = "";
        for (var a = 0; a < countForFtp; a++) {
            /*  var divadd="<div class='row-border-box' id='ftp_details_"+a+"'>\n" +
                      "                               <label class=\"groupname\">FTP Details "+(a+1)+"</label>"+ 
      "                                               <div class=\"pull-right subgroup-add subgroup-remove\">\n" + 
      "                                                   <a href=\"javascript:;\"><div class=\"cp-metadatagrp-rmv\" ng-Click=\"removePartnerConfigFtpGroup("+countForFtp+")\"> \n" + 
      "                                                       <span class=\"path1\"></span><span class=\"path2\"></span>\n" + 
      "                                                   </div></a>\n" + 
      "                                               </div>"+
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=ftpType_"+a+" class=\"form-control\" type=\"text\" placeholder=\"Ftp Type\"/>\n" + 
                      "                                </div> \n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=protocol_"+a+" class=\"form-control\" type=\"text\" placeholder=\"Protocol\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=host_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Host\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=port_"+a+" class=\"form-control\"  type=\"number\" placeholder=\"Port\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=userName_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Username\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=password_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Password\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=ftpPath_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Ftp Path\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=connectionTimeout_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Connection timeout\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=dataTimeout_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"Data timeout\"/>\n" + 
                      "                                </div>\n" + 
                      "                                <div class='col-lg-2'>\n" + 
                      "                                    <input id=isPassive_"+a+" class=\"form-control\"  type=\"text\" placeholder=\"isPassive\"/>\n" + 
                      "                                </div>\n" + 
                      "                            </div>";
      
      */
            finalDivForFtp = divadd;
            var el = $compile(finalDivForFtp)($rootScope);
            angular.element(document.getElementById('ftpCondition')).append(el);
        }
        //   countForFtp++;
        //  document.getElementById("ftp_details_"+count).remove();
    }

    var countForFtp = 0;
    $scope.showFtps = function () {
        var finalDivForFtp = "";
        var divadd = "<div class='row-border-box' id='ftp_details_" + countForFtp + "'>\n" +
            "                               <label class=\"groupname\">FTP Details " + (countForFtp + 1) + "</label>" +
            "                                               <div class=\"pull-right subgroup-add subgroup-remove\">\n" +
            "                                                   <a href=\"javascript:;\"><div class=\"cp-metadatagrp-rmv\" ng-Click=\"removePartnerConfigFtpGroup(" + countForFtp + ")\"> \n" +
            "                                                       <span class=\"path1\"></span><span class=\"path2\"></span>\n" +
            "                                                   </div></a>\n" +
            "                                               </div>" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=ftpType_" + countForFtp + " class=\"form-control\" type=\"text\" placeholder=\"Ftp Type\"/>\n" +
            "                                </div> \n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=protocol_" + countForFtp + " class=\"form-control\" type=\"text\" placeholder=\"Protocol\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=host_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Host\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=port_" + countForFtp + " class=\"form-control\"  type=\"number\" placeholder=\"Port\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=userName_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Username\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=password_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Password\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=ftpPath_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Ftp Path\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=connectionTimeout_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Connection timeout\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=dataTimeout_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"Data timeout\"/>\n" +
            "                                </div>\n" +
            "                                <div class='col-lg-2'>\n" +
            "                                    <input id=isPassive_" + countForFtp + " class=\"form-control\"  type=\"text\" placeholder=\"isPassive\"/>\n" +
            "                                </div>\n" +
            "                            </div>";


        finalDivForFtp += divadd;
        var el = $compile(finalDivForFtp)($rootScope);
        angular.element(document.getElementById('ftpCondition')).append(el);
        countForFtp++;
    }


    $scope.setFormatNamingForFormat = function (index, metaObj, formatObj) {
        $rootScope.pCdata.coverFormat[index].fieldDisplayName = metaObj.fieldDisplayName;
        $rootScope.pCdata.coverFormat[index].formatNaming = metaObj.jsonPath;
    }
    $scope.setFormatNamingConversionForFormat = function (index, metaObj, formatObj) {
        $rootScope.pCdata.formatDetails[index].fieldDisplayName = metaObj.fieldDisplayName;
        $rootScope.pCdata.formatDetails[index].formatNaming = metaObj.jsonPath;
    }

    $scope.setEpubVersion = function (index, val) {
        $rootScope.pCcurrentFormat.ePubVersion = val;
    }
 $scope.uploadMedataMappingExcel = function(file){
    var filename = file.name;
    var index = filename.lastIndexOf(".");
    var extension = filename.substring(index, filename.length);
         
    if(extension != ".xlsx"){
        alert("Please select only xlsx files to upload");
        $rootScope.pCmetadataMappingbrowsefilesExcel={};
       }
       else{
        $rootScope.pCmetadataMappingbrowsefilesExcel = file;
        $rootScope.disableBrowseButtonForMapping = true;
        Upload.upload({
                   method : 'POST',
                   url : '/uploadxlsxTemplateForMetadataMapping',
                   data: {
                       userId  :  $rootScope.loggedUser,
                       metadataUpload :  $rootScope.pCmetadataMappingbrowsefilesExcel,
                   }
               }).then(function(response) {
                   $rootScope.pCcurrentMetadata.mappingFilePath = response.data.Path;
                   $rootScope.pCcurrentMetadata.sheetNames = response.data.sheetNames;
                //   console.log($rootScope.pCdata.excelTempate);
                   $rootScope.disableBrowseButtonForMapping = false;

              /*     $http({
                    method: 'POST',
                    url: '/savePartnerConfiguration',
                    data: {
                        userId  :  $rootScope.loggedUser,
                        metadataUpload :  $rootScope.pCmetadataMappingbrowsefilesExcel,
                        fieldsTomap : $rootScope.pCcurrentMetadata.fieldsToMap,
                        sheetName : $rootScope.pCcurrentMetadata.sheetName
                    }
    
                })
                    .then(function (response) {
                        if (response.data.code == '200') {
                            $rootScope.msg.showPartnerConfigSuccessCreateMsg = true;
                            $rootScope.partnerConfigSuccessMsg = response.data.statusMessage;
                            setTimeout(function () {
                                $rootScope.msg.showPartnerConfigSuccessCreateMsg = false;
                                $rootScope.$apply();
                            }, $rootScope.alertTimeoutInterval)
                            angular.element('#createButtonForgds').addClass('disabled');
                            $location.url('/partner-configuration');
                        }
                    });
                    */
    //                angular.forEach($rootScope.duplicateMetaListForExcel,function(obj){
    //                    if(obj.selected)
    //                        obj.selected=false;
    //    });
                   //$scope.mfiles=null;
               });
               
    }
 }

$scope.pCSelectSheetNameForLookup = function(val){
    $rootScope.pCcurrentMetadata.sheetName = val;
}
$scope.existingFileLookUp = function(file){
$rootScope.pCcurrentMetadata.mappingFilePath = file.filePath;
$rootScope.pCcurrentMetadata.lookupName = file.lookupName;
$rootScope.pCcurrentMetadata.fieldsToMap = file.fieldsToMap;

}

$scope.metadataMappingLookup = function(slct){
$rootScope.pCcurrentMetadata.lookupName = null;
$rootScope.pCcurrentMetadata.mappingFilePath = null;
$rootScope.pCcurrentMetadata.customTemplatePath = null;
  $rootScope.metadataMappingLookupType = slct;
  $rootScope.metadataMappingDownload = false;
  $filter('filter')($rootScope.metadataFieldMapping, function(data){ return data.selected = false});
  $rootScope.pCcurrentMetadata.fieldsToMap = null;
}

    $scope.formatTags = function (data, chk) {
        //  alert("dfgfg");
        //data.findIndex(obj => obj[where] === what)
        if (chk) {
            if ($rootScope.pCdata.formatDetails == null) {
                $rootScope.pCdata.formatDetails = [];
            }
            if (data.isEpubFormat) {
                $rootScope.pCdata.formatDetails.push({
                    'formatId': data.formatId,
                    'isEpubFormat': true,
                    'epubValidator': false,
                    'formatNaming': '*',
                    'compressedIfMultiple': false,
                })
            }
            else {
                $rootScope.pCdata.formatDetails.push({
                    'formatId': data.formatId,
                    'compressedIfMultiple': false,
                    'formatNaming': '*',
                })
            }
        }
        else {
            $rootScope.formats[$rootScope.formats.findIndex(obj => obj['formatId'] === data.formatId)].selected = false;
            $rootScope.pCdata.formatDetails.splice($rootScope.pCdata.formatDetails.findIndex(obj => obj['formatId'] === data.formatId), 1);
        }
        if ($rootScope.pCdata.formatDetails.length > 0)
            $rootScope.pCdata.metadataTransferMedium = $rootScope.pCdata.metadataTransferMedium;
        else {
            $rootScope.pCdata.metadataTransferMedium = 'Email';
            if (!$rootScope.pCdata.coverFormat) {
                angular.forEach($rootScope.pCFtpTypes, function (obj) {
                    if (obj.selected)
                        obj.selected = false;
                });
                $rootScope.pCdata.ftpDetails = null;
            }
        }
        /*    console.log($rootScope.formatSelectedList.findIndex(obj => obj['formatId'] === data.formatId));
            if(chk){
              $rootScope.formatSelectedList.push(data);
              data.isEpubValidator=false;
              data.selected=true;
            }  
          else{
              $rootScope.formatSelectedList.splice($rootScope.formatSelectedList.findIndex(obj => obj['formatId'] === data.formatId),1); 
              data.isEpubValidator=false;      
              data.selected=false;
          }
        */

    }

    $scope.coverformatTags = function (obj, chk) {
        //  alert("dfgfg");
        if (chk) {
            if ($rootScope.pCdata.coverFormat == null) {
                $rootScope.pCdata.coverFormat = [];
            }
            $rootScope.pCdata.coverFormat.push({
                'formatId': obj.formatId,
            })
            // $scope.coverformatSelectedList.push(obj);
        }
        else {
            $rootScope.listForCoverFormats[$rootScope.listForCoverFormats.findIndex(data => data['formatId'] === obj.formatId)].selected = false;
            //  $rootScope.pCdata.formatDetails.splice($rootScope.pCdata.formatDetails.findIndex(obj => obj['formatId'] === data.formatId),1); 
            $rootScope.pCdata.coverFormat.splice($rootScope.pCdata.coverFormat.
                findIndex(data => data['formatId'] === obj.formatId), 1);
        }
        if ($rootScope.pCdata.coverFormat.length > 0)
            $rootScope.pCdata.metadataTransferMedium = $rootScope.pCdata.metadataTransferMedium;
        else {
            $rootScope.pCdata.metadataTransferMedium = 'Email';
            if (!$rootScope.pCdata.formatDetails) {
                angular.forEach($rootScope.pCFtpTypes, function (obj) {
                    if (obj.selected)
                        obj.selected = false;
                });
                $rootScope.pCdata.ftpDetails = null;
            }
        }
    }

    $scope.setPartnerForConfiggggg = function (partner) {
        $rootScope.formatListForGdsPartner = [];

        if ($rootScope.formats != null) {
            angular.forEach($rootScope.formats, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
        }
        if ($rootScope.pCdata.formatDetails != null) {
            angular.forEach($rootScope.pCdata.formatDetails, function (obj) {
                if (obj.selected)
                    obj.selected = false;
            });
        }
        $rootScope.formats = [];
       // $rootScope.pCdata.formatDetails = null;
        $rootScope.pCdataColne.partnerId = partner.partnerId;
        $scope.partnerSelected = partner.partnerName;
        $scope.partnerIdForCreate = partner.partnerId;
        if ($rootScope.pCdata.partnerId) {
            var index = $rootScope.distColumnPartners.findIndex(data => data['partnerId'] === $rootScope.pCdata.partnerId);
            $rootScope.formatListForGdsPartner = $rootScope.distColumnPartners[index].formatId;
        }
        for (var i = 0; i < $rootScope.formatListForGdsPartner.length; i++) {
            var index = $rootScope.formatList.findIndex(data => data['formatId'] === $rootScope.formatListForGdsPartner[i]);
            if (index != -1)
                $rootScope.formats.push($rootScope.formatList[index]);
        }
        //     console.log($scope.partnerSelected);
    }

    $scope.setPartnerForConfig = function (partner) {
       $rootScope.formatListForGdsPartner = [];
       $rootScope.pCdataColne = angular.copy($rootScope.pCdata);
       if ($rootScope.formats != null) {
           angular.forEach($rootScope.formats, function (obj) {
               if (obj.selected)
                   obj.selected = false;
           });
       }
       if ($rootScope.pCdata.formatDetails != null) {
           angular.forEach($rootScope.pCdata.formatDetails, function (obj) {
               if (obj.selected)
                   obj.selected = false;
           });
       }
       $rootScope.formats = [];
      // $rootScope.pCdata.formatDetails = null;
       $rootScope.pCdataColne.partnerId = partner.partnerId;
       $scope.partnerSelected = partner.partnerName;
       $scope.partnerIdForCreate = partner.partnerId;
       if ($rootScope.pCdata.partnerId) {
           var index = $rootScope.distColumnPartners.findIndex(data => data['partnerId'] === $rootScope.pCdata.partnerId);
           $rootScope.formatListForGdsPartner = $rootScope.distColumnPartners[index].formatId;
       }
       if ($rootScope.pCdataColne.partnerId) {
           var index = $rootScope.distColumnPartners.findIndex(data => data['partnerId'] === $rootScope.pCdataColne.partnerId);
           $rootScope.formatListForGdsPartnerClone = $rootScope.distColumnPartners[index].formatId;
       }
       $rootScope.pCIneligibleFormatList = [];
       angular.forEach($rootScope.pCdata.formatDetails,function(obj){
            if($rootScope.formatListForGdsPartnerClone.indexOf(obj.formatId) == -1){
                $rootScope.pCIneligibleFormatList.push(obj.formatId);
                $rootScope.pCdataColne.formatDetails.splice($rootScope.pCdataColne.formatDetails.
                    findIndex(data => data['formatId'] === obj.formatId), 1);
            }
       })
       for (var i = 0; i < $rootScope.formatListForGdsPartner.length; i++) {
           var index = $rootScope.formatList.findIndex(data => data['formatId'] === $rootScope.formatListForGdsPartner[i]);
           if (index != -1)
               $rootScope.formats.push($rootScope.formatList[index]);
       }
       //     console.log($scope.partnerSelected);
   }

    $scope.setpConfigElementFocus = function (elem, index) {
        setTimeout(function () {
            angular.element('#' + elem).trigger('focus');
        }, 10);
    }

    $scope.setPartnerFocus = function () {
        setTimeout(function () {
            angular.element('#partnerName').trigger('focus');
        }, 10);
    }
    $scope.setFormatNamingFocus = function (obj) {
        setTimeout(function () {
            angular.element('#' + obj.formatId + '_naming').trigger('focus');
        }, 10);
    }

    $scope.setMetadataTypeFocus = function () {
        setTimeout(function () {
            angular.element('#pCmetadataType').trigger('focus');
        }, 10);
    }

    $scope.setOnixTypeFocus = function () {
        setTimeout(function () {
            angular.element('#pConixType').trigger('focus');
        }, 10);
    }
    // /pCmetadataType
    $scope.partnerConfigs = function () {
        $rootScope.showLoader($('.partner-config'), 1, 'win8_linear');
        $rootScope.showLoader($('.gds-master'), 1, 'win8_linear');
        $scope.url = $location.url();

        //var a=url.contains('create');   
        $http({
            method: 'GET',
            url: '/getAllPartnerConfig'
        }).then(function successCallback(response) {

            $scope.partnerConfigsList = response.data.data.data;
           
            //$rootScope.partnerListForGds = angular.copy($rootScope.distColumnPartners);
            $rootScope.partnerListForGds = $filter('filter')($rootScope.distColumnPartners, function (value) {
                return (value.isActive && !value.isDeleted);
            });
            angular.forEach($scope.partnerConfigsList, function (obj) {
                angular.forEach($rootScope.partnerListForGds, function (innerObj) {
                    if (obj.partnerId == innerObj.partnerId && obj._id != null)
                        $rootScope.partnerListForGds.splice($rootScope.partnerListForGds.indexOf(innerObj), 1);
                })
            });
       /*     angular.forEach($scope.partnerConfigsList,function(obj){
                angular.forEach($rootScope.distColumnPartners,function(innerObj){
                    if(obj.partnerId != innerObj.partnerId)
                        $rootScope.partnerListForGds.push(innerObj);
                })
            })
            console.log($rootScope.partnerListForGds);
       */     $rootScope.hideLoader('gds-master');
            if ($location.$$url === '/partner-configuration') {
                $timeout(function () {
                    //alert('test');
                    $rootScope.hideLoader('partner-config');
                }, 1000)
            }
            else {
                $timeout(function () {
                    //alert('test');
                    $rootScope.hideLoader('partner-config');
                }, 3600)
            }

            //   $scope.hideLoaderForUpdatePage();

        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
            //    $window.alert('Error status: ' + response.status);
        });
        $http({
            method: 'GET',
            url: '/getPartners/false/null'
        }).then(function (response){
            $rootScope.distColumnPartners = response.data.data;
        }, function errorCallback(error) {
        });
    };

    $scope.getAllLookupNames = function () {  
        $http({
            method: 'GET',
            url: '/getAllGdsLookupNames'
        }).then(function successCallback(response) {
            // if(response.data.length > 0)
            if(response.data.data.data.length > 0)            
            $rootScope.lookUpNameandPath = response.data.data.data;
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status);
        });
    };

    /* Change Password Changes - Shahid - Start */


    $('#change-ftp-password').on('shown.bs.modal', function () {
        $(this).find('input:first').focus();
    });

    $('#change-ftp-password').find('button:first').on('keydown', function (e) {
        if ($("this:focus") && (e.which == 9)) {
            e.preventDefault();
            $('#change-ftp-password').find('input:first').focus();
        }
    });

    $scope.changeFtpPasswordForm = {};

    $scope.toggleChangeFtpPasswordModal = function () {
        //$scope.changeFtpPasswordForm.currentPassword = null;
        $scope.changeFtpPasswordForm.newPassword = null;
        $scope.ChangeFtpPasswordForm.$setPristine();
        $scope.ChangeFtpPasswordForm.$setUntouched();
        //$scope.ChangeFtpPasswordForm.$error = {};
        $('#change-ftp-password').modal('toggle');
    }

    $scope.checkPageReload = function () {
        if ( $rootScope.partnerConfigEdits != 'click') {
            if ($location.$$url === '/create-new-partner-config' && localStorage.getItem('gdsSelected') != null) {
                $scope.populateConfigPartnerForEdit(JSON.parse(localStorage.getItem('gdsSelected')), localStorage.getItem('actionForGds'));
            }
            else if ($location.$$url === '/partner-configuration') {
                localStorage.removeItem('gdsSelected');
                localStorage.removeItem('actionForGds');
            }


        }

    }

    $scope.checkPageReload();
    $scope.partnerConfigs();
    $scope.getAllLookupNames();
    $scope.getPartnerGroups();

    $scope.tab = 1;
    $scope.setTab = function (newTab) {
        $scope.tab = newTab;
        if ($rootScope.pCdata.metadataType != null) {
            if ($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel') {

                // $scope.tdtab = 'Excel';
                $rootScope.pCdata.metadataType ='Excel';
                // $scope.partnerExcel('Excel');

            }
            if ($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv') {
                // $scope.tdtab = 'CSV';
                $rootScope.pCdata.metadataType ='CSV';
                //$scope.partnerCsv('CSV');
            }
            if ($rootScope.pCdata.metadataType == 'ONIX' || $rootScope.pCdata.metadataType == 'onix') {
                $scope.tdtab = 'ONIX';
                if ($rootScope.pCdata.shortTag == null || $rootScope.pCdata.shortTag == false) {
                    $scope.partnerOnixTageTypetdtab = 'Long Tag';
                }
                else {
                    $scope.partnerOnixTageTypetdtab = 'Short Tag';
                }
                if ($rootScope.pCdata.onixType == null || $rootScope.pCdata.onixType == '2.1') {
                    $rootScope.pCdata.onixType == '2.1'
                    $scope.partnerOnixVersiontdtab = '2.1';
                }
                else {
                    $scope.partnerOnixVersiontdtab = '3.0';
                }

                // $scope.partnerOnix('ONIX');

            }
            if($rootScope.pCdata.metaRefreshInterval){
                $scope.metadaRefreshIsSettdtab = $rootScope.pCdata.metaRefreshInterval;
            }   
        }
        if ($rootScope.pCdata.metadataRequired == true) {
            $scope.partnerConfigMeta = 'Switch if metadata not required';
        }
        else {
            $scope.partnerConfigMeta = 'Switch if metadata required';
        }
    };

    $scope.isSet = function (tabNum) {
        // if ($rootScope.pCdata.metadataType != null) {
        //     if ($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel') {

        //         $scope.tdtab = 'Excel';
        //         // $scope.partnerExcel('Excel');

        //     }
        //     if ($rootScope.pCdata.metadataType == 'CSV' || $rootScope.pCdata.metadataType == 'csv') {
        //         $scope.tdtab = 'CSV';
        //         //$scope.partnerCsv('CSV');
        //     }
        //     if ($rootScope.pCdata.metadataType == 'ONIX' || $rootScope.pCdata.metadataType == 'onix') {
        //         $scope.tdtab = 'ONIX';
        //         if ($rootScope.pCdata.shortTag == null || $rootScope.pCdata.shortTag == false) {
        //             $scope.partnerOnixTageTypetdtab = 'Long Tag';
        //         }
        //         else {
        //             $scope.partnerOnixTageTypetdtab = 'Short Tag';
        //         }
        //         if ($rootScope.pCdata.onixType == null || $rootScope.pCdata.onixType == '2.1') {
        //             $rootScope.pCdata.onixType == '2.1'
        //             $scope.partnerOnixVersiontdtab = '2.1';
        //         }
        //         else {
        //             $scope.partnerOnixVersiontdtab = '3.0';
        //         }


        //     }
        // }
        return $scope.tab === tabNum;


    }
    $scope.showAssetConfig = function (chk) {

        if (chk == true) {
            $rootScope.pCdata.formatDetails = [];
            $rootScope.partnerConfigShow = chk;
            $rootScope.partnerConfigAsset = 'Switch if Asset not required';
        }
        else {
            $rootScope.pCdata.formatDetails = null;
            angular.forEach($rootScope.formats,function(obj){
                if(obj.selected == true)
                    obj.selected = false;
            })
            $rootScope.partnerConfigShow = chk;
            $rootScope.partnerConfigAsset = 'Switch if Asset required';
        }
    }
   
    $rootScope.pCdata.metadataRequired = true;
    $scope.showMetaConfig = function (chk) {
        if (chk === true) {
            $scope.partnerConfigMeta = 'Switch if Metadata not required';
        }
        else {
            $scope.partnerConfigMeta = 'Switch if Metadata required';
        }
    }
    $scope.fileUploadShow = false;
    $scope.metadaRefreshDayShow = false;
    $scope.tdtab = 1;
    $scope.fileUploadShow = true;
    $scope.csvFileUploadShow = false;
    $scope.onixFileUploadShow = false;
    $scope.cPexcelTransformation = false;
    $scope.cPexcelincluded = true;
    $scope.transInculdetdtab = 2;
    // $scope.partnerExcel = function(newTab){
    //   $scope.tdtab = newTab;
    //   $scope.fileUploadShow = true;
    //   $scope.csvFileUploadShow = false;
    //   $scope.onixFileUploadShow = false;
    //   $rootScope.pCdata.metadataType = 'Excel';
    // };
    $scope.pCclearMetadataType = function(newTab){
        $rootScope.metadataSeletedTab = newTab;
        $scope.transInculdetdtab = 'Included';
        if(newTab == 'ONIX' || newTab == 'onix'){
          if(( $rootScope.pCdata.excelFieldDetails !=null && $rootScope.pCdata.excelFieldDetails.length > 0) || ($rootScope.pCdata.csvFieldDetails != null && $rootScope.pCdata.csvFieldDetails.length > 0 ) || 
          ($rootScope.pCdata.excelTempate!=null && $rootScope.pCdata.excelTempate!='') || ( $rootScope.pCdata.excelTempateRowStartAt !=null &&  $rootScope.pCdata.excelTempateRowStartAt !=''))
          angular.element('#change-metadatatype').modal('toggle');
          else
            $scope.pCpartnerSlctFileType(); 
        }
        else if(newTab == 'Excel' || newTab == 'excel'){
            if(($rootScope.pCdata.excludeFieldList != null &&  $rootScope.pCdata.excludeFieldList.length > 0) || ($rootScope.pCdata.transformFieldList !=null) || ($rootScope.pCdata.csvFieldDetails != null && $rootScope.pCdata.csvFieldDetails.length > 0 ))
            angular.element('#change-metadatatype').modal('toggle');
            else
            $scope.pCpartnerSlctFileType(); 
        }
        else if(newTab == 'CSV'){
            if(($rootScope.pCdata.excludeFieldList != null &&  $rootScope.pCdata.excludeFieldList.length > 0 ) || ($rootScope.pCdata.transformFieldList !=null) || ($rootScope.pCdata.excelFieldDetails !=null && $rootScope.pCdata.excelFieldDetails.length > 0 ) || 
            ($rootScope.pCdata.excelTempate!=null && $rootScope.pCdata.excelTempate!='') || ( $rootScope.pCdata.excelTempateRowStartAt !=null &&  $rootScope.pCdata.excelTempateRowStartAt !=''))
            angular.element('#change-metadatatype').modal('toggle');
            else
            $scope.pCpartnerSlctFileType(); 
        }
    }
    $scope.pCpartnerSlctFileType = function () {
        $scope.tdtab = $rootScope.metadataSeletedTab;
        $rootScope.pCdata.metadataType = $rootScope.metadataSeletedTab;
        if($rootScope.pCdata.metadataType == 'ONIX' || $rootScope.pCdata.metadataType == 'onix'){
            $rootScope.pCdata.onixType = '2.1';
            $rootScope.pCdata.shortTag = false;
            $scope.partnerOnixVersiontdtab = '2.1';
            $scope.partnerOnixTageTypetdtab = 'Long Tag';
        }
        if($rootScope.metadataSeletedTab=='ONIX'){
            $rootScope.pCdata.excelFieldDetails=null;
            angular.forEach($rootScope.duplicateMetaListForExcel,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });
            $rootScope.pCdata.excelTempate=null;
            $rootScope.pCdata.excelTempateRowStartAt=null;
            $rootScope.pCdata.onixType='2.1';
            $rootScope.pCdata.sheetNames=null;
            $rootScope.pCdata.csvFieldDetails=null;
            angular.forEach($rootScope.duplicateMetaListForCSV,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });
            $rootScope.pCdata.transformFieldList=null;
            angular.forEach($rootScope.duplicateMetaListForTransform,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });    
        }
        if($rootScope.metadataSeletedTab=='Excel' || $rootScope.metadataSeletedTab=='excel'){
            $rootScope.pCdata.onixType=null;
            if(!$rootScope.pCdata.excelFieldDetails)
                $rootScope.pCdata.excelFieldDetails=[]; 
            $rootScope.pCdata.shortTag=false;
            $rootScope.pCdata.csvFieldDetails=null;
            angular.forEach($rootScope.duplicateMetaListForCSV,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });

            $rootScope.pCdata.excludeFieldList=null;
            angular.forEach($rootScope.duplicateMetaListForExclude,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });

            $rootScope.pCdata.transformFieldList=null;
            angular.forEach($rootScope.duplicateMetaListForTransform,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });  
        }
        if($rootScope.metadataSeletedTab=='CSV'){
            $rootScope.pCdata.excelFieldDetails=null;
            $rootScope.pCdata.excelTempate=null;
            $rootScope.pCdata.excelTempateRowStartAt=null;
            $rootScope.pCdata.onixType=null;
            if(!$rootScope.pCdata.csvFieldDetails)
                $rootScope.pCdata.csvFieldDetails=[]; 
            $rootScope.pCdata.shortTag=false; 
            $rootScope.pCdata.excelFieldDetails=null;
            angular.forEach($rootScope.duplicateMetaListForExcel,function(obj){
                if(obj.selected)
                    obj.selected=false;
            }); 
            $rootScope.pCdata.excludeFieldList=null;
            angular.forEach($rootScope.duplicateMetaListForExclude,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });

            $rootScope.pCdata.transformFieldList=null;
            angular.forEach($rootScope.duplicateMetaListForTransform,function(obj){
                if(obj.selected)
                    obj.selected=false;
            });
        }       
    };
    //   $scope.partnerOnix = function(newTab){
    //     $scope.tdtab = newTab;
    //     $scope.fileUploadShow = false;
    //     $scope.csvFileUploadShow = false;
    //     $scope.onixFileUploadShow = true;
    //     $rootScope.pCdata.metadataType = 'ONIX';
    //   };
    $scope.tdisSet = function (tabNum) {
        return $rootScope.pCdata.metadataType === tabNum;
    };
    $scope.pCexcelActive = function (check, chk) {
        $rootScope.pCdata.excelFieldDetails[check].isActive = chk;
    }
    // $scope.partnerConfigTransformation = function(transformation){
    //     $scope.transInculdetdtab = transformation;
    //     $scope.cPexcelTransformation = true;
    //     $scope.cPexcelincluded = false;
    // }
    $scope.transInculdetdtab = 'Included';
    $scope.pCtransformationType = function (newTab) {
        $scope.transInculdetdtab = newTab;
        // $scope.cPexcelTransformation = false;
        // $scope.cPexcelincluded = true;

    }
    $scope.transInculdeIsSet = function (tabNum) {
        return $scope.transInculdetdtab === tabNum;
    };
    $scope.metadaRefreshDaily = function (newTab) {
        $scope.metadaRefreshIsSettdtab = newTab;
        $scope.metadaRefreshDayShow = false;
        $scope.metadaRefreshMonthShow = false;
        $rootScope.pCdata.metaRefreshInterval = 1;
    }
    $scope.metadaRefreshWeekly = function (newTab) {
        $scope.metadaRefreshDayShow = true;
        $scope.metadaRefreshMonthShow = false;
        $scope.metadaRefreshIsSettdtab = newTab;
        $rootScope.pCdata.metaRefreshInterval = 7;
    }
    $scope.metadaRefreshMonthly = function (newTab) {
        $scope.metadaRefreshIsSettdtab = newTab;
        $scope.metadaRefreshDayShow = false;
        $scope.metadaRefreshMonthShow = true;
        $rootScope.pCdata.metaRefreshInterval = 30;
    }
    $scope.metadaRefreshIsSet = function (tabNum) {
        return $scope.metadaRefreshIsSettdtab === tabNum;
    };
    $scope.metadataREfreshDaySlct = function (newTab) {
        $scope.metadaRefreshDayIsSettdtab = newTab;
    }
    $scope.metadaRefreshDayIsSet = function (tabNum) {
        return $scope.metadaRefreshDayIsSettdtab === tabNum;
    };

    $scope.partnerOnixVersion = function (newTab) {
        // $scope.partnerOnixVersiontdtab = newTab;
        // $rootScope.pCdata.onixType = newTab;
        if (newTab == '2.1') {
            $rootScope.pCdata.onixType = '2.1';
             $scope.partnerOnixVersiontdtab = '2.1';
        }
        else {
            $rootScope.pCdata.onixType = '3.0';
             $scope.partnerOnixVersiontdtab = '3.0';
        }


    }
    $scope.partnerOnixVersionIsSet = function (tabNum) {
        return $rootScope.pCdata.onixType == tabNum;
    };
    $scope.partnerOnixTageType = function (newTab) {
        if (newTab == 'Short Tag') {
            $rootScope.pCdata.shortTag = true;
            $scope.partnerOnixTageTypetdtab = 'Short Tag';
        }
        else {
            $rootScope.pCdata.shortTag = false;
            $scope.partnerOnixTageTypetdtab = 'Long Tag';
        }

    }
    $scope.partnerOnixTageIsSet = function (tabNum) {
        return $scope.partnerOnixTageTypetdtab === tabNum;
    };
    $scope.onixTransformation = function (newTab) {
        $scope.onixTransformationtdtab = newTab;
    }
    $scope.onixConfigIncluded = function (newTab) {
        $scope.onixTransformationtdtab = newTab;
    }
    $scope.onixConfigIncluded = function (newTab) {
        $scope.onixTransformationtdtab = newTab;
    }
    $scope.onixTransformationIsSet = function (tabNum) {
        return $scope.onixTransformationtdtab === tabNum;
    };
    $scope.partnerCOnfigAddMetaField = function () {
        $('#addmetadatamodal').modal('toggle');
        /*  $http({
           method : 'GET',
           url : '/getMetadataConfigDetails',
           data : null
       }).then(function(response) {
           $rootScope.metadataFieldDetails = response.data.data;
           console.log(JSON.stringify($rootScope.metadataFieldDetails))
           $rootScope.mGroupEditFlg = false;
          $rootScope.pgFieldValueList = {};
           
          $rootScope.hideLoader('app-content');
       }); */
    }

    $scope.appletypeSelect = function (slct, index, data) {
        $scope.appletypeSelectData = slct;
        $rootScope.pCdata.formatDetails[index].appleFileType = slct.value;
    }
    $scope.pCcondionFormatModal = function (format, index) {
        $rootScope.currentIndexForFormat = index;
        $rootScope.pCcurrentFormat = angular.copy(format);
        //$rootScope.pCcurrentFormat = format;
        $rootScope.currentConditionSelected = null;
    }
    // $scope.pCconditionForFormatsTags = function (slct) {
    //     if (!$rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition)
    //         $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition = [];
    //     if($rootScope.pCcurrentFormat.condition == null)
    //         $rootScope.pCcurrentFormat.condition = [];
    //     if ($rootScope.pCcurrentFormat.condition.findIndex(obj => obj['value'] === slct.value) == -1)
    //         $rootScope.pCdata.pCcurrentFormat.condition.push({ 'value': slct.value, 'path': slct.path });
    //     console.log($rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition);
    //     $rootScope.currentConditionSelected = slct.type;
    // }
$scope.assetConditionCheck = function(data){
 if(data.formatNamingPrefix != null || data.formatNamingSuffix != null || (data.compressedIfMultiple != null && data.compressedIfMultiple == true)|| 
 (data.epubValidator != null && data.epubValidator == true) || (data.ePubVersion != null && data.ePubVersion != ''))
 return true
 else
 false
}
$scope.assetCoverConditionCheck = function(data){
    if(data.formatNamingPrefix != null || data.formatNamingSuffix != null || (data.compressedIfMultiple != null && data.compressedIfMultiple == true))
    return true
    else
    false
   }

 $scope.metadataExcelConditionCheck = function(data){
var list = $filter('filter')($rootScope.pCdata.transformFieldList, function(itm) { return (itm.metaDataFieldName == data)});
    if (list !=null && list.length >0) {
        return true;
    } else {
        return false;
    }
    

 }  
    $scope.pCconditionForFormatsTags = function (slct) {
        // if($rootScope.pCcurrentFormat.condition == null)
        //          $rootScope.pCcurrentFormat.condition = [];
        // if (!$rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition)
        //     $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition = [];
        // if ($rootScope.pCcurrentFormat.condition.findIndex(obj => obj['value'] === slct.value) == -1)
        //     $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].condition.push({ 'value': slct.value, 'path': slct.path });
        $rootScope.currentConditionSelected = slct.type;
        $rootScope.currentConditionPathSelected = slct;
    }
  $scope.pCsetAssetCondition = function(slct){
    if($rootScope.currentConditionSelected == 'Stop distribution'){
        $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat][slct.path] = $rootScope.pCcurrentFormat[slct.path];
        $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].ePubVersion = $rootScope.pCcurrentFormat.ePubVersion;
    }
    else
        $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat][slct.path] = $rootScope.pCcurrentFormat[slct.path];
  }
  $scope.assetFormatFormValidation = function(){
     var invalid = false;
     if($rootScope.currentConditionSelected == 'Stop distribution' && !$rootScope.pCcurrentFormat.epubValidator)
        invalid = true;
     if($rootScope.currentConditionSelected == 'File compress' && !$rootScope.pCcurrentFormat.compressedIfMultiple)
        invalid = true;
     if($rootScope.currentConditionSelected == 'Stop distribution' && $rootScope.pCcurrentFormat.epubValidator && $rootScope.pCcurrentFormat.ePubVersion == null)
        invalid = true;
    return invalid;
  }
    $scope.pCcondionCoverModal = function (format, index) {
        $rootScope.currentIndexForFormat = index;
        $rootScope.pCcurrentFormat = angular.copy(format);
        $rootScope.currentConditionSelected = null;
    }

    $scope.pCconditionForCoverTags = function (slct) {
        // if($rootScope.pCcurrentFormat.condition == null)
        //          $rootScope.pCcurrentFormat.condition = [];
        // if (!$rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat].condition)
        //     $rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat].condition = [];
        // if ($rootScope.pCcurrentFormat.condition.findIndex(obj => obj['value'] === slct.value) == -1)
        //     $rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat].condition.push({ 'value': slct.value, 'path': slct.path });
        $rootScope.currentConditionSelected = slct.type;
        $rootScope.currentConditionPathSelected = slct;
    }

    $scope.cpRemoveFormatCondition = function (rmv) {
        if($rootScope.pCcurrentFormat[rmv.path] == true){
            if(rmv.type == "Stop distribution"){
                $rootScope.pCcurrentFormat[rmv.path] = false;
                $rootScope.pCcurrentFormat.ePubVersion = null;
                $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat][rmv.path] = false;
                $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat].ePubVersion = null;
            }
            else{
                $rootScope.pCcurrentFormat[rmv.path] = false;
                $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat][rmv.path] = false;
            }
        }
        else{
            $rootScope.pCcurrentFormat[rmv.path] = null;
            $rootScope.pCdata.formatDetails[$rootScope.currentIndexForFormat][rmv.path] = null;
        }
        //        $rootScope.pCdata.formatDetails.splice($rootScope.pCdata.formatDetails.findIndex(obj => obj['formatId'] === data.formatId),1); 

        // $rootScope.pCcurrentFormat.condition.splice($rootScope.pCcurrentFormat.condition.findIndex(obj => obj['value'] === rmv.value), 1);
    }
    $scope.cpRemoveCoverCondition = function (rmv) {
        if($rootScope.pCcurrentFormat[rmv.path] == true){
            $rootScope.pCcurrentFormat[rmv.path] = false;
            $rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat][rmv.path] = false;
        }
        else{
            $rootScope.pCcurrentFormat[rmv.path] = null;
            $rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat][rmv.path] = null;
        }
        //        $rootScope.pCdata.formatDetails.splice($rootScope.pCdata.formatDetails.findIndex(obj => obj['formatId'] === data.formatId),1); 

        // $rootScope.pCcurrentFormat.condition.splice($rootScope.pCcurrentFormat.condition.findIndex(obj => obj['value'] === rmv.value), 1);
    }
    $scope.pCsetCoverCondition = function(slct){
   $rootScope.pCdata.coverFormat[$rootScope.currentIndexForFormat][slct.path] = $rootScope.pCcurrentFormat[slct.path];
    }

    $scope.setEpubValidator = function () {
        $rootScope.pCcurrentFormat.epubValidator = true;
    }
    $scope.setFileCompress = function () {
        $rootScope.pCcurrentFormat.compressedIfMultiple = true;
    }
    $scope.toggleTransferFolderStructure = function (chk) {
        $rootScope.pCdata.transferFolderStructure = chk;
    }
    
    $scope.pCemailShow = function (chk) {
        if(chk)
            $rootScope.pCdata.metadataTransferMedium = 'Email';
        else
            $rootScope.pCdata.metadataTransferMedium = 'FTP';
    }
   $scope.setNextPage = function(tab){
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    $scope.setTab(tab);  
}
$scope.mappingFileXlsDownload = function(){
    if($rootScope.pCcurrentMetadata.customTemplatePath != null)
    $rootScope.metadataMappingDownload = true;
    else
    $rootScope.metadataMappingDownload = false;
}
    $scope.xlsUploadButton = true;
    $rootScope.metadataLookUpDownloadxlsx = function () {
        $scope.xlsUploadButton = false;
        $http({
            method: 'POST',
            url: '/customTemplateMDataForLookupGds',
            data: {
                userId: $rootScope.loggedUser.userId,
                fieldsToMap: $rootScope.pCcurrentMetadata.fieldsToMap
            }
        })
            .then(function (response) {
                if (response.data.code == '200') {
             $rootScope.pCcurrentMetadata.customTemplatePath = response.data.data; 
            //$rootScope.pCcurrentMetadata.mappingFilePath = '/home/codemantra/Downloads/MetadataTemplate20191704120301.xlsx';
                }
            })
            
    }
$scope.metadataMappingShow = function(){
    var condition;
    if($rootScope.pCdata.metadataType != null){
       condition = true;
    }
    if($rootScope.pCdata.metadataType == 'Excel' || $rootScope.pCdata.metadataType == 'excel'){
        if($rootScope.pCdata.excelTempate!=null && $rootScope.pCdata.excelTempate!='')
        condition = true;
        else
        condition = false;
    }
    return condition;
}
 $scope.replaceFilter = function(data){

 }
    $rootScope.testScroll = function(){
        setTimeout(function(){
              //$('.index-table .divTableBody').perfectScrollbar();
              $('.index-table .divTableBody').bind('scroll', function (e) {
              //	console.log($(this))
                  $(this).closest('.index-table').children('.divTableHeading').css("left", -$(this).scrollLeft()); //fix the thead relative to the body scrolling
  
                  $(this).closest('.index-table').children('.divTableHeading').children('.divTableHead:nth-child(1)').css("left", $(this).scrollLeft());  //fix the first cell of the header
  
                  $(this).closest('.index-table.fixed-action').children('.divTableHeading').children('.divTableHead:last-child').css("left", -($(this).scrollLeft())); //fix the last cell of the header
  
                  /*$('.index-table .divTableHeading .divTableHead:last-child').css("left", -($(".index-table .divTableBody").scrollLeft())); */
  
  
                  $(this).find('.divTableCell:nth-child(1)').css("left", $(this).scrollLeft()); //fix the first column of tdbody
                  $(this).find('.asset-table-heads').css("left", $(this).scrollLeft());
  
                  
                  /*fix the last cell of the header and body start*/ 
                  
                  var tabWidth = $(this).closest('.index-table.fixed-action').width(); 
                  var innertabWidth = $(this).closest('.index-table.fixed-action').children('.divTableHeading').width(); 
                  //console.log(tabWidth)
                  //console.log(innertabWidth)
                  $(this).closest('.index-table.fixed-action').children('.divTableHeading').children('.divTableHead:last-child').css("left", -(innertabWidth - tabWidth - 4) + $(this).scrollLeft());   
                  $(this).closest('.index-table.fixed-action').children('.divTableBody').find('.divTableCell:nth-last-child(1)').css("left", -(innertabWidth - tabWidth - 4) + $(this).scrollLeft()); 
                  /*fix the last cell of the header and body end*/
              });
              $('.index-table .divTableBodys').bind('scroll', function (e) {
                  $(this).closest('.index-table').children('.divTableHeading').css("left", -$(this).scrollLeft()); //fix the thead relative to the body scrolling
  
                  $(this).closest('.index-table').children('.divTableHeading').children('.divTableHead:nth-child(1)').css("left", $(this).scrollLeft());  //fix the first cell of the header
                  $(this).find('.divTableCell:nth-child(1)').css("left", $(this).scrollLeft()); //fix the first column of tdbody
              });
            $('#assetVersionModal').on('hidden.bs.modal', function () {
                $rootScope.assetVersionDetails={};
                 //alert('asdf')
              })
  //		    $('.table-scrollX').perfectScrollbar({
  //				suppressScrollX: true
  //		    });
              /*$('.divTableBody').perfectScrollbar({
                  suppressScrollX: true
              });*/
  //			$('.table-scrollY').perfectScrollbar({
  //				suppressScrollY: true
  //			});
              $('.Gtable-scrollY').perfectScrollbar({
                  suppressScrollXY: true
              });
              $('.isbn-inner-details-scroll').perfectScrollbar({
                  suppressScrollY: true
              });
              $('.scrollY').perfectScrollbar({
                  suppressScrollY: true
              });
              $('.scrollX').perfectScrollbar({
                  suppressScrollX: true
              });
              $('.value-select').perfectScrollbar({
                  suppressScrollX: true
              });
        },500);
          
      /*$(document).on('focus', '.single-dropdown',function(){ 
          $(this).children().css("border", "1px solid #2eb45a");
      });
       $(document).on('blur', '.single-dropdown',function(){ 
          $(this).children().css('border','1px solid #C7C9C7')
      });*/
     }
     
     $rootScope.testScroll(); 
}]);
