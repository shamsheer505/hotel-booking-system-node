
app.controller('MetaDataController', ['$scope', '$http', '$timeout', '$rootScope', '$routeParams', '$filter', '$location', '$compile', '$parse', 'Upload', '$sce', function($scope, $http, $timeout, $rootScope, $routeParams, $filter, $location, $compile, $parse, Upload, $sce) {
    if ($location.$$path.contains("/metadata-edit/")) {
        if ($rootScope.reloadEdit != 'edit') {
            var isbnValue = localStorage.getItem("editMetaDataIsbn");
            $http({
                method: 'GET',
                url: '/getFrontCoverFormat',
                data: null
            }).then(function(response) {
                $rootScope.frontCoverID = response.data;
                $rootScope.frntCoverList = [];
                var filepath = isbnValue + "/" + $rootScope.frontCoverID + "/";
                $rootScope.frntCoverList.push(filepath);
                $http({
                    method: 'POST',
                    url: '/download',
                    data: {
                        filePathList: $scope.frntCoverList,
                        loggeduser: $rootScope.loggedUser.userId
                    }
                }).then(function(response) {
                    $rootScope.frontCoverUrl = response.data.data;
                    if (response.data.code === "500") {
                        $rootScope.frontCoverUrl = null
                    } else {
                        $rootScope.frontCoverUrl = response.data.data.url
                    }
                })
            });
            $rootScope.IDValue = isbnValue;
            $http({
                method: 'POST',
                url: '/editMetaData',
                data: {
                    userId: user_id,
                    permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                    idValue: $rootScope.IDValue
                }
            }).then(function(response) {
                $rootScope.mEditData = response.data.data;
                $http({
                    method: 'GET',
                    url: '/getCodeLookUpValues',
                    data: null
                }).then(function(response) {
                    $rootScope.metaDataProdList = response.data.data
                })
            })
        }
    }
    $rootScope.showLoader = function(el, num, effect) {
        text = 'Processing please wait...';
        fontSize = '';
        switch (num) {
            case 1:
                maxSize = '';
                textPos = 'vertical';
                break;
            case 2:
                text = '';
                maxSize = 30;
                textPos = 'vertical';
                break;
            case 3:
                maxSize = 30;
                textPos = 'horizontal';
                fontSize = '18px';
                break
        }
        el.waitMe({
            effect: effect,
            text: text,
            bg: 'rgba(255,255,255,1)',
            color: '#197535',
            maxSize: 500,
            source: '../../images/img.svg',
            textPos: textPos,
            fontSize: fontSize,
            onClose: function() {}
        })
    };
    $rootScope.hideLoader = function(classname) {
        $('.' + classname).waitMe('hide')
    }
    $rootScope.locationPath = $location.$$url;
    if ($rootScope.locationPath.contains('metadata')) {
        $rootScope.locationPath = '/#metadata';
        $rootScope.pagename = 'Metadata'
    } else {
        $rootScope.locationPath = '/#asset';
        $rootScope.pagename = 'Default'
    }
    $rootScope.initBasicMData = function() {
        $rootScope.showLoader($('.app-content'), 1, 'win8_linear');
        $rootScope.mDataCustomGridHeaders = [];
        $rootScope.metaDataProdList = [];
        $rootScope.mDataGridHeaders = [];
        $http({
            method: 'GET',
            url: '/getCodeLookUpValues',
            data: null
        }).then(function(response) {
            $rootScope.metaDataProdList = response.data.data;
            $http({
                method: 'GET',
                url: '/getMetadataConfigDetails',
                data: null
            }).then(function(response) {
                $rootScope.metadataFieldDetails = response.data.data;
                $rootScope.mGroupEditFlg = !1;
                $rootScope.pgFieldValueList = {};
                angular.forEach($rootScope.metadataFieldDetails, function(fields) {
                    var index = $rootScope.loggedUser.permissionGroup.metadataGroup.indexOf(fields.groupId);
                    if (index != -1) {
                        $rootScope.mGroupEditFlg = !0
                    } else {
                        $rootScope.mGroupEditFlg = !1
                    }
                    $rootScope.customMDataGrp[fields.groupDisplayName] = fields;
                    angular.forEach($rootScope.customMDataGrp, function(key, value) {
                        var str = null;
                        var fieldName = null;
                        var lookUpValue = null;
                        if (key.metadataSubFieldConfig.length <= 0) {
                            angular.forEach(key.metadataFieldConfig, function(mainFieldConfig) {
                                str = mainFieldConfig.initRefPath;
                                fieldName = mainFieldConfig.metaDataFieldName;
                                lookUpValue = mainFieldConfig.lookUp;
                                checkPGField = mainFieldConfig.permissionGroupField;
                                if (str != null) {
                                    var pos = str.indexOf('=');
                                    var resKey = str.substring(pos, 0);
                                    var resValue = str.substring(pos + 1);
                                    var model = $parse(resKey);
                                    model.assign($rootScope, eval(resValue))
                                }
                                var checkGroupfield = Boolean(checkPGField);
                                if (checkGroupfield) {
                                    var pgRootValue = "$rootScope." + mainFieldConfig.permissionGroupValue;
                                    if (fieldName == 'CountryOfPublication') {
                                        $rootScope.pgFieldValueList[fieldName] = $filter('filter')($rootScope.metaDataProdList[lookUpValue], function(data) {
                                            return $rootScope.accountMetadataMappingFieldValueList.indexOf(data.code) != -1
                                        })
                                    } else {
                                        $rootScope.pgFieldValueList[fieldName] = eval(pgRootValue)
                                    }
                                }
                                $rootScope.counter[fields.groupDisplayName] = 1
                            })
                        } else {
                            angular.forEach(key.metadataFieldConfig, function(mainFieldConfig) {
                                str = mainFieldConfig.initRefPath;
                                if (str != null) {
                                    var pos = str.indexOf('=');
                                    var resKey = str.substring(pos, 0);
                                    var resValue = str.substring(pos + 1);
                                    var model = $parse(resKey);
                                    model.assign($rootScope, eval(resValue))
                                }
                                var checkGroupfield = Boolean(checkPGField);
                                if (checkGroupfield) {
                                    var pgRootValue = "$rootScope." + mainFieldConfig.permissionGroupValue;
                                    if (fieldName == 'CountryOfPublication') {
                                        $rootScope.pgFieldValueList.push({
                                            "fieldName": fieldName,
                                            "valueList": $filter('filter')($rootScope.metaDataProdList[lookUpValue], function(data) {
                                                return $rootScope.accountMetadataMappingFieldValueList.indexOf(data.code) != -1
                                            })
                                        })
                                    } else {
                                        $rootScope.pgFieldValueList.push({
                                            "fieldName": fieldName,
                                            "valueList": eval(pgRootValue)
                                        })
                                    }
                                }
                                $rootScope.counter[fields.groupDisplayName] = 1
                            });
                            angular.forEach(key.metadataSubFieldConfig, function(SubFieldConfig) {
                                str = SubFieldConfig.initRefPath;
                                $rootScope.customMDataSubGrp.push(str);
                                if (str != null) {
                                    var pos = str.indexOf('=');
                                    var resKey = str.substring(pos, 0);
                                    var resValue = str.substring(pos + 1);
                                    var model = $parse(resKey);
                                    model.assign($rootScope, eval(resValue))
                                }
                                $rootScope.subCounter[0] = 1
                            })
                        }
                    })
                });
                $rootScope.hideLoader('app-content')
            })
        });
        $http({
            method: 'GET',
            url: '/getCustomHeaders/' + 'Metadata',
            data: null
        }).then(function(response) {
            $rootScope.mDataCustomHeaders = response.data.data
        });
        $http({
            method: 'GET',
            url: '/getGridHeaders/' + 'Metadata',
            data: null
        }).then(function(response) {
            $rootScope.mDataGridHeaders = response.data.data;
            $rootScope.tempMDataGridHeaders = angular.copy($rootScope.mDataGridHeaders);
            $rootScope.checkSavedGridHeaders()
        })
    };
    $scope.highlight = function(text, search) {
        if (!search) {
            return $sce.trustAsHtml(text)
        }
        var _search = search;
        var _text = text.replace(new RegExp('<b>', 'gi'), '<=>').replace(new RegExp('</b>', 'gi'), '</=>');
        return $sce.trustAsHtml(_text.replace(new RegExp(_search, 'gi'), '<span class="highligt-notify">$&</span>').replace(new RegExp('<=>', 'gi'), '<b>').replace(new RegExp('</=>', 'gi'), '</b>'))
    };
    $rootScope.testScroll();
    var user_id = $rootScope.loggedUser.userId;
    var mPermissionGroupId = $rootScope.loggedUser.permissionGroupId;
    $rootScope.customFieldList = {};
    $rootScope.customMDataGrp = {};
    $rootScope.customMDataSubGrp = [];
    $rootScope.counter = {};
    $rootScope.editCounter = {};
    $rootScope.counterEdit = {};
    $rootScope.subCounter = {};
    $rootScope.subGroupName = 'PRICE';
    $rootScope.isMEditGroup = [];
    $rootScope.mDatauploadfile = {};
    $rootScope.getNumber = function(key) {
        return new Array($rootScope.counter[key])
    }
    $rootScope.getSubNumber = function(key) {
        return new Array($rootScope.subCounter[key])
    }
    $rootScope.getSubNumberEdit = function(num) {
        return new Array(num)
    }
    $rootScope.getNumberEdit = function() {
        var len = 0;
        var sublen = 0;
        angular.forEach($rootScope.mEditData, function(value, key) {
            $rootScope.counterEdit[key] = [];
            var childCnt = 0;
            if (value != null || value != undefined) {
                if (Object.keys(value).length > 0) {
                    angular.forEach(value, function(value1, key1) {
                        childCnt = 0;
                        if (key == "SUPPLY DETAIL") {
                            $rootScope.childDetails = [];
                            var i = 0;
                            angular.forEach(value1.Price, function(priceValue) {
                                $rootScope.childDetails.push({
                                    "childIndex": i,
                                    "childData": priceValue
                                });
                                i++
                            });
                            $rootScope.counterEdit[key].push({
                                "parentIndex": key1,
                                "child": $rootScope.childDetails
                            })
                        } else {
                            $rootScope.counterEdit[key].push({
                                "parentIndex": key1,
                                "childCount": 0
                            })
                        }
                    })
                }
            }
        })
    }
    $rootScope.addNewGroup = function(event, val) {
        var parentCount = $(event.target).closest('#button-div').prev().data('index');
        var new_value = $rootScope.counter[val] + 1;
        $rootScope.counter[val] = new_value;
        angular.forEach($rootScope.customMDataSubGrp, function(str) {
            if (str != null && (str.indexOf("[0]") != -1)) {
                var newStr = str.replace(0, parentCount + 1);
                var pos = newStr.indexOf('=');
                var resKey = newStr.substring(pos, 0);
                var resValue = newStr.substring(pos + 1);
                var model = $parse(resKey);
                model.assign($rootScope, eval(resValue))
            }
        });
        $rootScope.subCounter[parentCount + 1] = 1
    };
    $rootScope.removeGroup = function(event, val) {
        var parentCount = $(event.target).closest('.subgroup-remove').parent().remove();
        var new_value = $rootScope.counter[val] - 1;
        $rootScope.counter[val] = new_value
    };
    $rootScope.removeEditGroup = function(event, val, $index, fieldData, allData) {
        if ($rootScope.editLst == undefined)
            $rootScope.editLst = angular.copy($rootScope.mEditData[val]);
        var parentCount = $(event.target).closest('.subgroup-remove').parent().remove();
        angular.forEach($rootScope.counterEdit[val], function(value, key) {
            if ($index == value.parentIndex) {
                $rootScope.editLst.splice($index, 1)
                $rootScope.counterEdit[val].splice($index, 1)
            }
            $rootScope.newMDataCodeList[val + $index] = []
        });
        $rootScope.productData = $rootScope.Product.Product;
        $rootScope.productData[allData[val].groupName] = $rootScope.editLst
    };
    $rootScope.addNewSubGroup = function(event, val) {
        var childCount = $(event.target).closest('#button-divsub').prev().children('.subgroup').data('index');
        var parentCnt = $(event.target).closest('#button-divsub').prev().parent('.meta-data-add').data('index');
        $rootScope.subCounter[parentCnt] = $rootScope.subCounter[parentCnt] + 1
    };
    $rootScope.addNewGroupEdit = function(event, val) {
        $rootScope.isMEditGroup[val] = !0;
        var new_value = Object.keys($rootScope.counterEdit[val]).length;
        $rootScope.counterEdit[val].push({
            "parentIndex": new_value,
            "childCount": 0
        });
        var groupAddVal = {};
        var str = "";
        angular.forEach($rootScope.customMDataGrp[val].metadataFieldConfig, function(value, key) {
            str = value.metaDataFieldName;
            groupAddVal[str] = ""
        });
        $rootScope.mEditData[val].push(groupAddVal)
    };
    $scope.customMetadatashow = function() {
        angular.element(".custom-metadata-doted").css("display", "block")
    }
    $scope.customMetadatahide = function() {
        angular.element("#fsModal").css("display", "none");
        angular.element("div").removeClass("modal-backdrop");
        angular.element(".menu-expanded").removeClass("modal-open")
    }
    $scope.mColumnsSearch = function() {
        var intcount = 0;
        angular.forEach($rootScope.customFieldList, function(key, value) {
            intcount++
        });
        return intcount
    };
    $rootScope.downloadMdataTemplate = function() {
        $rootScope.saveDataName = {}
        $scope.mDataNameList = [];
        if (Object.keys($rootScope.metadaNameFieldMap).length <= 0) {
            angular.forEach($rootScope.metadataFieldDetails, function(fields) {
                var mDataGroupName = fields.groupName;
                angular.forEach(fields.metadataFieldConfig, function(fieldD) {
                    var mTempfieldname = fieldD.fieldDisplayName;
                    $rootScope.saveDataName[mTempfieldname] = mDataGroupName
                })
            })
        }
        angular.forEach($rootScope.metadaNameFieldMap, function(key, value) {
            $scope.mDataNameList.push(value);
            $rootScope.saveDataName[value] = key.grpName
        });
        $scope.customTemDataRest();
        $http({
            method: 'POST',
            url: '/customTemplateMData',
            data: {
                custMData: $rootScope.saveDataName
            }
        }).then(function(response) {
            if (response.data.code == "200") {
                $rootScope.templateSuccess = response.data.data;
                $rootScope.successCustomTemplate = response.data.statusMessage;
                window.open('/mdataTemplate/' + response.data.data);
                angular.element("#customtemplatemodal").css("display", "none");
                $location.url('/metadata-upload');
                $rootScope.customFieldList = {};
                $rootScope.successCustomTemplateMsg = !0;
                setTimeout(function() {
                    $rootScope.successCustomTemplateMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    };
    $rootScope.browseMdataFile = function(mfiles) {
        var filename = mfiles[0].name;
        var index = filename.lastIndexOf(".");
        var extension = filename.substring(index, filename.length);
        if (extension != ".xlsx") {
            alert("Please select only xlsx files to upload")
        }
        $rootScope.mDatauploadfile = mfiles[0]
    };
    $rootScope.mDataonixuploadfile = {};
    $rootScope.browsexmlMdataFile = function(mfiles) {
        var filename = mfiles[0].name;
        var index = filename.lastIndexOf(".");
        var extension = filename.substring(index, filename.length);
        console.log(extension);
        if (extension == ".xml") {
            $scope.disableUploadButtonForOnix = !1;
            $rootScope.mDataonixuploadfile = mfiles[0]
        } else {
            $scope.mfiles = null;
            $rootScope.mDataonixuploadfile = null;
            alert("Please select only xml files to upload")
        }
    };
    $rootScope.uploadMetaData = function(mfiles) {
        Upload.upload({
            method: 'POST',
            url: '/uploadMetaData',
            data: {
                userId: user_id,
                permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                metadataUpload: $rootScope.mDatauploadfile
            }
        }).then(function(response) {
            $rootScope.mUploadData = response.data.data;
            if (response.data.code == "200") {
                $rootScope.successUploadMdataMsgContent = response.data.statusMessage;
                $location.url('/metadata');
                $rootScope.successUploadMdataMsg = !0;
                setTimeout(function() {
                    $rootScope.successUploadMdataMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $rootScope.initBasicMData()
            }
        })
    };
    $scope.disableUploadButtonForOnix = !1;
    $scope.disableCancelButtonForOnix = !1;
    $rootScope.uploadonixMetaData = function(mfiles) {
        $scope.disableUploadButtonForOnix = !0;
        $scope.disableCancelButtonForOnix = !0;
        $scope.spinForUpload = !0;
        Upload.upload({
            method: 'POST',
            url: '/uploadonixMetaData',
            data: {
                userId: user_id,
                permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                metadataUpload: $rootScope.mDataonixuploadfile
            }
        }).then(function(response) {
            $rootScope.mUploadData = response.data.data;
            if (response.data.code == "200") {
                $rootScope.successUploadMdataMsgContent = response.data.statusMessage;
                $scope.spinForUpload = !1;
                $scope.disableCancelButtonForOnix = !1;
                $location.url('/metadata');
                $rootScope.initBasicMData();
                $rootScope.successUploadMdataMsg = !0;
                setTimeout(function() {
                    $rootScope.successUploadMdataMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else if (response.data.code != 200 && response.data.code != null) {
                $rootScope.mDataonixuploadfile = {};
                $scope.spinForUpload = !1;
                $scope.disableCancelButtonForOnix = !1;
                $scope.failureUploadMdataMsgContent = response.data.statusMessage;
                $scope.failureUploadMdataMsg = !0;
                setTimeout(function() {
                    $scope.failureUploadMdataMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.mDataonixuploadfile = {};
                $scope.spinForUpload = !1;
                $scope.disableCancelButtonForOnix = !1;
                $scope.failureUploadMdataMsgContent = "Service not responding";
                $scope.failureUploadMdataMsg = !0;
                setTimeout(function() {
                    $scope.failureUploadMdataMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $scope.mfiles = null
        })
    };
    $rootScope.addCustomMdataFields = function(groupName, groupData, checkMdataFields) {
        var checkCount = 0;
        if (checkMdataFields) {
            $rootScope.customFieldList[groupData] = groupName
        } else {
            delete $rootScope.customFieldList[groupData]
        }
    };
    $rootScope.mDataRemove = function(val) {
        if (Object.keys($rootScope.customFieldList).length > 0) {
            delete $rootScope.customFieldList[val];
            document.getElementById("mTempdata_" + val).checked = !1
        }
    };
    $rootScope.metaDataResult = [];
    $rootScope.skipCount = 0;
    $scope.mDataSuggestions = [];
    $rootScope.Product = {};
    $rootScope.ProductEdit = {};
    var user_id = $rootScope.loggedUser.userId;
    $rootScope.exportMdataSearch = function() {
        $rootScope.viewMetaData($rootScope.skipMDataCount, !0, !1)
    };
    $rootScope.mdatacancel = function() {
        $rootScope.isMEditGroup[$rootScope.profileGrop] = !1;
        $rootScope.IDValue = $rootScope.metaEditIsbn;
        $http({
            method: 'POST',
            url: '/editMetaData',
            data: {
                userId: user_id,
                permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                idValue: $rootScope.IDValue
            }
        }).then(function(response) {
            $rootScope.mEditData = response.data.data;
            $http({
                method: 'GET',
                url: '/getCodeLookUpValues',
                data: null
            }).then(function(response) {
                $rootScope.metaDataProdList = response.data.data
            })
        })
    };
    $rootScope.mdataonixcancel = function() {
        $rootScope.initBasicMData();
        $rootScope.mDataonixuploadfile = {};
        $location.url('/metadata')
    };
    $rootScope.editMetaData = function(isbnValue, eve) {
        $rootScope.reloadEdit = eve;
        if (eve = 'edit') {
            localStorage.setItem("editMetaDataIsbn", isbnValue);
            $http({
                method: 'GET',
                url: '/getFrontCoverFormat',
                data: null
            }).then(function(response) {
                $rootScope.frontCoverID = response.data;
                $rootScope.frntCoverList = [];
                var filepath = isbnValue + "/" + $rootScope.frontCoverID + "/";
                $rootScope.frntCoverList.push(filepath);
                $http({
                    method: 'POST',
                    url: '/download',
                    data: {
                        filePathList: $scope.frntCoverList,
                        loggeduser: $rootScope.loggedUser.userId
                    }
                }).then(function(response) {
                    $rootScope.frontCoverUrl = response.data.data;
                    if (response.data.code === "500") {
                        $rootScope.frontCoverUrl = null
                    } else {
                        $rootScope.frontCoverUrl = response.data.data.url
                    }
                });
                $rootScope.IDValue = isbnValue;
                $http({
                    method: 'POST',
                    url: '/editMetaData',
                    data: {
                        userId: user_id,
                        permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                        idValue: $rootScope.IDValue
                    }
                }).then(function(response) {
                    $rootScope.mEditData = response.data.data;
                    $http({
                        method: 'GET',
                        url: '/getCodeLookUpValues',
                        data: null
                    }).then(function(response) {
                        $rootScope.metaDataProdList = response.data.data
                    });
                    $location.url('/metadata-edit')
                })
            })
        }
    };
    $rootScope.checkEditData = function(editData) {
        if (null != editData) {
            if (Object.keys(editData).length > 0) {
                return !0
            } else {
                return !1
            }
        } else {
            return !1
        }
    };
    $rootScope.newMDataCodeList = [];
    $rootScope.editMetaDataGroup = function(groupName, groupdata, parent, daataa) {
        $rootScope.profileGrop = groupName;
        $rootScope.isMEditGroup[groupName] = !0;
        if ($rootScope.mEditData[groupName] != null) {
            var x = '';
            $rootScope.pageIndex = 0;
            for ($rootScope.pageIndex; $rootScope.pageIndex < $rootScope.mEditData[groupName].length; $rootScope.pageIndex++) {
                x += $rootScope.pageIndex;
                angular.forEach(groupdata, function(key, value) {
                    if (key.fieldDataType == "MultiSelect") {
                        var lkp = key.metaDataFieldName;
                        var look = key.lookUp;
                        var fldname = key.metaDataFieldName + '_' + $rootScope.pageIndex;
                        var dd = ($rootScope.mEditData[groupName][$rootScope.pageIndex])[lkp];
                        $rootScope.newMDataCodeList[fldname] = [];
                        angular.forEach(dd, function(d) {
                            $rootScope.newMDataCodeList[fldname].push(d);
                            var id = lkp + "_" + d + "_" + $rootScope.pageIndex;
                            $timeout(function() {
                                document.getElementById(id).checked = !0;
                                var ss1 = $rootScope.newMDataCodeList[fldname];
                                var setSelectedText1 = document.getElementById("multiselectedText_" + fldname);
                                setSelectedText1.innerHTML = ss1
                            }, 1)
                        });
                        $timeout(function() {
                            document.getElementById("mAllMultiSelect_" + fldname).checked = ($rootScope.newMDataCodeList[fldname].length === $rootScope.metaDataProdList[look].length)
                        }, 1)
                    }
                })
            }
        }
    };
    $rootScope.initGroup = function(parentIndex, refPath, refValue, key) {
        if (key == 'SUPPLY DETAIL') {
            newStr1 = "Product.Product.SupplyDetail[parentInd].Price=[]";
            newStr = newStr1.replace('[parentInd]', '[' + parentIndex + ']');
            var pos = newStr.indexOf('=');
            var resKey = newStr.substring(pos, 0);
            var resValue = newStr.substring(pos + 1);
            var model = $parse(resKey);
            model.assign($rootScope, eval(resValue));
            angular.forEach($rootScope.counterEdit[key][parentIndex].child, function(value, key) {
                newStr2 = "Product.Product.SupplyDetail[parentInd].Price[childInd].DiscountCoded=[]";
                newStr2 = newStr2.replace('[parentInd]', '[' + parentIndex + ']');
                newStr2 = newStr2.replace('Price[childInd]', 'Price[' + value.childIndex + ']');
                var pos1 = newStr2.indexOf('=');
                var resKey1 = newStr2.substring(pos1, 0);
                var resValue1 = newStr2.substring(pos1 + 1);
                var model = $parse(resKey1);
                model.assign($rootScope, eval(resValue1))
            });
            if (refPath.contains('0')) {
                refPath = refPath.replace('0', parentIndex)
            } else {
                refPath = refPath
            }
            var modelPath = 'Product.' + refPath;
            var model1 = $parse(modelPath);
            model1.assign($rootScope, refValue)
        } else {
            if (refPath.contains('0')) {
                refPath = refPath.replace('0', parentIndex)
            } else {
                refPath = refPath
            }
            var modelPath = 'Product.' + refPath;
            var model = $parse(modelPath);
            model.assign($rootScope, refValue)
        }
    }
    $rootScope.initSubGroup = function(parentIndex, childIndex, modelrefpath, refvalue) {
        modelrefpath = modelrefpath.replace('0', parentIndex);
        modelrefpath = modelrefpath.replace('Price[0]', 'Price[' + eval(childIndex) + ']');
        var modelPath = 'Product.' + modelrefpath;
        var model = $parse(modelPath);
        model.assign($rootScope, refvalue)
    }
    $rootScope.initProductIdType = function(refpath, refpathvalue) {
        if (refpath != null || refpath != undefined) {
            var isbnTypePath = 'Product.' + refpath;
            var model = $parse(isbnTypePath);
            model.assign($rootScope, refpathvalue)
        }
    }
    $rootScope.mdtData = {};
    $rootScope.mdtDropDown = {};
    $rootScope.mdtData.showExistIsbnCheck = !1;
    $rootScope.mdtDropDown.selectDropDownValue = !1;
    $rootScope.existIsbnCheck = function($event, parentIndex, mflag, mfieldname, modeflRefPath, refpath, refpathvalue) {
        var isbnvalue = $event.target.value;
        $rootScope.metaEditIsbn = $event.target.value
        if (isbnvalue != "" || isbnvalue != null || isbnvalue != undefined) {
            $http({
                method: 'POST',
                url: '/existIsbnCheck',
                data: {
                    isbnValue: isbnvalue
                }
            }).then(function successCallback(response) {
                if (response.data.status == 'Failure') {
                    $rootScope.existIsbnCheckMsg = response.data.statusMessage;
                    $rootScope.mdtData.showExistIsbnCheck = !0
                } else {
                    $rootScope.setProductIdType(mfieldname, mflag, refpath, refpathvalue);
                    $rootScope.setModelISBN(isbnvalue, parentIndex, mfieldname, modeflRefPath)
                }
            }, function errorCallback(response) {})
        }
    }
    $rootScope.rangeValidation = !1;
    $rootScope.rangeErrorMsg;
    $rootScope.dateRangeFromValidate = function($event, parentIndex, childIndex, mfieldname, modeflRefPath) {
        var fromDate = $event.target.value;
        var toDate = $rootScope.toDateValue;
        if ((fromDate != "" && fromDate != null && fromDate != undefined) && (toDate != "" && toDate != null && toDate != undefined)) {
            var text = moment(toDate).format("YYYY/MM/DD") > moment(fromDate).format("YYYY/MM/DD");
            if (text) {
                $rootScope.rangeValidation = !0
            } else {
                $rootScope.rangeValidation = !1;
                $rootScope.rangeErrorMsg = 'From date should not be greater than to date'
            }
        } else {
            if (toDate != "" && toDate != null && toDate != undefined) {
                if (fromDate == "" || fromDate == null || fromDate == undefined) {
                    $rootScope.rangeValidation = !1;
                    $rootScope.rangeErrorMsg = 'Please enter from date'
                }
            }
        }
        var refpath = 'Product.SupplyDetail[' + parentIndex + '].Price[' + childIndex + '].PriceEffectiveFrom';
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, $event.target.value);
        $rootScope.fromDateValue = fromDate
    }
    $rootScope.dateRangeToValidate = function($event, parentIndex, childIndex, mfieldname, modeflRefPath) {
        var toDate = $event.target.value;
        var fromDate = $rootScope.fromDateValue;
        if ((fromDate != "" && fromDate != null && fromDate != undefined) && (toDate != "" && toDate != null && toDate != undefined)) {
            var text = moment(toDate).format("YYYY/MM/DD") > moment(fromDate).format("YYYY/MM/DD");
            if (text) {
                $rootScope.rangeValidation = !0
            } else {
                $rootScope.rangeValidation = !1;
                $rootScope.rangeErrorMsg = 'Until date should not be lesser than from date'
            }
        } else {
            if (fromDate != "" && fromDate != null && fromDate != undefined) {
                if (toDate == "" || toDate == null || toDate == undefined) {
                    $rootScope.rangeValidation = !1;
                    $rootScope.rangeErrorMsg = 'Please enter until date'
                }
            }
        }
        var refpath = 'Product.SupplyDetail[' + parentIndex + '].Price[' + childIndex + '].PriceEffectiveUntil';
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, $event.target.value);
        $rootScope.toDateValue = toDate
    }
    $rootScope.setProductIdType = function(mfieldname, mflag, refpath, refpathvalue) {
        var isbnTypePath = 'Product.' + refpath;
        var model = $parse(isbnTypePath);
        model.assign($rootScope, refpathvalue)
    }
    $rootScope.setModelISBN = function(targetvalue, parentIndex, mfieldname, refpath) {
        var childIndex = '0';
        refpath = refpath.replace('0', parentIndex);
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, targetvalue)
    }
    $rootScope.setModelMetaData = function(event, parentIndex, mfieldname, refpath) {
        var childIndex = '0';
        refpath = refpath.replace('0', parentIndex);
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, event.target.value)
    }
    $rootScope.setModelMetaDataDate = function(value, parentIndex, mfieldname, refpath) {
        var childIndex = '0';
        refpath = refpath.replace('0', parentIndex);
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, value)
    }
    $rootScope.setModelMetaDataSub = function(event, parentIndex, childIndex, mfieldname, refpath) {
        refpath = refpath.replace('0', parentIndex);
        refpath = refpath.replace('Price[0]', 'Price[' + eval(childIndex) + ']');
        var modelPath = 'Product.' + refpath;
        var model = $parse(modelPath);
        model.assign($rootScope, event.target.value)
    }
    $rootScope.selectedDropDownValue = [];
    $rootScope.selectedEditDropDownValue = [];
    $rootScope.subSelectedDropDownValue = [];
    $rootScope.dropDownChanges = !1;
    $rootScope.setDropdownMetadata = function(event, parentIndex, mfieldname, refpath) {
        var selectedValue = event.target.innerText.split("-");
        $rootScope.dropDownChanges = !0;
        $rootScope.selectedDropDownValue[mfieldname] = selectedValue[0];
        var childIndex = '0';
        refpath = refpath.replace('0', parentIndex);
        var refPathValue = 'Product.' + refpath;
        var model = $parse(refPathValue);
        var finalSelectedValue = selectedValue[0] == "Select" ? '' : selectedValue[0];
        model.assign($rootScope, finalSelectedValue);
        var ss = event.target.innerText;
        var setSelectedText = document.getElementById("selectedText_" + mfieldname + "_" + parentIndex);
        setSelectedText.innerHTML = ss
    }
    $rootScope.setDropdownMultiMetadata = function(event, parentIndex, mfieldname, refpath, lookup) {
        var checkMfield = Boolean(event.target.checked);
        if ($rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] == undefined) {
            $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] = []
        }
        if (checkMfield) {
            $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex].push(event.target.value)
        } else {
            var index = $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex].indexOf(event.target.value);
            $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex].splice(index, 1)
        }
        document.getElementById("mAllMultiSelect_" + mfieldname + "_" + parentIndex).checked = ($rootScope.newMDataCodeList[mfieldname + "_" + parentIndex].length === $rootScope.metaDataProdList[lookup].length)
        refpath = refpath.replace('0', parentIndex);
        var refPathValue = 'Product.' + refpath;
        var model = $parse(refPathValue);
        var ss = $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex];
        var setSelectedText = document.getElementById("multiselectedText_" + mfieldname + "_" + parentIndex);
        setSelectedText.innerHTML = ss;
        model.assign($rootScope, ss)
    }
    $rootScope.setDropdownAllMultiMetadata = function(event, parentIndex, lookupValues, mfieldname, refpath) {
        var checkMfield = Boolean(event.target.checked);
        if ($rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] == undefined) {
            $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] = []
        }
        $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] = [];
        if (checkMfield) {
            angular.forEach(lookupValues, function(val) {
                document.getElementById(mfieldname + "_" + val.code + "_" + parentIndex).checked = !0;
                $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex].push(val.code)
            })
        } else {
            angular.forEach(lookupValues, function(val) {
                document.getElementById(mfieldname + "_" + val.code + "_" + parentIndex).checked = !1
            });
            $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex] = []
        }
        refpath = refpath.replace('0', parentIndex);
        var refPathValue = 'Product.' + refpath;
        var model = $parse(refPathValue);
        var ss = $rootScope.newMDataCodeList[mfieldname + "_" + parentIndex];
        var setSelectedText = document.getElementById("multiselectedText_" + mfieldname + "_" + parentIndex);
        setSelectedText.innerHTML = ss;
        model.assign($rootScope, ss)
    }
    $scope.setDropDownFocus = function(fieldName, parentIndex) {
        setTimeout(function() {
            angular.element("#" + fieldName + "_" + parentIndex).trigger('focus')
        }, 10)
    }
    $scope.setEditDropDownFocus = function(fieldName, parentIndex, value) {
        $rootScope.selectedEditDropDownValue[fieldName] = value;
        setTimeout(function() {
            angular.element("#" + fieldName + "_" + parentIndex).trigger('focus')
        }, 10)
    }
    $scope.setEditMultiDropDownFocus = function(fieldName, parentIndex, value) {
        $rootScope.newMDataCodeList[fieldName] = value;
        setTimeout(function() {
            angular.element("#" + fieldName + "_" + parentIndex).trigger('focus')
        }, 10)
    }
    $scope.setSubEditDropDownFocus = function(fieldName, parentIndex, childIndex, value) {
        $rootScope.subSelectedDropDownValue[fieldName] = value;
        setTimeout(function() {
            angular.element("#" + fieldName + "_" + parentIndex + "_" + childIndex).trigger('focus')
        }, 10)
    }
    $scope.setSubDropDownFocus = function(fieldName, parentIndex, childIndex) {
        setTimeout(function() {
            angular.element("#" + fieldName + "_" + parentIndex + childIndex).trigger('focus')
        }, 10)
    }
    $rootScope.saveMdata = function(mceflag) {
        var refPathValue = 'Product.Product.LastModifiedBy';
        var model = $parse(refPathValue);
        model.assign($rootScope, $rootScope.loggedUser.userId);
        if (mceflag == "CR") {
            $http({
                method: 'POST',
                url: '/saveMetaData',
                data: $rootScope.Product
            }).then(function(response) {
                if (response.data.code == "200") {
                    $rootScope.mdataList = response.data.data;
                    $rootScope.successAddMdataMsgContent = response.data.statusMessage;
                    $rootScope.successAddMdataMsg = !0;
                    setTimeout(function() {
                        $rootScope.successAddMdataMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    localStorage.setItem("editMetaDataIsbn", $rootScope.metaEditIsbn);
                    $location.url('/metadata-edit/');
                    setTimeout(function() {
                        location.reload()
                    }, 200)
                } else {
                    $rootScope.successUpdateMdataMsgContent = response.data.statusMessage;
                    $rootScope.faildUpdateMdataMsg = !0;
                    setTimeout(function() {
                        $rootScope.faildUpdateMdataMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            })
        } else {
            $http({
                method: 'POST',
                url: '/updateMetaData',
                data: $rootScope.Product
            }).then(function(response) {
                if (response.data.code == "200") {
                    $rootScope.mdataList = response.data.data;
                    $rootScope.successUpdateMdataMsgContent = response.data.statusMessage;
                    $rootScope.successUpdateMdataMsg = !0;
                    setTimeout(function() {
                        $rootScope.successUpdateMdataMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    location.reload();
                    $location.url('/metadata-edit/')
                } else {
                    $rootScope.successUpdateMdataMsgContent = response.data.statusMessage;
                    $rootScope.faildUpdateMdataMsg = !0;
                    setTimeout(function() {
                        $rootScope.faildUpdateMdataMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            })
        }
    };
    $rootScope.deleteMetaData = function(isbnValue) {
        $rootScope.IDValue = isbnValue;
        $http({
            method: 'POST',
            url: '/deleteMetaData',
            data: {
                idValue: $rootScope.IDValue
            }
        }).then(function(response) {
            $rootScope.closeMdataDelete();
            $rootScope.mDeleteData = response.data.data;
            $location.url('/metadata');
            $rootScope.successDeleteMdataMsg = !0;
            $rootScope.successDeleteMdataMsgContent = $rootScope.mDeleteData.statusMessage;
            setTimeout(function() {
                $rootScope.successDeleteMdataMsg = !1;
                $rootScope.$apply()
            }, $rootScope.alertTimeoutInterval)
        })
    };
    $scope.addMdataColumnTags = function(input, checkFields, fieldName, event) {
        var checkCount = 0;
        angular.forEach($rootScope.mDataSuggestions[fieldName], function(value) {
            if (input === value) {
                if (document.getElementById(event.target.id).checked) checkCount++
            }
        });
        if (checkFields) {
            $rootScope.columnMFilterList[event.target.id] = input
        } else {
            delete $rootScope.columnMFilterList[event.target.id]
        }
        $rootScope.metaDataResult = [];
        $rootScope.viewMetaData('C', 0, !1, !1)
    };
    $rootScope.mDataDeleteModal = function(isbnValue) {
        $rootScope.metaDataDelete = isbnValue
    }
    $rootScope.closeMdataDelete = function() {
        $rootScope.metaDataDelete = null;
        $('#metadata-delete').modal('toggle');
        $rootScope.viewMetaData(0, !1, !1)
    }
    $rootScope.successMetaManualDistMsg;
    $rootScope.toggleMetaDistributionMsg = function() {
        $rootScope.successMetaManualDistMsg = !0;
        $rootScope.successMetaManualDistMsgContent = "Requested Successfully!";
        setTimeout(function() {
            $rootScope.successMetaManualDistMsg = !1;
            $rootScope.$apply()
        }, $rootScope.alertTimeoutInterval)
    }
    $rootScope.loadMetaManualDist = function() {
        document.getElementById("tempbucketerr").innerHTML = "";
        if (Object.keys($rootScope.downloadMetaUploadList).length > 100) {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to distribution request"
        } else {
            $http({
                method: 'POST',
                url: '/getEligiblePartners',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.partnerList = response.data.data;
                $rootScope.metaValidPartners = [];
                $rootScope.metaValidPartnerGrp = [];
                angular.forEach($rootScope.partnerList, function(value) {
                    $rootScope.metaValidPartners[value.partnerTypeId] = [];
                    $rootScope.metaValidPartnerGrp[value.partnerTypeId] = [];
                    angular.forEach(value.partners, function(partvalue) {
                        $rootScope.metaValidPartners[value.partnerTypeId].push(partvalue.partnerId)
                    });
                    angular.forEach(value.partnerGrps, function(partgrpvalue) {
                        $rootScope.metaValidPartnerGrp[value.partnerTypeId].push(partgrpvalue.partnerGroupId)
                    })
                })
            });
            $http({
                method: 'POST',
                url: '/getEligibleMetadataPartners',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.metaPartnerList = response.data.data
            });
            var res = JSON.parse(localStorage.getItem('selectedMetaData'));
            $rootScope.metaPartn = []
            angular.forEach(res, function(value) {
                $rootScope.metaPartn.push({
                    "isbn": value[0].isbn,
                    "title": value[0].title,
                    "partnerTypeId": "Temp001",
                    "priority": "Regular"
                })
            })
            $location.url('/meta-manual-distribution')
        }
    }
    $rootScope.checkForTakeDown = function() {
       document.getElementById("tempbucketerr").innerHTML = "";
       if (Object.keys($rootScope.downloadMetaUploadList).length > 100) {
           document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to distribution request"
       } else {
           $http({
               method: 'POST',
               url: '/getEligiblePartners',
               data: {
                   userId: $rootScope.loggedUser.userId
               }
           }).then(function(response) {
               $rootScope.partnerList = response.data.data;
               $rootScope.metaValidPartners = [];
               $rootScope.metaValidPartnerGrp = [];
               angular.forEach($rootScope.partnerList, function(value) {
                   $rootScope.metaValidPartners[value.partnerTypeId] = [];
                   $rootScope.metaValidPartnerGrp[value.partnerTypeId] = [];
                   angular.forEach(value.partners, function(partvalue) {
                       $rootScope.metaValidPartners[value.partnerTypeId].push(partvalue.partnerId)
                   });
                   angular.forEach(value.partnerGrps, function(partgrpvalue) {
                       $rootScope.metaValidPartnerGrp[value.partnerTypeId].push(partgrpvalue.partnerGroupId)
                   })
               })
           });
           $http({
               method: 'POST',
               url: '/getEligibleMetadataPartners',
               data: {
                   userId: $rootScope.loggedUser.userId
               }
           }).then(function(response) {
               $rootScope.metaPartnerList = response.data.data
           });
           var res = JSON.parse(localStorage.getItem('selectedMetaData'));
           $rootScope.metaPartn = []
           angular.forEach(res, function(value) {
               $rootScope.metaPartn.push({
                   "isbn": value[0].isbn,
                   "title": value[0].title,
                   "partnerTypeId": "Temp001",
                   "priority": "Regular"
               })
           })
           $location.url('/manual-take-down')
       }
   }
    $(".metadata-info-heading").click(function(e) {
        if ($(this).siblings().next().is(':visible')) {
            $(this).siblings().next().slideToggle(200);
            $(this).removeClass('cp-up-arrow');
            $(this).addClass('cp-down-arrow')
        } else {
            $(this).siblings().next().slideToggle(200);
            $(this).addClass('cp-up-arrow');
            $(this).removeClass('cp-down-arrow')
        }
    });
    $rootScope.metadaCodeDis = function(data) {
        if (data.code) {
            return data.code
        } else {
            return data
        }
    }
    $rootScope.metadaNameFieldMap = {};
    $scope.metaNameFieldChk = function(nameselect, chk, key, grpName, fieldName) {
        if (chk) {
            $scope.mDataList = {
                "key": key,
                "fieldName": fieldName,
                "grpName": grpName
            };
            $rootScope.metadaNameFieldMap[nameselect] = $scope.mDataList
        } else {
            delete $rootScope.metadaNameFieldMap[nameselect];
            document.getElementById("mdatauphead_" + grpName).checked = !1
        }
        var count = 0;
        angular.forEach($rootScope.customMDataGrp[key].metadataFieldConfig, function(value1) {
            if (document.getElementById("mdataup_" + value1.metaDataFieldName).checked) {
                count++
            }
        });
        if (count == $rootScope.customMDataGrp[key].metadataFieldConfig.length) {
            document.getElementById("mdatauphead_" + grpName).checked = !0
        }
        $scope.filterTags = Object.keys($rootScope.metadaNameFieldMap).length >= 1
    };
    $scope.metaNameFieldChkAll = function(event, key, grpName) {
        if (event.target.checked) {
            angular.forEach($rootScope.customMDataGrp[key].metadataFieldConfig, function(value1) {
                $scope.mDataList = {
                    "key": key,
                    "fieldName": value1.metaDataFieldName,
                    "grpName": grpName
                };
                $rootScope.metadaNameFieldMap[value1.fieldDisplayName] = $scope.mDataList;
                document.getElementById("mdataup_" + value1.metaDataFieldName).checked = !0
            })
        } else {
            angular.forEach($rootScope.customMDataGrp[key].metadataFieldConfig, function(value1) {
                delete $rootScope.metadaNameFieldMap[value1.fieldDisplayName];
                document.getElementById("mdataup_" + value1.metaDataFieldName).checked = !1
            })
        }
        $scope.filterTags = Object.keys($rootScope.metadaNameFieldMap).length >= 1
    };
    $scope.metaNameFieldChkRmv = function(rmvdata) {
        var data = $rootScope.metadaNameFieldMap[rmvdata];
        document.getElementById("mdataup_" + data.fieldName).checked = !1;
        var count = 0;
        angular.forEach($rootScope.customMDataGrp[data.key].metadataFieldConfig, function(value1) {
            if (document.getElementById("mdataup_" + value1.metaDataFieldName).checked) {
                count++
            }
        });
        if (count == $rootScope.customMDataGrp[data.key].metadataFieldConfig.length) {
            document.getElementById("mdatauphead_" + data.grpName).checked = !0
        } else {
            document.getElementById("mdatauphead_" + data.grpName).checked = !1
        }
        delete $rootScope.metadaNameFieldMap[rmvdata];
        $scope.filterTags = Object.keys($rootScope.metadaNameFieldMap).length >= 1
    }
    $scope.customTemDataSave = function() {
        $rootScope.saveDataName = {}
        $scope.mDataNameList = [];
        angular.forEach($rootScope.metadaNameFieldMap, function(key, value) {
            $scope.mDataNameList.push(value);
            $rootScope.saveDataName[value] = key.grpName
        });
        $scope.customTemDataRest()
    };
    $scope.customTemDataRest = function() {
        angular.forEach($rootScope.metadaNameFieldMap, function(key, value) {
            var datakey = key;
            angular.forEach(datakey, function() {
                var name = datakey.fieldName;
                var gropuname = datakey.grpName;
                document.getElementById("mdataup_" + name).checked = !1;
                document.getElementById("mdatauphead_" + gropuname).checked = !1
            })
        });
        document.getElementById("custommetadataview").checked = !1;
        $rootScope.metadaNameFieldMap = {}
    }
    $scope.metatoggleShelf = function(val) {
        angular.element(".self-content").toggle()
    }
    $rootScope.metaShelfData = {};
    $scope.metaShelfActionList = [];
    $rootScope.metaShAction = {};
    $scope.metaUnCheckAction = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityMetaLists, function(value) {
            document.getElementById("metaShelf_" + value.activityName).checked = !1
        })
    }
    $scope.metaUnCheckActionsDisable = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityMetaLists, function(value, key) {
            document.getElementById("metaShelf_" + value.activityName).disabled = !0
        })
    }
    $scope.metaUnCheckActionEnable = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityMetaLists, function(value, key) {
            document.getElementById("metaShelf_" + value.activityName).disabled = !1
        })
    }
    $scope.metaShelfNameChange = function(shelf, shelfList) {
        angular.forEach($rootScope.saveshelfList, function(value) {
            if ($scope.metaShelfData.metaShelfName === value.name) {
                $scope.metaShelfRemainderList = "";
                $scope.metaShelfComments = "";
                $scope.metaShelfActionList = [];
                $rootScope.metaShAction = {};
                $scope.metaUnCheckAction(shelf, shelfList);
                $scope.metaUnCheckActionEnable(shelf, shelfList);
                angular.element($(".shelfactionselect")).removeClass("shelfactionselect-disable");
                angular.element($(".shelf-remain")).removeClass("non-editable");
                $scope.metaShelfNameSelect(value, value.shelfdetails)
            } else if ($scope.metaShelfData.metaShelfName != value.name) {
                angular.element($(".shelfactionselect")).removeClass("shelfactionselect-disable");
                angular.element($(".shelf-remain")).removeClass("non-editable");
                $scope.metaUnCheckActionEnable(shelf, shelfList)
            }
        })
    }
    $scope.metaShelfNameSelect = function(shelf, shelfList) {
        $scope.metaUnCheckAction(shelf, shelfList);
        $rootScope.metaShelfData = {};
        $scope.metaShelfActionList = [];
        $rootScope.metaShAction = {};
        $scope.shelfName = "";
        angular.element($(".shelfactionselect")).addClass("shelfactionselect-disable");
        angular.element($(".header-search-drop")).removeClass("active");
        angular.element($(".shelf-remain")).addClass("non-editable");
        $scope.metaShelfData.metaShelfName = shelf.name;
        $scope.metaShelfRemainderList = shelf.remainder;
        $scope.metaShelfComments = shelf.comments;
        angular.forEach(shelfList, function(details) {
            angular.forEach(details.action, function(value, key) {
                if (key != null && key != "") {
                    document.getElementById("metaShelf_" + key).checked = !0;
                    if ($scope.metaShelfActionList.indexOf(key) == -1) {
                        angular.forEach($rootScope.shelfActivityMetaLists, function(data) {
                            if (data.activityName == key) {
                                if (!$scope.metaShelfActionList.includes(data.displayName))
                                    $scope.metaShelfActionList.push(data.displayName)
                            }
                        })
                        $rootScope.metaShAction[key] = value
                    }
                }
            })
        });
        $scope.metaUnCheckActionsDisable(shelf, shelfList)
    };
    $scope.metaSelfActionSelect = function(shelfAction, chk) {
        if (chk) {
            $scope.metaShelfActionList.push(shelfAction.displayName);
            $rootScope.metaShAction[shelfAction.activityName] = "InProgress"
        } else {
            var index = $scope.metaShelfActionList.indexOf(shelfAction.displayName);
            $scope.metaShelfActionList.splice(index, 1);
            delete $rootScope.metaShAction[shelfAction.activityName]
        }
    };
    $scope.metaSelfRemainderSelect = function(remainderList) {
        $scope.metaShelfRemainderList = remainderList
    };
    $scope.metaSaveDataShelf = function(shelf) {
        document.getElementById("tempbucketerr").innerHTML = "";
        $scope.metaShelfComments = $("#shelfComments").val();
        $scope.metaUpdatedBy = $rootScope.loggedUser.userId;
        $scope.metaShelfDetails = [];
        $scope.metaSAction = [];
        if (Object.keys($rootScope.downloadMetaUploadList).length > 100) {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to save shelf request";
            return !1
        }
        if (Object.keys($rootScope.downloadMetaUploadList).length > 0) {
            angular.forEach($rootScope.downloadMetaUploadList, function(key, value) {
                $scope.metaShelfDetails.push({
                    "isbn": key[0].isbn,
                    "title": key[0].title,
                    "author": key[0].author,
                    "action": $rootScope.metaShAction
                })
            })
            var metaShelfName = "";
            var metaShelfdocId = "";
            if ($rootScope.saveshelfList != undefined && $rootScope.saveshelfList != "")
                if ($rootScope.saveshelfList.length > 0) {
                    angular.forEach($rootScope.saveshelfList, function(value) {
                        if ($scope.metaShelfData.metaShelfName === value.name) {
                            metaShelfName = value.name;
                            metaShelfdocId = value.docId;
                            return !1
                        }
                    })
                }
            if (metaShelfName === $scope.metaShelfData.metaShelfName) {
                $http({
                    method: 'POST',
                    url: '/saveShelfDetails',
                    data: {
                        docId: metaShelfdocId,
                        name: $scope.metaShelfData.metaShelfName,
                        comments: $scope.metaShelfComments,
                        remainder: $scope.metaShelfRemainderList,
                        shelfType: "Meta_Book",
                        updatedBy: $scope.metaUpdatedBy,
                        shelfdetails: $scope.metaShelfDetails
                    }
                }).then(function(response) {
                    $scope.getShelf();
                    angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                    angular.element($(".self-content")).css("display", "none");
                    if (response.data.code == '200') {
                        $scope.metaSaveShelfUpdateSucess = !0;
                        $scope.metaSaveShelfUpdateSucessMsg = "META_SHELF_UPDATE_SUCCESSFULLY";
                        setTimeout(function() {
                            $scope.metaSaveShelfUpdateSucess = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    } else {
                        $scope.metaSaveShelfUpdateErr = !0;
                        $scope.metaSaveShelfUpdateErrMsg = "META_SHELF_UPDATE_ERROR";
                        setTimeout(function() {
                            $scope.metaSaveShelfUpdateErr = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                }, function errorCallback(error) {})
            } else {
                $http({
                    method: 'POST',
                    url: '/saveShelfDetails',
                    data: {
                        name: $scope.metaShelfData.metaShelfName,
                        comments: $scope.metaShelfComments,
                        remainder: $scope.metaShelfRemainderList,
                        shelfType: "Meta_Book",
                        updatedBy: $scope.metaUpdatedBy,
                        shelfdetails: $scope.metaShelfDetails
                    }
                }).then(function(response) {
                    $scope.getShelf();
                    angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                    angular.element($(".self-content")).css("display", "none");
                    if (response.data.code == '200') {
                        $scope.metaSaveShelfSucess = !0;
                        $scope.metaSaveShelfSucessMsg = "META_SHELF_SAVE_SUCCESSFULLY";
                        setTimeout(function() {
                            $scope.metaSaveShelfSucess = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    } else {
                        $scope.metaSaveShelfErr = !0;
                        $scope.metaSaveShelfErrMsg = "META_SHELF_SAVE_ERROR";
                        setTimeout(function() {
                            $scope.metaSaveShelfErr = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                }, function errorCallback(error) {})
            }
        } else {
            $scope.metaShelfActonChk = !0;
            return !1
        }
        $timeout(function() {
            $scope.metashelfReset()
        });
        $scope.metaShowShelfError = !1
    }
    $scope.metaShelfNameErr = function() {
        $scope.metaShowShelfError = !0
    }
    $scope.metashelfReset = function() {
        $scope.metaShelfData.metaShelfName = null;
        $scope.metaShelfRemainderList = "";
        $scope.metaShelfComments = "";
        $scope.metaShelfActionList = [];
        document.getElementById("tempbucketerr").innerHTML = "";
        document.getElementById("shelfComments").value = "";
        angular.forEach($rootScope.shelfActivityMetaLists, function(shelfAction) {
            document.getElementById("metaShelf_" + shelfAction.activityName).checked = !1
        })
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        angular.element($(".self-content")).css("display", "none");
        $scope.metaShowShelfError = !1;
        angular.element($(".shelfactionselect")).removeClass("shelfactionselect-disable");
        angular.element($(".shelf-remain")).removeClass("non-editable")
    }
    $rootScope.exportPartner = !1;
$rootScope.exportFormat = null;
    $rootScope.partnerExport = function() {
        document.getElementById("tempbucketerr").innerHTML = "";
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        angular.element("#partnerExport").modal('toggle');
        $rootScope.isbnList = [];
        $rootScope.partnerListId = [];
        angular.forEach($rootScope.downloadMetaUploadList, function(key, value) {
            $rootScope.isbnList.push(key[0].isbn)
        });
        $http({
            method: 'GET',
            url: '/getPartners/' + $rootScope.exportPartner  +'/' + $rootScope.exportFormat
        }).then(function successCallback(response) {
            $rootScope.exportPartnerList = response.data.data;
            angular.forEach($rootScope.exportPartnerList, function(partner) {
                partner.pEChecked = !1
            })
        }, function errorCallback(response) {})
    }
    $rootScope.expPartList = {};
    $rootScope.expSearchPart = [];
    $rootScope.partnerFilterDataList = function() {
        var container = angular.element("#dropdown-status-set");
        container[0].scrollTop = 0;
        var filteredList = $filter('filter')($rootScope.exportPartnerList, function(data) {
            var re = new RegExp($rootScope.search.partnerSearch, 'gi');
            return (data.isActive == !0 && data.partnerName.match(re))
        });
        $timeout(function() {
            $rootScope.exportAllPartnerTypeChecked = filteredList.every(function(itm) {
                return itm.pEChecked
            }) && filteredList.length > 0;
            document.getElementById("exportPartSelectAll").checked = $rootScope.exportAllPartnerTypeChecked
        }, 50)
    }
    $scope.exportPartnerSlct = function(distributionlist, chk) {
        var filteredList = $filter('filter')($rootScope.exportPartnerList, function(data) {
            var re = new RegExp($rootScope.search.partnerSearch, 'gi');
            return (data.isActive == !0 && data.partnerName.match(re))
        });
        $rootScope.partnerSelectErr = !1;
        if (chk.target.checked) {
            $rootScope.expPartList[distributionlist.partnerId] = distributionlist;
            $rootScope.expSearchPart.push(distributionlist.partnerName)
        } else {
            delete $rootScope.expPartList[distributionlist.partnerId];
            $rootScope.expSearchPart = $filter('filter')($rootScope.expSearchPart, function(data) {
                return data != distributionlist.partnerName
            });
            document.getElementById("exportPartSelectAll").checked = !1
        }
        if (filteredList.length === Object.keys($rootScope.expPartList).length) {
            document.getElementById("exportPartSelectAll").checked = !0;
            $rootScope.exportAllPartnerTypeChecked = !0
        } else {
            document.getElementById("exportPartSelectAll").checked = !1;
            $rootScope.exportAllPartnerTypeChecked = !1
        }
    }
    $rootScope.expPartTypeRemove = function(rmvpart, partnerid) {
        delete $rootScope.expPartList[partnerid];
        $rootScope.expSearchPart = $filter('filter')($rootScope.expSearchPart, function(data) {
            return data != rmvpart.partnerName
        });
        document.getElementById("export_" + partnerid).checked = !1;
        document.getElementById("exportPartSelectAll").checked = !1
    }
    $rootScope.exportAllPartnerType = function(event, checkFlg) {
        $rootScope.exportAllPartnerTypeChecked = checkFlg;
        var filteredList = $filter('filter')($rootScope.exportPartnerList, function(data) {
            var re = new RegExp($rootScope.search.partnerSearch, 'gi');
            return (data.isActive == !0 && data.partnerName.match(re))
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(partner) {
                partner.pEChecked = !0;
                if ($filter('filter')($rootScope.exportPartnerList, function(data) {
                        return data.partnerId == partner.partnerId
                    })) {
                    $rootScope.expPartList[partner.partnerId] = partner;
                    $rootScope.expSearchPart.push(partner.partnerName)
                }
            })
        } else {
            angular.forEach(filteredList, function(partner) {
                partner.pEChecked = !1;
                delete $rootScope.expPartList[partner.partnerId];
                $rootScope.expSearchPart = $filter('filter')($rootScope.expSearchPart, function(data) {
                    return data != partner.partnerName
                })
            })
        }
    }
    $rootScope.exportPartnerReset = function() {
        $rootScope.expPartList = {};
        $rootScope.expSearchPart = [];
        document.getElementById("exportPartSelectAll").checked = !1;
        $rootScope.search.partnerSearch = '';
        var container = angular.element("#dropdown-status-set");
        container[0].scrollTop = 0;
        var container1 = angular.element("#searchdataheight");
        container1[0].scrollTop = 0
    }
    $rootScope.exportPartnerData = function() {
        $rootScope.partnerListId = [];
        angular.forEach($rootScope.expPartList, function(key) {
            $rootScope.partnerListId.push(key.partnerId)
        });
        $http({
            method: 'POST',
            url: '/partneronixexport',
            data: {
                isbnList: $rootScope.isbnList,
                partnerList: $rootScope.partnerListId
            }
        }).then(function(response) {
            $rootScope.distHostoryData = response.data.data;
            if (response.data.code == '200') {
                $scope.exportPartSucessMsg = "SUCCESS_REQUEST";
                $scope.exportPartSucess = !0;
                angular.element('#partnerExport').modal('toggle');
                setTimeout(function() {
                    $scope.exportPartSucess = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $rootScope.expPartList = {};
                $rootScope.expSearchPart = [];
                document.getElementById("exportPartSelectAll").checked = !1
            } else {
                $scope.exportPartErrMsg = "FAILURE_REQUEST";
                $scope.exportPartErr = !0;
                setTimeout(function() {
                    $scope.exportPartSucess = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $rootScope.search.partnerSearch = '';
                $rootScope.expPartList = {};
                $rootScope.expSearchPart = [];
                document.getElementById("exportPartSelectAll").checked = !1
            }
        }, function errorCallback(error) {})
    }
    $scope.uncheckMetaItem = function($event, isbn, title, author, format, formatSize, formatId) {
        document.getElementById("tempbucketerr").innerHTML = "";
        $rootScope.errorRibbon = !1;
        $scope.shelfActonChk = !1;
        $scope.shelfDownErr = !1;
        $rootScope.emptyRibbon = !1;
        $rootScope.drmChkErr = !1;
        $scope.metaShelfActonChk = !1;
        $rootScope.downloadMetaUploadList = {};
        $rootScope.selectedMetaCheckCount = 0;
        $timeout(function() {
            angular.forEach($rootScope.metaDataMap, function(key, value) {
                if (document.getElementById("metaBucket_" + key[0].isbn).checked) {
                    $rootScope.selectedMetaCheckCount++;
                    $rootScope.downloadMetaUploadList[$rootScope.selectedMetaCheckCount] = key
                }
            })
        }, 300)
    };
    $rootScope.selectedMetaCount = 0;
    $rootScope.selectedMetaCheckCount = 0;
    $rootScope.metaDataMap = {};
    if (localStorage.getItem('selectedMetaData') != "" && localStorage.getItem('selectedMetaData') != null) {
        $rootScope.metaDataMap = JSON.parse(localStorage.getItem("selectedMetaData"));
        $rootScope.selectedMetaCount = Object.keys($rootScope.metaDataMap).length;
        $rootScope.selectedMetaCheckCount = Object.keys($rootScope.metaDataMap).length;
        angular.forEach($rootScope.metaDataMap, function(key, value) {
            $timeout(function() {
                if (key[0].isbn != null || key[0].isbn != undefined) {
                    if (document.getElementById("metaBucket_" + key[0].isbn))
                        document.getElementById("metaBucket_" + key[0].isbn).checked = !0
                }
            }, 200)
        });
        $rootScope.downloadMetaUploadList = angular.copy($rootScope.metaDataMap);
        localStorage.setItem('popup', angular.element($(".collection-drawer-mixin")).addClass('show-alert-view'))
    }
    $scope.showMetaCheckBox = function() {
        angular.forEach($rootScope.metaDataMap, function(key, value) {
            $timeout(function() {
                if (key[0].isbn != null && key[0].isbn != undefined && key[0].isbn != '') {
                    if (document.getElementById("meta_" + key[0].isbn)) {
                        document.getElementById("meta_" + key[0].isbn).checked = !0
                    }
                }
            }, 200)
        })
    };
    $scope.showMetaCheckBox();
    $scope.updateMetaCheckBox = function($event, result) {
        $rootScope.metaHideAction = !0;
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        var checkbox = $event.target;
        $scope.reportSent = !0;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            $scope.temp = [];
            $scope.temp.push({
                "isbn": result.ISBN13,
                "title": result.Title,
                "author": result.Author
            });
            $timeout(function() {
                document.getElementById("metaBucket_" + result.ISBN13).checked = !0
            }, 200);
            $rootScope.metaDataMap[result.ISBN13] = $scope.temp;
            localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap))
        } else if (action === 'remove') {
            delete $rootScope.metaDataMap[result.ISBN13];
            localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap));
            $scope.reportSent = !1
        }
        $rootScope.selectedMetaCheckCount = 0;
        $rootScope.downloadMetaUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.metaDataMap, function(key, value) {
                if (document.getElementById("metaBucket_" + key[0].isbn).checked) {
                    $rootScope.selectedMetaCheckCount++;
                    $rootScope.downloadMetaUploadList[$rootScope.selectedMetaCheckCount] = key
                }
            })
        }, 300);
        $rootScope.selectedMetaCount = 0;
        angular.forEach($rootScope.metaDataMap, function(key, value) {
            $rootScope.selectedMetaCount++
        });
        if (document.getElementById("checkAll"))
            document.getElementById("checkAll").checked = ($rootScope.selectedMetaCount === $rootScope.searchResult.length)
    };
    if ($rootScope.downloadMetaUploadList == null) {
        $rootScope.metaHideAction = !0
    } else if (Object.keys($rootScope.metaDataMap).length > 0) {
        $rootScope.metaHideAction = !0
    } else {
        $rootScope.metaHideAction = !1
    }
    $scope.updateAllMetaCheckBox = function($event, result) {
        $rootScope.downloadMetaUploadList = {};
        $scope.reportSent = !0;
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        var isbnId;
        var title;
        var authoer;
        if (action === 'add') {
            angular.forEach(result, function(value) {
                $scope.temp = [];
                $scope.temp.push({
                    "isbn": value.ISBN13,
                    "title": value.Title,
                    "author": value.Author
                });
                $rootScope.metaDataMap[value.ISBN13] = $scope.temp;
                localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap));
                $timeout(function() {
                    document.getElementById("metaBucket_" + value.ISBN13).checked = !0
                }, 200);
                document.getElementById("meta_" + value.ISBN13).checked = !0
            })
        } else if (action === 'remove') {
            angular.forEach(result, function(value) {
                document.getElementById("meta_" + value.ISBN13).checked = !1
            });
            $rootScope.metaDataMap = {};
            localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap))
        }
        $rootScope.selectedMetaCheckCount = 0;
        $rootScope.downloadMetaUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.metaDataMap, function(key, value) {
                if (document.getElementById("metaBucket_" + key[0].isbn).checked) {
                    $rootScope.selectedMetaCheckCount++;
                    $rootScope.downloadMetaUploadList[$rootScope.selectedMetaCheckCount] = key
                }
            });
            $rootScope.metaHideAction = !0
        }, 300);
        $rootScope.selectedMetaCount = 0;
        angular.forEach($rootScope.metaDataMap, function(key, value) {
            $rootScope.selectedMetaCount++
        })
    }
    $scope.removeMetaItem = function(itemIndex, isbn, format, formatSize, formatId) {
        document.getElementById("tempbucketerr").innerHTML = "";
        var temp = {};
        temp = $rootScope.metaDataMap;
        delete $rootScope.metaDataMap[isbn];
        if (null != document.getElementById("meta_" + isbn))
            document.getElementById("meta_" + isbn).checked = !1;
        localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap));
        $rootScope.selectedMetaCount--;
        document.getElementById("checkAll").checked = !1;
        if ($rootScope.selectedMetaCount == 0) {
            angular.element($(".collection-drawer-mixin")).removeClass('show-alert-view');
            $rootScope.metaDataMap = {};
            localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap))
        }
        $rootScope.selectedMetaCheckCount = 0;
        $rootScope.downloadMetaUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.metaDataMap, function(key, value) {
                if (document.getElementById("metaBucket_" + key[0].isbn).checked) {
                    $rootScope.selectedMetaCheckCount++;
                    $rootScope.downloadMetaUploadList[$rootScope.selectedMetaCheckCount] = key
                }
            })
        }, 300)
    }
    $scope.ClearMetaBucket = function() {
        angular.forEach($rootScope.metaDataMap, function(key, value) {
            if (document.getElementById("meta_" + key[0].isbn) != undefined)
                document.getElementById("meta_" + key[0].isbn).checked = !1
        });
        angular.element($(".collection-drawer-mixin")).removeClass('show-alert-view');
        document.getElementById("checkAll").checked = !1;
        $rootScope.metaDataMap = {};
        localStorage.setItem("selectedMetaData", JSON.stringify($rootScope.metaDataMap));
        $rootScope.selectedMetaCount = 0;
        $rootScope.downloadMetaUploadList = {};
        $rootScope.isbnValues = [];
        localStorage.getItem('isbnValues', $rootScope.isbnValues);
        $scope.metashelfReset()
    }
}]);