var searchBrData = {};
app.controller('businessController', ['$scope', '$http', '$timeout', '$rootScope', '$location', "$route", "$window", "ModalService", "$compile", function($scope, $http, $timeout, $rootScope, $location, $route, $window, ModalService, $compile) {
    if ($rootScope.language === 'en') {
        $rootScope.brSel = 'Select';
        $rootScope.brCreate = 'Create';
        $rootScope.brUpdate = 'Update'
    } else {
        $rootScope.brSel = 'Sélectionner';
        $rootScope.brCreate = 'Créer';
        $rootScope.brUpdate = 'Mettre à jour'
    }
    $rootScope.isScroll = !1;
    $rootScope.distMetaError = !1;
    $rootScope.prefMetaError = !1;
    $rootScope.testScroll();
    $rootScope.createDisable = !1;
    $rootScope.editDisable = !1;
    $rootScope.currentIndexLast = 0;
    $rootScope.currentIndex = 0;
    $scope.ruleTypeError = !1;
    $scope.ruleNameError = !1;
    $scope.metaDataError = !1;
    $scope.accountError = !1;
    $scope.vendorError = !1;
    $scope.triggerError = !1;
    $scope.shipError = !1;
    $rootScope.distribution = !1;
    $rootScope.operationShow = !0;
    $rootScope.ruleTypeDisabled = !1;
    $rootScope.vendorDisabled = !0;
    $rootScope.ruleType = angular.copy($rootScope.brSel)
    $rootScope.metadataType = angular.copy($rootScope.brSel)
    $rootScope.dateToStart = angular.copy($rootScope.brSel)
    $rootScope.shipDate = !1;
    $rootScope.trigerDays = !1;
    $rootScope.preflight = !1;
    $rootScope.dateSelect = "";
    $rootScope.addBrule = !0;
    $rootScope.updateBrule = !1;
    $rootScope.formats;
    $rootScope.users;
    $rootScope.acntId;
    $rootScope.accountType = angular.copy($rootScope.brSel);
    $rootScope.userSelect = angular.copy($rootScope.brSel);
    $rootScope.formatSelect = [];
    $rootScope.prefSelect = angular.copy($rootScope.brSel);
    $rootScope.operationSelect = angular.copy($rootScope.brSel);
    $rootScope.vendor = angular.copy($rootScope.brSel);
    $rootScope.formatValue = angular.copy($rootScope.brSel);
    $rootScope.approvalValue = angular.copy($rootScope.brSel);
    $rootScope.vendors = [];
    $rootScope.patners = [];
    $rootScope.createEdit = angular.copy($rootScope.brCreate);
    $rootScope.operationalConditions;
    $rootScope.metadataConditions;
    $rootScope.successAddBrMsg;
    $rootScope.failureAddBrMsg;
    $rootScope.selectDistValues = [];
    $rootScope.selectPrefValues = [];
    $rootScope.successAddBrMsgContent;
    $rootScope.failureAddBrMsgContent;
    $rootScope.action = "Create";
    $rootScope.showLoader($('.app-content'), 1, 'win8_linear');
    $http({
        method: 'GET',
        url: '/getAccounts'
    }).then(function successCallback(response) {
        $rootScope.accountList = response.data.data.accountList;
        angular.forEach($rootScope.accountList, function(acdata) {
            searchBrData[acdata.accountId] = "accountId"
        });
        if (Object.keys(searchBrData).length == $rootScope.accountList.length) {
            $http({
                method: 'POST',
                url: '/getColumnSearchData',
                data: {
                    columnSearchData: searchBrData,
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.dataList = response.data.data;
                $rootScope.hideLoader('app-content')
            })
        }
    }, function errorCallback(response) {
        console.log('Error status: ' + response.status)
    });
    $http({
        method: 'GET',
        url: '/getMetaDataDateTypes',
        data: null
    }).then(function(response) {
        $rootScope.dataTypeList = response.data.data
    });
    $http({
        method: 'GET',
        url: '/getAllLookUpValues',
        data: null
    }).then(function(response) {
        $rootScope.productsList = response.data.data
    });
    $scope.clearScope = function() {
        $rootScope.ruleName = "";
        $rootScope.description = "";
        $scope.trigger = "";
        $rootScope.action = "Create"
    }
    $scope.showCreate = function() {
        var check = !1;
        if (check) {}
    }
    $rootScope.ruleTypeDrp = [];
    $rootScope.vendorDrp = [];
    $rootScope.descDrp = [];
    var timeout = null;
    $scope.ruleTypeHeader = function(other, fieldName, suggestTxt, lookup) {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.ruleRuleTypeHeader(fieldName, suggestTxt, lookup)
        }, 800)
    }
    $scope.ruleRuleTypeHeader = function() {
        var searchName = $scope.typeSearch;
        if (searchName.length >= 3) {
            var typeSearchData = {};
            typeSearchData[searchName] = "ruleType";
            $http({
                method: 'POST',
                url: '/getColumnSearchFilterData',
                data: {
                    columnSearchData: typeSearchData,
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.ruleTypeDrp = response.data.data
            })
        }
    }
    $scope.brExport = function(exportType) {
        $scope.successAddBrMsg = !0;
        $scope.successAddBrMsgContent = "Export request placed successfully";
        setTimeout(function() {
            $scope.successAddBrMsg = !1;
            $scope.$apply()
        }, $rootScope.alertTimeoutInterval);
        $scope.expAccountIds = [];
        $http({
            method: 'GET',
            url: '/getAccounts',
            data: null
        }).then(function(response) {
            $rootScope.accData = response.data.data.accountList;
            angular.forEach($rootScope.accData, function(acdata) {
                $scope.expAccountIds.push(acdata.accountId)
            });
            if ($rootScope.accData.length == $scope.expAccountIds.length) {
                $http({
                    method: 'POST',
                    url: '/exportBr',
                    data: {
                        accountIds: $scope.expAccountIds,
                        userId: $rootScope.loggedUser.userId,
                        exportFormat:exportType.type
                    }
                }).then(function(response) {
                    $rootScope.getDownloadNotification();
                    if (response.data.code == '200') {
                        $scope.successAddBrMsg = !0;
                        $scope.successAddBrMsgContent = response.data.statusMessage;
                        setTimeout(function() {
                            $scope.successAddBrMsg = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    } else {
                        $scope.failureAddBrMsg = !0;
                        $scope.failureAddBrMsgContent = response.data.statusMessage;
                        setTimeout(function() {
                            $scope.failureAddBrMsg = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                })
            }
        })
    }
    var timeout = null;
    $scope.vendorHeader = function(other, fieldName, suggestTxt, lookup) {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.callVendorHeader(fieldName, suggestTxt, lookup)
        }, 800)
    }
    $scope.callVendorHeader = function() {
        var searchName = $scope.vendorSearch;
        if (searchName.length >= 3) {
            $scope.accountIds = [];
            $http({
                method: 'GET',
                url: '/getAccounts',
                data: null
            }).then(function(response) {
                $rootScope.accData = response.data.data.accountList;
                angular.forEach($rootScope.accData, function(acdata) {
                    $scope.accountIds.push(acdata.accountId)
                })
                $http({
                    method: 'POST',
                    url: '/getVendorData',
                    data: {
                        searchText: searchName,
                        accountIds: $scope.accountIds,
                        userId: $rootScope.loggedUser.userId
                    }
                }).then(function(response) {
                    $rootScope.vendorDrp = response.data.data
                })
            })
        }
    }
    var timeout = null;
    $scope.descriptionHeader = function(other, fieldName, suggestTxt, lookup) {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.callDescriptionHeader(fieldName, suggestTxt, lookup)
        }, 800)
    }
    $scope.callDescriptionHeader = function() {
        var searchName = $scope.desSearch;
        if (searchName.length >= 3) {
            var descSearchData = {};
            descSearchData[searchName] = "description";
            $http({
                method: 'POST',
                url: '/getColumnSearchFilterData',
                data: {
                    columnSearchData: descSearchData
                }
            }).then(function(response) {
                $rootScope.descDrp = response.data.data
            })
        }
    }
    $scope.searchBR = function(searchName, key, event) {
        if ($scope.ruleTypeDrp.length > 0) {
            $scope.ruleCheckall = $scope.ruleTypeDrp.every(function(item0) {
                return item0.selected
            })
        }
        if ($scope.vendorDrp.length > 0) {
            $scope.vendorCheckall = $scope.vendorDrp.every(function(item1) {
                return item1.selected
            })
        }
        if ($scope.descDrp.length > 0) {
            $scope.descCheckall = $scope.descDrp.every(function(item2) {
                return item2.selected
            })
        }
        if (null != searchName && undefined != searchName) {
            isChecked = event.target.checked;
            if (isChecked) {
                searchBrData[searchName] = key
            } else {
                delete searchBrData[searchName]
            }
        }
        $http({
            method: 'POST',
            url: '/getColumnSearchData',
            data: {
                columnSearchData: searchBrData,
                userId: $rootScope.loggedUser.userId
            }
        }).then(function(response) {
            $rootScope.dataList = response.data.data
        })
    }
    $scope.ruletypeCheckAll = function() {
        var chk = $scope.ruleCheckall;
        angular.forEach($scope.ruleTypeDrp, function(rdata) {
            rdata.selected = chk;
            if (chk) {
                searchBrData[rdata.ruleType] = "ruleType"
            } else {
                delete searchBrData[rdata.ruleType]
            }
        });
        $scope.searchBR(null, null)
    }
    $scope.vendorCheckAll = function() {
        var chk = $scope.vendorCheckall;
        angular.forEach($scope.vendorDrp, function(vdata) {
            vdata.selected = chk;
            if (chk) {
                searchBrData[vdata.customer] = "customer"
            } else {
                delete searchBrData[vdata.customer]
            }
        });
        $scope.searchBR(null, null)
    }
    $scope.descCheckAll = function() {
        var chk = $scope.descCheckall;
        angular.forEach($scope.descDrp, function(desdata) {
            desdata.selected = chk;
            if (chk) {
                searchBrData[desdata.description] = "description"
            } else {
                delete searchBrData[desdata.description]
            }
        });
        $scope.searchBR(null, null)
    }
    $rootScope.checkRuleName = function() {
        if ($scope.ruleName != "") {
            if ($scope.ruleName != undefined) {
                $http({
                    method: 'POST',
                    url: '/checkRule',
                    data: {
                        ruleName: $scope.ruleName
                    }
                }).then(function(response) {
                    if (response.data.code === "200") {
                        $scope.successBrMsg = !0;
                        $scope.successRuleMessgae = response.data.statusMessage
                    } else {
                        $scope.failureBrMsg = !0;
                        $rootScope.failuerRuleMessgae = response.data.statusMessage
                    }
                })
            }
        }
        $rootScope.createDisable = !1;
        $rootScope.editDisable = !1
    }
    $scope.setBrRoleTypeFocus = function() {
        setTimeout(function() {
            angular.element('#roleTypeTerm').trigger('focus')
        }, 10)
    }
    $scope.setBrAccountFocus = function() {
        setTimeout(function() {
            angular.element('#brAcntType').trigger('focus')
        }, 10)
    }
    $scope.setBrMetadataFocus = function() {
        setTimeout(function() {
            angular.element('#brMetadata').trigger('focus')
        }, 10)
    }
    $scope.setBrVendorFocus = function() {
        setTimeout(function() {
            angular.element('#brVendor1').trigger('focus')
        }, 50)
    }
    $scope.setBrPubDateFocus = function() {
        setTimeout(function() {
            angular.element('#brPubDate').trigger('focus')
        }, 10)
    }
    $scope.checkBrType = function() {
        $rootScope.createDisable = !1;
        $rootScope.editDisable = !1;
        if ($rootScope.ruleType == $rootScope.brSel || $rootScope.ruleType == undefined) {}
    }
    $scope.distMetaDataAll = function() {}
    $rootScope.operations = [];
    $scope.operationClick = function(name, event) {
        var check = !1;
        if (!event.target.checked) {
            var s = name + '_00';
            if (null != document.getElementById(s)) {
                document.getElementById(s).remove();
                $rootScope.oppFinalValues.splice($rootScope.oppFinalValues.indexOf(name), 1)
            }
            $rootScope.oppValues.splice($rootScope.oppValues.indexOf(name), 1)
        }
        var name1 = "OC_" + name;
        $timeout(function() {
            var opCount = 0;
            angular.forEach($rootScope.operationalConditions, function(data) {
                var s = "OC_" + data.conditionDisplayName;
                if (document.getElementById(s).checked) {
                    check = !0;
                    opCount++
                } else {
                    check = !1;
                    opCount--
                }
            });
            if (opCount === $rootScope.operationalConditions.length) {
                document.getElementById("operationS").checked = !0
            } else {
                document.getElementById("operationS").checked = !1
            }
            if (angular.element(document.getElementById(name1))[0].checked) {
                if ($rootScope.operations.indexOf(name) == -1) {
                    $rootScope.operations.push(name)
                }
            } else {
                $rootScope.operations.splice($rootScope.operations.indexOf(name), 1)
            }
        }, 50)
    }
    $scope.input = {};
    $scope.opp = {};
    $scope.groupData = {};
    $rootScope.values = [];
    $rootScope.editValues = [];
    $rootScope.getValue = function(value, groupName, chk, group) {
        group.selected = group.metadataFieldConfig.every(function(item) {
            return item.selected
        });
        $scope.prefAllMeta = $rootScope.metadataConditions1.every(function(item) {
            return item.selected
        });
        if (!chk) {
            var s = value + '_00';
            if (null != document.getElementById(s)) {
                document.getElementById(s).remove();
                $rootScope.FinalFields.splice($rootScope.FinalFields.indexOf(value), 1)
            }
            $rootScope.selectPrefValues.splice($rootScope.selectPrefValues.indexOf(value), 1)
        } else if (chk) {
            if ($rootScope.selectPrefValues.indexOf(value) === -1) {
                $rootScope.selectPrefValues.push(value)
            }
        }
    }
    $scope.distValue = function(name, groupName, chk, group, fieldName) {
        group.selected = group.metadataFieldConfig.every(function(item) {
            return item.selected
        });
        $scope.distributionAllMeta = $rootScope.metadataConditions.every(function(item) {
            return item.selected
        });
        if (!chk) {
            var s = fieldName + '_00';
            if (null != document.getElementById(s)) {
                document.getElementById(s).remove()
            }
            var index;
            for (var i = 0; i <= $rootScope.distFinalValues.length; i++) {
                var t = $rootScope.distFinalValues[i].split("_");
                if (t[0] == name) {
                    index = i;
                    break
                }
            }
            $rootScope.distFinalValues.splice(index, 1);
            $rootScope.selectDistValues.splice($rootScope.selectDistValues.indexOf(name), 1);
            $rootScope.distValues.splice($rootScope.distValues.indexOf(name), 1);
            $rootScope.distributionFields.splice($rootScope.distributionFields.indexOf(name), 1);
            if (null != document.getElementById(fieldName + "_0") || undefined != document.getElementById(fieldName + "_0")) {
                document.getElementById(fieldName + "_0").value = ''
            }
        } else {
            if ($rootScope.selectDistValues.indexOf(name) == -1) {
                $rootScope.selectDistValues.push(name)
            }
            if ($rootScope.distValues.indexOf(name) == -1) {
                $rootScope.distValues.push(name)
            }
        }
    }
    $scope.showDateType = function(name) {
        $timeout(function() {
            $rootScope.dateToStart = name
        }, 300)
    }
    $rootScope.vendorIds = [];
    $scope.showVendor = function(name, id) {
        $rootScope.createDisable = !1;
        $rootScope.editDisable = !1;
        $timeout(function() {
            if (angular.element(document.getElementById("ven_" + id))[0].checked) {
                if ($rootScope.vendors.indexOf(name) == -1) {
                    $rootScope.vendors.push(name)
                }
                if ($rootScope.vendorIds.indexOf(id) == -1) {
                    $rootScope.vendorIds.push(id)
                }
            } else {
                $rootScope.vendors.splice($rootScope.vendors.indexOf(name), 1);
                $rootScope.vendorIds.splice($rootScope.vendorIds.indexOf(id), 1)
            }
            var s = "";
            angular.forEach($rootScope.vendors, function(names) {
                if (s == "") {
                    s += names
                } else {
                    s += "," + names
                }
            });
            $rootScope.vendor = s
        }, 100)
    }
    $rootScope.popOut = function(n) {
        $rootScope.values.splice(n, 1);
        angular.element(document.getElementById(n))[0].checked = !1;
        $rootScope.FinalFields.splice(n, 1);
        var groupName;
        $rootScope.selectPrefValues.splice($rootScope.selectPrefValues.indexOf(n), 1);
        angular.forEach($rootScope.metadataConditions, function(key, value) {
            angular.forEach(key.metadataFieldConfig, function(fieldD) {
                if (fieldD.fieldDisplayName === n) {
                    groupName = key.groupName;
                    fieldD.selected = !1
                }
            })
        });
        if (document.getElementById(groupName).checked) {
            document.getElementById(groupName).checked = !1
        }
    }
    $scope.getGrpValue = function(groupD, grpChk) {
        angular.forEach(groupD.metadataFieldConfig, function(data) {
            data.selected = grpChk;
            if (grpChk) {
                if ($rootScope.selectPrefValues.indexOf(data.fieldDisplayName) == -1) {
                    $rootScope.selectPrefValues.push(data.fieldDisplayName)
                }
            } else {
                $rootScope.selectPrefValues.splice($rootScope.selectPrefValues.indexOf(data.fieldDisplayName), 1)
            }
            var s = data.fieldDisplayName + "_00";
            if (null != document.getElementById(s)) {
                document.getElementById(s).remove();
                $rootScope.FinalFields.splice($rootScope.FinalFields.indexOf(data.fieldDisplayName), 1)
            }
        });
        $scope.prefAllMeta = $rootScope.metadataConditions.every(function(item) {
            return item.selected
        })
    }
    $scope.getGrpDistValue = function(groupD, grpChk) {
        angular.forEach(groupD.metadataFieldConfig, function(data) {
            data.selected = grpChk;
            if (grpChk) {
                if ($rootScope.selectDistValues.indexOf(data.fieldDisplayName) == -1) {
                    $rootScope.selectDistValues.push(data.fieldDisplayName)
                }
            } else {
                $rootScope.selectDistValues.splice($rootScope.selectDistValues.indexOf(data.fieldDisplayName), 1);
                $rootScope.distributionFields.splice($rootScope.distributionFields.indexOf(data.fieldDisplayName), 1)
                var s = data.metaDataFieldName + "_00";
                if (null != document.getElementById(s)) {
                    document.getElementById(s).remove();
                    $rootScope.distFinalValues.splice($rootScope.distFinalValues.indexOf(data.fieldDisplayName), 1)
                }
            }
        });
        $scope.distributionAllMeta = $rootScope.metadataConditions.every(function(item) {
            return item.selected
        })
    }
    $rootScope.FinalFields = [];
    $scope.showPreflight = function() {
        var divs = "";
        angular.forEach($rootScope.metadataConditions1, function(fields) {
            angular.forEach(fields.metadataFieldConfig, function(fieldD) {
                if (fieldD.selected) {
                    if ($rootScope.FinalFields.indexOf(fieldD.fieldDisplayName) == -1) {
                        $rootScope.prefMetaError = !1;
                        var div = "<div class='row-border-box row-label' id='" + fieldD.fieldDisplayName + "_00'> " + "<div class='form-col-3 margin-left-right-5'> " + "</div> <div class='form-col-1 margin-left-right-10'> </div> " + "<div class='form-col-2 margin-left-right-10 margin-bottom-10'> " + "<div class='metadata-list-name'>" + fieldD.fieldDisplayName + "</div> </div> " + "<div class='form-col-9 margin-left-right-5 pull-right'> <span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"popOut('" + fieldD.fieldDisplayName + "')\"><i class='cp-close'></i></button></span> " + "</div> </div>";
                        divs += div;
                        $rootScope.FinalFields.push(fieldD.fieldDisplayName)
                    }
                }
            })
        });
        var temp = $compile(divs)($scope);
        angular.element(document.getElementById('preflightText')).append(temp)
    }
    $rootScope.editPreflightData = function(prefData) {
        var keys = "";
        var prefDivs = "";
        $rootScope.trigerDays = !0;
        $rootScope.shipDate = !0;
        $rootScope.distribution = !1;
        $rootScope.preflight = !0;
        $rootScope.binding = !1;
        angular.forEach(prefData, function(key, value) {
            prefDivs += "<div class='row-border-box row-label' id='" + JSON.stringify(value) + "_00'> " + "<div class='form-col-3 margin-left-right-10'> </div> " + "<div class='form-col-2 margin-left-right-10 margin-bottom-10'> " + "<div class='metadata-list-name'>" + JSON.stringify(value) + "</div>" + " </div> <div class='form-col-9 margin-left-right-5 pull-right'> <span>" + "<button type='button' class='form-row-close-btn'><i class='cp-close'>" + "</i></button></span> </div> </div>"
        });
        var editPref = $compile(prefDivs)($scope);
        angular.element(document.getElementById('editPreflightText')).append(editPref)
    }
    $rootScope.oppValues = [];
    $rootScope.oppPopOut = function(name, ch) {
        if (ch === 'user') {
            $rootScope.userSelect = 'Select';
            $rootScope.userrId = ''
        } else if (ch == 'pref') {
            $rootScope.prefSelect = angular.copy($rootScope.brSel)
        } else if (ch === 'approval') {
            $rootScope.approvalValue = angular.copy($rootScope.brSel);
            $rootScope.approvalValueId = ''
        }
        var s = name + '_00';
        if (null != document.getElementById(s)) {
            document.getElementById(s).remove();
            $rootScope.oppFinalValues.splice($rootScope.oppFinalValues.indexOf(name), 1)
        }
        $rootScope.oppValues.splice($rootScope.oppValues.indexOf(name), 1);
        var opCount = 0;
        angular.forEach($rootScope.operationalConditions, function(data) {
            var s = "OC_" + data.conditionDisplayName;
            if (document.getElementById(s).checked) {
                check = !0;
                opCount++
            } else {
                check = !1;
                opCount--
            }
        });
        document.getElementById("operationS").checked = !1;
        var value = name.split("_");
        angular.element(document.getElementById("OC_" + value[0]))[0].checked = !1;
        $rootScope.oppValues.splice($rootScope.oppValues.indexOf(name), 1);
        if (value[0] == "Format") {
            $rootScope.formatSelect = [];
            $rootScope.formatValue = angular.copy($rootScope.brSel)
        }
        $rootScope.operations.splice($rootScope.operations.indexOf(value[0]), 1);
        $rootScope.oppFinalValues.splice($rootScope.oppFinalValues.indexOf((value[0]), 1))
    }
    $rootScope.replaceAll = function(str, find, replace) {
        return str.replace(new RegExp(find, 'g'), replace)
    }
    $rootScope.spanClickevent = function(event, spId, metaCnds) {
        var ss = angular.element(event.target).text();
        $(spId).html(ss);
        if (ss == "Between") {
            var content = angular.element(event.target).closest('.conditions').next().clone();
            var tempContent = content[0].outerHTML;
            var finalContent = $rootScope.replaceAll(tempContent, metaCnds, metaCnds + "_1");
            var data = $compile(finalContent)($rootScope);
            angular.element(event.target).closest('.conditions').next().after(data)
        }
    }
    $rootScope.spanCondevent = function($event, spId) {
        var ss = angular.element(event.target).text();
        $(spId).html(ss)
    }
    $rootScope.spanOppsEvent = function($event, spId) {
        var ss = angular.element(event.target).text();
        $(spId).html(ss)
    }
    $scope.qwerty = "Select";
    $rootScope.distValues = [];
    $rootScope.distFinalValues = [];
    $scope.preflightSelectAll = function(event) {
        angular.forEach($rootScope.metadataConditions1, function(grp) {
            grp.selected = $scope.prefAllMeta;
            angular.forEach(grp.metadataFieldConfig, function(data) {
                data.selected = $scope.prefAllMeta;
                var s = data.fieldDisplayName + "_00";
                if ($scope.prefAllMeta) {
                    if ($rootScope.selectPrefValues.indexOf(data.fieldDisplayName) == -1) {
                        $rootScope.selectPrefValues.push(data.fieldDisplayName)
                    }
                } else {
                    $rootScope.selectPrefValues.splice($rootScope.selectPrefValues.indexOf(data.fieldDisplayName), 1)
                }
                if (null != document.getElementById(s)) {
                    document.getElementById(s).remove();
                    $rootScope.FinalFields.splice($rootScope.FinalFields.indexOf(data.fieldDisplayName), 1)
                }
            })
        })
    }
    $rootScope.selectAllFormats = function(event) {
        $timeout(function() {
            var checkbox = event.target;
            var action = (checkbox.checked ? 'add' : 'remove');
            if (action === 'add') {
                angular.forEach($rootScope.formats, function(fields) {
                    document.getElementById("F_" + fields.formatId).checked = !0;
                    $rootScope.formatSelect.push(fields.formatName)
                })
            } else if (action === 'remove') {
                angular.forEach($rootScope.formats, function(field) {
                    angular.forEach($rootScope.formatSelect, function(fields) {
                        if (field.formatName === fields) {
                            document.getElementById("F_" + field.formatId).checked = !1
                        }
                    })
                });
                $rootScope.formatSelect = []
            }
        }, 200)
    }
    $scope.vendorSelectAll = function(event) {
        $timeout(function() {
            var checkbox = event.target;
            var action = (checkbox.checked ? 'add' : 'remove');
            if (action === 'add') {
                angular.forEach($rootScope.patners, function(fields) {
                    document.getElementById("ven_" + fields.partnerId).checked = !0;
                    if ($rootScope.vendors.indexOf(fields.partnerName) == -1) {
                        $rootScope.vendors.push(fields.partnerName)
                    }
                    if ($rootScope.vendorIds.indexOf(fields.partnerId) == -1) {
                        $rootScope.vendorIds.push(fields.partnerId)
                    }
                    var s = "";
                    angular.forEach($rootScope.vendors, function(names) {
                        if (s == "") {
                            s += names
                        } else {
                            s += "," + names
                        }
                    });
                    $rootScope.vendor = s
                })
            } else if (action === 'remove') {
                angular.forEach($rootScope.patners, function(fields) {
                    document.getElementById("ven_" + fields.partnerId).checked = !1;
                    $rootScope.vendors = [];
                    $rootScope.vendorIds = [];
                    $rootScope.vendor = ""
                })
            }
        }, 100)
    }
    $scope.operationSelectAll = function(event) {
        var checkbox = event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            angular.forEach($rootScope.operationalConditions, function(value) {
                $rootScope.operations.push(value.conditionDisplayName);
                $scope.opp[value.conditionDisplayName] = !0;
                document.getElementById("OC_" + value.conditionDisplayName).checked = !0
            })
        } else if (action === 'remove') {
            angular.forEach($rootScope.operationalConditions, function(value) {
                $rootScope.operations = [];
                $scope.opp = {};
                var s = value.conditionDisplayName + '_00';
                if (null != document.getElementById(s)) {
                    document.getElementById(s).remove();
                    $rootScope.oppFinalValues.splice($rootScope.oppFinalValues.indexOf(value.conditionDisplayName), 1)
                }
                document.getElementById("OC_" + value.conditionDisplayName).checked = !1
            })
        }
    }
    $scope.distributionSelectAll = function(event) {
        angular.forEach($rootScope.metadataConditions, function(grp) {
            grp.selected = $scope.distributionAllMeta;
            angular.forEach(grp.metadataFieldConfig, function(data) {
                data.selected = $scope.distributionAllMeta;
                var s = data.fieldDisplayName + "_00";
                if ($scope.distributionAllMeta) {
                    if ($rootScope.selectDistValues.indexOf(data.fieldDisplayName) == -1) {
                        $rootScope.selectDistValues.push(data.fieldDisplayName)
                    }
                } else {
                    $rootScope.selectDistValues.splice($rootScope.selectDistValues.indexOf(data.fieldDisplayName), 1);
                    $rootScope.distributionFields.splice($rootScope.distributionFields.indexOf(data.fieldDisplayName), 1)
                }
                if (null != document.getElementById(s)) {
                    document.getElementById(s).remove();
                    $rootScope.distFinalValues.splice($rootScope.distFinalValues.indexOf(data.fieldDisplayName), 1)
                }
            })
        })
    }
    $rootScope.distPopOut = function(name, displayName) {
        var value = name.split("_");
        if (null != document.getElementById(value[0] + "_0") || undefined != document.getElementById(value[0] + "_0")) {
            document.getElementById(value[0] + "_0").value = ''
        }
        document.getElementById("distCheck").checked = !1;
        var groupName = ''
        $rootScope.distValues.splice($rootScope.distValues.indexOf(displayName), 1);
        var index;
        for (var i = 0; i <= $rootScope.distFinalValues.length; i++) {
            var t = $rootScope.distFinalValues[i].split("_");
            if (t[0] == displayName) {
                index = i;
                break
            }
        }
        $rootScope.distFinalValues.splice(index, 1);
        $rootScope.distributionFields.splice($rootScope.distributionFields.indexOf(displayName), 1);
        angular.forEach($rootScope.metadataConditions, function(key, value) {
            angular.forEach(key.metadataFieldConfig, function(fieldD) {
                if (fieldD.fieldDisplayName === displayName) {
                    groupName = key.groupName;
                    fieldD.selected = !1
                }
            })
        });
        if (document.getElementById("Dist_" + groupName).checked) {
            document.getElementById("Dist_" + groupName).checked = !1
        }
        document.getElementById("Dist_" + value[0]).checked = !1;
        $rootScope.selectDistValues.splice($rootScope.selectDistValues.indexOf(displayName), 1)
    }
    $rootScope.distributionFields = [];
    $rootScope.spanDrpClickSelectAll = function(event, spId, id) {
        var s = spId.split("_");
        var data = s[0];
        var selected = [];
        if (event.target.checked) {
            angular.forEach($rootScope.productsList[data], function(value) {
                var idVal = id + "_" + value.code + "_1";
                document.getElementById(idVal).checked = !0;
                selected.push(value.code)
            });
            document.getElementById(spId).innerText = selected;
            document.getElementById(spId).setAttribute('title', selected)
        } else {
            angular.forEach($rootScope.productsList[data], function(value) {
                var idVal = id + "_" + value.code + "_1";
                document.getElementById(idVal).checked = !1;
                selected.splice(selected.indexOf(value.code), 1)
            });
            document.getElementById(spId).innerText = 'Select';
            document.getElementById(spId).setAttribute('title', selected)
        }
    }
    $rootScope.spanDrpClick = function(event, spId, id, code) {
        var sd = spId.split("_");
        $scope.drpv = [];
        if (event.target.checked) {
            if (document.getElementById(spId).innerText === "" || document.getElementById(spId).innerText === $rootScope.brSel) {
                $scope.drpv.push(event.target.value)
                document.getElementById(spId).innerText = $scope.drpv
            } else {
                var ss = document.getElementById(spId).innerText;
                var spl = ss.split(",");
                angular.forEach(spl, function(val) {
                    if ($scope.drpv.indexOf(event.target.value) == -1) {
                        $scope.drpv.push(val)
                    }
                });
                if ($scope.drpv.indexOf(event.target.value) == -1) {
                    $scope.drpv.push(event.target.value)
                }
                document.getElementById(spId).innerText = $scope.drpv
            }
            var count = 0;
            angular.forEach($rootScope.productsList[sd[0]], function(value) {
                if (document.getElementById(sd[1] + "_" + value.code + "_1").checked) {
                    count++
                }
            });
            if (count === $rootScope.productsList[sd[0]].length) {
                document.getElementById(id).checked = !0
            }
            document.getElementById(spId).setAttribute('title', $scope.drpv)
        } else {
            var ss = document.getElementById(spId).innerText;
            var spl = ss.split(",");
            angular.forEach(spl, function(val) {
                $scope.drpv.push(val)
            });
            $scope.drpv.splice($scope.drpv.indexOf(event.target.value), 1);
            if ($scope.drpv.length > 0) {
                document.getElementById(spId).innerText = $scope.drpv
            } else {
                document.getElementById(spId).innerText = $rootScope.brSel
            }
            document.getElementById(id).checked = !1;
            document.getElementById(spId).setAttribute('title', $scope.drpv)
        }
    }
    $rootScope.spanDrpDwnClick = function(event, spId, id) {
        document.getElementById(spId).innerText = document.getElementById(event.target.id).innerText
    }
    $rootScope.editDisableChk = function() {
        var addCondition = !0;
        if ($scope.ruleName == undefined || $scope.ruleName === "") {
            addCondition = !1
        }
        if ($rootScope.metadataType == undefined || $rootScope.metadataType == $rootScope.brSel) {
            addCondition = !1
        }
        if ($rootScope.accountType == undefined || $rootScope.accountType == $rootScope.brSel) {
            addCondition = !1
        }
        if ($rootScope.vendor == undefined || $rootScope.vendor == $rootScope.brSel) {
            addCondition = !1
        }
        if ($rootScope.ruleType == "Pre-flight") {
            if ($scope.trigger == undefined || $scope.trigger == $rootScope.brSel) {
                addCondition = !1
            }
            if ($rootScope.dateToStart == undefined || $rootScope.dateToStart == $rootScope.brSel) {
                addCondition = !1
            }
        }
        return addCondition
    }
    $rootScope.createDisableChk = function() {
        var addCondition = !1;
        if ($rootScope.ruleType === $rootScope.brSel || $rootScope.ruleType === undefined) {
            addCondition = !0
        }
        if ($scope.ruleName == undefined || $scope.ruleName === "") {
            addCondition = !0
        }
        if ($rootScope.metadataType == undefined || $rootScope.metadataType == $rootScope.brSel) {
            addCondition = !0
        }
        if ($rootScope.accountType == undefined || $rootScope.accountType == $rootScope.brSel) {
            addCondition = !0
        }
        if ($rootScope.vendors.length <= 0) {
            addCondition = !0
        }
        if ($rootScope.ruleType == "Pre-flight") {
            if ($scope.trigger == undefined || $scope.trigger == $rootScope.brSel) {
                addCondition = !0
            }
            if ($rootScope.dateToStart == undefined || $rootScope.dateToStart == $rootScope.brSel) {
                addCondition = !0
            }
        }
        return addCondition
    }
    $scope.showDistribution = function() {
        var distDiv = "";
        var count = 0;
        angular.forEach($rootScope.metadataConditions, function(key, value) {
            angular.forEach(key.metadataFieldConfig, function(fieldD) {
                if (fieldD.selected) {
                    if ($rootScope.distributionFields.indexOf(fieldD.fieldDisplayName) === -1) {
                        $rootScope.distMetaError = !1;
                        var sel = fieldD.fieldDisplayName;
                        if ($rootScope.distFinalValues.length > 0) {
                            count = $rootScope.distFinalValues.length + 2
                        }
                        if ($rootScope.distFinalValues.indexOf(sel) === -1) {
                            $rootScope.distFinalValues.push(sel + "_" + count)
                        }
                        var divLi = "";
                        if (fieldD.fieldType != undefined) {
                            var check = !0;
                            angular.forEach($rootScope.dataTypeOperators, function(key1) {
                                if (check) {
                                    if ((fieldD.fieldType).toLowerCase() == (key1.type).toLowerCase()) {
                                        angular.forEach(key1.operators, function(oppValue) {
                                            divLi += "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "','Dis_" + fieldD.metaDataFieldName + "')\"> <span id='dbn_" + fieldD.metaDataFieldName + count + "'  class='title' >" + oppValue + "</span></li>"
                                        });
                                        check = !1
                                    }
                                }
                            })
                        } else {
                            divLi = "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + fieldD.metaDataFieldName + "1'  class='title' >=</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + fieldD.metaDataFieldName + "2' class='title' >&gt;</span> </li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + fieldD.metaDataFieldName + "3' class='title'>&gt;=</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + fieldD.metaDataFieldName + "4'>&lt;</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + fieldD.metaDataFieldName + "5'>&lt;&gt;</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + fieldD.metaDataFieldName + "6'>In</span> </li> " + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + fieldD.metaDataFieldName + "7'>Not in</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "','Dis_" + fieldD.metaDataFieldName + "')\"> <span class='title' id='dbn_" + fieldD.metaDataFieldName + "8'>Between</span></li>"
                        }
                        var div = "<div class='row-border-box' id='" + fieldD.metaDataFieldName + "_00'> " + "<div class='form-col-3 margin-left-right-5'> " + "<div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='dbCond_" + count + "'>AND</span></span>" + "</div> </div> </div> " + "<div class='form-col-2 margin-left-right-5'> <div class='metadata-list-name'>" + sel + "</div> </div> <div class='form-col-3 margin-left-right-5 conditions'> <div class='form-group'> " + " <div class='single-dropdown select-search dropdown-relative'>" + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='dbn_" + count + "'>Select</span></span>" + "<ul class='single-select-dropdown value-select' style='max-height: 330px;'>" + divLi + "</ul> </div> </div> </div>";
                        $rootScope.testScroll();
                        switch ((fieldD.fieldType).toLowerCase()) {
                            case "date":
                                div += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' placeholder='From' name='srch-term' type='text' id='Dis_" + fieldD.metaDataFieldName + "'> " + "<span class='date-icon-btn' ><i date-focus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\">" + "<i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'text':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input  type='text' class='form-control' id='Dis_" + fieldD.metaDataFieldName + "'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'number':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' numbers-only class='form-control'  id='Dis_" + fieldD.metaDataFieldName + "'  > </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'dropdown':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span id='Dis_" + fieldD.metaDataFieldName + "' class='dropdown-toggle toggle-select' single-select-dropdown>Select" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' common-scroll-top placeholder='Select' ng-model='" + fieldD.lookUp + "_" + count + "' name='srch-term'type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<li data-ng-repeat='user in productsList." + fieldD.lookUp + "| filter: { description : " + fieldD.lookUp + "_" + count + "}'> " + "<a href='javascript:void(0)'> " + "<span id='" + fieldD.metaDataFieldName + "{{user.code}}_1' class='dropdown-list-font' single-select-dropdown-item data-ng-click=\"spanDrpDwnClick($event,'Dis_" + fieldD.metaDataFieldName + "','" + fieldD.metaDataFieldName + "_1')\">{{user.code}}-{{user.description}}</a> </span>" + "</li>" + "</ul><div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div>";
                                break;
                            case 'boolean':
                                var Yes = "Yes";
                                var No = "No";
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'>" + " <span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{prefSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'>" + " <div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control Dis_" + sel + "' placeholder='Select' name='srch-term' type='text'></div></div" + "><div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'>" + "<ul> <li> <a href='javascript:void(0)'> " + "<span ng-model='prefValue' class='dropdown-list-font' ng-click=\"showPref('" + Yes + "')\">YES</span></a></li> <li> <a href='javascript:void(0)'>" + "<span ng-model='prefValue' class='dropdown-list-font' ng-click=\"showPref('" + No + "')\">NO</span></a></li></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'>" + "</div></div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'>" + "<div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div></div></div></div></div></div>" + "<div class='form-col-8 margin-left-right-5 pull-right'><span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'range':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' numbers-only class='form-control' numbers-only id='Dis_" + fieldD.metaDataFieldName + "'  > </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'textarea':
                                div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<textarea  class='form-control' id='Dis_" + fieldD.metaDataFieldName + "' cols='80' rows='10'></textarea>"
                                "</div> </div>" + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\">" + "<i class='cp-close'></i></button></span>" + "</div></div> </div>";
                                break;
                            case 'multiselect':
                                div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> <div class='multi-dropdown select-search dropdown-relative'> " + "<div class='dropdown-toggle toggle-select' multi-select-dropdown> <div class='dynamic-DrpDwn'> " + "<span id='" + fieldD.lookUp + "_" + fieldD.metaDataFieldName + "'>Select</span> </div> </div> " + "<div class='search-dropdown-content  multi-select-dropdown' tabindex='-1'> " + "<div class='search-box'> <div class='input-group'> " + "<input class='form-control' common-scroll-top placeholder='Search' ng-model='" + fieldD.lookUp + "_" + count + "' name='srch-term' type='search' > " + "<button class='search-icon-btn' type='submit'> <i class='cp-search'></i> </button> " + "<span class='checkbox search-check'> " + "<input id='" + fieldD.lookUp + "_" + count + "' type='checkbox' ng-click=\"spanDrpClickSelectAll($event,'" + fieldD.lookUp + "_" + fieldD.metaDataFieldName + "','" + fieldD.metaDataFieldName + "')\" ><i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span> <label for='" + fieldD.lookUp + "_" + count + "'></label> </span> " + "</div> </div> <div class='filter-search-border-green'></div>" + " <div class='filter-search-border-grey'></div> <div class='dropdown-status-set scrollX' style='position: relative; width: 100%; max-height: 180px'> " + "<ul> <li data-ng-repeat='user in productsList." + fieldD.lookUp + "| filter: { description : " + fieldD.lookUp + "_" + count + "}'>" + "<span class='checkbox check-right'> " + "<input id='" + fieldD.metaDataFieldName + "_{{user.code}}_1' type='checkbox' class='Dis_" + sel + "' value='{{user.code}}' data-ng-click=\"spanDrpClick($event,'" + fieldD.lookUp + "_" + fieldD.metaDataFieldName + "','" + fieldD.lookUp + "_" + count + "')\"> <label for='" + fieldD.metaDataFieldName + "_{{user.code}}_1'><i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span> <span class='dropdown-list-font'>{{user.code}}-{{user.description}}</span> </label> " + "</span></li> </ul> </div> </div> </div> </div></div>" + "<div class='form-col-8 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' " + "ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'email':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            case 'url':
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                                break;
                            default:
                                div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + fieldD.metaDataFieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>"
                        }
                        distDiv += div;
                        $rootScope.distributionFields.push(sel)
                    }
                }
                count++
            })
        });
        var el = $compile(distDiv)($rootScope);
        angular.element(document.getElementById('showdistribution')).append(el)
    }
    $scope.showEditDistribution = function(distributionData) {
        var count = 1;
        var distDiv = "";
        var DrpDownId = ''
        var DrpDownValue = '';
        angular.forEach(distributionData, function(key, value) {
            var sel = value;
            if ("" != key[0].value || undefined == key[0].value) {
                $rootScope.distValues.push(sel);
                $rootScope.distributionFields.push(sel);
                $rootScope.selectDistValues.push(sel);
                $rootScope.distFinalValues.push(sel + "_" + count);
                var divLi = "";
                if (key[0].type != undefined) {
                    var check = !0;
                    angular.forEach($rootScope.dataTypeOperators, function(key1) {
                        if (check) {
                            if ((key1.type).toLowerCase() == (key[0].type).toLowerCase()) {
                                angular.forEach(key1.operators, function(oppValue) {
                                    divLi += "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "','Dis_" + key[0].fieldName + "')\"> <span id='dbn_" + key[0].fieldName + count + "'  class='title' >" + oppValue + "</span></li>"
                                });
                                check = !1
                            }
                        }
                    })
                } else {
                    divLi = "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + key[0].fieldName + "1'  class='title' >=</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + key[0].fieldName + "2' class='title' >&gt;</span> </li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span id='dbn_" + key[0].fieldName + "3' class='title'>&gt;=</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + key[0].fieldName + "4'>&lt;</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + key[0].fieldName + "5'>&lt;&gt;</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + key[0].fieldName + "6'>In</span> </li> " + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "')\"> <span class='title' id='dbn_" + key[0].fieldName + "7'>Not in</span></li>" + "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#dbn_" + count + "','Dis_" + key[0].fieldName + "')\"> <span class='title' id='dbn_" + key[0].fieldName + "8'>Between</span></li>"
                }
                var div = "<div class='row-border-box' id='" + key[0].fieldName + "_00'> <div class='form-col-3 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='dbCond_" + count + "'>" + key[0].condition + "</span></span>" + "  </div> </div> </div> " + "<div class='form-col-2 margin-left-right-5'> <div class='metadata-list-name'>" + sel + "</div> </div> <div class='form-col-3 margin-left-right-5' conditions> <div class='form-group'> " + " <div class='single-dropdown select-search dropdown-relative'>" + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='dbn_" + count + "'>" + key[0].operator + "</span></span>" + "<ul class='single-select-dropdown value-select' style='max-height: 330px;'>" + divLi + "</ul> </div> </div> </div>";
                switch ((key[0].type).toLowerCase()) {
                    case "date":
                        if ("Between" === key[0].operator) {
                            div += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' placeholder='From' name='srch-term' value=" + key[0].value + " type='text' id='Dis_" + key[0].fieldName + "'> " + "<span class='date-icon-btn' ><i date-focus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' placeholder='From' name='srch-term' value=" + key[0].value1 + " type='text' id='Dis_" + key[0].fieldName + "_1'> " + "<span class='date-icon-btn'><i dateFocus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\">" + "<i class='cp-close'></i></button></span></div></div> </div>"
                        } else {
                            div += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' placeholder='From' name='srch-term' value=" + key[0].value + " type='text' id='Dis_" + key[0].fieldName + "'> " + "<span class='date-icon-btn'><i dateFocus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\">" + "<i class='cp-close'></i></button></span></div></div> </div>"
                        }
                        break;
                    case 'text':
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' id='Dis_" + key[0].fieldName + "' value='" + key[0].value + "' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    case 'number':
                        if ("Between" === key[0].operator) {
                            div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value='" + key[0].value + "' numbers-only class='form-control' id='Dis_" + key[0].fieldName + "'> </div> " + "</div> " + "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value='" + key[0].value1 + "' numbers-only class='form-control' id='Dis_" + key[0].fieldName + "_1'> </div> " + "</div> " + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\">" + "<i class='cp-close'></i></button></span></div></div></div>"
                        } else {
                            div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value='" + key[0].value + "' numbers-only class='form-control' id='Dis_" + key[0].fieldName + "'> </div> " + "</div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\">" + "<i class='cp-close'></i></button></span></div></div> </div>"
                        }
                        break;
                    case 'range':
                        if ("Between" === key[0].operator) {
                            div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value=" + key[0].value + " numbers-only class='form-control' id='Dis_" + key[0].fieldName + "'> </div> " + "</div> " + "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value=" + key[0].value1 + " numbers-only class='form-control' id='Dis_" + key[0].fieldName + "_1'> </div> " + "</div> " + "<div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\">" + "<i class='cp-close'></i></button></span></div></div></div>"
                        } else {
                            div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> " + "<input type='text' value='" + key[0].value + "' numbers-only class='form-control' id='Dis_" + key[0].fieldName + "'> </div> " + "</div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\">" + "<i class='cp-close'></i></button></span></div></div> </div>"
                        }
                        break;
                    case 'email':
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' id='Dis_" + key[0].fieldName + "' value='" + key[0].value + "' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    case 'url':
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' id='Dis_" + key[0].fieldName + "' value='" + key[0].value + "' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    case 'textarea':
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' id='Dis_" + key[0].fieldName + "' value='" + key[0].value + "' class='form-control'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    case 'dropdown':
                        DrpDownId = 'Dis_' + key[0].fieldName;
                        DrpDownValue = key[0].value;
                        $rootScope.testScroll();
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span id='Dis_" + key[0].fieldName + "' class='dropdown-toggle toggle-select' single-select-dropdown><span>Select</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' placeholder='Select' common-scroll-top ng-model=" + key[0].lookUp + " name='srch-term' type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<li data-ng-repeat='user in productsList." + key[0].lookUp + "| filter: { description : " + key[0].lookUp + "}'> " + "<a href='javascript:void(0)'> " + "<span id='" + key[0].fieldName + "{{user.code}}_1' class='dropdown-list-font' single-select-dropdown-item data-ng-click=\"spanDrpDwnClick($event,'Dis_" + key[0].fieldName + "','" + key[0].fieldName + "_1')\">{{user.code}}-{{user.description}}</a> </span>" + "</li>" + "</ul><div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' data-ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div>";
                        break;
                    case 'multiselect':
                        $rootScope.testScroll();
                        div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> <div class='multi-dropdown select-search dropdown-relative'> " + "<div class='dropdown-toggle toggle-select' multi-select-dropdown> <div class='dynamic-DrpDwn'> " + "<span id='" + key[0].lookUp + "_" + key[0].fieldName + "'>Select</span> </div> </div> " + "<div class='search-dropdown-content  multi-select-dropdown'tabindex='-1'> " + "<div class='search-box'> <div class='input-group'> " + "<input class='form-control' common-scroll-top placeholder='Search' ng-model=" + key[0].lookUp + " name='srch-term'type='search' > " + "<button class='search-icon-btn' type='submit'> <i class='cp-search'></i> </button> " + "<span class='checkbox search-check'> " + "<input id='" + key[0].lookUp + "_" + count + "' type='checkbox'> <label for='" + key[0].lookUp + "_" + count + "'><i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span></label> </span> " + "</div> </div> <div class='filter-search-border-green'></div>" + " <div class='filter-search-border-grey'></div> <div class='dropdown-status-set scrollX'style='position: relative; width: 100%; max-height: 180px'> " + "<ul> <li data-ng-repeat='user in productsList." + key[0].lookUp + "| filter: { description : " + key[0].lookUp + "_" + count + "}'>" + "<span class='checkbox check-right'> " + "<input id='" + key[0].fieldName + "_{{user.code}}_1' type='checkbox' class='Dis_" + sel + "' value='{{user.code}}' data-ng-click=\"spanDrpClick($event,'" + key[0].lookUp + "_" + key[0].fieldName + "','" + key[0].lookUp + "_" + count + "')\"> <label for='" + key[0].fieldName + "_{{user.code}}_1'><i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span> <span class='dropdown-list-font'>{{user.code}}-{{user.description}}</span> </label> " + "</span></li> </ul> </div> </div> </div> </div></div>" + "<div class='form-col-8 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' " + "ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    case 'boolean':
                        var Yes = "Yes";
                        var No = "No";
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'>" + " <span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{prefSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'>" + " <div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control bol_" + sel + "' placeholder='Select' name='srch-term' type='text'></div></div" + "><div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'>" + "<ul> <li> <a href='javascript:void(0)'> " + "<span ng-model='prefValue' class='dropdown-list-font' ng-click=\"showPref('" + Yes + "')\">YES</span></a></li> <li> <a href='javascript:void(0)'>" + "<span ng-model='prefValue' class='dropdown-list-font' ng-click=\"showPref('" + No + "')\">NO</span></a></li></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'>" + "</div></div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'>" + "<div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div></div></div></div></div></div>" + "<div class='form-col-8 margin-left-right-5 pull-right'><span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\"><i class='cp-close'></i></button></span></div></div> </div>";
                        break;
                    default:
                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' class='form-control' value=" + key[0].value + " id='Dis_" + key[0].fieldName + "'> </div> </div><div class='form-col-8 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"distPopOut('" + key[0].fieldName + "_" + count + "','" + sel + "')\")\"><i class='cp-close'></i></button></span></div></div> </div>"
                }
                distDiv += div;
                count++
            }
        });
        var el = $compile(distDiv)($rootScope);
        angular.element(document.getElementById('editDistribution')).append(el);
        $timeout(function() {
            var count = 1;
            angular.forEach(distributionData, function(key, value) {
                var type = (key[0].type).toLowerCase();
                if ("multiselect" === type) {
                    var data = [];
                    angular.forEach(key[0].value, function(values) {
                        data.push(values);
                        var idVal = key[0].fieldName + "_" + values + "_1";
                        $timeout(function() {
                            document.getElementById(idVal).checked = !0
                        }, $rootScope.alertTimeoutInterval)
                    });
                    document.getElementById(key[0].lookUp + "_" + count).checked = !0;
                    var idValdata = key[0].lookUp + "_" + key[0].fieldName;
                    $('#' + idValdata).html(data.toString())
                } else if ("dropdown" === type) {
                    document.getElementById('Dis_' + key[0].fieldName).innerText = key[0].value
                }
                count++
            })
        }, 100)
    }
    $rootScope.showApprovalStatus = function(name, id) {
        $rootScope.approvalValue = name;
        $rootScope.approvalValueId = id
    }
    $rootScope.oppFinalValues = [];
    $scope.showOperations = function() {
        var finalDiv = "";
        var count = 0;
        angular.forEach($scope.opp, function(key, value) {
            if (key == !0) {
                var c = 0;
                var sel = value;
                if ($rootScope.oppFinalValues.length >= 0) {
                    count = $rootScope.oppFinalValues.length + 1
                }
                if ($rootScope.oppFinalValues.indexOf(sel) == -1) {
                    $rootScope.oppValues.push(sel + "_" + count);
                    var divOps = "";
                    angular.forEach($rootScope.operationalConditions, function(key, value) {
                        if (key.conditionDisplayName.localeCompare(sel) == 0) {
                            var i = 1;
                            angular.forEach(key.operators, function(ops) {
                                divOps += "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#spn_" + count + "','dt" + count + "')\"> <span id='spn_" + sel + i + "'  class='title' >" + ops + "</span></li>";
                                i++
                            })
                        }
                    });
                    var div = "<div class='row-border-box' id='" + sel + "_00'> " + "<div class='form-col-2 margin-left-right-5'> <div class='metadata-list-name'>" + sel + "</div> </div> " + "<div class='form-col-3 margin-left-right-5 conditions'> " + "<div class='form-group'> " + " <div class='single-dropdown select-search dropdown-relative'>" + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='spn_" + count + "'>Select</span></span>" + "<ul class='single-select-dropdown value-select' style='max-height: 330px;'>" + divOps + "</ul> </div> </div> </div>";
                    angular.forEach($rootScope.operationalConditions, function(key, value) {
                        if (key.conditionDisplayName.localeCompare(sel) == 0) {
                            switch (key.dataType) {
                                case "Date":
                                    div += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' placeholder='From' name='srch-term' type='text' id='dt" + count + "'> " + "<span class='date-icon-btn'><i date-focus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + "<div class='form-col-7 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + sel + "_" + count + "')\">" + "<i class='cp-close'></i></button></span></div></div>";
                                    break;
                                case 'text':
                                    div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> <input type='text' class='form-control'> </div> </div><div class='form-col-7 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + sel + "_" + count + "')\"><i class='cp-close'></i></button></span></div></div>";
                                    break;
                                case 'DropDown':
                                    $rootScope.testScroll();
                                    if (sel.match("Uploaded By")) {
                                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{userSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' placeholder='Select' common-scroll-top name='srch-term'type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<li style='padding: 2px 10px;' ng-repeat=\"user in users | orderBy :'firstName'\" ng-click='showUser(user.firstName, user.userId)'> <a href='javascript:void(0)'> " + "<span ng-model='userName'class='dropdown-list-font' single-select-dropdown-item >{{user.firstName}}</a> </span></li></ul><div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + sel + "_" + count + "','user')\"><i class='cp-close'></i></button></span></div></div>"
                                    } else if (sel.match("Format")) {
                                        div += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> <div class='multi-dropdown select-search dropdown-relative'> " + "<div class='dropdown-toggle toggle-select' multi-select-dropdown> <div> " + "<span title='{{formatSelect.toString()}}'> {{ formatSelect.length>0?formatSelect.toString(): 'Select' | limitTo: 20 }}{{formatSelect.toString().length > 20 ? '...' : ''}}</span></div> </div> " + "<div class='search-dropdown-content  multi-select-dropdown'tabindex='-1'> " + "<div class='search-box'> <div class='input-group'> " + "<input class='form-control' common-scroll-top placeholder='Search' name='srch-term'type='search' ng-model='formatSearch'> " + "<button class='search-icon-btn' type='submit'> <i class='cp-search'></i> </button> " + "<span class='checkbox search-check' > " + "<input id='formatC' type='checkbox' data-ng-click='selectAllFormats($event)'> <label for='formatC' ><i class='cp-chkbox-select report-chk-head-right'><span class='path1'></span><span class='path2'></span></i></label> </span> " + "</div> </div> <div class='filter-search-border-green'></div>" + " <div class='filter-search-border-grey'></div> <div class='dropdown-status-set scrollX'style='position: relative; width: 100%; max-height: 180px'> " + "<ul> <li  data-ng-repeat=\"format in formats | filter: { formatName : formatSearch }  | orderBy :'formatName' \"><span class='checkbox check-right'> <input id='F_{{format.formatId}}' type='checkbox' class='formatNames' value='{{format.formatId}}'> <label for='F_{{format.formatId}}' ng-click='showFormat(format.formatName,format.formatId)'><i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span></i> <span class='dropdown-list-font'>{{format.formatName}}</span> </label> " + "</span></li> </ul> </div> </div> </div> </div></div>" + "<div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' " + "ng-click=\"oppPopOut('" + sel + "_" + count + "')\"><i class='cp-close'></i></button></span></div></div> </div>"
                                    } else if (sel.match("Approval Status")) {
                                        div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{approvalValue}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' placeholder='Select' common-scroll-top name='srch-term'type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<li style='padding: 2px 10px;' ng-repeat=\"approvalStatus in statusList | filter : {statusType:'FORMAT'} | orderBy :'description'\" ng-click='showApprovalStatus(approvalStatus.description,approvalStatus.code)'> <a  href='javascript:void(0)'> " + "<span class='dropdown-list-font' single-select-dropdown-item  >{{approvalStatus.description}}</a> </span></li></ul><div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + sel + "_" + count + "','approval')\"><i class='cp-close'></i></button></span></div></div>"
                                    }
                                    break;
                                case 'Boolean':
                                    var Yes = "Pass";
                                    var No = "Fail";
                                    div += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'>" + " <span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{prefSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'>" + " <div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' common-scroll-top placeholder='Select' name='srch-term'type='text'></div></div" + "><div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'>" + "<ul> <li style='padding: 2px 10px;'ng-click=\"showPref('" + Yes + "')\"> <a href='javascript:void(0)'> " + "<span ng-model='prefValue' class='dropdown-list-font' >Pass</span></a></li> <li style='padding: 2px 10px;' ng-click=\"showPref('" + No + "')\"> <a href='javascript:void(0)'>" + "<span ng-model='prefValue' class='dropdown-list-font' >Fail</span></a></li></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'>" + "</div></div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'>" + "<div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div></div></div></div></div></div>" + "<div class='form-col-7 margin-left-right-5 pull-right'><span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + sel + "_" + count + "','pref')\"><i class='cp-close'></i></button></span></div></div>";
                                    break;
                                default:
                            }
                        }
                    });
                    finalDiv += div;
                    $rootScope.oppFinalValues.push(sel)
                }
            } else {
                angular.forEach($rootScope.oppValues, function(v) {
                    var s = v.split("_");
                    if (s[0] === value) {
                        $rootScope.oppValues.splice(c, 1)
                    }
                    c++
                })
            }
            count++
        });
        var el = $compile(finalDiv)($rootScope);
        angular.element(document.getElementById('operationCondition')).append(el)
    }
    $rootScope.showUser = function(userName, usrId) {
        $rootScope.userSelect = userName;
        $rootScope.brUserId = usrId
    }
    $rootScope.showPref = function(name) {
        $rootScope.prefSelect = name;
        $rootScope.prefError = !1
    }
    $rootScope.showFormat = function(formatName, formatId) {
        $timeout(function() {
            if (document.getElementById("F_" + formatId).checked) {
                if ($rootScope.formatSelect.indexOf(formatName) == -1) {
                    $rootScope.formatSelect.push(formatName)
                }
            } else {
                if ($rootScope.formatSelect.indexOf(formatName) === 1) {
                    $rootScope.formatSelect.splice($scope.formatSelect.indexOf(formatName), 1)
                }
            }
        }, 50)
    }
    $scope.firstRule = !0;
    $scope.showGrid = function(ruleName) {
        $rootScope.createDisable = !1;
        $rootScope.editDisable = !1;
        $rootScope.ruleType = ruleName;
        $rootScope.trigerDays = !1;
        $rootScope.shipDate = !1;
        $rootScope.vendorDisabled = !0;
        if (ruleName.match("Dist")) {
            $rootScope.vendors = [];
            $rootScope.vendor = "";
            $rootScope.accountType = angular.copy($rootScope.brSel);
            $rootScope.metadataType = angular.copy($rootScope.brSel);
            $rootScope.patners = [];
            $rootScope.operationShow = !0;
            $rootScope.trigerDays = !1;
            $rootScope.shipDate = !1;
            $rootScope.distribution = !0;
            $rootScope.preflight = !1;
            $rootScope.binding = !1;
            $scope.trigger = "";
            angular.element(document.getElementById('preflightText')).text('')
        } else if (ruleName.match("flight")) {
            $rootScope.vendors = [];
            $rootScope.vendor = "";
            $rootScope.accountType = angular.copy($rootScope.brSel);
            $rootScope.metadataType = angular.copy($rootScope.brSel);
            $rootScope.patners = [];
            $rootScope.operationShow = !1;
            $rootScope.trigerDays = !0;
            $rootScope.shipDate = !0;
            $rootScope.distribution = !1;
            $rootScope.preflight = !0;
            $rootScope.binding = !1;
            angular.element(document.getElementById('showdistribution')).text('')
        } else if (ruleName.match("ing")) {
            $rootScope.vendors = [];
            $rootScope.vendor = "";
            $rootScope.accountType = angular.copy($rootScope.brSel);
            $rootScope.patners = [];
            $rootScope.operationShow = !0;
            $rootScope.trigerDays = !1;
            $rootScope.shipDate = !1;
            $rootScope.binding = !0;
            $rootScope.preflight = !1;
            $rootScope.distribution = !1;
            $rootScope.metadataType = angular.copy($rootScope.brSel)
        } else {
            $rootScope.operationShow = !0;
            $rootScope.trigerDays = !1;
            $rootScope.shipDate = !1;
            $rootScope.binding = !1;
            $rootScope.preflight = !1;
            $rootScope.distribution = !1
        }
    }
    $scope.rr = "";
    $scope.showRuleGrid = function(ruleName) {
        if ($scope.firstRule) {
            $scope.showGrid(ruleName);
            $scope.firstRule = !1
        } else {
            $('#brFailed').modal('toggle');
            $scope.rr = ruleName
        }
    }
    $scope.acceptClick = function() {
        $scope.showGrid($scope.rr)
    }
    $scope.showMetadata = function(name) {
        $rootScope.metadataType = name
    }
    $scope.showAccount = function(accountName, accountId) {
        $rootScope.vendorDisabled = !1;
        $rootScope.accountType = accountName;
        $rootScope.acntId = accountId;
        $rootScope.vendors = [];
        document.getElementById("vendorPC").checked = !1;
        $http({
            method: 'POST',
            url: '/getAllUserByAccountId',
            data: {
                accountId: accountId
            }
        }).then(function(response) {
            $rootScope.users = response.data.data
        });
        $http({
            method: 'POST',
            url: '/getPatnersByAccountId',
            data: {
                accountId: accountId
            }
        }).then(function(response) {
            var patnersData = response.data.data;
            if ($rootScope.ruleType == "Pre-flight") {
                $rootScope.patners = [];
                $rootScope.custom = []
                angular.forEach($rootScope.dataList, function(value) {
                    if (value.ruleType == "Pre-flight") {
                        var s = value.partnerIds;
                        angular.forEach(s, function(val) {
                            if ($rootScope.custom.indexOf(val) == -1) {
                                $rootScope.custom.push(val)
                            }
                        })
                    }
                });
                angular.forEach(patnersData, function(partner) {
                    if ($rootScope.custom.indexOf(partner.partnerId) == -1) {
                        $rootScope.patners.push(partner)
                    }
                })
            } else {
                $rootScope.patners = response.data.data
            }
        });
        $http({
            method: 'GET',
            url: '/getFormats',
            data: null
        }).then(function(response) {
            $rootScope.formats = response.data.data
        })
    }
    $scope.editShowAccount = function(accountName, accountId, operation, customer, partnerIds) {
        $http({
            method: 'GET',
            url: '/getAccounts',
            data: null
        }).then(function(response) {
            $rootScope.accData = response.data.data.accountList;
            angular.forEach($rootScope.accData, function(acdata) {
                if (acdata.accountId === accountId) {
                    $rootScope.accountType = acdata.accountName;
                    $rootScope.acntId = accountId
                }
            })
        });
        $http({
            method: 'POST',
            url: '/getAllUserByAccountId',
            data: {
                accountId: accountId
            }
        }).then(function(response) {
            $rootScope.users = response.data.data;
            if (null != operation)
                $scope.showEditOperation(operation)
        });
        $http({
            method: 'POST',
            url: '/getPatnersByAccountId',
            data: {
                accountId: accountId
            }
        }).then(function(response) {
            var dat = response.data.data;
            if ($rootScope.ruleType == "Pre-flight") {
                var patnersData = response.data.data;
                $rootScope.patners = [];
                $scope.custom = []
                angular.forEach($rootScope.dataList, function(value) {
                    if (value.ruleType = "Pre-flight") {
                        var s = value.partnerIds;
                        angular.forEach(s, function(val) {
                            if ($scope.custom.indexOf(val) == -1) {
                                $scope.custom.push(val)
                            }
                        })
                    }
                });
                angular.forEach(patnersData, function(partner) {
                    if ($scope.custom.indexOf(partner.partnerId) == -1) {
                        $rootScope.patners.push(partner)
                    }
                    angular.forEach(partnerIds, function(val) {
                        if (val == partner.partnerId) {
                            $rootScope.patners.push(partner)
                        }
                    })
                })
            } else {
                $rootScope.patners = response.data.data
            }
            $timeout(function() {
                if (null != partnerIds || undefined != partnerIds) {
                    var customers = partnerIds;
                    angular.forEach(partnerIds, function(cus) {
                        angular.forEach(response.data.data, function(partner) {
                            if (cus === partner.partnerId) {
                                $rootScope.vendors.push(partner.partnerName);
                                document.getElementById("ven_" + partner.partnerId).checked = !0
                            }
                        })
                    });
                    var s = "";
                    angular.forEach($rootScope.vendors, function(names) {
                        if (s == "") {
                            s += names
                        } else {
                            s += "," + names
                        }
                    });
                    $rootScope.vendor = s
                }
            }, 300)
        });
        $http({
            method: 'GET',
            url: '/getFormats',
            data: null
        }).then(function(response) {
            $rootScope.formats = response.data.data
        })
    }
    $http({
        method: 'GET',
        url: '/getOperationalConditions',
        data: null
    }).then(function(response) {
        $rootScope.operationalConditions = response.data.data
    });
    $http({
        method: 'GET',
        url: '/retrieveMetadataConditions',
        data: null
    }).then(function(response) {
        $rootScope.metadataConditions = response.data.data;
        $rootScope.metadataConditions1 = angular.copy($rootScope.metadataConditions)
    });
    $http({
        method: 'GET',
        url: '/getBrMetaDataTypes',
        data: null
    }).then(function(response) {
        $rootScope.metadataTypes = response.data.data
    });
    $http({
        method: 'GET',
        url: '/getBrRuleTypes',
        data: null
    }).then(function(response) {
        $rootScope.businessRuleTypes = response.data.data
    });
    $http({
        method: 'GET',
        url: '/getDataTypeOperators',
        data: null
    }).then(function(response) {
        $rootScope.dataTypeOperators = response.data.data
    });
    $rootScope.UpRuleName = "";
    $rootScope.activeInactiveBr = function(brId, flag, ruleName) {
        $rootScope.actInCatBrId = brId;
        $rootScope.UpRuleName = ruleName;
        if (flag) {
            $rootScope.actInCatBr = !1
        } else {
            $rootScope.actInCatBr = !0
        }
        $timeout(function() {
            $('#br-approve').modal('toggle')
        }, 600)
    }
    $scope.activeInactiveBrule = function() {
        $rootScope.disabledBtnClick();
        $http({
            method: 'POST',
            url: '/updateApproveFlag',
            data: {
                id: $scope.actInCatBrId,
                ruleName: $rootScope.UpRuleName,
                activeFlag: $scope.actInCatBr,
                userId: $rootScope.loggedUser.userId,
                columnSearchData: searchBrData
            }
        }).then(function(response) {
            $rootScope.dataList = response.data.data;
            var message = response.data.statusMessage;
            $('#br-approve').modal('toggle');
            if (response.data.code = "200") {
                $rootScope.successAddBrMsg = !0;
                $rootScope.successAddBrMsgContent = message;
                setTimeout(function() {
                    $rootScope.successAddBrMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.failureAddBrMsg = !0;
                $rootScope.failureAddBrMsgContent = message;
                setTimeout(function() {
                    $rootScope.failureAddBrMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    }
    $scope.removeBrId;
    $scope.removeBrC = function(brId) {
        $scope.removeBrId = brId
    }
    $scope.cancelReomve = function() {
        $rootScope.disabledBtnClickQuick();
        $('#br-delete').modal('toggle')
    }
    $scope.approveReomve = function() {
        $rootScope.disabledBtnClickQuick();
        $('#br-approve').modal('toggle');
        $http({
            method: 'POST',
            url: '/getColumnSearchData',
            data: {
                userId: $rootScope.loggedUser.userId,
                columnSearchData: searchBrData
            }
        }).then(function(response) {
            $rootScope.dataList = response.data.data
        })
    }
    $scope.removeBr = function() {
        $rootScope.disabledBtnClick();
        $http({
            method: 'POST',
            url: '/removeBusinessRules',
            data: {
                id: $scope.removeBrId,
                isDelete: !0,
                ruleName: $scope.ruleName,
                userId: $rootScope.loggedUser.userId,
                columnSearchData: searchBrData
            }
        }).then(function(response) {
            $('#br-delete').modal('toggle');
            if (response.data.code === "200") {
                $rootScope.dataList = response.data.data;
                $rootScope.successAddBrMsg = !0;
                setTimeout(function() {
                    $rootScope.successAddBrMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $rootScope.successAddBrMsgContent = response.data.statusMessage
            } else {
                $rootScope.dataList = response.data.data;
                $rootScope.failureAddBrMsg = !0;
                $rootScope.failureAddBrMsgContent = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.failureAddBrMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    }
    $rootScope.brId = "";
    $scope.showEditOperation = function(operationData) {
        var count = 1;
        var oppDivs = "";
        var userValue = "";
        var userOperator;
        var userId;
        var uploadedOn;
        var onOperator;
        var dateId;
        var dateOperator;
        var dateValue;
        var dateValueId;
        var dateBtValue;
        var dateBtValueId;
        var formatOperator;
        var formatId;
        var prefOperator;
        var approveSelectValue = "";
        var approveOperator = "";
        var prefId;
        var approveId;
        var apprId;
        angular.forEach(operationData, function(key, value) {
            if ("" != key[0].value) {
                $rootScope.operations.push(value);
                $rootScope.oppValues.push(value + "_" + count);
                $rootScope.oppFinalValues.push(value);
                document.getElementById("OC_" + value).checked = !0;
                var divOps = "";
                angular.forEach($rootScope.operationalConditions, function(key, value1) {
                    if (key.conditionDisplayName.localeCompare(value) == 0) {
                        var i = 1;
                        angular.forEach(key.operators, function(ops) {
                            divOps += "<li class='dropdown-item' single-select-dropdown-item ng-click=\"spanClickevent($event,'#spn_" + count + "')\"> <span id='spn_" + value + i + "'  class='title' >" + ops + "</span></li>";
                            i++
                        })
                    }
                });
                oppDivs += "<div class='row-border-box' id='" + value + "_00'> " + "<div class='form-col-2 margin-left-right-5'> <div class='metadata-list-name'>" + value + "</div> </div> <div class='form-col-3 margin-left-right-5'> <div class='form-group'> " + " <div class='single-dropdown select-search dropdown-relative'>" + "<span class='dropdown-toggle toggle-select' single-select-dropdown>" + "<span id='spn_" + count + "'>Select</span></span>" + "<ul class='single-select-dropdown value-select' style='max-height: 330px;'>" + divOps + "</ul> </div> </div> </div>";
                if (value.indexOf("Uploaded On") > 0) {
                    if ("Between" === key[0].operator) {
                        oppDivs += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' data-ng-model='dateOn' placeholder='From' name='srch-term' type='text' id='dt" + count + "'> " + "<span class='date-icon-btn'><i date-focus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' data-ng-model='dateTo' placeholder='To' name='srch-term' type='text' id='dt" + count + "_1'> " + "<span class='date-icon-btn'><i dateFocus class='cp-datepicker br-datepicker'></i></dateFocus> </div> </div> </div> " + "<div class='form-col-7 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + value + "_" + count + "')\">" + "<i class='cp-close'></i></button></span></div></div>";
                        dateBtValue = key[0].value1
                        dateBtValueId = "#dt" + count + "_1"
                    } else {
                        oppDivs += " <div class='form-col-4 margin-left-right-5'> <div class='form-group'> <div class='input-group'> " + "<input class='form-control datepicker' data-ng-model='dateOn'  placeholder='From' name='srch-term' type='text' id='dt" + count + "'> " + "<span class='date-icon-btn'><i dateFocus class='cp-datepicker br-datepicker'></i></span> </div> </div> </div> " + "<div class='form-col-7 margin-left-right-5 pull-right'> " + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + value + "_" + count + "')\">" + "<i class='cp-close'></i></button></span></div></div>"
                    }
                    dateValue = key[0].value;
                    dateValueId = "#dt" + count;
                    dateOperator = key[0].operator;
                    dateId = "#spn_" + count
                } else if (value.indexOf("By") > 0) {
                    $rootScope.testScroll();
                    oppDivs += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{userSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' common-scroll-top placeholder='Select' name='srch-term'type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<a href='javascript:void(0)'> <li style='padding: 2px 10px;\"ng-repeat='user in users | orderBy :'firstName' \"  single-select-dropdown-item ng-click='showUser(user.firstName, user.userId)'> " + "<span ng-model='userName'class='dropdown-list-font' >{{user.firstName}}</span></li></a></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + value + "_" + count + "','user')\"><i class='cp-close'></i></button></span></div></div>";
                    userValue = key[0].value;
                    userId = "#spn_" + count;
                    userOperator = key[0].operator
                } else if (value.indexOf("Approval Status") == 0) {
                    $rootScope.testScroll();
                    oppDivs += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'> " + "<span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{approvalValue}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'> " + "<div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' common-scroll-top placeholder='Select' name='srch-term'type='text'></div></div>" + "<div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'><ul>" + "<li style='padding: 2px 10px;' ng-repeat=\"approvalStatus in statusList | filter : {statusType:'FORMAT'} | orderBy : 'description' \"  single-select-dropdown-item ng-click='showApprovalStatus(approvalStatus.description,approvalStatus.code)'> <a href='javascript:void(0)'>" + "<span class='dropdown-list-font' >{{approvalStatus.description}}</span></a></li></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'></div>" + "</div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'><div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div>" + "</div></div></div></div></div><div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + value + "_" + count + "','approval')\"><i class='cp-close'></i></button></span></div></div>";
                    approveSelectValue = key[0].value;
                    approveId = "#spn_" + count;
                    approveOperator = key[0].operator;
                    apprId = key[0].approvalId
                } else if (value.indexOf("Format") == 0) {
                    $http({
                        method: 'GET',
                        url: '/getFormats',
                        data: null
                    }).then(function(response) {
                        $rootScope.formats = response.data.data
                    });
                    $rootScope.testScroll();
                    oppDivs += "<div class='form-col-4 margin-left-right-5'> " + "<div class='form-group'> <div class='multi-dropdown select-search dropdown-relative'> " + "<div class='dropdown-toggle toggle-select' multi-select-dropdown> <div> " + "<span title='{{formatSelect.toString()}}' > {{ formatSelect.length>0?formatSelect.toString(): 'Select' | limitTo: 20 }}{{formatSelect.toString().length > 20 ? '...' : ''}}</span> </div> </div> " + "<div class='search-dropdown-content  multi-select-dropdown'tabindex='-1'> " + "<div class='search-box'> <div class='input-group'> " + "<input class='form-control' common-scroll-top placeholder='Search' name='srch-term'type='search' ng-model='formatSearch'> " + "<button class='search-icon-btn' type='submit'> <i class='cp-search'></i> </button> " + "<span class='checkbox search-check' data-ng-click='selectAllFormats($event)'> " + "<input id='formatC' type='checkbox'> <label for='formatC'> <i class='cp-chkbox-select report-chk-head-right'><span class='path1'></span><span class='path2'></span></i></label> </span> " + "</div> </div> <div class='filter-search-border-green'></div>" + " <div class='filter-search-border-grey'></div> <div class='dropdown-status-set scrollX'style='position: relative; width: 100%; max-height: 180px'> " + "<ul> <li data-ng-repeat=\"format in formats | filter: { formatName : formatSearch } | orderBy :'formatName' \"><span class='checkbox check-right'> <input id='F_{{format.formatId}}'type='checkbox' class='formatNames' value='{{format.formatId}}'> <label for='F_{{format.formatId}}' ng-click='showFormat(format.formatName,format.formatId)'> <i class='cp-chkbox-select report-chk-right'><span class='path1'></span><span class='path2'></span></i><span class='dropdown-list-font'>{{format.formatName}}</span> </label> " + "</span></li> </ul> </div> </div> </div> </div></div>" + "<div class='form-col-7 margin-left-right-5 pull-right'>" + "<span remove-borderbox><button type='button' class='form-row-close-btn' " + "ng-click=\"oppPopOut('" + value + "_" + count + "')\"><i class='cp-close'></i></button></span></div></div> </div>";
                    formatOperator = key[0].operator;
                    formatId = "#spn_" + count
                } else if (value == "Pre-flight") {
                    var Yes = "Pass";
                    var No = "Fail";
                    oppDivs += "<div class='form-col-4 margin-left-right-5'> <div class='form-group'> " + "<div class='single-dropdown select-search dropdown-relative'>" + " <span class='dropdown-toggle toggle-select' single-select-dropdown><span>{{prefSelect}}</span>" + "</span> <div class='single-select-dropdown search-dropdown-content input-search toggle-dropdown'>" + " <div class='search-box br-creation-select'><div class='input-group'>" + "<input class='form-control' common-scroll-top placeholder='Select' name='srch-term'type='text'></div></div" + "><div class='filter-search-border-green'></div><div class='filter-search-border-grey'></div>" + "<div class='dropdown-status-set scrollX ps-container ps-theme-default'style='position: relative; width: 100%; max-height: 126px'data-ps-id='2b76e458-b820-c3f5-ddc1-ef9ecf2969d7'>" + "<ul> <li style='padding: 2px 10px;' ng-click=\"showPref('" + Yes + "')\"> <a href='javascript:void(0)'> " + "<span ng-model='prefValue' class='dropdown-list-font' >Pass</span></a></li> <li style='padding: 2px 10px;' ng-click=\"showPref('" + No + "')\"> <a href='javascript:void(0)'>" + "<span ng-model='prefValue' class='dropdown-list-font' >Fail</span></a></li></ul>" + "<div class='ps-scrollbar-x-rail' style='left: 0px; bottom: 0px;'><div class='ps-scrollbar-x' tabindex='0'style='left: 0px; width: 0px;'>" + "</div></div><div class='ps-scrollbar-y-rail' style='top: 0px; right: 0px;'>" + "<div class='ps-scrollbar-y' tabindex='0'style='top: 0px; height: 0px;'></div></div></div></div></div></div></div>" + "<div class='form-col-7 margin-left-right-5 pull-right'><span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"oppPopOut('" + value + "_" + count + "','pref')\"><i class='cp-close'></i></button></span></div></div>";
                    $rootScope.prefSelect = key[0].value;
                    prefId = "#spn_" + count;
                    prefOperator = key[0].operator
                }
                count++
            }
        });
        var temp = $compile(oppDivs)($rootScope);
        angular.element(document.getElementById('editOperationCondition')).append(temp);
        $(userId).html(userOperator);
        $(dateId).html(dateOperator);
        $(dateBtValueId).html(dateOperator);
        $(formatId).html(formatOperator);
        $(prefId).html(prefOperator);
        $(approveId).html(approveOperator);
        $rootScope.dateOn = dateValue;
        $rootScope.dateTo = dateBtValue;
        if ("" != userValue) {
            angular.forEach($rootScope.users, function(usr) {
                if (userValue == usr.userId) {
                    $rootScope.userSelect = usr.firstName;
                    $rootScope.brUserId = userValue
                }
            })
        }
        if ("" != approveSelectValue) {
            $rootScope.approvalValue = approveSelectValue;
            $rootScope.approvalValueId = apprId
        }
        $timeout(function() {
            angular.forEach(operationData, function(key, value) {
                if (value === "Format") {
                    angular.forEach(key[0].value, function(value) {
                        angular.forEach($rootScope.formats, function(formatData) {
                            if (formatData.formatId === value) {
                                var id = "F_" + formatData.formatId;
                                document.getElementById(id).checked = !0;
                                $rootScope.formatSelect.push(formatData.formatName)
                            }
                        })
                    })
                }
            });
            if ($rootScope.formatSelect.length === $rootScope.formats.length)
                document.getElementById("formatC").checked = !0;
            if ($rootScope.operationalConditions.length === Object.keys(operationData).length) {
                document.getElementById("operationS").checked = !0
            }
        }, 200)
    }
    $rootScope.description;
    $scope.input = {}
    $rootScope.gearValues = [];
    $rootScope.gearHeaders = function(event, gearName) {
        var checkbox = event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            $rootScope.gearValues.push(gearName)
        } else if (action === 'remove') {
            $rootScope.gearValues.splice($rootScope.gearValues.indexOf(gearName), 1)
        }
    }
    $rootScope.clearGear = function() {
        $timeout(function() {
            angular.forEach($rootScope.gearValues, function(key) {
                document.getElementById(key + "_header").checked = !1
            })
        }, 300)
    }
    $rootScope.saveGear = function() {
        angular.forEach($rootScope.gearValues, function(key) {
            if ($rootScope.showHeader.indexOf(key) === -1) {
                $rootScope.showHeader.push(key)
            }
        });
        $('.gear-Select').removeClass("active");
        $('.gear-dropdown').removeClass("active")
    }
    $rootScope.dContent = [];
    $rootScope.showEligibleTableLoader = function() {
        angular.element($(".asset-table-loader")).css("display", "block");
        if ($rootScope.dContent.length <= 10) {
            angular.element($(".asset-table-loader-height")).css("display", "none")
        }
        angular.element($(".asset-table-loader")).addClass("asset-table-loader-height")
    }
    $rootScope.showEligibleTitles = function(ruleName, eligibleCount) {
        $http({
            method: 'GET',
            url: '/getAllFormats',
            data: null
        }).then(function(response) {
            $rootScope.fff = response.data
        });
        $rootScope.testScroll();
        $rootScope.distPrefE = !1;
        var ecount = 0;
        if (eligibleCount == "" || eligibleCount == undefined) {
            ecount = 0
        } else {
            ecount = eligibleCount
        }
        $rootScope.ruleNameEli = ruleName;
        $location.url('/eligible-titles');
        $rootScope.showLoader($('.app-content'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/getGrid',
            data: {
                ruleName: ruleName,
                eligibleCount: ecount
            }
        }).then(function(response) {
            $rootScope.oper = [];
            $rootScope.metadataDist = [];
            $rootScope.metadataPref = [];
            $rootScope.dRuleType = "";
            $rootScope.dCustomer = "";
            $rootScope.dDescription = "";
            $rootScope.distOper = !1;
            $rootScope.Date = response.data.data;
            if (undefined != $rootScope.Date.Display) {
                $rootScope.dHeader = $rootScope.Date.Display
            } else {
                $rootScope.dHeader = []
            }
            angular.forEach($rootScope.Date.fieldData, function(eligibleVal) {
                $rootScope.dContent.push(eligibleVal)
            });
            $rootScope.showHeaderCount = $rootScope.Date.headerCount;
            $rootScope.totalCount = $rootScope.Date.totalCount;
            if (!$rootScope.isScroll) {
                $rootScope.showHeader = [];
                $rootScope.gear = [];
                var count = 1;
                angular.forEach($rootScope.Date.Display, function(key) {
                    if (count <= $rootScope.showHeaderCount) {
                        $rootScope.showHeader.push(key)
                    } else {
                        $rootScope.gear.push(key)
                    }
                    count++
                })
            }
            $rootScope.dRuleType = $rootScope.Date.RuleData.ruleType;
            $rootScope.dCustomer = $rootScope.Date.RuleData.customer;
            $rootScope.dDescription = $rootScope.Date.RuleData.description;
            $rootScope.dDatetype = $rootScope.Date.RuleData.dateToTrigger;
            $rootScope.dTrigger = $rootScope.Date.RuleData.trigger;
            $rootScope.dAccount = $rootScope.Date.RuleData.account;
            $rootScope.dMetadataType = $rootScope.Date.RuleData.metadataType;
            if ($rootScope.dRuleType == "Distribution") {
                $rootScope.distOper = !0;
                $rootScope.trig = !1;
                $rootScope.dateType = !1;
                angular.forEach($rootScope.Date.RuleData.metadataConditions, function(key, value) {
                    if ("Between" === key[0].operator) {
                        $rootScope.metadataDist.push({
                            "name": key[0].key,
                            "operator": key[0].operator,
                            "value": key[0].value,
                            "value1": key[0].value1,
                            "bt": !0
                        })
                    } else {
                        $rootScope.metadataDist.push({
                            "name": key[0].key,
                            "operator": key[0].operator,
                            "value": key[0].value,
                            "bt": !1
                        })
                    }
                });
                angular.forEach($rootScope.Date.RuleData.operations, function(key, value) {
                    if ("Between" == key[0].operator) {
                        $rootScope.oper.push({
                            "name": key[0].key,
                            "operator": key[0].operator,
                            "value": key[0].value,
                            "value1": key[0].value1,
                            "bt": !0
                        })
                    } else {
                        if ("Format" === key[0].key) {
                            $timeout(function() {
                                $scope.formts = [];
                                angular.forEach($rootScope.fff, function(data) {
                                    angular.forEach(key[0].value, function(fid) {
                                        if (fid === data.formatId) {
                                            $scope.formts.push(data.formatName)
                                        }
                                    })
                                });
                                $rootScope.oper.push({
                                    "name": key[0].key,
                                    "operator": key[0].operator,
                                    "value": $scope.formts,
                                    "bt": !1
                                })
                            }, 1000)
                        } else {
                            $rootScope.oper.push({
                                "name": key[0].key,
                                "operator": key[0].operator,
                                "value": key[0].value,
                                "bt": !1
                            })
                        }
                    }
                })
            } else {
                $rootScope.distPrefE = !0;
                angular.forEach($rootScope.Date.RuleData.metadataPreflight, function(key, value) {
                    $rootScope.metadataPref.push({
                        "name": value
                    })
                });
                $rootScope.trig = !0;
                $rootScope.dateType = !0
            }
            $rootScope.hideLoader('app-content')
        })
    }
    $scope.clearAll = function() {
        $location.url('/business-rules')
    }
    $scope.editBr = function(br) {
        $location.url('/create-business-rule');
        $rootScope.ruleName = br.ruleName;
        $timeout(function() {
            $rootScope.action = "Edit";
            $rootScope.accountType = br.account;
            $rootScope.brId = br.id;
            $rootScope.ruleTypeDisabled = !0;
            $rootScope.createEdit = angular.copy($rootScope.brUpdate);
            $rootScope.addBrule = !1;
            $rootScope.updateBrule = !0;
            $rootScope.vendorDisabled = !1;
            $rootScope.ruleType = br.ruleType;
            $rootScope.description = br.description;
            angular.forEach(br.partnerIds, function(pr) {
                $rootScope.vendorIds.push(pr)
            })
            if ($rootScope.ruleType === "Pre-flight") {
                $rootScope.operationShow = !1;
                $rootScope.preflight = !0
            } else if ($rootScope.ruleType === "Distribution") {
                $rootScope.distribution = !0
            }
            $scope.editShowAccount(br.account, br.accountId, br.operations, br.customer, br.partnerIds);
            var keys = "";
            var prefDivs = "";
            if (null != br.vendorIds && undefined != br.vendorIds) {
                angular.forEach(br.vendorIds, function(id) {
                    $rootScope.vendorIds.push(id)
                })
            }
            $rootScope.metadataType = br.metadataType;
            $rootScope.dateToStart = br.dateToTrigger;
            if (null != br.metadataConditions) {
                if (Object.keys(br.metadataConditions).length > 0) {
                    $rootScope.binding = !1;
                    $rootScope.preflight = !1;
                    $scope.showEditDistribution(br.metadataConditions)
                }
            }
            if (br.metadataPreflight != null) {
                if (Object.keys(br.metadataPreflight).length > 0) {
                    $rootScope.trigerDays = !0;
                    $rootScope.shipDate = !0;
                    $rootScope.distribution = !1;
                    $rootScope.preflight = !0;
                    $rootScope.binding = !1;
                    $rootScope.trigger = br.trigger;
                    angular.forEach(br.metadataPreflight, function(key, value) {
                        $rootScope.values.push(JSON.stringify(value).replace(/"/g, ""));
                        $rootScope.FinalFields.push(JSON.stringify(value).replace(/"/g, ""));
                        $rootScope.editValues.push(JSON.stringify(value).replace(/"/g, ""));
                        prefDivs += "<div class='row-border-box row-label'> " + "<div class='form-col-3 margin-left-right-5'> " + "</div> <div class='form-col-1 margin-left-right-10'> </div> " + "<div class='form-col-2 margin-left-right-10 margin-bottom-10'> " + "<div class='metadata-list-name'>" + JSON.stringify(value).replace(/"/g, "") + "</div> </div> " + "<div class='form-col-9 margin-left-right-5 pull-right'> <span remove-borderbox>" + "<button type='button' class='form-row-close-btn' ng-click=\"popOut('" + JSON.stringify(value).replace(/"/g, "") + "')\"><i class='cp-close'></i></button></span> " + "</div> </div>"
                    });
                    $rootScope.operationShow = !1;
                    var editPref = $compile(prefDivs)($rootScope);
                    angular.element(document.getElementById('editPreflightText')).append(editPref)
                }
            }
        }, 500);
        $timeout(function() {
            angular.forEach(br.metadataPreflight, function(key, value) {
                var idVal = JSON.stringify(value).replace(/"/g, "");
                $rootScope.selectPrefValues.push(idVal);
                document.getElementById(idVal).checked = !0
            })
        }, 800)
    }
    $scope.patnerData = {};
    $scope.dp = [];
    $scope.dupRuleNameCheck = function(ruleName) {}
    $rootScope.prefError = !1;
    $scope.addBr = function() {
        $rootScope.createDisable = !0;
        $scope.addCondition = !0;
        $scope.triggerDays = 0;
        if ($scope.trigger == "" || $scope.trigger == undefined) {
            $scope.triggerDays = 0
        } else {
            $scope.triggerDays = $scope.trigger
        }
        if ($scope.ruleName == undefined || $scope.ruleName === "") {
            $scope.ruleNameError = !0;
            $scope.addCondition = !1
        } else {
            $http({
                method: 'POST',
                url: '/checkRule',
                data: {
                    ruleName: $scope.ruleName
                }
            }).then(function(response) {
                if (response.data.code === "200") {
                    if ($scope.addCondition) {
                        $scope.oppCond = [];
                        $scope.operationalConds = {};
                        if ($rootScope.ruleType === 'Pre-flight') {
                            if ($rootScope.FinalFields.length <= 0) {
                                $rootScope.prefMetaError = !0;
                                return !1
                            } else {
                                $rootScope.prefMetaError = !1
                            }
                        }
                        if ($rootScope.ruleType === "Distribution") {
                            if ($rootScope.distFinalValues.length <= 0) {
                                $rootScope.distMetaError = !0;
                                return !1
                            } else {
                                $rootScope.distMetaError = !1
                            }
                            if ($rootScope.prefSelect === "Select") {
                                $rootScope.prefError = !0;
                                return !1
                            } else {
                                $rootScope.prefError = !1
                            }
                            if ($rootScope.oppValues.length > 0) {
                                angular.forEach($rootScope.oppValues, function(value) {
                                    var actValue = value.split("_");
                                    var count = !0;
                                    var keyName;
                                    if (count) {
                                        angular.forEach($rootScope.operationalConditions, function(value1) {
                                            if (actValue[0] === value1.conditionDisplayName) {
                                                var v = "spn_" + actValue[1];
                                                var operator;
                                                if (null != document.getElementById(v).innerText) {
                                                    operator = document.getElementById(v).innerText
                                                }
                                                var condition = "opp_" + actValue[1];
                                                if (actValue[0] === "File Uploaded By") {
                                                    $scope.oppCond.push({
                                                        "key": actValue[0],
                                                        "operator": operator,
                                                        "value": $rootScope.brUserId,
                                                        "referencePath": value1.referencePath
                                                    });
                                                    count = !1
                                                }
                                                if (actValue[0] === "Approval Status") {
                                                    $scope.oppCond.push({
                                                        "key": actValue[0],
                                                        "operator": operator,
                                                        "value": $rootScope.approvalValue,
                                                        "referencePath": value1.referencePath,
                                                        "approvalId": $rootScope.approvalValueId
                                                    });
                                                    count = !1
                                                } else if (actValue[0] === "Format") {
                                                    var checkedValue = [];
                                                    var inputElements = document.getElementsByClassName("formatNames");
                                                    for (var i = 0; inputElements[i]; ++i) {
                                                        if (inputElements[i].checked) {
                                                            checkedValue.push(inputElements[i].value)
                                                        }
                                                    }
                                                    $scope.oppCond.push({
                                                        "key": actValue[0],
                                                        "operator": operator,
                                                        "value": checkedValue,
                                                        "referencePath": value1.referencePath
                                                    });
                                                    count = !1
                                                } else if (actValue[0] === "File Uploaded On") {
                                                    var dtVal = "dt" + actValue[1];
                                                    var dtVal1 = "dt" + actValue[1] + "_1";
                                                    if ("Between" === operator) {
                                                        $scope.oppCond.push({
                                                            "key": actValue[0],
                                                            "operator": operator,
                                                            "value": document.getElementById(dtVal).value,
                                                            "value1": document.getElementById(dtVal1).value,
                                                            "referencePath": value1.referencePath
                                                        })
                                                    } else {
                                                        $scope.oppCond.push({
                                                            "key": actValue[0],
                                                            "operator": operator,
                                                            "value": document.getElementById(dtVal).value,
                                                            "referencePath": value1.referencePath
                                                        })
                                                    }
                                                    count = !1
                                                } else if (actValue[0] === "Pre-flight") {
                                                    $scope.oppCond.push({
                                                        "key": actValue[0],
                                                        "operator": operator,
                                                        "value": $rootScope.prefSelect,
                                                        "referencePath": value1.referencePath
                                                    });
                                                    count = !1
                                                }
                                                keyName = actValue[0];
                                                if (!count) {
                                                    return !1
                                                }
                                            }
                                        });
                                        $scope.operationalConds[keyName] = $scope.oppCond;
                                        $scope.oppCond = []
                                    }
                                })
                            }
                        }
                        $scope.distributionData = {};
                        angular.forEach($rootScope.distFinalValues, function(distVal) {
                            $scope.distribution = [];
                            var distValue = distVal.split("_");
                            var condValue = !0;
                            if (condValue) {
                                var cond = !0;
                                angular.forEach($rootScope.metadataConditions, function(value) {
                                    if (cond) {
                                        angular.forEach(value.metadataFieldConfig, function(value) {
                                            if (distValue[0] === value.fieldDisplayName) {
                                                switch ((value.fieldType).toLowerCase()) {
                                                    case "dropdown":
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if ('Select' != document.getElementById(operator).innerText) {
                                                            if ("Select" != document.getElementById("Dis_" + value.metaDataFieldName).innerText) {
                                                                var drpVal = document.getElementById("Dis_" + value.metaDataFieldName).innerText;
                                                                var selectval = drpVal.split('-');
                                                                $scope.distribution.push({
                                                                    "key": distValue[0],
                                                                    "operator": document.getElementById(operator).innerText,
                                                                    "value": selectval[0],
                                                                    "condition": document.getElementById(condition).innerText,
                                                                    "referenceTable": value.referenceTable,
                                                                    "referencePath": value.referencePath,
                                                                    "referenceValue": value.referenceValue,
                                                                    "fieldName": value.metaDataFieldName,
                                                                    "type": value.fieldType,
                                                                    "lookUp": value.lookUp,
                                                                    "fieldId": value.metaDataFieldId
                                                                })
                                                            }
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                    case "text":
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                            $scope.distribution.push({
                                                                "key": distValue[0],
                                                                "operator": document.getElementById(operator).innerText,
                                                                "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                "condition": document.getElementById(condition).innerText,
                                                                "referenceTable": value.referenceTable,
                                                                "referencePath": value.referencePath,
                                                                "referenceValue": value.referenceValue,
                                                                "fieldName": value.metaDataFieldName,
                                                                "type": value.fieldType,
                                                                "lookUp": value.lookUp,
                                                                "fieldId": value.metaDataFieldId
                                                            })
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                    case "number":
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if ('Select' != document.getElementById(operator).innerText) {
                                                            if ("Between" === document.getElementById(operator).innerText) {
                                                                if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                                    $scope.distribution.push({
                                                                        "key": distValue[0],
                                                                        "operator": document.getElementById(operator).innerText,
                                                                        "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                        "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                                        "condition": document.getElementById(condition).innerText,
                                                                        "referenceTable": value.referenceTable,
                                                                        "referencePath": value.referencePath,
                                                                        "referenceValue": value.referenceValue,
                                                                        "fieldName": value.metaDataFieldName,
                                                                        "type": value.fieldType,
                                                                        "lookUp": value.lookUp,
                                                                        "fieldId": value.metaDataFieldId
                                                                    })
                                                                }
                                                            } else {
                                                                if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText) {
                                                                    $scope.distribution.push({
                                                                        "key": distValue[0],
                                                                        "operator": document.getElementById(operator).innerText,
                                                                        "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                        "condition": document.getElementById(condition).innerText,
                                                                        "referenceTable": value.referenceTable,
                                                                        "referencePath": value.referencePath,
                                                                        "referenceValue": value.referenceValue,
                                                                        "fieldName": value.metaDataFieldName,
                                                                        "type": value.fieldType,
                                                                        "lookUp": value.lookUp,
                                                                        "fieldId": value.metaDataFieldId
                                                                    })
                                                                }
                                                            }
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                    case "date":
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if ('Select' != document.getElementById(operator).innerText) {
                                                            if ("Between" === document.getElementById(operator).innerText) {
                                                                if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                                    $scope.distribution.push({
                                                                        "key": distValue[0],
                                                                        "operator": document.getElementById(operator).innerText,
                                                                        "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                        "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                                        "condition": document.getElementById(condition).innerText,
                                                                        "referenceTable": value.referenceTable,
                                                                        "referencePath": value.referencePath,
                                                                        "referenceValue": value.referenceValue,
                                                                        "fieldName": value.metaDataFieldName,
                                                                        "type": value.fieldType,
                                                                        "lookUp": value.lookUp
                                                                    })
                                                                }
                                                            } else {
                                                                if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText) {
                                                                    $scope.distribution.push({
                                                                        "key": distValue[0],
                                                                        "operator": document.getElementById(operator).innerText,
                                                                        "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                        "condition": document.getElementById(condition).innerText,
                                                                        "referenceTable": value.referenceTable,
                                                                        "referencePath": value.referencePath,
                                                                        "referenceValue": value.referenceValue,
                                                                        "fieldName": value.metaDataFieldName,
                                                                        "type": value.fieldType,
                                                                        "lookUp": value.lookUp
                                                                    })
                                                                }
                                                            }
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                    case 'range':
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if ('Select' != document.getElementById(operator).innerText) {
                                                            if ("Between" === document.getElementById(operator).innerText) {
                                                                if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                                    $scope.distribution.push({
                                                                        "key": distValue[0],
                                                                        "operator": document.getElementById(operator).innerText,
                                                                        "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                        "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                                        "condition": document.getElementById(condition).innerText,
                                                                        "referenceTable": value.referenceTable,
                                                                        "referencePath": value.referencePath,
                                                                        "referenceValue": value.referenceValue,
                                                                        "fieldName": value.metaDataFieldName,
                                                                        "type": value.fieldType,
                                                                        "lookUp": value.lookUp
                                                                    })
                                                                }
                                                            }
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                        break;
                                                    case 'textarea':
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                            $scope.distribution.push({
                                                                "key": distValue[0],
                                                                "operator": document.getElementById(operator).innerText,
                                                                "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                "condition": document.getElementById(condition).innerText,
                                                                "referenceTable": value.referenceTable,
                                                                "referencePath": value.referencePath,
                                                                "referenceValue": value.referenceValue,
                                                                "fieldName": value.metaDataFieldName,
                                                                "type": value.fieldType,
                                                                "lookUp": value.lookUp,
                                                                "fieldId": value.metaDataFieldId
                                                            })
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                        break;
                                                    case 'multiselect':
                                                        var checkedValue = [];
                                                        var inputElements = document.getElementsByClassName("Dis_" + distValue[0]);
                                                        for (var i = 0; inputElements[i]; ++i) {
                                                            if (inputElements[i].checked) {
                                                                var s = inputElements[i].value.split("-");
                                                                checkedValue.push(s[0])
                                                            }
                                                        }
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if ('Select' != document.getElementById(operator).innerText) {
                                                            if (checkedValue.length > 0) {
                                                                $scope.distribution.push({
                                                                    "key": distValue[0],
                                                                    "operator": document.getElementById(operator).innerText,
                                                                    "value": checkedValue,
                                                                    "condition": document.getElementById(condition).innerText,
                                                                    "referenceTable": value.referenceTable,
                                                                    "referencePath": value.referencePath,
                                                                    "referenceValue": value.referenceValue,
                                                                    "fieldName": value.metaDataFieldName,
                                                                    "type": value.fieldType,
                                                                    "lookUp": value.lookUp,
                                                                    "fieldId": value.metaDataFieldId
                                                                })
                                                            }
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                        break;
                                                    case 'email':
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                            $scope.distribution.push({
                                                                "key": distValue[0],
                                                                "operator": document.getElementById(operator).innerText,
                                                                "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                "condition": document.getElementById(condition).innerText,
                                                                "referenceTable": value.referenceTable,
                                                                "referencePath": value.referencePath,
                                                                "referenceValue": value.referenceValue,
                                                                "fieldName": value.metaDataFieldName,
                                                                "type": value.fieldType,
                                                                "lookUp": value.lookUp,
                                                                "fieldId": value.metaDataFieldId
                                                            })
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                        break;
                                                    case 'url':
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                            $scope.distribution.push({
                                                                "key": distValue[0],
                                                                "operator": document.getElementById(operator).innerText,
                                                                "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                "condition": document.getElementById(condition).innerText,
                                                                "referenceTable": value.referenceTable,
                                                                "referencePath": value.referencePath,
                                                                "referenceValue": value.referenceValue,
                                                                "fieldName": value.metaDataFieldName,
                                                                "type": value.fieldType,
                                                                "lookUp": value.lookUp,
                                                                "fieldId": value.metaDataFieldId
                                                            })
                                                        }
                                                        cond = !1;
                                                        return cond;
                                                        break;
                                                    default:
                                                        var operator = "dbn_" + distValue[1];
                                                        var condition = "dbCond_" + distValue[1];
                                                        if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                            $scope.distribution.push({
                                                                "key": distValue[0],
                                                                "operator": document.getElementById(operator).innerText,
                                                                "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                                "condition": document.getElementById(condition).innerText,
                                                                "referenceTable": value.referenceTable,
                                                                "referencePath": value.referencePath,
                                                                "referenceValue": value.referenceValue,
                                                                "fieldName": value.metaDataFieldName,
                                                                "type": value.fieldType,
                                                                "lookUp": value.lookUp,
                                                                "fieldId": value.metaDataFieldId
                                                            })
                                                        }
                                                        cond = !1;
                                                        return cond
                                                }
                                            }
                                        })
                                    } else {
                                        condValue = !1;
                                        return condValue
                                    }
                                })
                            }
                            if ($scope.distribution.length > 0) {
                                $scope.distributionData[distValue[0]] = $scope.distribution
                            }
                            $scope.distribution = []
                        });
                        $rootScope.metadataPreflight = {};
                        if ($rootScope.FinalFields.length > 0) {
                            var prefcondition = [];
                            var count = 0;
                            var displayName;
                            angular.forEach($rootScope.FinalFields, function(fName) {
                                var cond = !0;
                                if (cond) {
                                    angular.forEach($rootScope.metadataConditions, function(value) {
                                        angular.forEach(value.metadataFieldConfig, function(value) {
                                            if (fName === value.fieldDisplayName) {
                                                prefcondition.push({
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "fieldId": value.metaDataFieldId
                                                });
                                                cond = !1;
                                                displayName = value.fieldDisplayName
                                            }
                                        })
                                    });
                                    $rootScope.metadataPreflight[displayName] = prefcondition;
                                    prefcondition = []
                                }
                            })
                        }
                        $http({
                            method: 'POST',
                            url: '/saveBr',
                            data: {
                                columnSearchData: searchBrData,
                                ruleName: $scope.ruleName,
                                ruleType: $rootScope.ruleType,
                                customer: $rootScope.vendor,
                                description: $scope.description,
                                account: $rootScope.accountType,
                                metadataPreflight: Object.keys($rootScope.metadataPreflight).length > 0 ? $rootScope.metadataPreflight : null,
                                activeFlag: !1,
                                isDelete: !1,
                                trigger: $scope.triggerDays,
                                partnerIds: $rootScope.vendorIds,
                                dateToTrigger: $rootScope.dateToStart,
                                operations: Object.keys($scope.operationalConds).length > 0 ? $scope.operationalConds : null,
                                accountId: $rootScope.acntId,
                                metadataType: $rootScope.metadataType,
                                metadataConditions: Object.keys($scope.distributionData).length > 0 ? $scope.distributionData : null,
                                createdBy: $rootScope.loggedUser.userId,
                                modifiedBy: $rootScope.loggedUser.userId
                            }
                        }).then(function(response) {
                            if (response.data.code == "200") {
                                $location.url('/business-rules');
                                $rootScope.dataList = response.data.data;
                                $rootScope.successAddBrMsg = !0;
                                $rootScope.successAddBrMsgContent = response.data.statusMessage;
                                setTimeout(function() {
                                    $rootScope.successAddBrMsg = !1;
                                    $rootScope.$apply()
                                }, $rootScope.alertTimeoutInterval)
                            } else {
                                $rootScope.failureAddBrMsg = !0;
                                $rootScope.failureAddBrMsgContent = response.data.statusMessage;
                                $rootScope.dataList = response.data.data;
                                setTimeout(function() {
                                    $rootScope.failureAddBrMsg = !1;
                                    $rootScope.$apply()
                                }, $rootScope.alertTimeoutInterval)
                            }
                        })
                    }
                } else {
                    $scope.addCondition = !1
                }
            })
        }
    }
    $scope.updateBr = function() {
        $rootScope.editDisable = !0;
        $scope.addCondition = !0;
        if ($rootScope.ruleType === $rootScope.brSel || $rootScope.ruleType === undefined) {
            $scope.ruleTypeError = !0;
            $scope.addCondition = !1
        }
        if ($scope.ruleName == undefined) {
            $scope.ruleNameError = !0;
            $scope.addCondition = !1
        }
        if ($scope.addCondition) {
            if ($rootScope.ruleType === 'Pre-flight') {
                if ($rootScope.FinalFields.length <= 0) {
                    $rootScope.prefMetaError = !0;
                    return !1
                } else {
                    $rootScope.prefMetaError = !1
                }
            } else if ($rootScope.ruleType === "Distribution") {
                if ($rootScope.distFinalValues.length <= 0) {
                    $rootScope.distMetaError = !0;
                    return !1
                } else {
                    $rootScope.distMetaError = !1
                }
                if ($rootScope.prefSelect === "Select") {
                    $rootScope.prefError = !0;
                    return !1
                } else {
                    $rootScope.prefError = !1
                }
            }
            $scope.distributionData = {};
            angular.forEach($rootScope.distFinalValues, function(distVal) {
                $scope.distribution = [];
                var distValue = distVal.split("_");
                var condValue = !0;
                if (condValue) {
                    var cond = !0;
                    angular.forEach($rootScope.metadataConditions, function(value1) {
                        if (cond) {
                            angular.forEach(value1.metadataFieldConfig, function(value) {
                                if (distValue[0] === value.fieldDisplayName) {
                                    switch ((value.fieldType).toLowerCase()) {
                                        case "dropdown":
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if ('Select' != document.getElementById(operator).innerText) {
                                                if ("Select" != document.getElementById("Dis_" + value.metaDataFieldName).innerText) {
                                                    var drpVal = document.getElementById("Dis_" + value.metaDataFieldName).innerText;
                                                    var selectval = drpVal.split('-');
                                                    $scope.distribution.push({
                                                        "key": distValue[0],
                                                        "operator": document.getElementById(operator).innerText,
                                                        "value": selectval[0],
                                                        "condition": document.getElementById(condition).innerText,
                                                        "referenceTable": value.referenceTable,
                                                        "referencePath": value.referencePath,
                                                        "referenceValue": value.referenceValue,
                                                        "fieldName": value.metaDataFieldName,
                                                        "type": value.fieldType,
                                                        "lookUp": value.lookUp,
                                                        "fieldId": value.metaDataFieldId
                                                    })
                                                }
                                            }
                                            cond = !1;
                                            return cond;
                                        case "text":
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                $scope.distribution.push({
                                                    "key": distValue[0],
                                                    "operator": document.getElementById(operator).innerText,
                                                    "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                    "condition": document.getElementById(condition).innerText,
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "type": value.fieldType,
                                                    "lookUp": value.lookUp,
                                                    "fieldId": value.metaDataFieldId
                                                })
                                            }
                                            cond = !1;
                                            return cond;
                                        case "number":
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if ('Select' != document.getElementById(operator).innerText) {
                                                if ("Between" === document.getElementById(operator).innerText) {
                                                    if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                        $scope.distribution.push({
                                                            "key": distValue[0],
                                                            "operator": document.getElementById(operator).innerText,
                                                            "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                            "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                            "condition": document.getElementById(condition).innerText,
                                                            "referenceTable": value.referenceTable,
                                                            "referencePath": value.referencePath,
                                                            "referenceValue": value.referenceValue,
                                                            "fieldName": value.metaDataFieldName,
                                                            "type": value.fieldType,
                                                            "lookUp": value.lookUp,
                                                            "fieldId": value.metaDataFieldId
                                                        })
                                                    }
                                                } else {
                                                    if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText) {
                                                        $scope.distribution.push({
                                                            "key": distValue[0],
                                                            "operator": document.getElementById(operator).innerText,
                                                            "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                            "condition": document.getElementById(condition).innerText,
                                                            "referenceTable": value.referenceTable,
                                                            "referencePath": value.referencePath,
                                                            "referenceValue": value.referenceValue,
                                                            "fieldName": value.metaDataFieldName,
                                                            "type": value.fieldType,
                                                            "lookUp": value.lookUp,
                                                            "fieldId": value.metaDataFieldId
                                                        })
                                                    }
                                                }
                                            }
                                            cond = !1;
                                            return cond;
                                        case "date":
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if ('Select' != document.getElementById(operator).innerText) {
                                                if ("Between" === document.getElementById(operator).innerText) {
                                                    if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                        $scope.distribution.push({
                                                            "key": distValue[0],
                                                            "operator": document.getElementById(operator).innerText,
                                                            "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                            "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                            "condition": document.getElementById(condition).innerText,
                                                            "referenceTable": value.referenceTable,
                                                            "referencePath": value.referencePath,
                                                            "referenceValue": value.referenceValue,
                                                            "fieldName": value.metaDataFieldName,
                                                            "type": value.fieldType,
                                                            "lookUp": value.lookUp
                                                        })
                                                    }
                                                } else {
                                                    if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText) {
                                                        $scope.distribution.push({
                                                            "key": distValue[0],
                                                            "operator": document.getElementById(operator).innerText,
                                                            "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                            "condition": document.getElementById(condition).innerText,
                                                            "referenceTable": value.referenceTable,
                                                            "referencePath": value.referencePath,
                                                            "referenceValue": value.referenceValue,
                                                            "fieldName": value.metaDataFieldName,
                                                            "type": value.fieldType,
                                                            "lookUp": value.lookUp
                                                        })
                                                    }
                                                }
                                            }
                                            cond = !1;
                                            return cond;
                                        case 'range':
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if ('Select' != document.getElementById(operator).innerText) {
                                                if ("Between" === document.getElementById(operator).innerText) {
                                                    if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "" != document.getElementById("Dis_" + value.metaDataFieldName + "_1").value) {
                                                        $scope.distribution.push({
                                                            "key": distValue[0],
                                                            "operator": document.getElementById(operator).innerText,
                                                            "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                            "value1": document.getElementById("Dis_" + value.metaDataFieldName + "_1").value,
                                                            "condition": document.getElementById(condition).innerText,
                                                            "referenceTable": value.referenceTable,
                                                            "referencePath": value.referencePath,
                                                            "referenceValue": value.referenceValue,
                                                            "fieldName": value.metaDataFieldName,
                                                            "type": value.fieldType,
                                                            "lookUp": value.lookUp
                                                        })
                                                    }
                                                }
                                            }
                                            cond = !1;
                                            return cond;
                                            break;
                                        case 'textarea':
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                $scope.distribution.push({
                                                    "key": distValue[0],
                                                    "operator": document.getElementById(operator).innerText,
                                                    "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                    "condition": document.getElementById(condition).innerText,
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "type": value.fieldType,
                                                    "lookUp": value.lookUp,
                                                    "fieldId": value.metaDataFieldId
                                                })
                                            }
                                            cond = !1;
                                            return cond;
                                            break;
                                        case 'multiselect':
                                            var checkedValue = [];
                                            var inputElements = document.getElementsByClassName("Dis_" + distValue[0]);
                                            for (var i = 0; inputElements[i]; ++i) {
                                                if (inputElements[i].checked) {
                                                    var s = inputElements[i].value.split("-");
                                                    checkedValue.push(s[0])
                                                }
                                            }
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if ('Select' != document.getElementById(operator).innerText) {
                                                if (checkedValue.length > 0) {
                                                    $scope.distribution.push({
                                                        "key": distValue[0],
                                                        "operator": document.getElementById(operator).innerText,
                                                        "value": checkedValue,
                                                        "condition": document.getElementById(condition).innerText,
                                                        "referenceTable": value.referenceTable,
                                                        "referencePath": value.referencePath,
                                                        "referenceValue": value.referenceValue,
                                                        "fieldName": value.metaDataFieldName,
                                                        "type": value.fieldType,
                                                        "lookUp": value.lookUp,
                                                        "fieldId": value.metaDataFieldId
                                                    })
                                                }
                                            }
                                            cond = !1;
                                            return cond;
                                            break;
                                        case 'email':
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                $scope.distribution.push({
                                                    "key": distValue[0],
                                                    "operator": document.getElementById(operator).innerText,
                                                    "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                    "condition": document.getElementById(condition).innerText,
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "type": value.fieldType,
                                                    "lookUp": value.lookUp,
                                                    "fieldId": value.metaDataFieldId
                                                })
                                            }
                                            cond = !1;
                                            return cond;
                                            break;
                                        case 'url':
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                $scope.distribution.push({
                                                    "key": distValue[0],
                                                    "operator": document.getElementById(operator).innerText,
                                                    "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                    "condition": document.getElementById(condition).innerText,
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "type": value.fieldType,
                                                    "lookUp": value.lookUp,
                                                    "fieldId": value.metaDataFieldId
                                                })
                                            }
                                            cond = !1;
                                            return cond;
                                            break;
                                        default:
                                            var operator = "dbn_" + distValue[1];
                                            var condition = "dbCond_" + distValue[1];
                                            if (null != document.getElementById("Dis_" + value.metaDataFieldName) && null != document.getElementById(condition).innerText && "Select" != document.getElementById(operator).innerText) {
                                                $scope.distribution.push({
                                                    "key": distValue[0],
                                                    "operator": document.getElementById(operator).innerText,
                                                    "value": document.getElementById("Dis_" + value.metaDataFieldName).value,
                                                    "condition": document.getElementById(condition).innerText,
                                                    "referenceTable": value.referenceTable,
                                                    "referencePath": value.referencePath,
                                                    "referenceValue": value.referenceValue,
                                                    "fieldName": value.metaDataFieldName,
                                                    "type": value.fieldType,
                                                    "lookUp": value.lookUp,
                                                    "fieldId": value.metaDataFieldId
                                                })
                                            }
                                            cond = !1;
                                            return cond
                                    }
                                }
                            })
                        } else {
                            condValue = !1;
                            return condValue
                        }
                    })
                }
                if ($scope.distribution.length > 0) {
                    $scope.distributionData[distValue[0]] = $scope.distribution
                }
                $scope.distribution = []
            });
            $scope.oppCond = [];
            $scope.operationalConds = {};
            if ($scope.ruleName != "Pre-flight") {
                if ($rootScope.oppValues.length > 0) {
                    angular.forEach($rootScope.oppValues, function(value) {
                        var actValue = value.split("_");
                        var count = !0;
                        var keyName;
                        if (count) {
                            angular.forEach($rootScope.operationalConditions, function(value1) {
                                if (actValue[0] === value1.conditionDisplayName) {
                                    var v = "spn_" + actValue[1];
                                    var operator;
                                    if (null != document.getElementById(v).innerText) {
                                        operator = document.getElementById(v).innerText
                                    }
                                    var condition = "opp_" + actValue[1];
                                    if (actValue[0] === "File Uploaded By") {
                                        $scope.oppCond.push({
                                            "key": actValue[0],
                                            "operator": operator,
                                            "value": $rootScope.brUserId,
                                            "referencePath": value1.referencePath
                                        });
                                        count = !1
                                    }
                                    if (actValue[0] === "Approval Status") {
                                        $scope.oppCond.push({
                                            "key": actValue[0],
                                            "operator": operator,
                                            "value": $rootScope.approvalValue,
                                            "referencePath": value1.referencePath,
                                            "approvalId": $rootScope.approvalValueId
                                        });
                                        count = !1
                                    } else if (actValue[0] === "Format") {
                                        var checkedValue = [];
                                        var inputElements = document.getElementsByClassName("formatNames");
                                        for (var i = 0; inputElements[i]; ++i) {
                                            if (inputElements[i].checked) {
                                                checkedValue.push(inputElements[i].value)
                                            }
                                        }
                                        $scope.oppCond.push({
                                            "key": actValue[0],
                                            "operator": operator,
                                            "value": checkedValue,
                                            "referencePath": value1.referencePath
                                        });
                                        count = !1
                                    } else if (actValue[0] === "File Uploaded On") {
                                        var dtVal = "dt" + actValue[1];
                                        var dtVal1 = "dt" + actValue[1] + "_1";
                                        if ("Between" === operator) {
                                            $scope.oppCond.push({
                                                "key": actValue[0],
                                                "operator": operator,
                                                "value": document.getElementById(dtVal).value,
                                                "value1": document.getElementById(dtVal1).value,
                                                "referencePath": value1.referencePath
                                            })
                                        } else {
                                            $scope.oppCond.push({
                                                "key": actValue[0],
                                                "operator": operator,
                                                "value": document.getElementById(dtVal).value,
                                                "referencePath": value1.referencePath
                                            })
                                        }
                                        count = !1
                                    } else if (actValue[0] === "Pre-flight") {
                                        $scope.oppCond.push({
                                            "key": actValue[0],
                                            "operator": operator,
                                            "value": $rootScope.prefSelect,
                                            "referencePath": value1.referencePath
                                        });
                                        count = !1
                                    }
                                    keyName = actValue[0];
                                    if (!count) {
                                        return !1
                                    }
                                }
                            });
                            $scope.operationalConds[keyName] = $scope.oppCond;
                            $scope.oppCond = []
                        }
                    })
                }
            }
            $rootScope.metadataPreflight = {};
            if ($rootScope.FinalFields.length > 0) {
                var prefcondition = [];
                var count = 0;
                var displayName;
                angular.forEach($rootScope.FinalFields, function(fName) {
                    var cond = !0;
                    if (cond) {
                        angular.forEach($rootScope.metadataConditions, function(value) {
                            angular.forEach(value.metadataFieldConfig, function(value) {
                                if (fName === value.fieldDisplayName) {
                                    prefcondition.push({
                                        "referenceTable": value.referenceTable,
                                        "referencePath": value.referencePath,
                                        "referenceValue": value.referenceValue,
                                        "fieldName": value.metaDataFieldName,
                                        "fieldId": value.metaDataFieldId
                                    });
                                    cond = !1;
                                    displayName = value.fieldDisplayName
                                }
                            })
                        });
                        $rootScope.metadataPreflight[displayName] = prefcondition;
                        prefcondition = []
                    }
                })
            }
            $http({
                method: 'POST',
                url: '/updateBr',
                data: {
                    columnSearchData: searchBrData,
                    id: $rootScope.brId,
                    ruleName: $scope.ruleName,
                    ruleType: $rootScope.ruleType,
                    customer: $rootScope.vendor,
                    description: $scope.description,
                    account: $rootScope.accountType,
                    partnerIds: $rootScope.vendorIds,
                    metadataPreflight: Object.keys($rootScope.metadataPreflight).length > 0 ? $rootScope.metadataPreflight : null,
                    activeFlag: !1,
                    isDelete: !1,
                    trigger: $scope.trigger,
                    dateToTrigger: $rootScope.dateToStart,
                    operations: Object.keys($scope.operationalConds).length > 0 ? $scope.operationalConds : null,
                    accountId: $rootScope.acntId,
                    metadataType: $rootScope.metadataType,
                    metadataConditions: Object.keys($scope.distributionData).length > 0 ? $scope.distributionData : null,
                    modifiedBy: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                if (response.data.code == "200") {
                    $rootScope.dataList = response.data.data;
                    $location.url('/business-rules');
                    $rootScope.successAddBrMsg = !0;
                    setTimeout(function() {
                        $rootScope.successAddBrMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    $rootScope.successAddBrMsgContent = response.data.statusMessage
                } else {
                    $location.url('/business-rules');
                    $rootScope.failureAddBrMsg = !0;
                    $rootScope.failureAddBrMsgContent = response.data.statusMessage;
                    setTimeout(function() {
                        $rootScope.failureAddBrMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    $rootScope.dataList = response.data.data
                }
            })
        }
    }
    $scope.show = function(event) {
        ModalService.showModal({
            templateUrl: 'modal.html',
            controller: "ModalController"
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {
                if (result == 'Yes') {
                    $scope.disabled = !0
                } else if (result == 'No') {
                    $scope.disabled = !1
                }
            })
        })
    }
}]);
app.controller('ModalController', function($scope, close) {
    $scope.close = function(result) {
        close(result, 500)
    }
});
app.directive('numbersOnly', function() {
    return {
        require: '?ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return
            }
            ngModelCtrl.$parsers.push(function(val) {
                if (angular.isUndefined(val)) {
                    var val = ''
                }
                var clean = val.replace(/[^-0-9\.]/g, '');
                var negativeCheck = clean.split('-');
                var decimalCheck = clean.split('.');
                if (!angular.isUndefined(negativeCheck[1])) {
                    negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                    clean = negativeCheck[0] + '-' + negativeCheck[1];
                    if (negativeCheck[0].length > 0) {
                        clean = negativeCheck[0]
                    }
                }
                if (!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0, 2);
                    clean = decimalCheck[0] + '.' + decimalCheck[1]
                }
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render()
                }
                return clean
            });
            element.bind('keypress', function(event) {
                if (event.keyCode === 32 || event.keyCode === 45 || event.keyCode === 46) {
                    event.preventDefault()
                }
            })
        }
    }
});
app.directive('brScrollToBottom', function($document, $rootScope) {
    return {
        restrict: 'A',
        link: function($scope, element, attrs) {
            $('#divTableBody').bind('scroll', function() {
                if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                    $rootScope.LastCurrentIndex = $rootScope.currentIndexLast;
                    $rootScope.skipCountScroll = $rootScope.LastCurrentIndex;
                    if ($rootScope.currentIndexLast < $rootScope.totalCount) {
                        if ($rootScope.totalCount.toString() === $rootScope.dContent.length.toString()) {
                            return
                        }
                        $rootScope.currentIndexLast = $rootScope.dContent.length;
                        $rootScope.showEligibleTitles($rootScope.ruleNameEli, $rootScope.skipCountScroll)
                        $rootScope.showEligibleTableLoader();
                        return !1
                    } else {
                        return !1
                    }
                }
            })
        }
    }
})