var app = angular.module('ManageonCP', ['pascalprecht.translate', 'ngRoute','dndLists','ngAnimate', 'ngSanitize', 'ui.bootstrap', 'angularModalService', 'ngCookies', 'ngFileUpload', 'angularFileUpload', 'ngFilesizeFilter', "chart.js", 'angular.filter', 'msl.uploads', 'flow', 'ManageonCP.dashboard.controller', 'ManageonCP.dashboard.serivce', 'pdfjsViewer', '720kb.tooltips', '720kb.datepicker', 'ui.toggle', 'angular-star-rating', 'btford.socket-io', 'ngIdle']).config(function($routeProvider) {
    $routeProvider.when('/', {
        templateUrl: "templates/dashboard.html",
        controller: "dashboardController",
        title: "cP 4.0 - Login",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/dashboard', {
        templateUrl: "templates/dashboard.html",
        controller: "dashboardController",
        title: "cP 4.0 - Login",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-list', {
        templateUrl: "templates/notification-all-list.html",
        controller: "notificationController",
        title: "cP 4.0 - Notification",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/pdf-viewer', {
        templateUrl: "templates/viewer-pdf.html",
        controller: "BaseController",
        title: "cP 4.0 - Viewer",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/epub-viewer', {
        templateUrl: "templates/viewer-epub.html",
        controller: "BaseController",
        title: "cP 4.0 - Viewer",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/view/', {
        templateUrl: "templates/view.html",
        controller: "pdfviewerController",
        title: "cP 4.0 - Viewer",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/widget-preview', {
        templateUrl: "templates/widget-preview.html",
        controller: "pdfviewerController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/widget-action', {
        templateUrl: "templates/widget-action.html",
        controller: "widgetCreationController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/widget-dashboard', {
        templateUrl: "templates/widget-dashboard.html",
        controller: "widgetCreationController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-master/app-template', {
        templateUrl: "templates/notification-master-app-template.html",
        controller: "notificationMasterController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-master/email-template', {
        templateUrl: "templates/notification-master-email-template.html",
        controller: "notificationMasterController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-master', {
        templateUrl: "templates/notification-master.html",
        controller: "notificationMasterController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-mapping', {
        templateUrl: "templates/notification-mapping.html",
        controller: "notificationMasterController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/notification-mapping-creation', {
        templateUrl: "templates/notification-mapping-creation.html",
        controller: "notificationMasterController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/user-master', {
        templateUrl: "templates/user-master.html",
        controller: "UserMasterController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/role-master', {
        templateUrl: "templates/role-view.html",
        controller: "RoleMasterController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/business-rules', {
        templateUrl: "templates/business-rules-view.html",
        controller: "businessController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/partners', {
        templateUrl: "templates/partners.html",
        controller: "PartnerController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/product-category', {
        templateUrl: "templates/product-category.html",
        controller: "ProductCategoryController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/formats', {
        templateUrl: "templates/formats.html",
        controller: "BaseController",
        title: "cP 4.0 - Buisness"
    }).when('/accounts', {
        templateUrl: "templates/accounts.html",
        controller: "AccountMasterController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/create-business-rule', {
        templateUrl: "templates/create-business-rule.html",
        controller: "businessController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/create-role', {
        templateUrl: "templates/role-form.html",
        controller: "RoleMasterController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !0;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/metadata', {
        templateUrl: "templates/metadata.html",
        controller: "MetaDataController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/metadata-create', {
        templateUrl: "templates/metadata-create.html",
        controller: "MetaDataController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/metadata-edit/', {
        templateUrl: "templates/metadata-edit.html",
        controller: "MetaDataController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/metadata-upload', {
        templateUrl: "templates/metadata-upload.html",
        controller: "MetaDataController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/metadata-onix-upload', {
        templateUrl: "templates/metadata-onix-upload.html",
        controller: "MetaDataController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/myprofile', {
        templateUrl: "templates/myprofile.html",
        controller: "UserProfileController",
        title: "cP 4.0 - Buisness",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/asset', {
        templateUrl: "templates/asset.html",
        controller: "BaseController",
        title: "cP 4.0 - Login",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/standardDashboard-master', {
        templateUrl: "templates/standardDashboard.html",
        controller: "StandardDashboardController",
        title: "cP 4.0 - DashboardMaster",
        resolve: {
            isAdminTabs: function($route) {
                $route.current.params.isAdminTab = !0
            }
        }
    }).when('/shelf', {
        templateUrl: "templates/shelf.html",
        controller: "ShelfController",
        title: "cP 4.0 - Login",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/support', {
        templateUrl: "templates/support.html",
        controller: "supportController",
        title: "cP 4.0 - Login",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/upload', {
        templateUrl: "templates/upload.html",
        controller: "FileUploadController",
        title: "cP 4.0 - File Upload",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/shelfUpload', {
        templateUrl: "templates/upload.html",
        controller: "FileUploadController",
        title: "cP 4.0 - File Upload",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/report', {
        templateUrl: "templates/report.html",
        controller: "ReportController",
        title: "cP 4.0 - Report",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            },
            loadAssetSummaryReports: function($route) {
                return function() {}
            }
        }
    }).when('/asset-approval-report', {
        templateUrl: "templates/report.html",
        controller: "ReportController",
        title: "cP 4.0 - File Upload",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            },
            loadAssetApprovalReports: function($route) {
                return function() {}
            }
        }
    }).when('/bulk-upload', {
        templateUrl: "templates/bulk-upload.html",
        controller: "BaseController",
        title: "cP 4.0 - Bulk File Upload",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/meta-manual-distribution', {
        templateUrl: "templates/meta-manual-distribution.html",
        controller: "metaManualDistributionController",
        title: "cP 4.0 - Manual Distribution",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/partner-configuration', {
        templateUrl: "templates/partner-configuration.html",
        controller: "PartnerConfigController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/create-new-partner-config', {
        templateUrl: "templates/create-new-partner-config.html",
        controller: "PartnerConfigController",
        title: "cP 4.0 - pdf",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/manual-distribution', {
        templateUrl: "templates/manual-distribution.html",
        controller: "manualDistributionController",
        title: "cP 4.0 - Manual Distribution",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/eligible-titles', {
        templateUrl: "templates/business_rule_details.html",
        controller: "businessController",
        title: "cP 4.0 - Eligible Titles",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    }).when('/manual-take-down', {
       templateUrl: "templates/manual-takedown.html",
       controller: "metaManualDistributionController",
       title: "cP 4.0 - Manual Distribution",
       resolve: {
           isAdminTabs: function($route, $window) {
               $route.current.params.isAdminTab = !1;
               if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                   $window.location.href = 'login/#'
               }
           }
       }
   }).when('/unauthorized', {
        templateUrl: "templates/unauthorized.html",
        title: "cP 4.0 - Unauthorized"
    }).otherwise({
        templateUrl: "templates/under-construction.html",
        controller: "BaseController",
        title: "cP 4.0 - Dashboard",
        resolve: {
            isAdminTabs: function($route, $window) {
                $route.current.params.isAdminTab = !1;
                if ($window.sessionStorage.device == "false" || $window.sessionStorage.device == undefined) {
                    $window.location.href = 'login/#'
                }
            }
        }
    })
}).run(function($rootScope, $translate, Idle, $window, $http) {
    $rootScope.$on('$translateChangeSuccess', function() {
        $rootScope.hideLoader('body')
    });
    $rootScope.$on("$routeChangeSuccess", function(event, currentRoute, previousRoute) {
        var request = {
            method: 'get',
            url: 'Pageaccess.json',
            dataType: 'json',
            contentType: "application/json"
        };
        $rootScope.arrBirds = [];
        $http(request).success(function(jsonData) {
            $rootScope.pageAccessData = jsonData;
            angular.forEach($rootScope.pageAccessData, function(role) {
                if (role.pagename == $window.location.hash) {
                    if (role.pagename == '#/report') {
                        var flag = $rootScope.checkReportAccessPermission(role.moduleId, role.accessId)
                    } else {
                        var flag = $rootScope.checkAccessPermission(role.moduleId, role.accessId, role.rolename)
                    }
                    if (!flag) {
                        $window.location.href = '#/unauthorized'
                    }
                }
            })
        }).error(function() {});
        if ($rootScope.language === 'undefined' || $rootScope.language === undefined || $rootScope.language === null)
            $rootScope.language = 'en';
        $translate.use($rootScope.language)
    });
    Idle.watch();
    $rootScope.$on('IdleStart', function() {});
    $rootScope.$on('IdleTimeout', function() {
        $rootScope.reloadRedirect();
        $rootScope.isAuthenticated = !1;
        $window.sessionStorage.device = $rootScope.isAuthenticated;
    })
});
app.config(function(IdleProvider, KeepaliveProvider) {
    IdleProvider.idle(3600);
    IdleProvider.interrupt('mousemove keydown DOMMouseScroll mousewheel mousedown');
    IdleProvider.timeout(3)
});
app.config(function($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: '../resources/lang/locale-',
        suffix: '.json'
    });
    $translateProvider.useSanitizeValueStrategy('escape')
});
app.controller('BaseController', ['$scope', '$window', '$rootScope', 'ModalService', '$timeout', '$http', '$routeParams', '$location', '$filter', '$q', '$translate', '$interval', 'socket', '$sce', 'Idle', 'notificationService', function($scope, $window, $rootScope, ModalService, $timeout, $http, $routeParams, $location, $filter, $q, $translate, $interval, socket, $sce, Idle, notificationService) {
    $rootScope.notificationFilter = [];
    $rootScope.uniqueSelectedPageRange = [];
    $rootScope.showNoResultDiv = !1;
    $rootScope.showNoResultAllVer = !1;
    $rootScope.search = {};
    $rootScope.alertTimeoutInterval = 10000;
    $rootScope.checkAccessPermission = function(moduleId, accessId, tabName) {
        var returnFlg = !1;
        try {
            var loggedUserRole = $filter('filter')($rootScope.roleList, function(data) {
                return (data.roleId == $rootScope.loggedUser.permissionGroup.roleId)
            })[0];
            if (loggedUserRole != undefined && loggedUserRole != null) {
                var module = $filter('filter')(loggedUserRole.module, function(module) {
                    return module.moduleId === moduleId
                });
                if (module.length == 1) {
                    var submodule = $filter('filter')(module[0].submodule, function(val) {
                        return val.accessId == accessId
                    });
                    if (submodule.length == 1) {
                        if ($filter('filter')(submodule[0].activityAccess, function(tab) {
                                return tab == tabName
                            }).length == 1)
                            returnFlg = !0
                    }
                }
            }
        } catch (e) {}
        return returnFlg
    };
    $rootScope.showLoader = function(el, num, effect) {
        text = 'Processing please wait...';
        fontSize = '';
        switch (num) {
            case 1:
                maxSize = '';
                textPos = 'vertical';
                break;
            case 2:
                text = '';
                maxSize = 30;
                textPos = 'vertical';
                break;
            case 3:
                maxSize = 30;
                textPos = 'horizontal';
                fontSize = '18px';
                break
        }
        el.waitMe({
            effect: effect,
            text: text,
            bg: 'rgba(255,255,255,1)',
            color: '#197535',
            maxSize: 500,
            source: '../../images/img.svg',
            textPos: textPos,
            fontSize: fontSize,
            onClose: function() {}
        })
    }
    $rootScope.hideLoader = function(classname) {
        $('.' + classname).waitMe('hide')
    }
    if ($location.$$path.contains("/view") != !0 && $location.$$path.contains("/pdf-viewer") != !0) {
        $rootScope.showLoader($('.assetTable'), 1, 'win8_linear')
    }
    $rootScope.Idlewatch = function(flag) {
        if (flag == !0)
            Idle.watch();
        else Idle.unwatch()
    }
    if ($location.$$path.contains("/bulk-upload") == !0) {
        $rootScope.fileuploadlist = [];
        var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
        if (is_chrome) {
            $rootScope.showBulkUpload = !0;
            $rootScope.fileuploadlist = [];
            $http({
                method: 'GET',
                url: '/getAllFormats',
                data: null
            }).then(function(response) {
                $rootScope.getAllFormats = response.data
            })
        } else {
            alert("The current browser will not support bulk upload functionality. kindly try using chrome web browser.");
            $location.url('/asset')
        }
    } else {
        $rootScope.showBulkUpload = !1
    }
    if ($location.$$path.contains("/upload") == !0) {
        $rootScope.uploadpagename = 'Asset'
    } else if ($location.$$path.contains("/shelfUpload") == !0) {
        $rootScope.uploadpagename = 'Shelf'
    }
    $scope.ShowBulkUploadPage = function() {
        $rootScope.data = {};
        $location.url('/bulk-upload');
        $rootScope.uploadEmailForm = !1;
        document.getElementById("uploadChkHide").checked = !0
    }
    $rootScope.locationPath = $location.$$url;
    if ($rootScope.locationPath.contains('metadata')) {
        $rootScope.locationPath = '/#metadata';
        $rootScope.pagename = 'Metadata'
    } else {
        $rootScope.locationPath = '/#asset';
        $rootScope.pagename = 'Default'
    }
    $rootScope.myIndex = 0;
    $rootScope.pCategoryFilterList = [];
    $rootScope.dateFormat = 'yyyy/MM/dd';
    $scope.getDashBoard = function() {
        $http({
            method: 'GET',
            url: '/getDashBoard'
        }).then(function(response) {
            $scope.dashboardlist = response.data.data
        })
    }
    $rootScope.loadAssetSummaryReports = function(reportList) {
        localStorage.setItem("reportId", JSON.stringify(reportList))
        $timeout(function() {
            $rootScope.loadReports(reportList)
        }, 1000)
    }
    $rootScope.reportDelete = function(reportList) {
        $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/deleteSavedReport',
            data: {
                id: reportList.id
            }
        }).then(function successCallback(response) {
            $rootScope.getReportsList();
            if (response.data.status == '200') {
                $rootScope.showRPTDeleteSuccessMsg = !0;
                $rootScope.deleteReportSuccessMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTDeleteSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.showRPTDeleteErrorMsg = !0;
                $rootScope.deleteReportErrorMsg = response.data.statusMessage;
                setTimeout(function() {
                    $scope.showRPTDeleteErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {});
        $http({
            method: 'POST',
            url: '/loadAllReportChart',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                searchText: "",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                advancedSearch: {},
                pageName: reportList.pageName
            }
        }).then(function(response) {
            $rootScope.labels = response.data.data.label;
            $rootScope.series = response.data.data.series;
            $rootScope.data = response.data.data.data;
            $rootScope.trends = response.data.data.trends;
            eval('var obj=' + response.data.data.options);
            $scope.options = obj;
            angular.forEach($scope.options.title, function(key, val) {
                if (val === "text") {
                    $rootScope.commonHeader = key
                }
            })
            $rootScope.hideLoader('chart-container')
        });
        $http({
            method: 'POST',
            url: '/loadAllReportGrid',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                searchText: "",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                advancedSearch: {},
                pageName: reportList.pageName
            }
        }).then(function(response) {
            $rootScope.gridData = [];
            $rootScope.gridData = response.data.data;
            $rootScope.rptSearchCount = response.data.searchCount;
            $rootScope.hideLoader('report-grid')
        })
    };
    $rootScope.loadSavedReports = function(reportList) {
        localStorage.setItem("reportId", JSON.stringify(reportList))
        $timeout(function() {
            $rootScope.savedReports(reportList);
            $rootScope.copySavedReportList = angular.copy(reportList)
        }, 1000)
    }
    $rootScope.isEditRpt = [];
    $rootScope.duplicateRPTName = function(reportList, pageName, index) {
        $timeout(function() {
            $rootScope.reportIndex = index;
            $rootScope.isEditRpt[index] = !0;
            angular.element(".menu-side-edit-inputs" + index).show()
        }, 400)
        angular.forEach($rootScope.isEditRpt, function(key, val) {
            if (val != index)
                $rootScope.isEditRpt[val] = !1;
            angular.element(".menu-side-edit-inputs" + index).show()
        })
    };
    $http({
        method: 'GET',
        url: '/getLanguage'
    }).then(function successCallback(response) {
        $rootScope.language = response.data.language;
        if ($rootScope.language === null)
            $rootScope.language = "en";
        $translate.use($rootScope.language)
    }, function errorCallback(response) {});
    $scope.viewerFormats = function() {
        $http({
            method: 'GET',
            url: '/viewerFormats'
        }).then(function successCallback(response) {
            $rootScope.viewerEligibleFormats = response.data.data
        }, function errorCallback(response) {})
    }
    $scope.viewerFormats();
    $scope.newUserPcSearchNames = [];
    $http({
        method: 'GET',
        url: '/accountUser'
    }).then(function successCallback(response) {
        $rootScope.loggedUser = response.data.data;
        if ($rootScope.loggedUser == null || $rootScope.loggedUser == undefined || $rootScope.loggedUser.isActive == !1) {
            $rootScope.logout()
        }
    }, function errorCallback(response) {});
    $rootScope.redirectToBase = function(pageUrl) {
        $timeout(function() {
            $location.url('/' + pageUrl)
        }, 900)
    }
    $rootScope.togglePdfBook = !0;
    $rootScope.isEligibleFormat = function(format) {
        var frmEligible = $filter('filter')($rootScope.viewerEligibleFormats, function(data) {
            return (data.formatId == format.formatId)
        });
        return (frmEligible.length == 1) ? !0 : !1
    }
    $rootScope.getAssetBase = function(result, format) {
        localStorage.setItem("viewerISBN", result.ISBN13);
        localStorage.setItem("viewerFormat", format.formatId);
        localStorage.setItem("viewerEligibleFormat", angular.toJson($rootScope.viewerEligibleFormats));
        localStorage.setItem("isWidget", "false")
    }
    $rootScope.successManualDistMsg;
    $rootScope.toggleDistributionMsg = function() {
        $rootScope.successManualDistMsg = !0;
        $rootScope.successManualDistMsgContent = "Distribution order processed successfully!";
        setTimeout(function() {
            $rootScope.successManualDistMsg = !1;
            $rootScope.$apply()
        }, $rootScope.alertTimeoutInterval)
    }
    $rootScope.checkFormatDist = function() {
        $rootScope.manualDistribution = 'click';
        document.getElementById("tempbucketerr").innerHTML = "";
        if (Object.keys($rootScope.downloadUploadList).length > 100) {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to distribution request";
            return !1
        }
        if (Object.keys($rootScope.downloadUploadList).length > 0) {
            $http({
                method: 'POST',
                url: '/getEligiblePartners',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.partnerList = response.data.data
            });
            $scope.formatData = [];
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                $scope.formatData.push({
                    isbn: key[0].isbn,
                    format: key[0].format,
                    formatId: key[0].formatId,
                    title: key[0].title,
                    countryOfPublication: key[0].countryOfPublication,
                    ebookType: key[0].ebookType,
                    discount: key[0].discount
                })
            });
            $http({
                method: 'POST',
                url: '/getEligibleFormats',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $scope.validFormats = [];
                var count = 0;
                angular.forEach($scope.formatData, function(formats) {
                    var check = !0;
                    angular.forEach(response.data.data, function(item) {
                        if (check) {
                            if (formats.formatId === item.formatId) {
                                $scope.validFormats.push(formats);
                                count++;
                                check = !1
                            }
                        }
                    })
                });
                if (count === $scope.formatData.length) {
                    $http({
                        method: 'POST',
                        url: '/getFormatGridData',
                        data: {
                            partnerDetails: $scope.validFormats,
                            userId: $rootScope.loggedUser.userId
                        }
                    }).then(function(response) {
                        $rootScope.Partn = response.data.data;
                        angular.forEach($rootScope.Partn,function(obj){
                            angular.forEach($scope.formatData,function(innerobj){
                                if(innerobj.isbn == obj.isbn){
                                   obj.ebookType = innerobj.ebookType;
                                   obj.discount = innerobj.discount;
                                }
                            })
                        })
                        angular.forEach($rootScope.partnerList, function(prList) {
                            angular.forEach(response.data.data, function(resData) {
                                if (prList.partnerTypeId == resData.partnerTypeId) {
                                    prList.count = prList.count + 1
                                }
                            })
                        })
                        $location.url('/manual-distribution')
                    })
                } else {
                    angular.forEach($scope.formatData, function(formats) {
                        var id = "";
                        if ($scope.validFormats.indexOf(formats) == -1) {
                            document.getElementById("tempbucketerr").innerHTML = "Few file(s) are not eligible for distribution. Please uncheck the file(s) and proceed further.";
                            if (undefined == formats.formatId) {
                                angular.element("#" + formats.isbn + "_").children('.divTableCell').css('background', 'pink')
                            } else {
                                var id = formats.isbn + "_" + formats.formatId;
                                angular.element("#" + id).children('.divTableCell').css('background', 'pink')
                            }
                        }
                    })
                }
            })
        } else {
            document.getElementById("tempbucketerr").innerHTML = "Kindly check atleast one ISBN with valid format to proceed further."
        }
    }
    $rootScope.toggleEditProfile = function(arg) {
        if (arg == 'EDIT')
            $rootScope.showProfile = !0;
        else $rootScope.showProfile = !1;
        $window.location.href = '#/myprofile'
    }
    $scope.showshare = !1;
    $rootScope.downloadUploadList = {};
    $scope.emailList = [];
    $scope.showSuccessShareMail = !1;
    $scope.showFailedShareMail = !1;
    $rootScope.searchSuggestions = [];
    $scope.download_share_email_show = !1;
    $rootScope.downloadBtnShow = !1;
    $scope.fileList = [];
    $rootScope.logout = function() {
        $rootScope.isAuthenticated = !1;
        $window.sessionStorage.device = $rootScope.isAuthenticated;
        $http({
            method: 'GET',
            url: '/logout',
            data: null
        }).then(function(response) {
            $window.location.href = 'login/#'
        })
    }
    $rootScope.reloadRedirect = function() {
        angular.element("#reloadrequest").modal('toggle')
    }
    $rootScope.enableDisableAssetBulkUpload = function() {
        var disableBulkUploadButton = !1;
        angular.forEach($rootScope.fileBulkList, function(obj) {
            if (obj.status != !0)
                disableBulkUploadButton = !0
        })
        return disableBulkUploadButton
    }
    $scope.fileItems = [];
    $rootScope.fileBulkList = [];
    $rootScope.fileuploadlist = [];
    $scope.showNamingBox = !1;
    $scope.selectedFormatList = [];
    $scope.newArray = [];
    $scope.showSuccessBulkShare = !1;
    $http({
        method: 'POST',
        url: '/getPermissionGroup',
        data: {
            id: "BulkShare"
        }
    }).then(function successCallback(response) {
        if (response.data.code == '200') {
            $rootScope.checkBulkShareAccess = response.data.data.config.isEnabled
        }
    });
    $scope.bulk = function($flow) {
        $scope.fileItems = [];
        $scope.files = [];
        for (var i = 0; i < $flow.files.length; i++) {
            $scope.files.push($flow.files[i])
        }
        $flow.cancel();
        var result = !0;
        var count = 0;
        if ($scope.newArray.length > 0) {
            var array = [];
            var array1 = [];
            angular.forEach($scope.newArray, function(file) {
                var filepath = file.file.relativePath;
                if (!filepath.contains("/"))
                    filepath = filepath.replace("_", "/");
                var s = filepath.split('/')[0] + "/" + filepath.split('/')[1];
                angular.forEach($scope.files, function(file1) {
                    var filepath1 = file1.relativePath;
                    if (!filepath1.contains("/"))
                        filepath1 = filepath1.replace("_", "/");
                    if (filepath1.contains(s)) {
                        result = !1;
                        count++
                    }
                })
            })
        }
        if (count == 0) {
            angular.forEach($scope.files, function(file) {
                $scope.fileItems.push({
                    filePath: file.relativePath,
                    fileSize: file.size
                })
            });
            $http({
                method: 'POST',
                url: '/bulkUploadValidation',
                data: {
                    bulkFileList: $scope.fileItems,
                    loggeduser: $rootScope.loggedUser.userId,
                    assetActivity: "UPLOAD"
                }
            }).then(function(response) {
                angular.forEach($scope.files, function(file) {
                    angular.forEach(response.data.data, function(item) {
                        if (file.relativePath == item.filePath) {
                            $rootScope.fileBulkList.push({
                                path: item.filePath,
                                size: item.convertedFileSize,
                                status: item.fileStatus,
                                statusmessage: item.fileStatusMessage,
                                isbn: item.isbn,
                                title: item.title,
                                author: item.author,
                                formatName: item.formatName,
                                fileName: item.fileName,
                                fileSize: item.fileSize,
                                file: file.file
                            })
                        }
                    })
                });
                $scope.newArray1 = $rootScope.fileBulkList.filter(function(jobData) {
                    return $scope.files.some(function(userData) {
                        return (userData.relativePath === jobData.path) && jobData.status
                    })
                });
                Array.prototype.push.apply($scope.newArray, $scope.newArray1)
                $scope.invalidBulkUploadIsbn = $rootScope.fileBulkList.filter(function(jobData) {
                    return $scope.files.some(function(userData) {
                        return (userData.relativePath != jobData.path) && !jobData.status
                    })
                })
            })
        } else {
            alert("Format already exist for same isbn. Cancel the files and try again!!!")
        }
    };
    $scope.bulkClose = function(index) {
        angular.forEach($rootScope.fileBulkList, function(file, fileindex) {
            if (fileindex == index) {
                angular.forEach($scope.newArray, function(array, arrayindex) {
                    if (array.file.relativePath == file.path) {
                        $scope.newArray.splice(arrayindex, 1)
                    }
                })
            }
        })
        $rootScope.fileBulkList.splice(index, 1)
    }
    $scope.bulkCancel = function() {
        $rootScope.fileBulkList = [];
        $scope.fileItems = [];
        $scope.newArray = []
    }
    $scope.$on('$routeChangeSuccess', function(event, current) {
        if (current.loadedTemplateUrl != 'templates/bulk-upload.html')
            $rootScope.showBulkUpload = !1
    })
    $scope.openNamingBox = function() {
        if ($scope.showNamingBox) {
            $scope.showNamingBox = !1
        } else {
            $scope.showNamingBox = !0
        }
    }
    $scope.hideLoginContainer = function() {
        $scope.showNamingBox = !1
    };
    $scope.downloadNamingConversion = function() {
        $http({
            method: 'GET',
            url: '/exportNamingConversion',
            data: null
        }).then(function(response) {
            if (response.data.code == "200") {
                window.open(response.data.data, "_blank")
            }
        })
    }
    $rootScope.uploadEmailForm = !1;
    $rootScope.emailShowUpload = function() {
        $rootScope.uploadEmailForm = !0;
        $http({
            method: 'GET',
            url: '/getNotificationEmailIds',
            data: null
        }).then(function(response) {
            if (response.data.code == '200') {
                $rootScope.data = {};
                document.getElementById('uploadEmail').value = '';
                $rootScope.getNotificationUserEmailIds = response.data.data.emailIds.toString();
                document.getElementById('uploadEmail').value = response.data.data.emailIds.toString();
                $rootScope.data.emailNotiGroup = response.data.data.emailIds.toString()
            }
        })
    }
    $rootScope.emailHideUpload = function(uploadForm) {
        $rootScope.uploadEmailForm = !1
    }
    $rootScope.srchIsbnFilter = function(val) {
        $rootScope.uploadFileFilteredList = $filter('filter')($rootScope.fileuploadlist, function(data) {
            return data.file1.file.relativePath.indexOf($scope.searchString) != -1
        })
    };
    $scope.bulkUploadEmailList = [];
    $scope.fileUploadedShow = !1;
    $scope.bulkupload = function() {
        $scope.fileUploadedShow = !0;
        var notificationEmailList = document.getElementById('uploadEmail').value.split(",").map(function(item) {
            return item.trim()
        });
        notificationEmailList = notificationEmailList.filter(function(e) {
            return e
        });
        $rootScope.addEmailIds = [];
        angular.forEach(notificationEmailList, function(email) {
            if (!$rootScope.addEmailIds.includes(email)) {
                $rootScope.addEmailIds.push(email)
            }
        })
        $rootScope.Idlewatch(!1);
        var file_id = 0;
        $http({
            method: 'POST',
            url: '/generateFileUploadLink',
            data: null
        }).then(function(response) {
            var accessKey = response.data.data.accessKey;
            var bucketName = response.data.data.bucketName;
            var region = response.data.data.region;
            var signerUrl = "/fileUploadSignature";
            var filePromises = [],
                allCompleted
            COOKIE = 'evaporate_example', cookie_data = {
                persist: "off"
            }, cookie_options = {
                expires: 1
            };
            var count = 0;
            angular.forEach($scope.newArray, function(file, index) {
                var newArrayLength = $scope.newArray.length;
                $rootScope.fileBulkList = [];
                $scope.fileItems = [];
                var randomkey = Math.floor((Math.random() * 1000) + 1);
                $rootScope.fileuploadlist.push({
                    file1: file,
                    randomkey: randomkey,
                    convertedSize: file.size,
                    fileindex: index
                });
                var filepath = file.file.relativePath;
                var originalFilename = "";
                var path = "";
                var folname = "";
                if (filepath.indexOf("/") === -1) {
                    filepath = filepath.replace("_", "/");
                    originalFilename = file.file.relativePath
                } else {
                    originalFilename = file.fileName
                }
                var tmp = filepath.split("/");
                var tempLength = tmp.length;
                var isbn = tmp[0];
                var formatname = ""
                var dbfoldername = "";
                var formatId = "";
                angular.forEach($rootScope.getAllFormats, function(format) {
                    if (format.formatName == file.formatName) {
                        formatId = format.formatId
                    }
                    if (tmp[1].lastIndexOf('.') === -1) {
                        var namingConvention = format.namingConvention;
                        if (namingConvention != null) {
                            if (namingConvention.toUpperCase() === tmp[1].toUpperCase()) {
                                formatname = format.formatName;
                                for (var i = 1; i < tempLength - 1; i++) {
                                    if ("" === folname) {
                                        folname += format.formatName;
                                        dbfoldername += tmp[i]
                                    } else {
                                        folname += "/" + tmp[i];
                                        dbfoldername += "/" + tmp[i]
                                    }
                                }
                                path = tmp[0] + "/" + format.formatName + "/" + dbfoldername
                            }
                        }
                    } else {
                        var name = tmp[1].substr(0, tmp[1].lastIndexOf('.'));
                        var namingConvention = format.namingConvention;
                        if (namingConvention != null) {
                            if (namingConvention.toUpperCase() === name.toUpperCase()) {
                                formatname = format.formatName;
                                path = tmp[0] + "/" + format.formatName
                            }
                        }
                    }
                });
                Evaporate.create({
                    signerUrl: signerUrl,
                    aws_key: accessKey,
                    bucket: bucketName,
                    cloudfront: !1,
                    s3Acceleration: !0,
                    awsSignatureVersion: '4',
                    awsRegion: region,
                    directoryName: path + "/",
                    projectId: $scope.project_id,
                    computeContentMd5: !0,
                    cryptoMd5Method: function(data) {
                        return AWS.util.crypto.md5(data, 'base64')
                    },
                    cryptoHexEncodedHash256: function(data) {
                        return AWS.util.crypto.sha256(data, 'hex')
                    },
                    logging: !1,
                    s3FileCacheHoursAgo: 1,
                    allowS3ExistenceOptimization: !0
                }).then(function(_e_) {
                    var name = originalFilename;
                    var size = file.fileSize;
                    var fileKey = bucketName + '/' + name;
                    callback_methods = callbacks(file, fileKey, randomkey, index);
                    var promise = _e_.add({
                        name: name,
                        file: file.file,
                        started: callback_methods.started,
                        complete: callback_methods.complete,
                        progress: callback_methods.progress,
                        paused: callback_methods.paused,
                        pausing: callback_methods.pausing,
                        resumed: callback_methods.resumed,
                        cancelled: callback_methods.cancelled
                    }, {
                        bucket: bucketName,
                        aws_key: accessKey
                    }).then((function(requestedName) {
                        return function(awsKey) {
                            if (awsKey === requestedName) {
                                console.log(awsKey, 'successfully uploaded!');
                                $scope.bulkUploadEmailList.push({
                                    isbn: file.isbn,
                                    title: file.title,
                                    author: file.author,
                                    formatName: file.formatName,
                                    fileName: file.file.relativePath,
                                    fileSize: file.size
                                });
                                $scope.templateData = {};
                                $scope.templateData["[file-name]"] = file.fileName;
                                $scope.templateData["[format-name]"] = file.formatName;
                                $scope.templateData["[file-size]"] = file.size;
                                $scope.templateData["[isbn]"] = file.isbn;
                                $scope.templateData["[title]"] = file.title;
                                $scope.templateData["[author]"] = file.author;
                                $scope.templateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                                $scope.templateData["[upload-type]"] = "Bulk Upload";
                                $http({
                                    method: 'POST',
                                    url: '/addfileobjects',
                                    data: {
                                        productIDValue: isbn,
                                        loggeduser: $rootScope.loggedUser.userId,
                                        filename: originalFilename,
                                        formatName: file.formatName,
                                        size: size,
                                        bucket: bucketName,
                                        folder: dbfoldername,
                                        transactionStatus: "12",
                                        title: file.title,
                                        templateData: $scope.templateData,
                                        ipAddress: $window.sessionStorage.userIP,
                                        additionaleMailList: $rootScope.addEmailIds
                                    }
                                }).then(function(response) {});
                                $http({
                                    method: 'POST',
                                    url: '/saveShelfTransaction',
                                    data: {
                                        isbn: isbn,
                                        formatId: formatId,
                                        loggedUser: $rootScope.loggedUser.userId,
                                        action: "FILE_UPLOAD",
                                        shelfType: "Asset_Book"
                                    }
                                }).then(function(response) {})
                            } else {}
                        }
                    })(name));
                    filePromises.push(promise);
                    allCompleted = Promise.all(filePromises).then(function() {
                        $scope.newArray = [];
                        $rootScope.Idlewatch(!0);
                        count++;
                        if (count == newArrayLength) {
                            $http({
                                method: 'POST',
                                url: '/uploadMail',
                                data: {
                                    uploadMailList: $scope.bulkUploadEmailList,
                                    invalidbulkUploadList: $scope.invalidBulkUploadIsbn,
                                    loggeduser: $rootScope.loggedUser.firstName,
                                    loggedUserEmail: $rootScope.loggedUser.emailId,
                                    additionaleMailList: $rootScope.addEmailIds,
                                    loggedUserId: $rootScope.loggedUser.userId
                                }
                            }).then(function(response) {
                                count = 0;
                                $scope.bulkUploadEmailList = []
                            })
                        }
                    }, function(reason) {
                        $scope.newArray = [];
                        count++;
                        if (count == newArrayLength) {
                            $http({
                                method: 'POST',
                                url: '/uploadMail',
                                data: {
                                    uploadMailList: $scope.bulkUploadEmailList,
                                    invalidbulkUploadList: $scope.invalidBulkUploadIsbn,
                                    loggeduser: $rootScope.loggedUser.firstName,
                                    loggedUserEmail: $rootScope.loggedUser.emailId,
                                    additionaleMailList: $rootScope.addEmailIds,
                                    loggedUserId: $rootScope.loggedUser.userId
                                }
                            }).then(function(response) {
                                count = 0;
                                $scope.bulkUploadEmailList = []
                            })
                        }
                    });

                    function callbacks(file, fileKey, randomkey, fileindex) {
                        $('#show_cancel_' + fileindex + randomkey).click(function() {
                            _e_.cancel(fileKey)
                        });
                        $('#show_pause_' + fileindex + randomkey).click(function() {
                            _e_.pause(fileKey)
                        });
                        $('#show_resume_' + fileindex + randomkey).click(function() {
                            _e_.resume(fileKey)
                        });
                        var clock = new ProgressBar.Line(angular.element(document.getElementById('progressbar_' + fileindex + randomkey))[0], {
                            strokeWidth: 0,
                            duration: 350,
                            text: {
                                value: ''
                            },
                            step: function(state, bar) {
                                var bar1 = (bar.value() * 100).toFixed(0) + '%';
                                $('#progressbar_' + fileindex + randomkey).css('width', bar1)
                            }
                        });
                        var speed = angular.element(document.getElementById('filesize_show_' + fileindex + randomkey));
                        var time = angular.element(document.getElementById('time_show_' + fileindex + randomkey));

                        function markComplete(className) {
                            progress_clock.addClass(className);
                            status.text(className)
                        }
                        return {
                            started: function(fid) {
                                angular.element($("#progressClock_" + fileindex + randomkey)).addClass('evaporating');
                                angular.element($("#progressClock_" + fileindex + randomkey)).addClass('progress');
                                $('#show_cancel_' + fileindex + randomkey).show();
                                $('#show_pause_' + fileindex + randomkey).show();
                                $('#show_close_' + fileindex + randomkey).hide();
                                $('#selected_show_' + fileindex + randomkey).hide();
                                $('#title_show_' + fileindex + randomkey).show();
                                $('#progress_show_' + fileindex + randomkey).show();
                                $('#filesize_show_' + fileindex + randomkey).show();
                                $('#show_resume_' + fileindex + randomkey).hide();
                                $('#cancel_text_show_' + fileindex + randomkey).hide();
                                var file_id = fid
                            },
                            progress: function(progressValue, data) {
                                progress = progressValue;
                                clock.animate(progressValue);
                                $scope.fileloaded = data && data.loaded ? data.loaded : '';
                                $scope.remainingTime = data && data.secondsLeft ? Math.round(data.secondsLeft / 60) : '';
                                $scope.speed = data && data.speed ? data.readableSpeed + '/s' : '';
                                if (data) {
                                    var xferRate = data.speed ? data.readableSpeed + "/s - " : '';
                                    var rate = data && data.loaded ? data.loaded : '';
                                    var ra = $scope.sizefilter(data.totalUploaded);
                                    var rr = " of " + $scope.sizefilter(size);
                                    var remaining = data.secondsLeft ? Math.round(data.secondsLeft / 60) + ' mins left' : '';
                                    speed.html(xferRate + ra + rr);
                                    time.html(remaining)
                                }
                            },
                            complete: function(_xhr, awsKey, stats) {
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('progress');
                                angular.element($("#progressClock_" + fileindex + randomkey)).addClass("completed");
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating');
                                clock.animate(1);
                                $('#show_cancel_' + fileindex + randomkey).hide();
                                $('#show_pause_' + fileindex + randomkey).hide();
                                $('#show_close_' + fileindex + randomkey).show();
                                $('#selected_show_' + fileindex + randomkey).show();
                                $('#title_show_' + fileindex + randomkey).hide();
                                $('#progress_show_' + fileindex + randomkey).hide();
                                $('#filesize_show_' + fileindex + randomkey).hide();
                                $('#show_resume_' + fileindex + randomkey).hide();
                                $('#cancel_text_show_' + fileindex + randomkey).hide();
                                $('#time_show_' + fileindex + randomkey).hide()
                            },
                            pausing: function() {
                                $('#show_resume_' + fileindex + randomkey).show();
                                $('#show_pause_' + fileindex + randomkey).hide();
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning')
                            },
                            paused: function() {
                                $('#show_resume_' + fileindex + randomkey).show();
                                $('#show_pause_' + fileindex + randomkey).hide();
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning pausing')
                            },
                            resumed: function() {
                                clock.animate(progress);
                                $('#show_resume_' + fileindex + randomkey).hide();
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('pausing paused')
                            },
                            cancelled: function() {
                                $scope.newArray.splice(index, 1);
                                clock.animate(progress);
                                angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning paused pausing');
                                $('#show_cancel_' + fileindex + randomkey).hide();
                                $('#show_pause_' + fileindex + randomkey).hide();
                                $('#show_resume_' + fileindex + randomkey).hide();
                                $('#cancel_text_show_' + fileindex + randomkey).show();
                                $('#title_show_' + fileindex + randomkey).hide();
                                $('#progress_show_' + fileindex + randomkey).hide();
                                $('#filesize_show_' + fileindex + randomkey).hide();
                                $('#time_show_' + fileindex + randomkey).hide()
                            },
                        }
                    }
                })
            })
        })
    }
    $scope.sizefilter = function(size) {
        if (isNaN(size))
            size = 0;
        if (size < 1024) {
            $scope.filteredsize = size + ' Bytes';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Kb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Mb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Gb';
            return $scope.filteredsize
        }
        size /= 1024;
        $scope.filteredsize = size.toFixed(2) + ' Tb';
        return $scope.filteredsize
    }
    $scope.cancelupload = function(file, index) {
        var elmn = angular.element(document.querySelector('#progressClock_' + file.fileindex + file.randomkey));
        elmn.remove();
        $rootScope.fileuploadlist.splice(index, 1)
    };
    $scope.clearAll = function(file, index) {
        $timeout(function() {
            $scope.searchString = ''
        }, 300);
        $rootScope.fileuploadlist = []
    };
    $scope.removeBulkShareEmailError = function() {
        $scope.bulk_share_email_show = !1;
        $scope.bulk_share_email_error = ""
    };
    $scope.removeBulkShareEmailLinkError = function() {
        $scope.bulk_share_email_valid_show = !1
    };
    $scope.filterList1 = ['Completed', 'Progress', 'Failed'];
    $scope.actionList1 = [];
    $scope.filterUploads1 = function($event, val) {
        var isChecked = $event.target.checked;
        if (isChecked) {
            console.log(JSON.stringify($rootScope.fileuploadlist));
            $rootScope.randomkeyId = $rootScope.fileuploadlist.map(function(item) {
                return item.randomkey
            });
            console.log($rootScope.randomkeyId)
        } else {
            $scope.actionList1.splice(index, 1)
        }
    }
    $scope.filterUploadschkAll = function($event) {
        var isChecked = $event.target.checked;
        angular.forEach($scope.filterList1, function(data) {
            var result = document.getElementsByClassName(data);
            if (isChecked) {
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            } else {
                angular.element(result).removeClass('active');
                angular.element(result).addClass('inactive')
            }
        })
    }
    $scope.userFormat = function(activity) {
        $http({
            method: 'POST',
            url: '/getUserPermissionFormats',
            data: {
                permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                assetActivity: activity
            }
        }).then(function successCallback(response) {
            if (response.data.code == "200") {
                $scope.userPermissionFormats = response.data.data
            }
        })
    }
    $scope.bulkFormatAllSelect = function($event) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            angular.forEach($scope.userPermissionFormats, function(format, index) {
                document.getElementById("format_" + index).checked = !0;
                $scope.selectedFormatList.push(format)
            })
        } else if (action === 'remove') {
            angular.forEach($scope.userPermissionFormats, function(format, index) {
                document.getElementById("format_" + index).checked = !1;
                $scope.selectedFormatList.splice($scope.selectedFormatList.indexOf(format), 1)
            })
            $scope.formatAppendPath = null
        }
    }
    $scope.bulkFormatSelect = function(format, checkFormatNames, $event) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            if ($scope.selectedFormatList.indexOf(format) == -1) {
                $scope.selectedFormatList.push(format)
            }
        } else if (action === 'remove') {
            if ($scope.selectedFormatList.indexOf(format) != -1) {
                $scope.selectedFormatList.splice($scope.selectedFormatList.indexOf(format), 1)
            }
        }
    }
    $scope.sendBulkEmail = function() {
        $scope.bulkemailList = [];
        var bulkexpiryTime = angular.element(document.getElementById("bulkexpiryTime")).val();
        if (bulkexpiryTime == null || bulkexpiryTime == "" || bulkexpiryTime == undefined) {
            $scope.bulk_share_email_valid_show = !0;
            $scope.bulk_share_email_valid_error = "Please enter valid till"
        } else {
            $scope.bulk_share_email_valid_show = !1;
            $scope.bulk_share_email_valid_error = ""
        }
        if ($scope.bulkshareemail != null && $scope.bulkshareemail != "") {
            $scope.bulk_share_email_show = !1;
            $scope.bulk_share_email_error = "";
            $scope.bulk_share_email_pattern_error = !1;
            $scope.bulk_share_email_pattern_error_msg = "";
            if ($scope.bulkshareemail.indexOf(',') != -1) {
                var em = $scope.bulkshareemail.split(',');
                var valid = !0;
                var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                for (var i = 0; i < em.length; i++) {
                    if (em[i] == "" || !regex.test(em[i])) {
                        valid = !1
                    } else {
                        $scope.bulkemailList.push(em[i])
                    }
                }
                if ($scope.bulkemailList.length == 0) {
                    $scope.bulk_share_email_pattern_error = !0;
                    $scope.bulk_share_email_pattern_error_msg = "Please enter valid email"
                } else {}
            } else {
                var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if ($scope.bulkshareemail == "" || !regex.test($scope.bulkshareemail)) {
                    $scope.bulk_share_email_pattern_error = !0;
                    $scope.bulk_share_email_pattern_error_msg = "Please enter valid email"
                } else {
                    $scope.bulkemailList.push($scope.bulkshareemail)
                }
            }
            if ($scope.bulk_share_email_valid_show || $scope.bulk_share_email_show || $scope.bulk_share_email_pattern_error) {
                var myEl = angular.element(document.querySelector('#sendDownload'));
                myEl.removeAttr('data-dismiss', "modal")
            } else {
                var failedEmails = [];
                var uploadFormatArray = [];
                angular.forEach($scope.selectedFormatList, function(itm) {
                    $http({
                        method: 'POST',
                        url: '/getFormat',
                        data: {
                            formatName: itm
                        }
                    }).then(function successCallback(response) {
                        uploadFormatArray.push(response.data.data.formatId)
                    })
                });
                var myEl = angular.element(document.querySelector('#sendDownload'));
                myEl.attr('data-dismiss', "modal");
                var expiryTime = bulkexpiryTime;
                $scope.bulkshareemail = "";
                angular.element(document.getElementById("bulkexpiryTime")).val = "";
                $scope.showbulkshare = !1;
                if ($scope.bulkemailList.length > 0) {
                    angular.forEach($scope.bulkemailList, function(emailId) {
                        $http({
                            method: 'POST',
                            url: '/verifyUser',
                            data: {
                                emailId: emailId
                            }
                        }).then(function successCallback(response) {
                            if (response.data.code == '500') {
                                $http({
                                    method: 'POST',
                                    url: '/getPermissionGroup',
                                    data: {
                                        id: "BulkUpload"
                                    }
                                }).then(function successCallback(response) {
                                    if (response.data.code == '200') {
                                        $http({
                                            method: 'POST',
                                            url: '/createPermissionGroup',
                                            data: {
                                                roleId: response.data.data.config.roleId,
                                                asset: [{
                                                    permission: "UPLOAD",
                                                    format: uploadFormatArray
                                                }]
                                            }
                                        }).then(function successCallback(response) {
                                            $http({
                                                method: 'POST',
                                                url: '/createUser',
                                                data: {
                                                    emailId: emailId,
                                                    permissionGroupId: response.data.data.permissionGroupId,
                                                    userExpiryDate: expiryTime
                                                }
                                            }).then(function(response) {})
                                        })
                                    }
                                })
                            } else if (response.data.code == '200') {
                                var existingUserPg = response.data.data.permissionGroupId;
                                var viewFormatArray = [];
                                var downloadFormatArray = [];
                                var shareFormatArray = [];
                                var deleteFormatArray = [];
                                $http({
                                    method: 'POST',
                                    url: '/getUserPermissionGroup',
                                    data: {
                                        permissionGroupId: response.data.data.permissionGroupId,
                                    }
                                }).then(function(response) {
                                    angular.forEach(response.data.data.asset, function(asset) {
                                        if (asset.permission === 'UPLOAD') {
                                            angular.forEach(asset.format, function(format) {
                                                uploadFormatArray.push(format)
                                            })
                                        } else if (asset.permission === 'VIEW') {
                                            viewFormatArray = angular.copy(asset.format)
                                        } else if (asset.permission === 'DOWNLOAD') {
                                            downloadFormatArray = angular.copy(asset.format)
                                        } else if (asset.permission === 'SHARE') {
                                            shareFormatArray = angular.copy(asset.format)
                                        } else if (asset.permission === 'DELETE') {
                                            deleteFormatArray = angular.copy(asset.format)
                                        }
                                    })
                                    $http({
                                        method: 'POST',
                                        url: '/editPermissionGroup/' + existingUserPg,
                                        data: {
                                            permissionGroupName: response.data.data.permissionGroupName,
                                            roleId: response.data.data.roleId,
                                            account: response.data.data.account,
                                            metadataType: response.data.data.metadataType,
                                            imprint: response.data.data.imprint,
                                            productCategory: response.data.data.productCategory,
                                            metadataGroup: response.data.data.metadataGroup,
                                            partnerType: response.data.data.partnerType,
                                            application: response.data.data.application,
                                            asset: [{
                                                permission: "VIEW",
                                                format: viewFormatArray
                                            }, {
                                                permission: "UPLOAD",
                                                format: uploadFormatArray
                                            }, {
                                                permission: "DOWNLOAD",
                                                format: downloadFormatArray
                                            }, {
                                                permission: "SHARE",
                                                format: shareFormatArray
                                            }, {
                                                permission: "DELETE",
                                                format: deleteFormatArray
                                            }],
                                            report: response.data.data.report,
                                            administrator: response.data.data.administrator
                                        }
                                    }).then(function successCallback(response) {
                                        $http({
                                            method: 'POST',
                                            url: '/sendExistingUserShareMail',
                                            data: {
                                                emailId: emailId,
                                                loggedUserEmail: $scope.loggedUser.emailId,
                                            }
                                        }).then(function successCallback(response) {})
                                    })
                                })
                            } else {
                                failedEmails.push(emailId)
                            }
                        })
                    });
                    if (failedEmails.length > 0) {
                        $http({
                            method: 'POST',
                            url: '/sendExistingUserFailedShareMail',
                            data: {
                                emailList: failedEmails,
                                loggedUserEmail: $scope.loggedUser.emailId,
                            }
                        }).then(function successCallback(response) {})
                    }
                    $scope.showSuccessBulkShare = !0;
                    setTimeout(function() {
                        $scope.showSuccessBulkShare = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            }
        } else {
            $scope.download_share_email_show = !0;
            $scope.download_share_email_error = "Please enter valid emailid"
        }
    };
    $scope.oneAtATime = !1;
    if ($routeParams.isAdminTab === undefined)
        $scope.adminTab = !1;
    else $scope.adminTab = $routeParams.isAdminTab;
    $scope.addnew_format_open = !0;
    $scope.metadata_sales_open = !0;
    $rootScope.setAdminTab = function() {
        $scope.adminTab = !0;
        $rootScope.pagename = 'Default';
        $rootScope.locationPath = '/#asset'
    }
    $rootScope.isAdminTab = function() {
        var AdminTab = ['/user-master', '/role-master', '/business-rules', '/metadatamaster', '/partners', '/product-category', '/formats', '/accounts'];
        if (AdminTab.indexOf($location.path()) != -1) {
            $rootScope.setAdminTab()
        }
        return $scope.adminTab
    }
    $rootScope.accountUser = function() {
        $http({
            method: 'GET',
            url: '/accountUser'
        }).then(function successCallback(response) {
            $rootScope.loggedUser = response.data.data;
            if ($rootScope.loggedUser == null || $rootScope.loggedUser == undefined) {
                $rootScope.logout()
            }
            if ($rootScope.loggedUser.firstName == null || $rootScope.loggedUser.firstName == undefined || $rootScope.loggedUser.firstName == "") {
                $('#enterUserNameModal').modal('show')
            }
        }, function errorCallback(response) {})
    };
    $rootScope.accountUser();
    $scope.isActive = function(viewLocation) {
        var active = (viewLocation === $location.path());
        return active
    };
    $scope.getBaseValues = function() {
        $http({
            method: 'GET',
            url: '/getToken',
            data: null
        }).then(function(response) {}, function(response) {
            $rootScope.token = 'Bearer :' + response.data.token
        })
    };
    $rootScope.showSuccessSearchSaveMsg = !1;
    $rootScope.Search = {};
    $rootScope.search.searchValue = "";
    $rootScope.search.globalSearchText = "";
    $rootScope.Search.HeaderSearch = {};
    $rootScope.Search.AdvancedSearch = {};
    $rootScope.Search.ImprintAssetSearch = {};
    $rootScope.Search.fieldDisplayName;
    $rootScope.search.statusAllSelect = {};
    $rootScope.existsError = !1;
    $rootScope.viewAll = "MENU.LABLE.VIEWALL";
    $rootScope.imprintName = "";
    $rootScope.assetStatus = "";
    $rootScope.searchResult = [];
    $rootScope.searchName;
    $rootScope.isExport = !1;
    $rootScope.customHeadersDisplayName = [];
    $rootScope.customHeadersDisplayOrder = [];
    $rootScope.accountFilterList = [];
    $rootScope.imprintFilterList = [];
    $rootScope.GlobalImprintList = [];
    $rootScope.GlobalOthersList = [];
    $rootScope.GlobalOthersCodeList = [];
    $rootScope.formatFilterList = [];
    $rootScope.formatCodeList = [];
    $rootScope.pCategoryFilterList = [];
    $rootScope.downloadType = [{'name':'CSV','type':'CSV'},
                                {'name':'Excel','type':'XLSX'}];
    $rootScope.statusFilterList = {};
    $rootScope.othersFilterList = [];
    $rootScope.advancedOthersFilterList = [];
    $rootScope.columnFilterList = {};
    $rootScope.searchCount = "";
    $rootScope.selectedAccounts = [];
    $rootScope.columnFilterSearch = {};
    $rootScope.From = {};
    $rootScope.To = {};
    $scope.closeSaveSearch = function() {
        $('#myModal').modal('toggle');
        angular.element($("#savesearchname")).val('')
    }
    $scope.resetSaveSearch = function() {
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            angular.element("#myModal").modal('toggle')
            angular.element($("#savesearchname")).val('')
        }
    }
    $rootScope.checkSavedGridHeaders = function() {
        $rootScope.gridHeaderAssetCount = [];
        $rootScope.gridHeaderMetaCount = [];
        $timeout(function() {
            if($rootScope.pagename == 'Metadata'){
                angular.forEach($rootScope.mDataCustomHeaders, function(value, key) {
                    if ($filter('filter')($rootScope.tempMDataGridHeaders, function(itm) {
                            return (itm.fieldName == value.fieldName)
                        }).length > 0) {
                        $rootScope.gridHeaderMetaCount.push(value.fieldName);
                        value.mChecked = !0
                    } else {
                        value.mChecked = !1
                    }
                })
            }
            else{
                angular.forEach($rootScope.customHeaders, function(value, key) {
                    if ($filter('filter')($rootScope.tempGridHeaders, function(itm) {
                            return (itm.fieldName == value.fieldName)
                        }).length > 0) {
                            
                        value.sChecked = !0;
                        $rootScope.gridHeaderAssetCount.push(value.fieldName)
                    } else {
                        value.sChecked = !1
                    }
                })
            }
           
        }, 10);
        $timeout(function() {
            $rootScope.headerColoumn()
        }, 900)
    }
    $scope.updateNotificationFlag = function(flag, id) {
        var updateflag;
        if (flag) {
            updateflag = !1
        } else {
            updateflag = !0
        }
        $http({
            method: 'POST',
            url: '/updateNotifcationFlag',
            data: {
                id: id,
                flag: updateflag,
                userId: $rootScope.loggedUser.userId
            }
        }).then(function(response) {
            $rootScope.notificationMessages = response.data.data;
            $rootScope.notificationMessages = notificationService.modifyNotifyList($rootScope.notificationMessages);
            angular.forEach($rootScope.notificationMessages, function(data) {
                if ($rootScope.notificationFilter.indexOf(data.notificationName) == -1)
                    $rootScope.notificationFilter.push(data.notificationName)
            })
        })
    }
    $scope.clearAllNotification = function() {
        var user_id = $rootScope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/clearAllNotifications',
            data: {
                userId: user_id
            }
        }).then(function(response) {
            $rootScope.notificationMessages = response.data.data;
            $rootScope.notificationMessages = notificationService.modifyNotifyList($rootScope.notificationMessages);
            angular.forEach($rootScope.notificationMessages, function(data) {
                if ($rootScope.notificationFilter.indexOf(data.notificationName) == -1)
                    $rootScope.notificationFilter.push(data.notificationName)
            })
        })
    }
    $rootScope.markAllReadNotifications = function() {
        var user_id = $rootScope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/markAllReadNotifications',
            data: {
                userId: user_id
            }
        }).then(function(response) {
            $rootScope.notificationMessages = response.data.data;
            $rootScope.notificationMessages = notificationService.modifyNotifyList($rootScope.notificationMessages);
            angular.forEach($rootScope.notificationMessages, function(data) {
                if ($rootScope.notificationFilter.indexOf(data.notificationName) == -1)
                    $rootScope.notificationFilter.push(data.notificationName)
            })
        })
    }
    $scope.cancelNotification = function() {
        $rootScope.rmNotificationId = ""
    }
    $scope.cancelDownloadNotification = function() {
        $scope.rmDownloadUniqueId = ""
    }
    $scope.removeNotificationChk = function(id) {
        $rootScope.rmNotificationId = id;
        $rootScope.showDeleteNotificationMsg = !0;
        $timeout(function() {
            $rootScope.showDeleteNotificationMsg = !1
        }, $rootScope.alertTimeoutInterval)
    }
    $scope.removeDownloadNotification = function(id) {
        $rootScope.removBtnDisabled = !0;
        $rootScope.rmDownloadUniqueId = id;
        $rootScope.msg.showCommonSuccessMsgExport = !1;
        $rootScope.msg.showReportSuccessMsgExport = !1;
        $http({
            method: 'POST',
            url: '/deleteDownloadData',
            data: {
                userId: $rootScope.loggedUser.userId,
                uniqueId: $rootScope.rmDownloadUniqueId
            }
        }).then(function(response) {
            $rootScope.getDownloadNotification();
            $scope.cancelDownloadNotification();
            if (response.data.code == '200') {
                $rootScope.msg.showBaseSuccessMsg = !0;
                $rootScope.msg.baseSuccessMsg = response.data.status;
                $timeout(function() {
                    $rootScope.removBtnDisabled = !1
                }, 1000);
                setTimeout(function() {
                    $rootScope.msg.showBaseSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.msg.showBaseErrorMsg = !0;
                $rootScope.msg.baseErrorMsg = response.data.status;
                $timeout(function() {
                    $rootScope.removBtnDisabled = !1
                }, 1000)
                setTimeout(function() {
                    $rootScope.msg.showBaseErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    };
    $rootScope.InitBasicDataHeader = function() {
        $rootScope.customGridHeaders = [];
        $rootScope.gridHeaders = [];
        $rootScope.tempGridHeaders = [];
        $rootScope.tempMDataGridHeaders = [];
        var user_id = "";
        $http({
            method: 'GET',
            url: '/getLoggedUserId',
            data: null
        }).then(function(response) {
            user_id = response.data;
            $http({
                method: 'POST',
                url: '/getNotifications',
                data: {
                    userId: user_id
                }
            }).then(function(response) {
                $rootScope.notificationMessages = response.data.data;
                $rootScope.notificationMessages = notificationService.modifyNotifyList($rootScope.notificationMessages);
                angular.forEach($rootScope.notificationMessages, function(data) {
                    if ($rootScope.notificationFilter.indexOf(data.notificationName) == -1)
                        $rootScope.notificationFilter.push(data.notificationName)
                })
            });
            socket.on(user_id, function(data) {
                $rootScope.notificationMessages.push(data);
                $rootScope.notificationMessages = notificationService.modifyNotifyList($rootScope.notificationMessages);
                angular.forEach($rootScope.notificationMessages, function(data) {
                    if ($rootScope.notificationFilter.indexOf(data.notificationName) == -1)
                        $rootScope.notificationFilter.push(data.notificationName)
                })
            });
            $http({
                method: 'GET',
                url: '/getMetaDataTypes',
                data: null
            }).then(function(response) {
                $rootScope.metaDataTypes = response.data.data;
                $rootScope.mDataType = $rootScope.metaDataTypes[0].metadataTypeName;
                $rootScope.mCategory = $rootScope.metaDataTypes[0].categories[0].description;
                $rootScope.searchFieldName = $rootScope.metaDataTypes[0].categories[0].fieldDisplayName;
                $rootScope.mTypeTitle = $rootScope.metaDataTypes[0].categories[0].displayName;
                $rootScope.Search.HeaderSearch.metaDataType = $rootScope.mDataType;
                $rootScope.Search.HeaderSearch.metaDataCategory = $rootScope.mCategory;
                $rootScope.rTypeTitle = $rootScope.metaDataTypes[0].categories[1].displayName;
                $rootScope.rCategoryValues = $rootScope.metaDataTypes[0].categories[1].description;
                $rootScope.rCategory = $rootScope.metaDataTypes[0].categories[1].fieldDisplayName;
                $rootScope.Search.fieldDisplayName = $rootScope.searchFieldName;
                $rootScope.search.searchValue = "";
                $rootScope.search.globalSearchText = "";
                $rootScope.searchFlag = "G";
                if ($location.$$url == '/asset' || $location.$$url == '/metadata')
                    $rootScope.searchClearAll()
            });
            $http({
                method: 'GET',
                url: '/getAdvancedFilters',
                data: null
            }).then(function(response) {
                if (!$rootScope.checkAccessPermission('MOD00012', 'DEFAULT_ACTIVITY', 'INACTIVE_TITLES'))
                    $rootScope.othersList = $filter('filter')(response.data.data.othersList, function(data) {
                        return data.code != 'INACTIVE'
                    });
                else $rootScope.othersList = response.data.data.othersList;
                $rootScope.statusList = response.data.data.statusList;
                if (!$rootScope.checkAccessPermission('MOD00012', 'DEFAULT_ACTIVITY', 'INACTIVE_TITLES'))
                    $rootScope.advanceFilterStatusList = $filter('filter')(response.data.data.statusFilterList, function(data) {
                        return data.code != 'METADATA'
                    });
                else $rootScope.advanceFilterStatusList = response.data.data.statusFilterList
            });
            $http({
                method: 'POST',
                url: '/getReportGridHeaders/',
                data: {
                    userId: 'USR00001',
                    pageName: 'RPT00001'
                }
            }).then(function(response) {
                $rootScope.reportGridHeaders = response.data.data
            });
            $http({
                method: 'GET',
                url: '/getCustomHeaders/' + 'Default',
                data: null
            }).then(function(response) {
                $rootScope.customHeaders = response.data.data;
                $http({
                    method: 'GET',
                    url: '/getGridHeaders/' + 'Default',
                    data: null
                }).then(function(response) {
                    $rootScope.gridHeaders = response.data.data;
                    $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
                    $rootScope.checkSavedGridHeaders()
                })
            });
            $http({
                method: 'POST',
                url: '/getSavedSearch',
                data: {
                    userId: user_id,
                    pageName: 'Default'
                }
            }).then(function(response) {
                $rootScope.savedSearchList = response.data.data
            });
            $http({
                method: 'POST',
                url: '/getSavedSearch',
                data: {
                    userId: user_id,
                    pageName: 'Metadata'
                }
            }).then(function(response) {
                $rootScope.savedMetadataList = response.data.data
            })
        })
    };
    $rootScope.getMdataTypeValues = function(mDataType, mCategory, displayname, fieldName) {
        if ($rootScope.search.searchValue != '') {
            $rootScope.searchEnable = !0
        }
        $rootScope.mCategory = mCategory;
        $rootScope.searchFieldName = fieldName;
        $rootScope.Search.HeaderSearch.metaDataType = mDataType;
        $rootScope.Search.HeaderSearch.metaDataCategory = mCategory;
        $rootScope.Search.fieldDisplayName = fieldName;
        $rootScope.mTypeTitle = displayname
    };
    $rootScope.recentSearchValue = function(searchKey) {
        $rootScope.search.searchValue = searchKey;
        angular.element($("#txtSearch")).val(searchKey);
        $rootScope.reqId = new Date().getTime();
        $rootScope.commonAllFilter()
    };
    $rootScope.suggestSearchValue = function(suggestsearchKey) {
        $rootScope.search.searchValue = suggestsearchKey;
        angular.element($("#txtSearch")).val(suggestsearchKey);
        $rootScope.reqId = new Date().getTime();
        $rootScope.commonAllFilter()
    };
    $rootScope.columnsSearch = function() {
        var filterCount = 0;
        if (Object.keys($rootScope.inColFilterList).length != 0 || Object.keys($rootScope.ninColFilterList).length != 0) {
            $.each($rootScope.inColFilterList, function(index, fieldName) {
                if (fieldName != null && fieldName != undefined && Object.keys(fieldName).length != 0) {
                    filterCount = 1
                    return
                }
            });
            if (filterCount == 0) {
                $.each($rootScope.ninColFilterList, function(index, fieldName) {
                    if (fieldName != null && fieldName != undefined && Object.keys(fieldName).length != 0) {
                        filterCount = 1
                        return
                    }
                })
            }
        } else {
            filterCount = 0
        }
        return filterCount
    };
    $rootScope.dateColumnSearch = function() {
        var isMyObjectEmpty = !Object.keys($rootScope.fromDateFilterList).length;
        if (isMyObjectEmpty)
            isMyObjectEmpty = !Object.keys($rootScope.toDateFilterList).length;
        return !isMyObjectEmpty
    };
    $rootScope.clearCustomHeaders = function() {
        $timeout(function() {
            $rootScope.headerColoumn();
            $rootScope.gearFilterTopScroll()
        }, 200)
        if ($rootScope.pagename == 'Metadata') {
            angular.forEach($rootScope.mDataCustomHeaders, function(itm) {
                itm.mChecked = !1
            })
            angular.forEach($rootScope.mDataCustomHeaders, function(itm) {
                angular.forEach($rootScope.tempMDataGridHeaders, function(data) {
                    if(itm.fieldName == data.fieldName){
                        itm.sChecked = !1;
                var index = $rootScope.tempMDataGridHeaders.indexOf(data);
                $rootScope.tempMDataGridHeaders.splice(index, 1);
                        
                    }
                })
            })
            // $rootScope.tempMDataGridHeaders = angular.copy($rootScope.mDataGridHeaders);
            // angular.forEach($rootScope.mDataCustomHeaders, function(itm) {
            //     angular.forEach($rootScope.tempMDataGridHeaders, function(data) {
            //         if(itm.fieldName == data.fieldName){
            //             itm.sChecked = !1;
            //     var index = $rootScope.tempMDataGridHeaders.indexOf(data);
            //     $rootScope.tempMDataGridHeaders .splice(index, 1);
                        
            //         }
            //     })
            // })
        } else {
            angular.forEach($rootScope.customHeaders, function(itm) {
                angular.forEach($rootScope.tempGridHeaders, function(data) {
                    if(itm.fieldName == data.fieldName){
                        itm.sChecked = !1;
                var index = $rootScope.tempGridHeaders.indexOf(data);
                $rootScope.tempGridHeaders.splice(index, 1);
                        
                    }
                })
            })
            // $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
            // angular.forEach($rootScope.customHeaders, function(itm) {
            //     angular.forEach($rootScope.tempGridHeaders, function(data) {
            //         if(itm.fieldName == data.fieldName){
            //             itm.sChecked = !1;
            //     var index = $rootScope.tempGridHeaders.indexOf(data);
            //     $rootScope.tempGridHeaders.splice(index, 1);
                        
            //         }
            //     })
            // })
            
        }
    };
    $rootScope.showStatusFilter = function(statusFilter) {
        if (statusFilter.code == 'METADATA') {
            var data = $filter('filter')($rootScope.othersList, function(data) {
                return (data.code == 'INACTIVE')
            });
            if (data.length == 1 && document.getElementById("other_" + data[0].description) != null && document.getElementById("other_" + data[0].description).checked)
                return !0;
            else {
                var data2 = $filter('filter')($rootScope.advanceFilterStatusList, function(data) {
                    return data.code == 'METADATA'
                });
                if (data2.length == 1) {
                    $rootScope.search.statusAllSelect[data2[0].code] = !1;
                    $rootScope.statusFilterList[data2[0].code] = [];
                    angular.forEach($filter('filter')($rootScope.statusList, function(data) {
                        return data.statusType == data2[0].statusType
                    }), function(status) {
                        status.afchecked = !1
                    })
                }
                return !1
            }
        } else return !0
    }
    $rootScope.cpRemove = function(filterCategory, val) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        if (filterCategory == "ACCOUNT") {
            if ($rootScope.accountFilterList.length > 0) {
                if (document.getElementById("region_" + val.accountId) != null)
                    document.getElementById("region_" + val.accountId).checked = !1;
                $rootScope.accountFilterList = $filter('filter')($rootScope.accountFilterList, function(data) {
                    return data.accountId != val.accountId
                });
                $rootScope.selectedAccounts = $filter('filter')($rootScope.selectedAccounts, function(data) {
                    return data != val.accountId
                });
                document.getElementById("regionAllSelected").checked = !1;
                $rootScope.search.regionAllSelected = !1;
                $rootScope.getImprints();
                if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'F';
                    $rootScope.resetGlobalFilters()
                }
            }
        } else if (filterCategory == "IMPRINT") {
            if ($rootScope.imprintFilterList.length > 0) {
                if (document.getElementById("imprint_" + val) != null)
                    document.getElementById("imprint_" + val).checked = !1;
                $rootScope.imprintFilterList = $filter('filter')($rootScope.imprintFilterList, function(data) {
                    return data != val
                });
                $rootScope.refreshSearchImprintList();
                if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'F';
                    $rootScope.resetGlobalFilters()
                }
            }
        } else if (filterCategory == "PRODUCTCATEGORY") {
            $rootScope.pCategoryFilterList = $filter('filter')($rootScope.pCategoryFilterList, function(data) {
                return data.productCategoryId != val.productCategoryId
            });
            val.selected = !1;
            if (val.children && val.children.length > 0) {
                $rootScope.traverseSearchTree(val.children, "UNSELECT")
            }
            $rootScope.search.pCateoryAllSelected = !1;
            $rootScope.getSelectedSearchFilterProductCategories();
            setTimeout(function() {
                if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'F';
                    $rootScope.resetGlobalFilters()
                }
            }, 100)
        } else if (filterCategory == 'FORMAT') {
            if ($rootScope.formatFilterList.length > 0) {
                angular.forEach($rootScope.formatList, function(itm) {
                    if (itm.formatId == val.formatId)
                        itm.sChecked = !1
                });
                $rootScope.refreshSearchFormatList();
                $rootScope.formatCodeList = $filter('filter')($rootScope.formatCodeList, function(data) {
                    return data != val.formatId
                });
                $rootScope.formatFilterList = $filter('filter')($rootScope.formatFilterList, function(data) {
                    return data.formatId != val.formatId
                });
                if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'F';
                    $rootScope.resetGlobalFilters()
                }
            }
        } else if (filterCategory == 'OTHERS') {
            if ($rootScope.othersFilterList.length > 0) {
                if (document.getElementById("other_" + val.description) != null)
                    document.getElementById("other_" + val.description).checked = !1;
                document.getElementById("otherCheckAll").checked = !1;
                $rootScope.search.otherAllSelect = !1;
                $rootScope.othersFilterList = $filter('filter')($rootScope.othersFilterList, function(data) {
                    return data.code != val.code
                });
                $rootScope.advancedOthersFilterList = $filter('filter')($rootScope.advancedOthersFilterList, function(data) {
                    return data != val.code
                });
                if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'F';
                    $rootScope.resetGlobalFilters()
                }
            }
        } else if (filterCategory == "IMPRINTGLOBAL") {
            if ($rootScope.GlobalImprintList.length > 0) {
                if (document.getElementById(val + "_Global") != null)
                    document.getElementById(val + "_Global").checked = !1;
                $rootScope.GlobalImprintList = $filter('filter')($rootScope.GlobalImprintList, function(data) {
                    return data != val
                });
                $rootScope.refreshSearchGlobalImprintList();
                if ($rootScope.GlobalImprintList.length === 0 && $rootScope.GlobalOthersList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'I';
                    $rootScope.resetAdvancedFilters()
                }
            }
        } else if (filterCategory == "OTHERSGLOBAL") {
            if ($rootScope.GlobalOthersList.length > 0) {
                if (document.getElementById(val.description + "_Global") != null)
                    document.getElementById(val.description + "_Global").checked = !1;
                document.getElementById("mtAllSelected").checked = !1;
                $rootScope.GlobalOthersList = $filter('filter')($rootScope.GlobalOthersList, function(data) {
                    return data.code != val.code
                });
                $rootScope.GlobalOthersCodeList = $filter('filter')($rootScope.GlobalOthersCodeList, function(data) {
                    return data != val.code
                });
                $rootScope.mtAllSelected = !1;
                if ($rootScope.GlobalImprintList.length === 0 && $rootScope.GlobalOthersList.length === 0) {
                    $rootScope.searchFlag = 'G'
                } else {
                    $rootScope.searchFlag = 'I';
                    $rootScope.resetAdvancedFilters()
                }
            }
        } else if (filterCategory == "GLOBALSEARCH") {
            $rootScope.Search.HeaderSearch.searchText = "";
            angular.element($("#txtSearch")).val('');
            angular.element($("#txtSearchInner")).val('');
            $rootScope.search.searchValue = "";
            $rootScope.search.globalSearchText = "";
            if ($rootScope.accountFilterList.length === 0 && $rootScope.imprintFilterList.length === 0 && $rootScope.formatFilterList.length === 0 && $rootScope.pCategoryFilterList.length === 0 && $rootScope.othersFilterList.length === 0) {
                $rootScope.searchFlag = 'G'
            } else {
                $rootScope.searchFlag = 'F';
                $rootScope.resetGlobalFilters()
            }
        }
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.loadSearchResults = function(searchModule) {
        angular.element(".menu-action-dropdown").removeClass('active');
        if (searchModule == "ASSET") {
            location.href = "#/asset"
            setTimeout(function() {
                $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
            }, 100);
        } else {
            location.href = "#/metadata"
            setTimeout(function() {
                $rootScope.tempMDataGridHeaders = angular.copy($rootScope.mDataGridHeaders);
            }, 100);
        }
        setTimeout(function() {
            $rootScope.searchClearAll()
        }, 100);
       
        $rootScope.showLoader($('.assetTable'), 1, 'win8_linear');
        if (angular.element("#assetdivTableBody").is(":visible")) {
            angular.element("#assetdivTableBody").scrollLeft(0);
            var container = document.getElementById("assetdivTableBody");
            container.scrollTop = 0
        }
        $rootScope.gearHide = false;
        
    }
    $rootScope.reportPageClick = 'ggg';
    $rootScope.reportPageLoad = function() {
        $rootScope.reportPageClick = 'click';
        if ($location.$$url != '/report') {
            $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
            location.href = "#/report";
            $rootScope.loadAssetSummaryReports({
                "reportId": 'RPT00001',
                "reportName": 'Asset Activity',
                "isCursorFlag": !1,
                "$$hashKey": "object:414"
            });
            angular.element("#RPT00001").click()
        } else {
            return !1
        }
    }
    $rootScope.loadSearchAllResults = function(searchModule) {
        angular.element(".menu-action-dropdown").removeClass('active');
        $rootScope.assetmeta = 'click';
        $rootScope.searchSuggestion = !1;
        if (searchModule == "CLEAR") {
            if ($location.$$url != '/asset' && $location.$$url != '/metadata') {
                if ($location.$$url.contains('metadata'))
                    searchModule = "METADATA";
                else searchModule = "ASSET"
            }
        }
        if (searchModule == "ASSET") {
            if ($location.$$url == '/asset') {
                return !1
            } else {
                location.href = "#/asset";
                setTimeout(function() {
                    $rootScope.searchClearAll()
                }, 100);
                $rootScope.showLoader($('.assetTable'), 1, 'win8_linear');
                if (angular.element("#assetdivTableBody").is(":visible")) {
                    angular.element("#assetdivTableBody").scrollLeft(0);
                    var container = document.getElementById("assetdivTableBody");
                    container.scrollTop = 0
                }
            }
        } else if (searchModule == "METADATA") {
            if ($location.$$url == '/metadata') {
                return !1
            }
            location.href = "#/metadata";
            setTimeout(function() {
                $rootScope.searchClearAll()
            }, 100);
            $rootScope.showLoader($('.assetTable'), 1, 'win8_linear');
            if (angular.element("#assetdivTableBody").is(":visible")) {
                angular.element("#assetdivTableBody").scrollLeft(0);
                var container = document.getElementById("assetdivTableBody");
                container.scrollTop = 0
            }
        } else {
            $rootScope.searchClearAll()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0;
        $timeout(function() {
            angular.element(".searchdataheight").removeClass('save-search-data')
        })
    }
    $rootScope.assetmeta = 'sdas';
    if ($location.$$url == '/asset') {
        if ($rootScope.assetmeta != 'click') {
            $timeout(function() {
                angular.element("#asset-submenu").addClass('open')
            }, 2000)
        }
    }
    if ($location.$$url == '/metadata') {
        if ($rootScope.assetmeta != 'click') {
            $timeout(function() {
                angular.element("#meta-submenu").addClass('open')
            }, 2000)
        }
    }
    $rootScope.loadSavedSearch = function(searchModule, searchName, event) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.customGlobal = !0;
        $rootScope.search.globalSearchText = '';
        $rootScope.search.searchValue = '';
        if (!($(event.target).hasClass('icon') || $(event.target).parents().hasClass('icon'))) {
            if (searchModule == "ASSET") {
                location.href = "#/asset"
            } else {
                location.href = "#/metadata"
            }
            setTimeout(function() {
                $rootScope.viewSearch('N', searchName, 0, !1, !1, !1)
            }, 100)
        }
        if (angular.element("#assetdivTableBody").is(":visible")) {
            angular.element("#assetdivTableBody").scrollLeft(0);
            var container = document.getElementById("assetdivTableBody");
            container.scrollTop = 0
        }
    }
    $rootScope.searchClearAll = function() {
        $rootScope.reqId = new Date().getTime();
        $http({
            method: 'GET',
            url: '/getMetaDataTypes',
            data: null
        }).then(function(response) {
            $rootScope.metaDataTypes = response.data.data;
            $rootScope.mDataType = $rootScope.metaDataTypes[0].metadataTypeName;
            $rootScope.mCategory = $rootScope.metaDataTypes[0].categories[0].description;
            $rootScope.searchFieldName = $rootScope.metaDataTypes[0].categories[0].fieldDisplayName;
            $rootScope.mTypeTitle = $rootScope.metaDataTypes[0].categories[0].displayName;
            $rootScope.search.searchValue = "";
            $rootScope.search.globalSearchText = ""
        }); {
            angular.forEach($rootScope.accountList, function(value, key) {
                if (document.getElementById("region_" + value.accountId) != null && document.getElementById("region_" + value.accountId) != undefined)
                    document.getElementById("region_" + value.accountId).checked = !1;
                value.checkAcct = !1
            });
            if (document.getElementById("regionAllSelected") != null && document.getElementById("regionAllSelected") != undefined)
                document.getElementById("regionAllSelected").checked = !1;
            $rootScope.search.regionAllSelected = !1
        } {
            angular.forEach($rootScope.imprintList, function(value, key) {
                if (document.getElementById("imprint_" + value) != null && document.getElementById("imprint_" + value) != undefined)
                    document.getElementById("imprint_" + value).checked = !1
            });
            if (document.getElementById("imAllSelected") != null && document.getElementById("imAllSelected") != undefined)
                document.getElementById("imAllSelected").checked = !1;
            $rootScope.search.imAllSelected = !1
        }
        $rootScope.search.pCateoryAllSelected = !1;
        $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "UNSELECT");
        $rootScope.searchEnable = !1;
        angular.forEach($rootScope.formatList, function(itm) {
            itm.sChecked = !1
        });
        $rootScope.search.formatCheckAll = !1;
        angular.forEach($rootScope.advanceFilterStatusList, function(statusFilter) {
            $rootScope.search.statusAllSelect[statusFilter.code] = !1;
            angular.forEach($filter('filter')($rootScope.statusList, function(data) {
                return data.statusType == statusFilter.statusType
            }), function(itm) {
                itm.afchecked = !1
            })
        }); {
            angular.forEach($rootScope.othersList, function(value, key) {
                if (document.getElementById("other_" + value.description) != null && document.getElementById("other_" + value.description) != undefined)
                    document.getElementById("other_" + value.description).checked = !1
            });
            if (document.getElementById("otherCheckAll") != null && document.getElementById("otherCheckAll") != undefined)
                document.getElementById("otherCheckAll").checked = !1;
            $rootScope.search.otherAllSelect = !1
        } {
            angular.forEach($rootScope.GlobalImprintList, function(value, key) {
                if (document.getElementById(value + "_Global") != null && document.getElementById(value + "_Global") != undefined)
                    document.getElementById(value + "_Global").checked = !1
            });
            if (document.getElementById("imgAllSelected") != null && document.getElementById("imgAllSelected") != undefined)
                document.getElementById("imgAllSelected").checked = !1;
            $rootScope.imgAllSelected = !1
        } {
            angular.forEach($rootScope.GlobalOthersList, function(value, key) {
                if (document.getElementById(value.description + "_Global") != null && document.getElementById(value.description + "_Global") != undefined)
                    document.getElementById(value.description + "_Global").checked = !1
            });
            if (document.getElementById("mtAllSelected") != null && document.getElementById("mtAllSelected") != undefined)
                document.getElementById("mtAllSelected").checked = !1;
            $rootScope.mtAllSelected = !1
        }
        Object.keys($rootScope.fromDateFilterList).forEach(function(itm) {
            if (document.getElementById(itm + "_From") != null && document.getElementById(itm + "_From") != undefined) {
                document.getElementById(itm + "_From").value = ""
            }
        });
        Object.keys($rootScope.toDateFilterList).forEach(function(itm) {
            if (document.getElementById(itm + "_To") != null && document.getElementById(itm + "_To") != undefined) {
                document.getElementById(itm + "_To").value = ""
            }
        });
        $rootScope.From = {};
        $rootScope.To = {};
        $rootScope.inColFilterList = {};
        $rootScope.inColumnFilterList = {};
        $rootScope.ninColFilterList = {};
        $rootScope.ninColumnFilterList = {};
        $rootScope.columnSuggestions = {};
        $rootScope.gHeadresAllSelect = {};
        $rootScope.columnFormatYes = {};
        $rootScope.columnFormatNo = {};
        $rootScope.colFormatStatus = {};
        $rootScope.fromDateFilterList = {};
        $rootScope.toDateFilterList = {};
        $rootScope.lookUpSuggestions = {};
        $rootScope.accountFilterList = [];
        $rootScope.selectedAccounts = [];
        $rootScope.imprintFilterList = [];
        $rootScope.formatFilterList = [];
        $rootScope.formatCodeList = [];
        $rootScope.pCategoryFilterList = [];
        $rootScope.statusFilterList = {};
        $rootScope.othersFilterList = [];
        $rootScope.advancedOthersFilterList = [];
        $rootScope.GlobalImprintList = [];
        $rootScope.GlobalOthersList = [];
        $rootScope.GlobalOthersCodeList = [];
        angular.element($("#txtSearch")).val("");
        angular.element($("#txtSearchInner")).val("");
        $('.dateClear').each(function() {
            $(this).val('')
        });
        $rootScope.searchKeyScroll = "";
        $rootScope.skipCountScroll = 0;
        $rootScope.columnFilterSearch = {};
        $rootScope.searchCount = "";
        $rootScope.searchResult = [];
        $rootScope.getImprints();
        $rootScope.searchEnable = !1;
        $rootScope.viewSearch('G', '', 0, !1, !1, !1)
    };
    $rootScope.clearSearchFilters = function() {
        {
            angular.forEach($rootScope.accountList, function(value, key) {
                if (document.getElementById("region_" + value.accountId) != null && document.getElementById("region_" + value.accountId) != undefined)
                    document.getElementById("region_" + value.accountId).checked = !1;
                value.checkAcct = !1
            });
            if (document.getElementById("regionAllSelected") != null && document.getElementById("regionAllSelected") != undefined)
                document.getElementById("regionAllSelected").checked = !1;
            $rootScope.search.regionAllSelected = !1
        } {
            angular.forEach($rootScope.imprintList, function(value, key) {
                if (document.getElementById("imprint_" + value) != null && document.getElementById("imprint_" + value) != undefined)
                    document.getElementById("imprint_" + value).checked = !1
            });
            if (document.getElementById("imAllSelected") != null && document.getElementById("imAllSelected") != undefined)
                document.getElementById("imAllSelected").checked = !1;
            $rootScope.search.imAllSelected = !1
        }
        $rootScope.search.pCateoryAllSelected = !1;
        $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "UNSELECT");
        angular.forEach($rootScope.formatList, function(itm) {
            itm.sChecked = !1
        });
        $rootScope.search.formatCheckAll = !1;
        angular.forEach($rootScope.advanceFilterStatusList, function(statusFilter) {
            $rootScope.search.statusAllSelect[statusFilter.code] = !1;
            angular.forEach($filter('filter')($rootScope.statusList, function(data) {
                return data.statusType == statusFilter.statusType
            }), function(itm) {
                itm.afchecked = !1
            })
        }); {
            angular.forEach($rootScope.othersList, function(value, key) {
                if (document.getElementById("other_" + value.description) != null && document.getElementById("other_" + value.description) != undefined)
                    document.getElementById("other_" + value.description).checked = !1
            });
            if (document.getElementById("otherCheckAll") != null && document.getElementById("otherCheckAll") != undefined)
                document.getElementById("otherCheckAll").checked = !1;
            $rootScope.search.otherAllSelect = !1
        } {
            angular.forEach($rootScope.GlobalImprintList, function(value, key) {
                if (document.getElementById(value + "_Global") != null && document.getElementById(value + "_Global") != undefined)
                    document.getElementById(value + "_Global").checked = !1
            });
            if (document.getElementById("imgAllSelected") != null && document.getElementById("imgAllSelected") != undefined)
                document.getElementById("imgAllSelected").checked = !1;
            $rootScope.imgAllSelected = !1
        } {
            angular.forEach($rootScope.GlobalOthersList, function(value, key) {
                if (document.getElementById(value.description + "_Global") != null && document.getElementById(value.description + "_Global") != undefined)
                    document.getElementById(value.description + "_Global").checked = !1
            });
            if (document.getElementById("mtAllSelected") != null && document.getElementById("mtAllSelected") != undefined)
                document.getElementById("mtAllSelected").checked = !1;
            $rootScope.mtAllSelected = !1
        }
        Object.keys($rootScope.fromDateFilterList).forEach(function(itm) {
            if (document.getElementById(itm + "_From") != null && document.getElementById(itm + "_From") != undefined) {
                document.getElementById(itm + "_From").value = ""
            }
        });
        Object.keys($rootScope.toDateFilterList).forEach(function(itm) {
            if (document.getElementById(itm + "_To") != null && document.getElementById(itm + "_To") != undefined) {
                document.getElementById(itm + "_To").value = ""
            }
        });
        $rootScope.From = {};
        $rootScope.To = {};
        $rootScope.accountFilterList = [];
        $rootScope.selectedAccounts = [];
        $rootScope.imprintFilterList = [];
        $rootScope.formatFilterList = [];
        $rootScope.formatCodeList = [];
        $rootScope.pCategoryFilterList = [];
        $rootScope.statusFilterList = {};
        $rootScope.othersFilterList = [];
        $rootScope.advancedOthersFilterList = [];
        $rootScope.GlobalImprintList = [];
        $rootScope.GlobalOthersList = [];
        $rootScope.GlobalOthersCodeList = [];
        $rootScope.searchKeyScroll = "";
        $rootScope.skipCountScroll = 0;
        $rootScope.searchCount = "";
        $rootScope.searchResult = [];
        $rootScope.getImprints()
    };
    $rootScope.getNestedChildren = function(arr, parent) {
        var out = [];
        for (var i in arr) {
            if (arr[i].parentId == parent) {
                var children = $rootScope.getNestedChildren(arr, arr[i].productCategoryId)
                if (children.length) {
                    arr[i].children = children
                }
                out.push(arr[i])
            }
        }
        return out
    }
    $rootScope.traverseSearchTree = function(arr, operation) {
        if (arr != undefined) {
            for (var i = 0, l = arr.length; i < l; i++) {
                var current = arr[i];
                if (operation == "GETSELECTED") {
                    if (current.selected) {
                        $rootScope.selectedProductCategoryArraySearch.push(current.productCategoryId)
                    }
                } else if (operation == "UNSELECT") {
                    current.selected = !1;
                    $rootScope.pCategoryFilterList = $filter('filter')($rootScope.pCategoryFilterList, function(data) {
                        return data.productCategoryId != current.productCategoryId
                    });
                    $rootScope.selectedProductCategoryArraySearch = $filter('filter')($rootScope.selectedProductCategoryArraySearch, function(data) {
                        return data != current.productCategoryId
                    })
                } else if (operation == "SELECT") {
                    current.selected = !0;
                    var tempList = $filter('filter')($rootScope.pCategoryFilterList, function(data) {
                        return data.productCategoryId == current.productCategoryId
                    });
                    if (tempList.length == 0) {
                        $rootScope.pCategoryFilterList.push(current)
                    }
                } else if (operation == "POPULATEFOREDIT") {
                    if ($rootScope.selectedProductCategoryArraySearch.indexOf(current.productCategoryId) > -1) {
                        current.selected = !0;
                        var tempList = $filter('filter')($rootScope.pCategoryFilterList, function(data) {
                            return data.productCategoryId == current.productCategoryId
                        });
                        if (tempList.length == 0) {
                            $rootScope.pCategoryFilterList.push(current)
                        }
                    }
                }
                if (current.children && current.children.length > 0) {
                    $rootScope.traverseSearchTree(current.children, operation)
                }
            }
        }
    }
    $rootScope.getSelectedSearchFilterProductCategories = function() {
        $rootScope.selectedProductCategoryArraySearch = [];
        $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "GETSELECTED")
    };
    $rootScope.toggleSearchProductCategoryChildren = function(data, pCId) {
        $rootScope.reqId = new Date().getTime();
        if (!data.selected) {
            $rootScope.pCategoryFilterList = $filter('filter')($rootScope.pCategoryFilterList, function(current) {
                return current.productCategoryId != data.productCategoryId
            });
            if (data.children && data.children.length > 0) {
                $rootScope.traverseSearchTree(data.children, "UNSELECT")
            }
        } else {
            $rootScope.pCategoryFilterList.push(data);
            if (data.children && data.children.length > 0) {
                $rootScope.traverseSearchTree(data.children, "SELECT")
            }
        }
        $rootScope.searchEnable = !0;
        $rootScope.getSelectedSearchFilterProductCategories();
        setTimeout(function() {
            $rootScope.search.pCateoryAllSelected = (($rootScope.pCategoryFilterList.length === $rootScope.productCategorySearchList.length) && $rootScope.productCategorySearchList.length != 0);
            $rootScope.searchFlag = 'F';
            $rootScope.resetGlobalFilters();
            if ($rootScope.refreshSearch()) {
                $rootScope.commonAllFilter()
            }
        }, 100);
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    };
    $rootScope.msg = {};
    $rootScope.renameSearch = function(changeName, $index, pageName) {
        var renameSearchs = encodeURI(changeName);
        var existingName = $rootScope.existingSearchName;
        var user_id = $rootScope.loggedUser.userId;
        if (changeName === undefined || changeName === '') {
            $rootScope.msg.showBaseErrorMsg = !0;
            $rootScope.msg.baseErrorMsg = "SEARCH_NAME_EMPTY";
            setTimeout(function() {
                $rootScope.msg.showBaseErrorMsg = !1;
                $rootScope.$apply()
            }, $rootScope.alertTimeoutInterval)
        } else if (changeName === existingName) {
            if (pageName == 'Metadata') {
                document.getElementById("mdatarename_" + renameSearchs).display = 'none';
                document.getElementById("searchmdataname_" + renameSearchs).display = 'block';
                if (document.getElementById("iconmdata_" + existingName) != null && document.getElementById("iconmdata_" + existingName) != undefined)
                    document.getElementById("iconmdata_" + existingName).style.display = "block"
            } else {
                document.getElementById("rename_" + existingName).display = 'none';
                document.getElementById("searchname_" + existingName).display = 'block';
                if (document.getElementById("icon_" + existingName) != null && document.getElementById("icon_" + existingName) != undefined)
                    document.getElementById("icon_" + existingName).style.display = "block"
            }
        } else {
            $http({
                method: 'POST',
                url: '/renameSearch/',
                data: {
                    userId: user_id,
                    searchName: existingName,
                    changeSearchName: changeName,
                    pageName: pageName
                }
            }).then(function(response) {
                if (response.data.code == '200') {
                    $rootScope.msg.showBaseSuccessMsg = !0;
                    $rootScope.msg.baseSuccessMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseSuccessMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval);
                    if (pageName == 'Metadata') {
                        angular.element(".menu-side-edit-input").css("display", "none");
                        angular.element(".sub-menu-title-label").css("display", "block");
                        if (document.getElementById("iconmdata_" + renameSearchs) != null && document.getElementById("iconmdata_" + renameSearchs) != undefined)
                            document.getElementById("iconmdata_" + renameSearchs).style.display = "block"
                    } else {
                        angular.element(".menu-side-edit-input").css("display", "none");
                        angular.element(".sub-menu-title-label").css("display", "block");
                        if (document.getElementById("icon_" + renameSearchs) != null && document.getElementById("icon_" + renameSearchs) != undefined)
                            document.getElementById("icon_" + renameSearchs).style.display = "block"
                    }
                } else {
                    $rootScope.msg.showBaseErrorMsg = !0;
                    $rootScope.msg.baseErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseErrorMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    if (pageName == 'Metadata') {
                        document.getElementById("mdatarename_" + existingName).display = 'block';
                        document.getElementById("searchmdataname_" + existingName).display = 'none'
                    } else {
                        document.getElementById("rename_" + existingName).display = 'block';
                        document.getElementById("searchname_" + existingName).display = 'none'
                    }
                }
            })
        }
    };
    $rootScope.duplicateSearch = function(changeName, $index, pageName) {
        var duplicateSearchs = encodeURI(changeName);
        if (pageName == 'Metadata')
            var changeNameVal = document.getElementById("mdataduplicate_" + duplicateSearchs).value;
        else var changeNameVal = document.getElementById("duplicate_" + duplicateSearchs).value;
        var user_id = $rootScope.loggedUser.userId;
        if (changeNameVal === undefined || changeNameVal === '') {
            $rootScope.msg.showBaseErrorMsg = !0;
            $rootScope.msg.baseErrorMsg = "SEARCH_NAME_EMPTY";
            setTimeout(function() {
                $rootScope.msg.showBaseErrorMsg = !1;
                $rootScope.$apply()
            }, $rootScope.alertTimeoutInterval)
            if (pageName == 'Metadata') {
                $rootScope.isEditMetaDuplicate[$index] = !0;
                $rootScope.isEditMetaItem[$index] = !1
            } else {
                $rootScope.isEditDuplicate[$index] = !0;
                $rootScope.isEditItem[$index] = !1
            }
        } else if (changeName === changeNameVal) {
            $rootScope.msg.showBaseErrorMsg = !0;
            $rootScope.msg.baseErrorMsg = 'SEARCH_NAME_EXISTS';
            angular.element(".menu-side-edit-input").css("display", "none");
            angular.element(".sub-menu-title-label").css("display", "block");
            setTimeout(function() {
                $rootScope.msg.showBaseErrorMsg = !1;
                $rootScope.$apply()
            }, $rootScope.alertTimeoutInterval)
            if (pageName == 'Metadata') {
                $rootScope.isEditMetaDuplicate[$index] = !0;
                $rootScope.isEditMetaItem[$index] = !1
            } else {
                $rootScope.isEditDuplicate[$index] = !0;
                $rootScope.isEditItem[$index] = !1
            }
        } else {
            $http({
                method: 'POST',
                url: '/duplicateSearch/',
                data: {
                    userId: user_id,
                    searchName: changeName,
                    changeSearchName: changeNameVal,
                    pageName: pageName
                }
            }).then(function(response) {
                if (response.data.code == '200') {
                    $rootScope.getSavedSearchByPageName(pageName);
                    $rootScope.msg.showBaseSuccessMsg = !0;
                    $rootScope.msg.baseSuccessMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseSuccessMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    if (pageName == 'Metadata') {
                        $rootScope.isEditMetaDuplicate[$index] = !1;
                        $rootScope.isEditMetaItem[$index] = !0
                    } else {
                        $rootScope.isEditDuplicate[$index] = !1;
                        $rootScope.isEditItem[$index] = !0
                    }
                } else {
                    $rootScope.msg.showBaseErrorMsg = !0;
                    $rootScope.msg.baseErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseErrorMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    if (pageName == 'Metadata') {
                        $rootScope.isEditMetaDuplicate[$index] = !0;
                        $rootScope.isEditMetaItem[$index] = !1
                    } else {
                        $rootScope.isEditDuplicate[$index] = !0;
                        $rootScope.isEditItem[$index] = !1
                    }
                }
            })
        }
    };
    $rootScope.searchSuggestion = !1;
    var timeout = null;
    $rootScope.getSearchSuggestions = function(mType, mTypeCategory, fielddisplayname) {
        $rootScope.reqId = new Date().getTime();
        if ($rootScope.searchFlag == 'N' || $rootScope.searchFlag == 'I') {
            $rootScope.searchFlag = 'G'
        }
        if ($rootScope.search.globalSearchText != $rootScope.search.searchValue) {
            $rootScope.searchEnable = !0;
            $rootScope.searchSuggestion = !0;
            if ($location.$$url === '/asset' || $location.$$url.contains('metadata')) {
                $rootScope.search.globalSearchText = $rootScope.search.searchValue;
                $timeout(function() {
                    if ($rootScope.refreshSearch()) {
                        $rootScope.searchSuggestion = !1;
                        $rootScope.commonAllFilter()
                    }
                }, 100)
            }
        }
        $rootScope.search.globalSearchText = $rootScope.search.searchValue;
        var user_id = $rootScope.loggedUser.userId;
        var searchKey = angular.element($("#txtSearch")).val();
        $rootScope.Search.HeaderSearch.metaDataType = mType;
        $rootScope.Search.HeaderSearch.metaDataCategory = mTypeCategory;
        $rootScope.Search.HeaderSearch.searchText = searchKey;
        if (searchKey.length !== 0) {
            if (searchKey.length >= 30) {
                return !1
            } else if (searchKey.length >= 4) {
                $http({
                    method: 'POST',
                    url: '/getSearchSuggestions',
                    data: {
                        headerSearch: Object.keys($rootScope.Search.HeaderSearch).length > 0 ? $rootScope.Search.HeaderSearch : null,
                        fieldDisplayName: fielddisplayname
                    }
                }).then(function(response) {
                    $rootScope.searchSuggestions[fielddisplayname] = response.data.data
                })
            } else {
                $rootScope.searchSuggestions[fielddisplayname] = []
            }
        } else {
            $http({
                method: 'POST',
                url: '/getRecentSearch/',
                data: {
                    userId: user_id,
                    headerSearch: Object.keys($rootScope.Search.HeaderSearch).length > 0 ? $rootScope.Search.HeaderSearch : null
                }
            }).then(function(response) {
                $rootScope.recentSearch = response.data.data
            })
        }
    };
    $rootScope.openAdvanceFilterPopup = function() {
        angular.element(".search-dropdown-content").removeClass('active');
        if ($location.$$url != '/asset' && $location.$$url != '/metadata') {
            $rootScope.clearSearchFilters()
        }
    }
    $rootScope.getSavedSearch = function() {
        var user_id = $rootScope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/getSavedSearch',
            data: {
                userId: user_id,
                pageName: $rootScope.pagename
            }
        }).then(function(response) {
            if ($rootScope.pagename == 'Metadata') {
                $rootScope.savedMetadataList = response.data.data
            } else {
                $rootScope.savedSearchList = response.data.data
            }
        })
    };
    $rootScope.getSavedSearchByPageName = function(pageName) {
        var user_id = $rootScope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/getSavedSearch',
            data: {
                userId: user_id,
                pageName: pageName
            }
        }).then(function(response) {
            if (pageName == 'Metadata') {
                $rootScope.savedMetadataList = response.data.data
            } else {
                $rootScope.savedSearchList = response.data.data
            }
        })
    };
    $rootScope.dataToDeleteSearch = function($index, deleteSearchName) {
        $rootScope.deleteSearchName = deleteSearchName
    }
    $rootScope.closeSearchDelete = function() {
        $rootScope.deleteSearchName = null;
        $('#search-delete').modal('toggle')
    }
    $rootScope.deleteSearch = function($index, deleteSearchName, pageName) {
        var user_id = $rootScope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/deleteSearch',
            data: {
                userId: user_id,
                searchName: deleteSearchName,
                pageName: pageName
            }
        }).then(function(response) {
            $rootScope.closeSearchDelete();
            $rootScope.getSavedSearchByPageName(pageName);
            if (response.data.code == '200') {
                $rootScope.msg.showBaseSuccessMsg = !0;
                $rootScope.msg.baseSuccessMsg = response.data.status;
                if (deleteSearchName == $rootScope.searchName && ($location.$$url == '/asset' || $location.$$url == '/metadata')) {
                    $rootScope.searchClearAll()
                }
                setTimeout(function() {
                    $rootScope.msg.showBaseSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.msg.showBaseErrorMsg = !0;
                $rootScope.msg.baseErrorMsg = response.data.status;
                setTimeout(function() {
                    $rootScope.msg.showBaseErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    };
    $rootScope.pinSearchToDashboard = function($index, searchName, pageName) {
        $http({
            method: 'POST',
            url: '/pintodashboard',
            data: {
                searchName: searchName,
                pageName: pageName
            }
        }).then(function(response) {
            if (response.data.code == '200') {
                $rootScope.msg.showBaseSuccessMsg = !0;
                $rootScope.msg.baseSuccessMsg = response.data.status;
                setTimeout(function() {
                    $rootScope.msg.showBaseSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.msg.showBaseErrorMsg = !0;
                $rootScope.msg.baseErrorMsg = response.data.status;
                setTimeout(function() {
                    $rootScope.msg.showBaseErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        })
    };
    $rootScope.exportFormat = null;
    $rootScope.pendingDownloadRequest = false;
    $rootScope.exportSearch = function(exportType) {
        $rootScope.exportFormat = exportType;
        $rootScope.reqId = new Date().getTime();
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            if($rootScope.pendingDownloadRequest == true){
                angular.element("#downloadInprogress").modal('toggle');
            }
            else{
                $rootScope.pendingDownloadRequest = true;
                $rootScope.viewSearch($rootScope.searchFlag, $rootScope.searchName, $rootScope.skipCount, !0, !1,
                    !0, $rootScope.exportFormat)
            }
            
        }
    };
    $scope.countAsset = 1;
    $rootScope.assetShowLoadMore = !0;
    $rootScope.assetButtonText = "Load More";
    $rootScope.refreshSearch = function() {
        if ($rootScope.accountFilterList.length != 0 || $rootScope.columnsSearch() != 0 || $rootScope.dateColumnSearch() || $rootScope.imprintFilterList.length != 0 || $rootScope.formatFilterList.length != 0 || $rootScope.pCategoryFilterList.length != 0 || $rootScope.othersFilterList.length != 0 || $rootScope.GlobalImprintList.length != 0 || $rootScope.GlobalOthersList.length != 0 || ($rootScope.search.globalSearchText != '' && $rootScope.search.globalSearchText != undefined && ($rootScope.searchFlag == 'G' || $rootScope.searchFlag == 'F')) || $rootScope.checkStatusFilterApplied()) {
            $rootScope.searchSuggestion = !1;
            return !1
        } else {
            return !0
        }
    }
    $rootScope.resetGlobalFilters = function() {
        if ($rootScope.GlobalImprintList.length > 0) {
            angular.forEach($rootScope.GlobalImprintList, function(value, key) {
                if (document.getElementById(value + "_Global") != null && document.getElementById(value + "_Global") != undefined)
                    document.getElementById(value + "_Global").checked = !1
            });
            if (document.getElementById("imgAllSelected") != null && document.getElementById("imgAllSelected") != undefined)
                document.getElementById("imgAllSelected").checked = !1;
            $rootScope.imgAllSelected = !1
        }
        if ($rootScope.GlobalOthersList.length > 0) {
            angular.forEach($rootScope.GlobalOthersList, function(value, key) {
                if (document.getElementById(value.description + "_Global") != null && document.getElementById(value.description + "_Global") != undefined)
                    document.getElementById(value.description + "_Global").checked = !1
            });
            if (document.getElementById("mtAllSelected") != null && document.getElementById("mtAllSelected") != undefined) {
                document.getElementById("mtAllSelected").checked = !1
            }
            $rootScope.mtAllSelected = !1
        }
        $rootScope.GlobalImprintList = [];
        $rootScope.GlobalOthersList = [];
        $rootScope.GlobalOthersCodeList = []
    }
    $rootScope.resetAdvancedFilters = function() {
        if ($rootScope.accountFilterList.length > 0) {
            angular.forEach($rootScope.accountFilterList, function(value, key) {
                if (document.getElementById("region_" + value.accountId) != null && document.getElementById("region_" + value.accountId) != undefined)
                    document.getElementById("region_" + value.accountId).checked = !1
            });
            if (document.getElementById("regionAllSelected") != null && document.getElementById("regionAllSelected") != undefined)
                document.getElementById("regionAllSelected").checked = !1;
            $rootScope.search.regionAllSelected = !1
        }
        if ($rootScope.imprintFilterList.length > 0) {
            angular.forEach($rootScope.imprintFilterList, function(value, key) {
                if (document.getElementById("imprint_" + value) != null && document.getElementById("imprint_" + value) != undefined)
                    document.getElementById("imprint_" + value).checked = !1
            });
            if (document.getElementById("imAllSelected") != null && document.getElementById("imAllSelected") != undefined)
                document.getElementById("imAllSelected").checked = !1;
            $rootScope.search.imAllSelected = !1
        }
        if ($rootScope.formatList.length > 0) {
            angular.forEach($rootScope.formatList, function(itm) {
                itm.sChecked = !1
            });
            $rootScope.search.formatCheckAll = !1
        }
        if ($rootScope.checkStatusFilterApplied()) {
            angular.forEach($rootScope.advanceFilterStatusList, function(statusFilter) {
                $rootScope.search.statusAllSelect[statusFilter.code] = !1;
                angular.forEach($filter('filter')($rootScope.statusList, function(data) {
                    return data.statusType == statusFilter.statusType
                }), function(itm) {
                    itm.afchecked = !1
                })
            })
        }
        if ($rootScope.othersFilterList.length > 0) {
            angular.forEach($rootScope.othersFilterList, function(value, key) {
                if (document.getElementById("other_" + value.description) != null && document.getElementById("other_" + value.description) != undefined)
                    document.getElementById("other_" + value.description).checked = !1
            });
            if (document.getElementById("otherCheckAll") != null && document.getElementById("otherCheckAll") != undefined)
                document.getElementById("otherCheckAll").checked = !1
        }
        $rootScope.accountFilterList = [];
        $rootScope.selectedAccounts = [];
        $rootScope.imprintFilterList = [];
        $rootScope.formatFilterList = [];
        $rootScope.formatCodeList = [];
        $rootScope.pCategoryFilterList = [];
        $rootScope.statusFilterList = {};
        $rootScope.othersFilterList = [];
        $rootScope.advancedOthersFilterList = [];
        $rootScope.Search.HeaderSearch.searchText = "";
        angular.element($("#txtSearch")).val('');
        angular.element($("#txtSearchInner")).val('');
        $rootScope.search.searchValue = "";
        $rootScope.search.globalSearchText = ""
    }
    $rootScope.tempcartdisable = !1;
    $rootScope.viewSearch = function(searchflag, searchname, skipCount, searchExport, isScroll, columnFilterFlg, exportFormat) {
        $rootScope.viewSearchLoad = !0;
        document.getElementById("txtSearchInner").readOnly = "true";
        document.getElementById("txtSearch").readOnly = "true";
        if ($rootScope.locationPath.contains('metadata')) {
            $rootScope.locationPath = '/#metadata';
            $rootScope.pagename = 'Metadata'
        } else {
            $rootScope.locationPath = '/#asset';
            $rootScope.pagename = 'Default'
        }
        if (!searchExport) {
            $rootScope.showNoResultDiv = !1;
            $rootScope.showLoader($('.loader-table'), 1, 'win8_linear');
            if (skipCount == undefined || skipCount == 0)
                $rootScope.showLoader($('.assetTable'), 1, 'win8_linear')
        }
        var searchKey = angular.element($("#txtSearch")).val();
        $rootScope.isExport = searchExport;
        if (!isScroll) {
            $rootScope.currentIndexLast = '0';
            $rootScope.currentIndex = '0'
        }
        var user_id = $rootScope.loggedUser.userId;
        var fieldname = $rootScope.searchFieldName;
        var columnSearchTexts = $rootScope.columnFilterSearch;
        if (searchflag == 'F') {
            if (!columnFilterFlg) {
                $rootScope.inColFilterList = {};
                $rootScope.inColumnFilterList = {};
                $rootScope.ninColFilterList = {};
                $rootScope.ninColumnFilterList = {};
                $rootScope.columnSuggestions = {};
                $rootScope.gHeadresAllSelect = {};
                $rootScope.columnFormatYes = {};
                $rootScope.columnFormatNo = {};
                $rootScope.colFormatStatus = {};
                $rootScope.fromDateFilterList = {};
                $rootScope.toDateFilterList = {};
                $rootScope.columnFilterSearch = {}
            }
            $rootScope.Search.AdvancedSearch.accounts = $rootScope.selectedAccounts;
            $rootScope.Search.AdvancedSearch.formats = $rootScope.formatCodeList;
            $rootScope.Search.AdvancedSearch.status = $rootScope.statusFilterList;
            $rootScope.Search.AdvancedSearch.imprints = $rootScope.imprintFilterList;
            $rootScope.Search.AdvancedSearch.others = $rootScope.advancedOthersFilterList;
            $rootScope.Search.AdvancedSearch.productCategories = $rootScope.selectedProductCategoryArraySearch;
            $rootScope.Search.ImprintAssetSearch = {};
            if ((skipCount == undefined || skipCount == 0) && !searchExport)
                $rootScope.searchResult = [];
            $rootScope.resetGlobalFilters();
            var metaDataType = $rootScope.mDataType;
            var metaDataCategory = $rootScope.mCategory;
            var searchText = searchKey;
            $rootScope.Search.HeaderSearch.metaDataType = metaDataType;
            $rootScope.Search.HeaderSearch.metaDataCategory = metaDataCategory;
            $rootScope.Search.HeaderSearch.searchText = searchText
        } else if (searchflag == "I") {
            if (!columnFilterFlg) {
                $rootScope.inColFilterList = {};
                $rootScope.inColumnFilterList = {};
                $rootScope.ninColFilterList = {};
                $rootScope.ninColumnFilterList = {};
                $rootScope.columnSuggestions = {};
                $rootScope.gHeadresAllSelect = {};
                $rootScope.columnFormatYes = {};
                $rootScope.columnFormatNo = {};
                $rootScope.colFormatStatus = {};
                $rootScope.fromDateFilterList = {};
                $rootScope.toDateFilterList = {};
                $rootScope.columnFilterSearch = {}
            }
            $rootScope.Search.ImprintAssetSearch.imprintNames = $rootScope.GlobalImprintList;
            $rootScope.Search.ImprintAssetSearch.assetDescription = $rootScope.GlobalOthersCodeList;
            $rootScope.Search.HeaderSearch = {};
            $rootScope.Search.AdvancedSearch = {};
            if ((skipCount == undefined || skipCount == 0) && !searchExport)
                $rootScope.searchResult = [];
            $rootScope.resetAdvancedFilters()
        } else if (searchflag == 'G') {
            $rootScope.resetGlobalFilters();
            $rootScope.resetAdvancedFilters()
            if (!columnFilterFlg) {
                $rootScope.inColFilterList = {};
                $rootScope.inColumnFilterList = {};
                $rootScope.ninColFilterList = {};
                $rootScope.ninColumnFilterList = {};
                $rootScope.columnSuggestions = {};
                $rootScope.gHeadresAllSelect = {};
                $rootScope.columnFormatYes = {};
                $rootScope.columnFormatNo = {};
                $rootScope.colFormatStatus = {};
                $rootScope.fromDateFilterList = {};
                $rootScope.toDateFilterList = {};
                $rootScope.columnFilterSearch = {}
            }
            var metaDataType = $rootScope.mDataType;
            var metaDataCategory = $rootScope.mCategory;
            var searchText = searchKey;
            if (metaDataCategory == "All") {
                var checkCountforISBN = 0;
                var arrayIsbn = searchKey.replace(/\s/g, "").split(',');
                angular.forEach(arrayIsbn, function(key, value) {
                    if (key.length == 13 && /^\d+$/.test(key)) {} else {
                        checkCountforISBN++
                    }
                });
                if (arrayIsbn.length == 1 || checkCountforISBN == arrayIsbn.length) {
                    metaDataCategory = $rootScope.mCategory;
                    $rootScope.searchFieldName = "ALL"
                } else {
                    $rootScope.searchFieldName = "ISBN13"
                }
            }
            $rootScope.Search.AdvancedSearch = {};
            $rootScope.Search.ImprintAssetSearch = {};
            $rootScope.GlobalImprintList = [];
            $rootScope.GlobalOthersList = [];
            $rootScope.GlobalOthersCodeList = [];
            $rootScope.Search.HeaderSearch.metaDataType = metaDataType;
            $rootScope.Search.HeaderSearch.metaDataCategory = metaDataCategory;
            $rootScope.Search.HeaderSearch.searchText = searchText;
            $rootScope.search.globalSearchText = searchText
        } else if (searchflag == 'N') {
            if (!columnFilterFlg) {
                $rootScope.inColFilterList = {};
                $rootScope.inColumnFilterList = {};
                $rootScope.ninColFilterList = {};
                $rootScope.ninColumnFilterList = {};
                $rootScope.columnSuggestions = {};
                $rootScope.gHeadresAllSelect = {};
                $rootScope.columnFormatYes = {};
                $rootScope.columnFormatNo = {};
                $rootScope.colFormatStatus = {};
                $rootScope.fromDateFilterList = {};
                $rootScope.toDateFilterList = {};
                $rootScope.columnFilterSearch = {};
                $rootScope.inColumnFilterList = {}
            }
            if (skipCount == undefined || skipCount == 0 && !searchExport) {
                $rootScope.searchResult = [];
                angular.element($("#txtSearch")).val("");
                angular.element($("#txtSearchInner")).val("");
                $rootScope.clearSearchFilters()
            }
            $rootScope.Search.HeaderSearch = {}
        }
        $rootScope.searchName = searchname;
        $rootScope.skipCount = skipCount;
        $rootScope.searchFlag = searchflag;
        if (searchExport) {
            $rootScope.msg.showCommonSuccessMsgExport = !0;
            angular.element("#getDownloadNotification").addClass('open');
            $rootScope.msg.exportSucessmsg = "DOWNLOAD_EXPORT_SUCESS";
            setTimeout(function() {
                $rootScope.msg.showCommonSuccessMsgExport = !1;
                $rootScope.$apply()
            }, $rootScope.alertTimeoutInterval)
        }
        var accountFilterList = $rootScope.accountFilterList;
        var selectedAccounts = $rootScope.selectedAccounts;
        var imprintFilterList = $rootScope.imprintFilterList;
        var formatFilterList = $rootScope.formatFilterList;
        var formatCodeList = $rootScope.formatCodeList;
        var pCategoryFilterList = $rootScope.pCategoryFilterList;
        var statusFilterList = $rootScope.statusFilterList;
        var othersFilterList = $rootScope.othersFilterList;
        var advancedOthersFilterList = $rootScope.advancedOthersFilterList;
        var statusAllSelect = $rootScope.search.statusAllSelect;
        var regionAllSelect = $rootScope.search.regionAllSelected;
        var imAllSelected = $rootScope.search.imAllSelected;
        var pCateoryAllSelected = $rootScope.search.pCateoryAllSelected;
        var formatCheckAll = $rootScope.search.formatCheckAll;
        var otherAllSelect = $rootScope.search.otherAllSelect;
        $http({
            method: 'POST',
            url: '/viewSearch',
            data: {
                headerSearch: Object.keys($rootScope.Search.HeaderSearch).length > 0 ? $rootScope.Search.HeaderSearch : null,
                advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : null,
                imprintAssetSearch: Object.keys($rootScope.Search.ImprintAssetSearch).length > 0 ? $rootScope.Search.ImprintAssetSearch : null,
                searchName: $rootScope.searchName,
                userId: user_id,
                skipCount: skipCount,
                fieldDisplayName: $rootScope.searchFieldName,
                columnFilterValues: $rootScope.columnFilterList,
                exportCheck: searchExport,
                exportFormat: exportFormat,
                permissionGroupId: $rootScope.loggedUser.permissionGroupId,
                searchflag: $rootScope.searchFlag,
                inColumnFilterList: $rootScope.inColumnFilterList,
                ninColumnFilterList: $rootScope.ninColumnFilterList,
                fromDateFilterList: $rootScope.fromDateFilterList,
                toDateFilterList: $rootScope.toDateFilterList,
                pageName: $rootScope.pagename,
                reqId: $rootScope.reqId
            }
        }).then(function(response) {
            $rootScope.accountFilterList = accountFilterList;
            $rootScope.selectedAccounts = selectedAccounts;
            $rootScope.imprintFilterList = imprintFilterList;
            $rootScope.formatFilterList = formatFilterList;
            $rootScope.formatCodeList = formatCodeList;
            $rootScope.pCategoryFilterList = pCategoryFilterList;
            $rootScope.statusFilterList = statusFilterList;
            $rootScope.othersFilterList = othersFilterList;
            $rootScope.advancedOthersFilterList = advancedOthersFilterList;
            $rootScope.search.statusAllSelect = statusAllSelect;
            $rootScope.search.regionAllSelected = regionAllSelect;
            $rootScope.search.imAllSelected = imAllSelected;
            $rootScope.search.pCateoryAllSelected = pCateoryAllSelected;
            $rootScope.search.formatCheckAll = formatCheckAll;
            $rootScope.search.otherAllSelect = otherAllSelect;
            $rootScope.viewSearchLoad = !1;
            document.getElementById("txtSearchInner").removeAttribute('readonly');
            document.getElementById("txtSearch").removeAttribute('readonly');
            if (!searchExport) {
                if ($rootScope.reqId == response.data.reqId) {
                    $rootScope.showNoResultDiv = !0;
                    if (skipCount == 0) {
                        $rootScope.searchResult = response.data.data
                    } else $rootScope.searchResult = $rootScope.searchResult.concat(response.data.data);
                    if ($rootScope.searchCount === 0 && isScroll) {
                        $rootScope.searchCount = $rootScope.currentIndexLast
                    } else {
                        $rootScope.searchCount = response.data.searchCount
                    }
                    $rootScope.hideLoader('loader-table');
                    $rootScope.hideLoader('assetTable');
                    $rootScope.testScroll();
                    $scope.showCheckBox();
                    $rootScope.checkSavedGridHeaders();
                    if ($rootScope.searchResult.length == $rootScope.searchCount) {
                        $rootScope.assetShowLoadMore = !1;
                        $rootScope.searchResult.length = $rootScope.searchCount
                    } else {
                        $rootScope.assetShowLoadMore = !0
                    }
                }
            } else {
                $rootScope.getDownloadNotification();
                if (response.data.code == '200') {
                    $rootScope.msg.showCommonSuccessMsgExport = !0;
                    $rootScope.msg.exportSucessmsg = response.data.status;
                    angular.element("#getDownloadNotification").addClass('open');
                    angular.element(".download-up").addClass("flashit");
                    setTimeout(function() {
                        $rootScope.msg.showCommonSuccessMsgExport = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                } else {
                    $rootScope.msg.exportSucessmsg = !1;
                    $rootScope.msg.exportErromsg = !0;
                    $rootScope.msg.exportErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.exportErromsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            }
            if ($rootScope.searchFlag == 'G' || $rootScope.searchFlag == 'F') {
                $rootScope.Search.HeaderSearch.searchText = searchKey;
                $rootScope.search.searchValue = searchKey;
                $rootScope.search.globalSearchText = searchKey;
                angular.element($("#txtSearch")).val(searchKey);
                angular.element($("#txtSearchInner")).val(searchKey)
            }
            if (columnFilterFlg)
                $rootScope.columnFilterSearch = columnSearchTexts;
            if (skipCount == 0) {
                if (angular.element("#assetdivTableBody").is(":visible")) {
                    angular.element("#assetdivTableBody").scrollLeft(0);
                    var container = document.getElementById("assetdivTableBody");
                    container.scrollTop = 0
                }
            }
            if ($rootScope.locationPath.contains('metadata')) {
                $timeout(function() {
                    angular.element(".index-table .divTableBody").trigger('scroll')
                }, 100)
            }
        })
    };
    $rootScope.saveSearch = function(modifyExistingFlg) {
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            var user_id = $rootScope.loggedUser.userId;
            $rootScope.existsError = !1;
            $rootScope.isEmpty = !1;
            var searchKey = $rootScope.search.globalSearchText;
            if (modifyExistingFlg)
                var searchname = $rootScope.searchName;
            else var searchname = angular.element($("#savesearchname")).val();
            $rootScope.Search.HeaderSearch.metaDataType = $rootScope.mDataType;
            $rootScope.Search.HeaderSearch.metaDataCategory = $rootScope.mCategory;
            $rootScope.Search.fieldDisplayName = $rootScope.searchFieldName;
            $rootScope.Search.HeaderSearch.searchText = searchKey;
            $rootScope.Search.AdvancedSearch.accounts = $rootScope.selectedAccounts;
            $rootScope.Search.AdvancedSearch.formats = $rootScope.formatCodeList;
            $rootScope.Search.AdvancedSearch.status = $rootScope.statusFilterList;
            $rootScope.Search.AdvancedSearch.imprints = $rootScope.imprintFilterList;
            $rootScope.Search.AdvancedSearch.others = $rootScope.advancedOthersFilterList;
            $rootScope.Search.ImprintAssetSearch.imprintNames = $rootScope.GlobalImprintList;
            $rootScope.Search.ImprintAssetSearch.assetDescription = $rootScope.GlobalOthersCodeList;
            $rootScope.Search.columnFilterValues = $rootScope.columnFilterList;
            if (searchname === undefined || searchname === '') {
                $rootScope.isEmpty = !0;
                $rootScope.SearchNameEmpty = 'SEARCH_NAME_EMPTY'
            } else {
                $http({
                    method: 'POST',
                    url: '/saveSearch',
                    data: {
                        headerSearch: Object.keys($rootScope.Search.HeaderSearch).length > 0 ? $rootScope.Search.HeaderSearch : null,
                        advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : null,
                        imprintAssetSearch: Object.keys($rootScope.Search.ImprintAssetSearch).length > 0 ? $rootScope.Search.ImprintAssetSearch : null,
                        columnFilterValues: Object.keys($rootScope.Search.columnFilterValues).length > 0 ? $rootScope.Search.columnFilterValues : null,
                        searchName: searchname,
                        fieldDisplayName: $rootScope.searchFieldName,
                        searchflag: $rootScope.searchFlag,
                        userId: user_id,
                        inColumnFilterList: $rootScope.inColumnFilterList,
                        ninColumnFilterList: $rootScope.ninColumnFilterList,
                        fromDateFilterList: $rootScope.fromDateFilterList,
                        toDateFilterList: $rootScope.toDateFilterList,
                        pageName: $rootScope.pagename,
                        modifyExistingFlg: modifyExistingFlg,
                        existingSearchName: $rootScope.searchName
                    }
                }).then(function(response) {
                    if (response.data.code == '200') {
                        $rootScope.getSavedSearch();
                        $rootScope.msg.showBaseSuccessMsg = !0;
                        $rootScope.msg.baseSuccessMsg = response.data.status;
                        setTimeout(function() {
                            $rootScope.msg.showBaseSuccessMsg = !1;
                            $rootScope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                        $('#myModal').modal('hide');
                        $rootScope.savesearchname = null;
                        $rootScope.saveSearchName = "";
                        angular.element($("#savesearchname")).val('')
                    } else {
                        $rootScope.existsError = !0;
                        $rootScope.SearchNameExists = response.data.status;
                        setTimeout(function() {
                            $rootScope.msg.showBaseErrorMsg = !1;
                            $rootScope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                })
            }
        }
    };
    $rootScope.gearFilterTopScroll = function() {
        var container = document.getElementById("gearfilterdata");
        container.scrollTop = 0
    }
    $rootScope.customHeaderList = [];
    $rootScope.headerColoumn = function(chk,obj) {
        var selectheader = obj;
        if ($rootScope.pagename == 'Metadata') {
            try {
                $rootScope.customHeaderList = $filter('filter')($rootScope.mDataCustomHeaders, function(data) {
                    return data.mChecked == !0
                }).map(function(data) {
                    return data.fieldName
                });
              }
              catch (e) {}
              
             if(chk == true){
                $rootScope.tempMDataGridHeaders.push(selectheader);
            }
            else if(chk == false){
                $rootScope.tempMDataGridHeaders.splice($rootScope.tempMDataGridHeaders.findIndex(data => data['fieldName'] === selectheader.fieldName), 1);
            }
            if ($rootScope.customHeaderList.length === $rootScope.gridHeaderMetaCount.length && $rootScope.customHeaderList.every(el => $rootScope.gridHeaderMetaCount.includes(el))) {
                $rootScope.msearchSaveEnable = !1
            } else {
                $rootScope.msearchSaveEnable = !0
            }
            if ($rootScope.customHeaderList.length <= 0) {
                $rootScope.msearchClrEnable = !1
            } else {
                $rootScope.msearchClrEnable = !0
            }
        } else {
            $rootScope.customHeaderList = $filter('filter')($rootScope.customHeaders, function(item) {
                return item.sChecked == !0
            }).map(function(item) {
                return item.fieldName
            });
            if(chk == true){
                $rootScope.tempGridHeaders.push(selectheader);
            }
            else if(chk == false){
                $rootScope.tempGridHeaders.splice($rootScope.tempGridHeaders.findIndex(data => data['fieldName'] === selectheader.fieldName), 1);
            }
            if ($rootScope.customHeaderList.length === $rootScope.gridHeaderAssetCount.length && $rootScope.customHeaderList.every(el => $rootScope.gridHeaderAssetCount.includes(el))) {
                $rootScope.searchSaveEnable = !1
            } else {
                $rootScope.searchSaveEnable = !0
            }
            if ($rootScope.customHeaderList.length <= 0) {
                $rootScope.searchClrEnable = !1
            } else {
                $rootScope.searchClrEnable = !0
            }
        }
    }
    $rootScope.canDisplayColumn = function (fieldName) {
        if ($rootScope.pagename == 'Metadata') {
            var candisplay = false;
            angular.forEach($rootScope.mDataCustomHeaders, function (data) {
                if (data.fieldName == fieldName) {
                    if (data.canChange == true)
                        candisplay = true;
                }
            });
            return candisplay;
        }
        else {
            var candisplay = false;
            angular.forEach($rootScope.customHeaders, function (data) {
                if (data.fieldName == fieldName) {
                    if (data.canChange == true)
                        candisplay = true;
                }
            });
            return candisplay;
        }
        

    }
    
    $rootScope.searchSaveEnable = false;
    $rootScope.TestisDragged = function(){
        if($rootScope.pagename == 'Metadata')
        $rootScope.msearchSaveEnable = true;
        else
        $rootScope.searchSaveEnable = true;
    }

    // $rootScope.headersReorderSaveValidation = function(){
    //     $timeout(function(){$rootScope.headerColoumn()},5000);
    //     if($rootScope.pagename == 'Metadata'){
    //         if ($rootScope.customHeaderList.length === $rootScope.gridHeaderMetaCount.length 
    //             && $rootScope.customHeaderList.every(el => $rootScope.gridHeaderMetaCount.includes(el))  
    //             //&& angular.equals($rootScope.tempMDataGridHeaders,$rootScope.mDataGridHeaders) 
    //             && ($rootScope.tempMDataGridHeaders.length == $rootScope.mDataGridHeaders.length)) {
    //             $rootScope.msearchSaveEnable = !1
    //         } else {
    //             $rootScope.msearchSaveEnable = !0
    //         }
    //     }
    //     else{
    //         if ($rootScope.customHeaderList.length === $rootScope.gridHeaderAssetCount.length
    //              && $rootScope.customHeaderList.every(el => $rootScope.gridHeaderAssetCount.includes(el))
    //               //&& ($rootScope.tempGridHeaders).equals($rootScope.gridHeaders)
                   
    //               && ($rootScope.tempGridHeaders.length == $rootScope.gridHeaders.length)) {
    //             $rootScope.searchSaveEnable = !1;
    //         } else {
    //             $rootScope.searchSaveEnable = !0
    //         }
    //     }
        
    // }
    // $rootScope.headersReorderClearValidation = function(){
      
    //     if($rootScope.pagename == 'Metadata'){
    //         if ($rootScope.customHeaderList.length <= 0 && !$rootScope.isDragged) {
    //             $rootScope.msearchClrEnable = !1
    //         } else {
    //             $rootScope.msearchClrEnable = !0
    //         }
    //     }
    //     else{
    //         if ($rootScope.customHeaderList.length <= 0 && !$rootScope.isDragged) {
    //             $rootScope.searchClrEnable = !1
    //         } else {
    //             $rootScope.searchClrEnable = !0
    //         }
    //     }
        
    // }
    $rootScope.headersDefaultValidation = function(){
        if($rootScope.pagename == 'Metadata'){
            var val = true;
            if(angular.equals($rootScope.tempMDataGridHeadersDefault, $rootScope.tempMDataGridHeaders))
            val = false;
            else
            val = true;
            return val;
        }
        else{
            var validation = true;
            if(angular.equals($rootScope.tempGridHeadersDefault, $rootScope.tempGridHeaders))
            validation = false;
            else
            validation = true;
            return validation;
        }
        
    }
    
    $rootScope.customHeaderRemove = function(obj){
        if($rootScope.pagename == 'Metadata'){
            angular.forEach($rootScope.mDataCustomHeaders, function(itm) {
                if(obj.fieldName == itm.fieldName)
                itm.mChecked = !1
            })
            var index = $rootScope.tempMDataGridHeaders.indexOf(obj);
            $rootScope.tempMDataGridHeaders.splice(index, 1);
        }
        else{
            angular.forEach($rootScope.customHeaders, function(itm) {
                if(obj.fieldName == itm.fieldName)
                itm.sChecked = !1
            })
            var index = $rootScope.tempGridHeaders.indexOf(obj);
            $rootScope.tempGridHeaders.splice(index, 1);
        }
        $rootScope.headerColoumn();  
    }
    $rootScope.saveCustomHeadersBasedOnOrder = function() {
        $rootScope.showLoader($('.assetTable'), 1, 'win8_linear');
         //angular.element("#gear-column-filter-dropdown").css("display","none");
        $rootScope.reqId = new Date().getTime();
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            angular.element(".gear-btn-enable").addClass('buttondisabled');
            $timeout(function() {
                $rootScope.headerColoumn()
            }, 10)
            $rootScope.isDragged = false;
           
            if ($rootScope.pagename == 'Metadata'){
                $rootScope.saveFinalHeader = angular.copy($rootScope.tempMDataGridHeaders);
            }
            else{
                $rootScope.saveFinalHeader = angular.copy($rootScope.tempGridHeaders);
            }
            $http({
                method: 'POST',
                url: '/saveCustomHeadersBaseOnOrder',
                data: {
                    customGrid: $rootScope.saveFinalHeader,
                    pageName: $rootScope.pagename
                }
            }).then(function(response) {
                if (response.data.code == '200') {
                    $rootScope.msg.showBaseSuccessMsg = !0;
                    $rootScope.msg.baseSuccessMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseSuccessMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                } else {
                    $rootScope.msg.showBaseErrorMsg = !0;
                    $rootScope.msg.baseErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseErrorMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
                $http({
                    method: 'GET',
                    url: '/getGridHeaders/' + $rootScope.pagename,
                    data: null
                }).then(function(response) {
                    if ($rootScope.pagename == 'Metadata'){
                        $rootScope.mDataGridHeaders = response.data.data;
                        $rootScope.tempMDataGridHeaders = angular.copy($rootScope.mDataGridHeaders);
                    }
                        
                    else{
                        $rootScope.gridHeaders = response.data.data;
                        $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
                    } 
                    $rootScope.viewSearch($rootScope.searchFlag, $rootScope.searchName, 0, !1, !1, !0);
                    $rootScope.gearDrop()
                })
            });
            angular.element(".column-filter-dropdown").removeClass("active");
            angular.element(".gear-Select").removeClass("active");
            angular.element("#assetdivTableBody").scrollLeft(0);
            var container = document.getElementById("assetdivTableBody");
            container.scrollTop = 0;
            $rootScope.gearFilterTopScroll()
        }
        // location.reload();
    };
    $rootScope.saveCustomHeadersDefault = function() {
        //$rootScope.showLoader($('.assetTable'), 1, 'win8_linear');
         //angular.element("#gear-column-filter-dropdown").css("display","none");
        $rootScope.reqId = new Date().getTime();
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            $timeout(function() {
                $rootScope.headerColoumn()
            }, 10)
            if ($rootScope.pagename == 'Metadata'){
                $rootScope.saveFinalHeader = angular.copy($rootScope.tempMDataGridHeaders);
            }
            else{
                $rootScope.saveFinalHeader = angular.copy($rootScope.tempGridHeaders);
            }
            $http({
                method: 'POST',
                url: '/saveCustomHeadersBaseOnOrder',
                data: {
                    isRemove: true,
                    pageName: $rootScope.pagename
                }
            }).then(function(response) {
                if (response.data.code == '200') {
                    $rootScope.msg.showBaseSuccessMsg = !0;
                    $rootScope.msg.baseSuccessMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseSuccessMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                } else {
                    $rootScope.msg.showBaseErrorMsg = !0;
                    $rootScope.msg.baseErrorMsg = response.data.status;
                    setTimeout(function() {
                        $rootScope.msg.showBaseErrorMsg = !1;
                        $rootScope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
                $http({
                    method: 'GET',
                    url: '/getGridHeaders/' + $rootScope.pagename,
                    data: null
                }).then(function(response) {
                    if ($rootScope.pagename == 'Metadata'){
                        $rootScope.mDataGridHeaders = response.data.data;
                        $rootScope.tempMDataGridHeaders = angular.copy($rootScope.mDataGridHeaders);
                        $rootScope.tempMDataGridHeadersDefault = angular.copy($rootScope.tempMDataGridHeaders);
                    }
                        
                    else{
                        $rootScope.gridHeaders = response.data.data;
                        $rootScope.tempGridHeadersDefault = angular.copy($rootScope.gridHeaders);
                        $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
                    } 
                    $rootScope.viewSearch($rootScope.searchFlag, $rootScope.searchName, 0, !1, !1, !0);
                    $rootScope.gearDrop()
                })
            });
            angular.element(".column-filter-dropdown").removeClass("active");
            angular.element(".gear-Select").removeClass("active");
            angular.element("#assetdivTableBody").scrollLeft(0);
            var container = document.getElementById("assetdivTableBody");
            container.scrollTop = 0;
            $rootScope.gearFilterTopScroll()
        }
    };
    $scope.saveCustomHeaders = function() {
        $rootScope.reqId = new Date().getTime();
        var user_id = $rootScope.loggedUser.userId;
        $rootScope.customList = [];
        angular.forEach($rootScope.customHeaders, function(value, key) {
            if (value.displayName === 'ISBN' || value.displayName === 'TITLE' || value.displayName === 'AUTHOR') {
                $rootScope.customGridHeaders.push(value.fieldName)
            }
        });
        angular.forEach($rootScope.customGridHeaders, function(value) {
            $rootScope.customList.push({
                "userId": user_id,
                "fieldName": value,
                "pageName": "Default"
            })
        });
        $http({
            method: 'POST',
            url: '/saveCustomHeaders',
            data: {
                headers: $rootScope.customList
            }
        }).then(function(response) {
            $rootScope.customHeadersSave = response.data.data;
            angular.element($(".single-select-dropdown.gear-dropdown")).removeClass('active');
            $rootScope.showSuccessSearchSaveMsg = !0;
            setTimeout(function() {
                $rootScope.showSuccessSearchSaveMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
            $http({
                method: 'GET',
                url: '/getGridHeaders/' + $rootScope.pagename,
                data: null
            }).then(function(response) {
                $rootScope.gridHeaders = response.data.data;
                $rootScope.tempGridHeaders = angular.copy($rootScope.gridHeaders);
                $rootScope.viewSearch($rootScope.searchFlag, $rootScope.searchName, 0, !1, !1, !0)
            })
        })
    };
    $scope.addCustomHeaders = function(checkHeader, customFields, fieldName, displayName, event) {
        if (checkHeader) {
            if ($rootScope.customGridHeaders.indexOf(fieldName) == -1) {
                $rootScope.customGridHeaders.push(fieldName)
            }
        } else {
            $rootScope.customGridHeaders.splice($rootScope.customGridHeaders.indexOf(fieldName), 1)
        }
    };
    $rootScope.inColFilterList = {};
    $rootScope.inColumnFilterList = {};
    $rootScope.ninColFilterList = {};
    $rootScope.ninColumnFilterList = {};
    $rootScope.columnSuggestions = {};
    $rootScope.gHeadresAllSelect = {};
    $rootScope.columnFormatYes = {};
    $rootScope.columnFormatNo = {};
    $rootScope.colFormatStatus = {};
    $rootScope.fromDateFilterList = {};
    $rootScope.toDateFilterList = {};
    $rootScope.addRemoveColumnTags = function(input, chkFlg, fieldName) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        var gridFieldname = $filter('filter')($rootScope.gridHeaders, function(data) {
            return data.fieldName == fieldName
        })[0];
        if (chkFlg) {
            if ($rootScope.inColFilterList[fieldName] == undefined) {
                $rootScope.inColumnFilterList[fieldName] = [];
                $rootScope.inColFilterList[fieldName] = []
            }
            $rootScope.inColFilterList[fieldName].push(input);
            $rootScope.inColumnFilterList[fieldName].push(input.code);
            if (gridFieldname == null || gridFieldname == undefined || gridFieldname.fieldType != 'boolean')
                $rootScope.gHeadresAllSelect[fieldName] = $rootScope.columnSuggestions[fieldName].every(function(itm) {
                    return itm.selected
                })
        } else {
            if (gridFieldname == null || gridFieldname == undefined || gridFieldname.fieldType != 'boolean') {
                $rootScope.gHeadresAllSelect[fieldName] = !1;
                $.each($rootScope.columnSuggestions[fieldName], function(index, data) {
                    if (data.code == input.code) {
                        data.selected = !1;
                        return !1
                    }
                })
            } else {
                $rootScope.colFormatStatus[fieldName + '_' + input.code] = !1
            }
            $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                return (data != input.code)
            });
            $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                return (data.code != input.code)
            })
        }
        Object.keys($rootScope.columnSuggestions).forEach(function(itm) {
            if (itm != fieldName) delete $rootScope.columnSuggestions[itm]
        });
        Object.keys($rootScope.columnFilterSearch).forEach(function(itm) {
            if (itm != fieldName) delete $rootScope.columnFilterSearch[itm]
        });
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.addRemoveFormatColumnTags = function(format, chkFlg, fieldName, checkBoxName) {
        $rootScope.reqId = new Date().getTime();
        var input = {
            code: format.formatId,
            description: format.formatName
        };
        if (checkBoxName == 'YES') {
            if (chkFlg) {
                $rootScope.columnFormatNo[input.code] = !1;
                if ($rootScope.inColFilterList[fieldName] == undefined) {
                    $rootScope.inColumnFilterList[fieldName] = [];
                    $rootScope.inColFilterList[fieldName] = []
                }
                $rootScope.inColFilterList[fieldName].push(input);
                $rootScope.inColumnFilterList[fieldName].push(input.code);
                $rootScope.ninColumnFilterList[fieldName] = $filter('filter')($rootScope.ninColumnFilterList[fieldName], function(data) {
                    return (data != input.code)
                });
                $rootScope.ninColFilterList[fieldName] = $filter('filter')($rootScope.ninColFilterList[fieldName], function(data) {
                    return (data.code != input.code)
                })
            } else {
                $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                    return (data != input.code)
                });
                $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                    return (data.code != input.code)
                })
            }
        } else {
            if (chkFlg) {
                $rootScope.columnFormatYes[input.code] = !1;
                if ($rootScope.ninColFilterList[fieldName] == undefined) {
                    $rootScope.ninColumnFilterList[fieldName] = [];
                    $rootScope.ninColFilterList[fieldName] = []
                }
                $rootScope.ninColFilterList[fieldName].push(input);
                $rootScope.ninColumnFilterList[fieldName].push(input.code);
                $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                    return (data != input.code)
                });
                $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                    return (data.code != input.code)
                })
            } else {
                $rootScope.ninColumnFilterList[fieldName] = $filter('filter')($rootScope.ninColumnFilterList[fieldName], function(data) {
                    return (data != input.code)
                });
                $rootScope.ninColFilterList[fieldName] = $filter('filter')($rootScope.ninColFilterList[fieldName], function(data) {
                    return (data.code != input.code)
                })
            }
        }
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.removeFormatColumnTags = function(input, chkFlg, fieldName, checkBoxName) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        if (checkBoxName == 'YES') {
            $rootScope.columnFormatYes[input.code] = !1;
            $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                return (data != input.code)
            });
            $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                return (data.code != input.code)
            })
        } else {
            $rootScope.columnFormatNo[input.code] = !1;
            $rootScope.ninColumnFilterList[fieldName] = $filter('filter')($rootScope.ninColumnFilterList[fieldName], function(data) {
                return (data != input.code)
            });
            $rootScope.ninColFilterList[fieldName] = $filter('filter')($rootScope.ninColFilterList[fieldName], function(data) {
                return (data.code != input.code)
            })
        }
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.addRemoveFormatColumnStatusTags = function(status, chkFlg, fieldName) {
        $rootScope.reqId = new Date().getTime();
        var input = {
            code: status.code,
            description: status.description
        };
        if (chkFlg) {
            if ($rootScope.inColFilterList[fieldName] == undefined) {
                $rootScope.inColumnFilterList[fieldName] = [];
                $rootScope.inColFilterList[fieldName] = []
            }
            $rootScope.inColFilterList[fieldName].push(input);
            $rootScope.inColumnFilterList[fieldName].push(input.code)
        } else {
            $rootScope.colFormatStatus[input.code] = !1;
            $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                return (data != input.code)
            });
            $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                return (data.code != input.code)
            })
        }
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.addDateFilters = function(fieldName, fieldType, dateVal) {
        $rootScope.reqId = new Date().getTime();
        if (fieldType == "FROM") {
            if (dateVal == "" || dateVal == null || dateVal == undefined)
                delete $rootScope.fromDateFilterList[fieldName];
            else $rootScope.fromDateFilterList[fieldName] = dateVal
        } else {
            if (dateVal == "" || dateVal == null || dateVal == undefined)
                delete $rootScope.toDateFilterList[fieldName];
            else $rootScope.toDateFilterList[fieldName] = dateVal
        }
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    $rootScope.removeDateFilter = function(fieldName, fieldType) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        if (fieldType == "FROM") {
            delete $rootScope.fromDateFilterList[fieldName];
            document.getElementById(fieldName + "_From").value = "";
            $rootScope.From[fieldName] = null
        } else {
            delete $rootScope.toDateFilterList[fieldName];
            document.getElementById(fieldName + "_To").value = "";
            $rootScope.To[fieldName] = null
        }
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    $rootScope.gearHide = !1;
    $rootScope.gearDrop = function() {
        $rootScope.gearFilterTopScroll();
        if (angular.element("#gear-column-filter-dropdown").is(":visible")) {
            angular.element("#gear-column-filter-dropdown").toggle();
            angular.element(".gear-btn-disable").removeClass('buttondisabled');
            angular.element(".gear-btn-disable").addClass('btn-save');
            $rootScope.gearHide = !1
        } else {
            $rootScope.gearFilterTopScroll();
            if ($rootScope.searchEnable == !0) {
                angular.element("#searchrequest").modal('toggle')
            } else {
                angular.element("#gear-column-filter-dropdown").toggle();
                angular.element(".gear-btn-disable").addClass('buttondisabled');
                angular.element(".gear-btn-disable").removeClass('btn-save');
                $rootScope.gearHide = !0
            }
        }
    }
    $rootScope.gridHeadresAllSelected = function(fieldName, chkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        var filteredList = $filter('filter')($rootScope.columnSuggestions[fieldName], function(data) {
            var re = new RegExp(RegExp.escape($rootScope.columnFilterSearch[fieldName]), 'gi');
                return data.description.match(re)
            
        });
        if (chkFlg) {
            if ($rootScope.inColFilterList[fieldName] == undefined) {
                $rootScope.inColumnFilterList[fieldName] = [];
                $rootScope.inColFilterList[fieldName] = []
            }
            angular.forEach(filteredList, function(input) {
                if ($rootScope.inColumnFilterList[fieldName].indexOf(input.code) == -1) {
                    $rootScope.inColFilterList[fieldName].push(input);
                    $rootScope.inColumnFilterList[fieldName].push(input.code);
                    input.selected = !0
                }
            })
        } else {
            angular.forEach(filteredList, function(input) {
                $rootScope.inColFilterList[fieldName] = $filter('filter')($rootScope.inColFilterList[fieldName], function(data) {
                    return (data.code != input.code)
                });
                $rootScope.inColumnFilterList[fieldName] = $filter('filter')($rootScope.inColumnFilterList[fieldName], function(data) {
                    return (data != input.code)
                });
                input.selected = !1
            })
        }
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    RegExp.escape = function(string) {
        return (string == undefined || string == null) ? string : string.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')
    };
    $rootScope.gridHeadersResetFilter = function(fieldName, fieldType) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        if (fieldName == "Format") {
            angular.forEach($rootScope.formatList, function(format) {
                $rootScope.columnFormatNo[format.formatId] = !1;
                $rootScope.columnFormatYes[format.formatId] = !1
            })
            angular.forEach($rootScope.statusList, function(fStatus) {
                if (fStatus.statusType == 'FORMAT') {
                    $rootScope.colFormatStatus[fStatus.code] = !1
                }
            })
            delete $rootScope.inColFilterList.Format;
            delete $rootScope.inColumnFilterList.Format;
            delete $rootScope.inColFilterList['Format Status'];
            delete $rootScope.inColumnFilterList['Format Status'];
            delete $rootScope.ninColFilterList.Format;
            delete $rootScope.ninColumnFilterList.Format
        } else if (fieldName == 'Uploaded') {
            $rootScope.gHeadresAllSelect['Uploaded By'] = !1;
            angular.forEach($rootScope.columnSuggestions['Uploaded By'], function(itm) {
                itm.selected = !1
            });
            delete $rootScope.inColFilterList['Uploaded By'];
            delete $rootScope.inColumnFilterList['Uploaded By'];
            delete $rootScope.fromDateFilterList['Uploaded On'];
            delete $rootScope.toDateFilterList['Uploaded On'];
            document.getElementById('Uploaded On' + "_From").value = "";
            document.getElementById('Uploaded On' + "_To").value = "";
            $rootScope.From['Uploaded On'] = null;
            $rootScope.To['Uploaded On'] = null
        } else {
            if (fieldType == 'Date') {
                delete $rootScope.fromDateFilterList[fieldName];
                delete $rootScope.toDateFilterList[fieldName];
                document.getElementById(fieldName + "_From").value = "";
                document.getElementById(fieldName + "_To").value = "";
                $rootScope.From[fieldName] = null;
                $rootScope.To[fieldName] = null
            } else if (fieldType == 'boolean') {
                angular.forEach($rootScope.statusList, function(bStatus) {
                    if (bStatus.statusType == 'BOOLEAN_STATUS') {
                        $rootScope.colFormatStatus[fieldName + '_' + bStatus.code] = !1
                    }
                })
                delete $rootScope.inColFilterList[fieldName];
                delete $rootScope.inColumnFilterList[fieldName]
            } else {
                $rootScope.gHeadresAllSelect[fieldName] = !1;
                angular.forEach($rootScope.columnSuggestions[fieldName], function(itm) {
                    itm.selected = !1
                });
                angular.forEach($rootScope.lookUpSuggestions[fieldName], function(itm) {
                    itm.selected = !1
                });
                delete $rootScope.inColFilterList[fieldName];
                delete $rootScope.inColumnFilterList[fieldName]
            }
        }
        Object.keys($rootScope.columnSuggestions).forEach(function(itm) {
            delete $rootScope.columnSuggestions[itm]
        });
        Object.keys($rootScope.columnFilterSearch).forEach(function(itm) {
            delete $rootScope.columnFilterSearch[itm]
        });
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    $rootScope.filterApplied = function(fieldName, fieldType) {
        var flag = !1;
        if (fieldName == "Format") {
            if ($rootScope.inColFilterList != undefined && $rootScope.inColFilterList != null && Object.keys($rootScope.inColFilterList).length != 0) {
                if ($rootScope.inColFilterList.Format != null && $rootScope.inColFilterList.Format != undefined && Object.keys($rootScope.inColFilterList.Format).length != 0)
                    flag = !0;
                if ($rootScope.inColFilterList['Format Status'] != null && $rootScope.inColFilterList['Format Status'] != undefined && Object.keys($rootScope.inColFilterList['Format Status']).length != 0)
                    flag = !0
            }
            if (!flag && $rootScope.ninColFilterList != undefined && $rootScope.ninColFilterList != null && Object.keys($rootScope.ninColFilterList).length != 0) {
                if ($rootScope.ninColFilterList.Format != null && $rootScope.ninColFilterList.Format != undefined && Object.keys($rootScope.ninColFilterList.Format).length != 0)
                    flag = !0;
                if ($rootScope.ninColFilterList['Format Status'] != null && $rootScope.ninColFilterList['Format Status'] != undefined && Object.keys($rootScope.ninColFilterList['Format Status']).length != 0)
                    flag = !0
            }
        } else if (fieldName == 'Uploaded') {
            if ($rootScope.inColFilterList != undefined && $rootScope.inColFilterList != null && Object.keys($rootScope.inColFilterList).length != 0) {
                if ($rootScope.inColFilterList['Uploaded By'] != null && $rootScope.inColFilterList['Uploaded By'] != undefined && Object.keys($rootScope.inColFilterList['Uploaded By']).length != 0)
                    flag = !0
            }
            if (!flag && $rootScope.ninColFilterList != undefined && $rootScope.ninColFilterList != null && Object.keys($rootScope.ninColFilterList).length != 0) {
                if ($rootScope.ninColFilterList['Uploaded By'] != null && $rootScope.ninColFilterList['Uploaded By'] != undefined && Object.keys($rootScope.ninColFilterList['Uploaded By']).length != 0)
                    flag = !0
            }
            if (!flag && ("Uploaded On" in $rootScope.fromDateFilterList || "Uploaded On" in $rootScope.toDateFilterList))
                flag = !0
        } else {
            if (fieldType == 'Date') {
                if (!flag && (fieldName in $rootScope.fromDateFilterList || fieldName in $rootScope.toDateFilterList))
                    flag = !0
            } else {
                if ($rootScope.inColFilterList != undefined && $rootScope.inColFilterList != null && Object.keys($rootScope.inColFilterList).length != 0) {
                    if ($rootScope.inColFilterList[fieldName] != null && $rootScope.inColFilterList[fieldName] != undefined && Object.keys($rootScope.inColFilterList[fieldName]).length != 0)
                        flag = !0
                }
                if (!flag && $rootScope.ninColFilterList != undefined && $rootScope.ninColFilterList != null && Object.keys($rootScope.ninColFilterList).length != 0) {
                    if ($rootScope.ninColFilterList[fieldName] != null && $rootScope.ninColFilterList[fieldName] != undefined && Object.keys($rootScope.ninColFilterList[fieldName]).length != 0)
                        flag = !0
                }
            }
        }
        return flag
    }
    $rootScope.addAccountTags = function(input, checkAcct) {
        $rootScope.reqId = new Date().getTime();
        var checkCount = 0;
        var filteredAccountList = $rootScope.accountList;
        angular.forEach(filteredAccountList, function(acl) {
            if (document.getElementById("region_" + acl.accountId).checked) checkCount++
        });
        $timeout(function() {
            $rootScope.search.regionAllSelected = ((checkCount === filteredAccountList.length) && (checkCount != 0))
        }, 100);
        if (checkAcct) {
            $rootScope.accountFilterList.push(input);
            $rootScope.selectedAccounts.push(input.accountId)
        } else {
            $rootScope.accountFilterList = $filter('filter')($rootScope.accountFilterList, function(data) {
                return data.accountId != input.accountId
            });
            $rootScope.selectedAccounts = $filter('filter')($rootScope.selectedAccounts, function(data) {
                return data != input.accountId
            })
        }
        $rootScope.getImprints();
        setTimeout(function() {
            $rootScope.getSelectedSearchFilterProductCategories();
            $rootScope.searchFlag = 'F';
            $rootScope.searchEnable = !0;
            $rootScope.resetGlobalFilters();
            if ($rootScope.refreshSearch()) {
                $rootScope.commonAllFilter()
            }
        }, 200);
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    };
    $rootScope.refreshSearchImprintList = function() {
        var filteredList = $filter('filter')($rootScope.imprintList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.imprintFilter), 'gi');
            return data.match(re)
        });
        var checkCount = 0;
        angular.forEach(filteredList, function(item) {
            if ($rootScope.imprintFilterList.indexOf(item) != -1) {
                document.getElementById("imprint_" + item).checked = !0;
                checkCount++
            }
        });
        $timeout(function() {
            $rootScope.search.imAllSelected = ((checkCount == filteredList.length) && (checkCount != 0))
        }, 100)
    }
    $rootScope.addImprintTags = function(input, checkImprint) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.searchEnable = !0;
        if (checkImprint) {
            $rootScope.imprintFilterList.push(input)
        } else {
            $rootScope.imprintFilterList = $filter('filter')($rootScope.imprintFilterList, function(data) {
                return data != input
            })
        }
        $rootScope.refreshSearchImprintList();
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.callCommonAllFilter = function() {
        $rootScope.reqId = new Date().getTime();
        $rootScope.commonAllFilter()
    };
    $rootScope.commonAllFilter = function() {
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0;
        $rootScope.commonFilterClicked = !0;
        $rootScope.refreshSearchImprintList();
        $rootScope.viewSearch($rootScope.searchFlag, $rootScope.searchName, 0, !1, !1, !0);
        if ($rootScope.locationPath.contains('metadata')) {
            location.href = "#/metadata";
            angular.element("#asset-submenu").removeClass('open');
            angular.element("#report-submenu").removeClass('open');
            angular.element("#meta-submenu").addClass('open')
        } else {
            location.href = "#/asset";
            angular.element("#asset-submenu").addClass('open');
            angular.element("#report-submenu").removeClass('open');
            angular.element("#meta-submenu").removeClass('open')
        }
        $rootScope.searchEnable = !1;
        angular.element(".innerFilter,.header-filter").removeClass('active');
        angular.element(".innerFilterDropdown,.header-filter-dropdown").removeClass('active');
        if (angular.element("#assetdivTableBody").is(":visible")) {
            angular.element("#assetdivTableBody").scrollLeft(0);
            var container = document.getElementById("assetdivTableBody");
            container.scrollTop = 0
        };
        $timeout(function() {
            angular.element(".searchdataheight").removeClass('save-search-data')
        }, 200)
    }
    $rootScope.refreshSearchFormatList = function() {
        var filteredList = $filter('filter')($rootScope.formatList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.formatFilter), 'gi');
            return data.formatName.match(re)
        });
        $timeout(function() {
            $rootScope.search.formatCheckAll = filteredList.every(function(itm) {
                return itm.sChecked
            }) && filteredList.length > 0
        }, 50)
    }
    $rootScope.addFormatTags = function(input, checkFormat) {
        $rootScope.reqId = new Date().getTime();
        if (checkFormat) {
            $rootScope.formatFilterList.push(input);
            $rootScope.formatCodeList.push(input.formatId)
        } else {
            $rootScope.formatFilterList = $filter('filter')($rootScope.formatFilterList, function(data) {
                return data.formatId != input.formatId
            });
            $rootScope.formatCodeList = $filter('filter')($rootScope.formatCodeList, function(data) {
                return data != input.formatId
            })
        }
        $rootScope.refreshSearchFormatList();
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    };
    $rootScope.addStatusTags = function(input, chkFlg, statusFilter) {
        $rootScope.reqId = new Date().getTime();
        if (chkFlg) {
            if ($rootScope.statusFilterList[statusFilter.code] == undefined) {
                $rootScope.statusFilterList[statusFilter.code] = []
            }
            $rootScope.statusFilterList[statusFilter.code].push(input.code);
            $rootScope.search.statusAllSelect[statusFilter.code] = $filter('filter')($rootScope.statusList, function(data) {
                return data.statusType == statusFilter.statusType
            }).every(function(itm) {
                return itm.afchecked
            })
        } else {
            $rootScope.search.statusAllSelect[statusFilter.code] = !1;
            $.each($filter('filter')($rootScope.statusList, function(data) {
                return data.statusType == statusFilter.statusType
            }), function(index, data) {
                if (data.code == input.code) {
                    data.afchecked = !1;
                    return !1
                }
            });
            $rootScope.statusFilterList[statusFilter.code] = $filter('filter')($rootScope.statusFilterList[statusFilter.code], function(data) {
                return (data != input.code)
            })
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.statusAllSelect = function(chkFlg, statusFilter) {
        $rootScope.reqId = new Date().getTime();
        var tempList = $filter('filter')($rootScope.statusList, function(data) {
            return data.statusType == statusFilter.statusType
        });
        angular.forEach(tempList, function(itm) {
            itm.afchecked = chkFlg
        });
        if (chkFlg) {
            $rootScope.statusFilterList[statusFilter.code] = [];
            angular.forEach(tempList, function(input) {
                $rootScope.statusFilterList[statusFilter.code].push(input.code)
            })
        } else {
            $rootScope.statusFilterList[statusFilter.code] = []
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.checkStatusFilterApplied = function() {
        var flg = !1;
        if (Object.keys($rootScope.statusFilterList).length != 0) {
            $.each($rootScope.statusFilterList, function(index, fieldName) {
                if (fieldName != null && fieldName != undefined && Object.keys(fieldName).length != 0) {
                    flg = !0;
                    return
                }
            })
        }
        return flg
    };
    $rootScope.addOthersTags = function(input, checkOthers) {
        $rootScope.reqId = new Date().getTime();
        var checkCount = 0;
        angular.forEach($rootScope.othersList, function(other) {
            if (document.getElementById("other_" + other.description).checked) checkCount++
        });
        $timeout(function() {
            $rootScope.search.otherAllSelect = ((checkCount === $rootScope.othersList.length) && (checkCount != 0))
        }, 100);
        if (checkOthers) {
            $rootScope.advancedOthersFilterList.push(input.code);
            $rootScope.othersFilterList.push(input)
        } else {
            $rootScope.othersFilterList = $filter('filter')($rootScope.othersFilterList, function(data) {
                return data.code != input.code
            });
            $rootScope.advancedOthersFilterList = $filter('filter')($rootScope.advancedOthersFilterList, function(data) {
                return data != input.code
            })
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    };
    $rootScope.refreshSearchGlobalImprintList = function() {
        var filteredList = $filter('filter')($rootScope.imprintListGlobal, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.imprintGlobal), 'gi');
            return data.match(re)
        });
        var checkCount = 0;
        angular.forEach(filteredList, function(item) {
            if ($rootScope.GlobalImprintList.indexOf(item) != -1) {
                document.getElementById(item + "_Global").checked = !0;
                checkCount++
            }
        });
        $timeout(function() {
            $rootScope.search.imgAllSelected = ((checkCount == filteredList.length) && (checkCount != 0))
        }, 100)
    }
    $rootScope.addImprintGlobalTags = function(input, checkImprint) {
        $rootScope.reqId = new Date().getTime();
        if (checkImprint) {
            $rootScope.GlobalImprintList.push(input)
        } else {
            $rootScope.GlobalImprintList = $filter('filter')($rootScope.GlobalImprintList, function(data) {
                return data != input
            })
        }
        $rootScope.refreshSearchGlobalImprintList();
        $rootScope.searchFlag = 'I';
        $rootScope.resetAdvancedFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.refreshSearchAllMetadataGlobal = function() {
        var filteredList = $filter('filter')($rootScope.othersList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.allMetadataGlobal), 'gi');
            return data.description.match(re)
        });
        var checkCount = 0;
        angular.forEach(filteredList, function(other) {
            if ($rootScope.GlobalOthersCodeList.indexOf(other.code) != -1) {
                document.getElementById(other.description + "_Global").checked = !0;
                checkCount++
            }
        });
        $timeout(function() {
            $rootScope.search.mtAllSelected = ((checkCount == filteredList.length) && (checkCount != 0))
        }, 100)
    }
    $rootScope.addOthersGlobalTags = function(input, checkImprint) {
        $rootScope.reqId = new Date().getTime();
        if (checkImprint) {
            $rootScope.GlobalOthersList.push(input);
            $rootScope.GlobalOthersCodeList.push(input.code)
        } else {
            $rootScope.GlobalOthersList = $filter('filter')($rootScope.GlobalOthersList, function(data) {
                return data.code != input.code
            });
            $rootScope.GlobalOthersCodeList = $filter('filter')($rootScope.GlobalOthersCodeList, function(data) {
                return data != input.code
            })
        }
        $rootScope.refreshSearchAllMetadataGlobal();
        $rootScope.searchFlag = 'I';
        $rootScope.searchEnable = !0;
        $rootScope.resetAdvancedFilters();
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    };
    $rootScope.lookUpSuggestions = {};
    var timeout = null;
    $rootScope.getColumnFilterSuggestions = function(fieldName, suggestTxt, lookup) {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $rootScope.callColumnFilterSuggestions(fieldName, suggestTxt, lookup)
        }, 800)
    }
    $rootScope.callColumnFilterSuggestions = function(fieldName, suggestTxt, lookup) {
        var searchFlag = $rootScope.searchFlag;
        if ($rootScope.lookUpSuggestions[fieldName] != undefined && Object.keys($rootScope.lookUpSuggestions[fieldName]).length > 0) {
            var filteredList = angular.copy($filter('filter')($rootScope.lookUpSuggestions[fieldName], function(data) {
                var re = new RegExp(RegExp.escape($rootScope.columnFilterSearch[fieldName]), 'gi');
                    return data.description.match(re);
            }));
            if (filteredList != null && filteredList.length > 0) {
                if ($rootScope.inColFilterList[fieldName] != undefined && $rootScope.inColFilterList[fieldName] != [] && $rootScope.inColFilterList[fieldName] != null) {
                    $.each(filteredList, function(index, data) {
                        if ($rootScope.inColumnFilterList[fieldName].indexOf(data.code) != -1) {
                            data.selected = !0
                        }
                    })
                }
                $rootScope.columnSuggestions[fieldName] = $filter('filter')(filteredList, function(data) {
                    return (data.code != null && data.code != undefined && data.code != "")
                })
                $rootScope.gHeadresAllSelect[fieldName] = $rootScope.columnSuggestions[fieldName].every(function(itm) {
                    return itm.selected
                })
            } else {
                $rootScope.columnSuggestions[fieldName] = filteredList;
                $rootScope.gHeadresAllSelect[fieldName] = !1
            }
            return !1
        } else {
            if (searchFlag == 'F') {
                $rootScope.Search.AdvancedSearch.accounts = $rootScope.selectedAccounts;
                $rootScope.Search.AdvancedSearch.formats = $rootScope.formatCodeList;
                $rootScope.Search.AdvancedSearch.status = $rootScope.statusFilterList;
                $rootScope.Search.AdvancedSearch.imprints = $rootScope.imprintFilterList;
                $rootScope.Search.AdvancedSearch.others = $rootScope.advancedOthersFilterList;
                $rootScope.Search.AdvancedSearch.productCategories = $rootScope.selectedProductCategoryArraySearch;
                $rootScope.Search.HeaderSearch.searchText = $rootScope.search.globalSearchText
            } else if (searchFlag == "I") {
                $rootScope.Search.ImprintAssetSearch.imprintNames = $rootScope.GlobalImprintList;
                $rootScope.Search.ImprintAssetSearch.assetDescription = $rootScope.GlobalOthersCodeList
            } else if (searchFlag == "G") {
                $rootScope.Search.HeaderSearch.metaDataType = $rootScope.mDataType;
                $rootScope.Search.HeaderSearch.metaDataCategory = $rootScope.mCategory;
                $rootScope.Search.HeaderSearch.searchText = $rootScope.search.globalSearchText
            }
            $http({
                method: 'POST',
                url: '/getColumnFilterSuggestions',
                data: {
                    headerSearch: Object.keys($rootScope.Search.HeaderSearch).length > 0 ? $rootScope.Search.HeaderSearch : null,
                    advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : null,
                    imprintAssetSearch: Object.keys($rootScope.Search.ImprintAssetSearch).length > 0 ? $rootScope.Search.ImprintAssetSearch : null,
                    searchName: $rootScope.searchName,
                    fieldDisplayName: $rootScope.searchFieldName,
                    searchflag: searchFlag,
                    suggestionText: suggestTxt,
                    filterFieldName: fieldName,
                    inColumnFilterList: $rootScope.inColumnFilterList,
                    ninColumnFilterList: $rootScope.ninColumnFilterList,
                    fromDateFilterList: $rootScope.fromDateFilterList,
                    toDateFilterList: $rootScope.toDateFilterList
                }
            }).then(function(response) {
                if (response.data.data != null && Object.keys(response.data.data).length > 0) {
                    if ($rootScope.inColFilterList[fieldName] != undefined && $rootScope.inColFilterList[fieldName] != [] && $rootScope.inColFilterList[fieldName] != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($rootScope.inColumnFilterList[fieldName].indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    if (lookup == !0) {
                        $rootScope.lookUpSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                            return (data.code != null && data.code != undefined && data.code != "")
                        })
                    } else {
                        $rootScope.lookUpSuggestions = {}
                    }
                    $rootScope.columnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $rootScope.gHeadresAllSelect[fieldName] = $rootScope.columnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                } else {
                    $rootScope.columnSuggestions[fieldName] = response.data.data;
                    $rootScope.gHeadresAllSelect[fieldName] = !1
                }
            })
        }
    };
    $scope.masters = [{
        'masterId': 1,
        'masterName': 'Users',
        'masterPage': '#/user-master',
        'imageSrc': '../resources/images/user-master.svg'
    }, {
        'masterId': 2,
        'masterName': 'Roles',
        'masterPage': '#/role-master',
        'imageSrc': '../resources/images/roles.svg'
    }, {
        'masterId': 3,
        'masterName': 'Business Rules',
        'masterPage': '#/business-rules',
        'imageSrc': '../resources/images/business-rule.svg'
    }, {
        'masterId': 4,
        'masterName': 'Metadata',
        'masterPage': '#/metadata',
        'imageSrc': '../resources/images/metadata1.svg'
    }, {
        'masterId': 5,
        'masterName': 'Partners',
        'masterPage': '#/partners',
        'imageSrc': '../resources/images/partners.svg'
    }, {
        'masterId': 6,
        'masterName': 'Product Category',
        'masterPage': '#/product-category',
        'imageSrc': '../resources/images/product-categroy.svg'
    }, {
        'masterId': 7,
        'masterName': 'Formats',
        'masterPage': '#/metadata',
        'imageSrc': '../resources/images/formats.svg'
    }, {
        'masterId': 8,
        'masterName': 'Account',
        'masterPage': '#/accounts',
        'imageSrc': '../resources/images/account.svg'
    }];
    $scope.selected = -1;
    $scope.historySelect = function(index, event) {
        $scope.selected = index;
        angular.forEach(event.currentTarget.classList, function(value, key) {
            if (value == "active") {
                $scope.selected = -1
            }
        })
    };
    $rootScope.testScroll = function() {
        setTimeout(function() {
            $('.index-table .divTableBody').bind('scroll', function(e) {
                $(this).closest('.index-table').children('.divTableHeading').css("left", -$(this).scrollLeft());
                $(this).closest('.index-table').children('.divTableHeading').children('.divTableHead:nth-child(1)').css("left", $(this).scrollLeft());
                $(this).closest('.index-table.fixed-action').children('.divTableHeading').children('.divTableHead:last-child').css("left", -($(this).scrollLeft()));
                $(this).find('.divTableCell:nth-child(1)').css("left", $(this).scrollLeft());
                $(this).find('.asset-table-heads').css("left", $(this).scrollLeft());
                var tabWidth = $(this).closest('.index-table.fixed-action').width();
                var innertabWidth = $(this).closest('.index-table.fixed-action').children('.divTableHeading').width();
                $(this).closest('.index-table.fixed-action').children('.divTableHeading').children('.divTableHead:last-child').css("left", -(innertabWidth - tabWidth - 4) + $(this).scrollLeft());
                $(this).closest('.index-table.fixed-action').children('.divTableBody').find('.divTableCell:nth-last-child(1)').css("left", -(innertabWidth - tabWidth - 4) + $(this).scrollLeft());
                $(this).find('.usermaster-loadmore').css("left", $(this).scrollLeft());
            });
            $('.index-table .divTableBodys').bind('scroll', function(e) {
                $(this).closest('.index-table').children('.divTableHeading').css("left", -$(this).scrollLeft());
                $(this).closest('.index-table').children('.divTableHeading').children('.divTableHead:nth-child(1)').css("left", $(this).scrollLeft());
                $(this).find('.divTableCell:nth-child(1)').css("left", $(this).scrollLeft())
            });
            $('#assetVersionModal').on('hidden.bs.modal', function() {
                $rootScope.assetVersionDetails = {}
            })
            $('.Gtable-scrollY').perfectScrollbar({
                suppressScrollXY: !0
            });
            $('.isbn-inner-details-scroll').perfectScrollbar({
                suppressScrollY: !0
            });
            $('.scrollY').perfectScrollbar({
                suppressScrollY: !0
            });
            $('.scrollX').perfectScrollbar({
                suppressScrollX: !0
            });
            $('.value-select').perfectScrollbar({
                suppressScrollX: !0
            })
        }, 500)
    }
    $rootScope.testScroll();
    $scope.allVersionDownloadTrans = function(assetverlist, assetDetail) {
        var downloadtemplateData = {};
        downloadtemplateData["[file-name]"] = assetverlist.fileName;
        downloadtemplateData["[format-name]"] = assetDetail.assetType;
        downloadtemplateData["[file-size]"] = assetverlist.size;
        downloadtemplateData["[isbn]"] = assetDetail.isbn;
        downloadtemplateData["[title]"] = assetDetail.title;
        downloadtemplateData["[author]"] = assetDetail.author;
        downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
        downloadtemplateData["[download-type]"] = "HTTP";
        $http({
            method: 'POST',
            url: '/addTransactionDetails',
            data: {
                productIDValue: assetDetail.isbn,
                formatName: assetDetail.assetType,
                size: assetverlist.size,
                formatId: assetDetail.formatId,
                title: assetDetail.title,
                loggeduser: $rootScope.loggedUser.userId,
                transactionStatus: "15",
                transactionType: "FILE_DOWNLOAD",
                templateData: downloadtemplateData,
                ipAddress: $window.sessionStorage.userIP
            }
        }).then(function(response) {});
        $http({
            method: 'POST',
            url: '/saveShelfTransaction',
            data: {
                isbn: assetDetail.isbn,
                formatId: assetDetail.formatId,
                loggedUser: $rootScope.loggedUser.userId,
                action: "FILE_DOWNLOAD",
                shelfType: "Asset_Book"
            }
        }).then(function(response) {})
    }
    $scope.CheckboxCount = function($event, result) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            $scope.checkedCount++
        } else if (action === 'remove') {
            $scope.checkedCount--
        }
    };
    $scope.showdownloadModal = !1;
    $rootScope.downloadButton = !0;
    $scope.fileList1 = [];
    $rootScope.showSuccessHTTPRequest = !1;
    $scope.downloadfile = function() {
        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
        myEl.removeAttr('data-target', "#download-file");
        myEl.removeAttr('data-toggle', "modal");
        $('#download-file').modal('toggle');
        $scope.downloadTransactionList = [];
        var dbTransactionList = [];
        var shelfList = [];
        angular.forEach($rootScope.downloadUploadList, function(key, value) {
            $scope.downloadTransactionList.push({
                "isbn": key[0].isbn,
                "formatId": key[0].formatId,
                "title": key[0].title
            })
            var downloadtemplateData = {};
            downloadtemplateData["[format-name]"] = key[0].format;
            downloadtemplateData["[file-size]"] = key[0].formatSize;
            downloadtemplateData["[isbn]"] = key[0].isbn;
            downloadtemplateData["[title]"] = key[0].title;
            downloadtemplateData["[author]"] = key[0].author;
            downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
            downloadtemplateData["[download-type]"] = "HTTP";
            dbTransactionList.push({
                "isbn": key[0].isbn,
                "formatName": key[0].format,
                "formatSize": key[0].formatSize,
                "formatId": key[0].formatId,
                "title": key[0].title,
                "userId": $rootScope.loggedUser.userId,
                "transactionType": "FILE_DOWNLOAD",
                "transactionStatus": "15",
                "templateDataList": downloadtemplateData,
                "ipAddress": $window.sessionStorage.userIP
            })
            shelfList.push({
                "isbn": key[0].isbn,
                "formatId": key[0].formatId,
                "loggedUser": $rootScope.loggedUser.userId,
                "action": "FILE_DOWNLOAD",
                "shelfType": "Asset_Book"
            })
        });
        var uniqueId = $rootScope.loggedUser.userId + new Date().getTime();
        $http({
            method: 'POST',
            url: '/saveDownloadData',
            data: {
                downloadData: $scope.downloadTransactionList,
                versionId: "",
                uniqueId: uniqueId,
                userId: $rootScope.loggedUser.userId,
                downloadStatus: "14",
                downloadType: "Asset Download"
            }
        }).then(function(response) {
            $rootScope.getDownloadNotification();
            $rootScope.showSuccessHTTPRequest = !0;
            setTimeout(function() {
                $rootScope.showSuccessHTTPRequest = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        });
        $http({
            method: 'POST',
            url: '/addBulkTransactionDetails',
            data: {
                transactionList: dbTransactionList
            }
        }).then(function(response) {});
        $http({
            method: 'POST',
            url: '/saveBulkShelfTransaction',
            data: {
                shelfList: shelfList
            }
        }).then(function(response) {});
        angular.forEach($rootScope.downloadUploadList, function(key, value) {})
    };
    $rootScope.showSuccessFTPRequest = !1;
    $scope.FTPdownloadfile = function() {
        $scope.emailList = [];
        if ($scope.expiryTime == null || $scope.expiryTime == "" || $scope.expiryTime == undefined) {
            $scope.download_share_email_valid_show = !0;
            $scope.download_share_email_valid_error = "Please enter valid till"
        } else {
            $scope.download_share_email_valid_show = !1;
            $scope.download_share_email_valid_error = ""
        }
        if (sharecheckbox.checked || ($scope.shareemail != null && $scope.shareemail != "")) {
            $scope.download_share_email_show = !1;
            $scope.download_share_email_error = "";
            $scope.share_email_pattern_error = !1;
            $scope.share_email_pattern_error_msg = "";
            if (sharecheckbox.checked) {
                $scope.emailList.push($rootScope.loggedUser.emailId)
            }
            if ($scope.shareemail != null && $scope.shareemail != "") {
                if ($scope.shareemail.indexOf(',') != -1) {
                    var em = $scope.shareemail.split(',');
                    var valid = !0;
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    for (var i = 0; i < em.length; i++) {
                        if (em[i] == "" || !regex.test(em[i])) {
                            valid = !1
                        } else {
                            $scope.emailList.push(em[i])
                        }
                    }
                    if ($scope.emailList.length == 0) {
                        $scope.share_email_pattern_error = !0;
                        $scope.share_email_pattern_error_msg = "Please enter valid email"
                    }
                } else {
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if ($scope.shareemail == "" || !regex.test($scope.shareemail)) {
                        $scope.share_email_pattern_error = !0;
                        $scope.share_email_pattern_error_msg = "Please enter valid email"
                    } else {
                        $scope.emailList.push($scope.shareemail)
                    }
                }
            }
            if ($scope.download_share_email_valid_show || $scope.download_share_email_show || $scope.share_email_pattern_error) {
                var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                myEl.removeAttr('data-target', "#download-file");
                myEl.removeAttr('data-toggle', "modal")
            } else {
                var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                myEl.attr('data-target', "#download-file");
                myEl.attr('data-toggle', "modal");
                $('#download-file').modal('toggle');
                var expiryTime = $scope.expiryTime;
                $scope.shareemail = "";
                $scope.expiryTime = "";
                document.getElementById("sharecheckbox").checked = !1;
                $scope.showshare = !1;
                var dbTransactionList = [];
                $scope.downloadTransactionList = [];
                var shelfList = [];
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    $scope.downloadTransactionList.push({
                        "isbn": key[0].isbn,
                        "formatId": key[0].formatId,
                        "title": key[0].title
                    })
                    var downloadtemplateData = {};
                    downloadtemplateData["[format-name]"] = key[0].format;
                    downloadtemplateData["[file-size]"] = key[0].formatSize;
                    downloadtemplateData["[isbn]"] = key[0].isbn;
                    downloadtemplateData["[title]"] = key[0].title;
                    downloadtemplateData["[author]"] = key[0].author;
                    downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                    downloadtemplateData["[download-type]"] = "FTP";
                    dbTransactionList.push({
                        "isbn": key[0].isbn,
                        "formatName": key[0].format,
                        "formatSize": key[0].formatSize,
                        "formatId": key[0].formatId,
                        "title": key[0].title,
                        "userId": $rootScope.loggedUser.userId,
                        "transactionType": "FILE_DOWNLOAD",
                        "transactionStatus": "15",
                        "templateDataList": downloadtemplateData,
                        "ipAddress": $window.sessionStorage.userIP
                    })
                    shelfList.push({
                        "isbn": key[0].isbn,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId,
                        "action": "FILE_DOWNLOAD",
                        "shelfType": "Asset_Book"
                    })
                });
                var uniqueId = $rootScope.loggedUser.userId + new Date().getTime();
                $http({
                    method: 'POST',
                    url: '/saveDownloadData',
                    data: {
                        downloadData: $scope.downloadTransactionList,
                        ftpEmailds: $scope.emailList,
                        expiryDays: expiryTime,
                        versionId: "",
                        uniqueId: uniqueId,
                        userId: $rootScope.loggedUser.userId,
                        downloadStatus: "14",
                        downloadType: "FTP"
                    }
                }).then(function(response) {
                    $rootScope.getDownloadNotification()
                });
                $http({
                    method: 'POST',
                    url: '/addBulkTransactionDetails',
                    data: {
                        transactionList: dbTransactionList
                    }
                }).then(function(response) {});
                $http({
                    method: 'POST',
                    url: '/saveBulkShelfTransaction',
                    data: {
                        shelfList: shelfList
                    }
                }).then(function(response) {});
                angular.forEach($rootScope.downloadUploadList, function(key, value) {});
                $rootScope.showSuccessFTPRequest = !0;
                setTimeout(function() {
                    $rootScope.showSuccessFTPRequest = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        } else {
            $scope.download_share_email_show = !0;
            $scope.download_share_email_error = "Please enter valid emailid or select the checkbox"
        }
    };
    $scope.sharedownloadFile1 = function() {
        $scope.singleshowshare = !0;
        document.getElementById("sharecheckbox1").checked = !0
    };
    $scope.singleFTPdownloadfile = function() {
        $scope.emailList1 = [];
        if ($scope.singleexpiryTime == null || $scope.singleexpiryTime == "" || $scope.singleexpiryTime == undefined) {
            $scope.download_share_email_valid_single_show = !0;
            $scope.download_share_email_valid_single_error = "Please enter valid till"
        } else {
            $scope.download_share_email_valid_single_show = !1;
            $scope.download_share_email_valid_signle_error = ""
        }
        if (sharecheckbox1.checked || ($scope.singleshareemail != null && $scope.singleshareemail != "")) {
            $scope.download_share_email_single_show = !1;
            $scope.download_share_email_single_error = "";
            $scope.share_email_pattern_single_error = !1;
            $scope.share_email_pattern_error_single_msg = "";
            if (sharecheckbox1.checked) {
                $scope.emailList1.push($rootScope.loggedUser.emailId)
            }
            if ($scope.singleshareemail != null && $scope.singleshareemail != "") {
                if ($scope.singleshareemail.indexOf(',') != -1) {
                    var em = $scope.singleshareemail.split(',');
                    var valid = !0;
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    for (var i = 0; i < em.length; i++) {
                        if (em[i] == "" || !regex.test(em[i])) {
                            valid = !1
                        } else {
                            $scope.emailList1.push(em[i])
                        }
                    }
                    if ($scope.emailList1.length == 0) {
                        $scope.share_email_pattern_single_error = !0;
                        $scope.share_email_pattern_error_single_msg = "Please enter valid email"
                    }
                } else {
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if ($scope.singleshareemail == "" || !regex.test($scope.singleshareemail)) {
                        $scope.share_email_pattern_single_error = !0;
                        $scope.share_email_pattern_error_single_msg = "Please enter valid email"
                    } else {
                        $scope.emailList1.push($scope.singleshareemail)
                    }
                }
            }
            if ($scope.download_share_email_valid_single_show || $scope.download_share_email_single_show || $scope.share_email_pattern_single_error) {
                var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                myEl.removeAttr('data-target', "#single-download");
                myEl.removeAttr('data-toggle', "modal")
            } else {
                var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                myEl.attr('data-target', "#single-download");
                myEl.attr('data-toggle', "modal");
                $('#single-download').modal('toggle');
                var expiryTime = $scope.singleexpiryTime;
                $scope.singleshareemail = "";
                $scope.singleexpiryTime = "";
                document.getElementById("sharecheckbox1").checked = !1;
                $scope.singleshowshare = !1;
                var dbTransactionList = [];
                $scope.downloadTransactionList1 = [];
                var shelfList = [];
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    $scope.downloadTransactionList1.push({
                        "isbn": key[0].isbn,
                        "formatId": key[0].formatId,
                        "title": key[0].title
                    })
                    var downloadtemplateData = {};
                    downloadtemplateData["[format-name]"] = key[0].format;
                    downloadtemplateData["[file-size]"] = key[0].formatSize;
                    downloadtemplateData["[isbn]"] = key[0].isbn;
                    downloadtemplateData["[title]"] = key[0].title;
                    downloadtemplateData["[author]"] = key[0].author;
                    downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                    downloadtemplateData["[download-type]"] = "FTP";
                    dbTransactionList.push({
                        "isbn": key[0].isbn,
                        "formatName": key[0].format,
                        "formatSize": key[0].formatSize,
                        "formatId": key[0].formatId,
                        "title": key[0].title,
                        "userId": $rootScope.loggedUser.userId,
                        "transactionType": "FILE_DOWNLOAD",
                        "transactionStatus": "15",
                        "templateDataList": downloadtemplateData,
                        "ipAddress": $window.sessionStorage.userIP
                    })
                    shelfList.push({
                        "isbn": key[0].isbn,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId,
                        "action": "FILE_DOWNLOAD",
                        "shelfType": "Asset_Book"
                    })
                });
                var uniqueId = $rootScope.loggedUser.userId + new Date().getTime();
                $http({
                    method: 'POST',
                    url: '/saveDownloadData',
                    data: {
                        downloadData: $scope.downloadTransactionList1,
                        ftpEmailds: $scope.emailList1,
                        expiryDays: expiryTime,
                        versionId: "",
                        uniqueId: uniqueId,
                        userId: $rootScope.loggedUser.userId,
                        downloadStatus: "14",
                        downloadType: "FTP"
                    }
                }).then(function(response) {
                    $scope.getDownloadNotification()
                });
                $http({
                    method: 'POST',
                    url: '/addBulkTransactionDetails',
                    data: {
                        transactionList: dbTransactionList
                    }
                }).then(function(response) {});
                $http({
                    method: 'POST',
                    url: '/saveBulkShelfTransaction',
                    data: {
                        shelfList: shelfList
                    }
                }).then(function(response) {});
                angular.forEach($rootScope.downloadUploadList, function(key, value) {});
                $rootScope.showSuccessFTPRequest = !0;
                setTimeout(function() {
                    $rootScope.showSuccessFTPRequest = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        } else {
            $scope.download_share_email_single_show = !0;
            $scope.download_share_email_single_error = "Please enter valid emailid or select the checkbox"
        }
    };
    $scope.downloadfileModal = function() {
        $scope.downloadListCount = Object.keys($rootScope.downloadUploadList).length;
        $scope.fileList = [];
        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
        myEl.removeAttr('data-target', "#download-file");
        myEl.removeAttr('data-toggle', "modal");
        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
        myEl.removeAttr('data-target', "#single-download");
        myEl.removeAttr('data-toggle', "modal");
        $rootScope.downloadBtnShow = !1;
        $rootScope.downloadButton = !0;
        $scope.downloadFormatErr = !1;
        var flag = !1;
        var length = Object.keys($rootScope.downloadUploadList).length;
        document.getElementById("tempbucketerr").innerHTML = "";
        var loggedUserDownloadFormatIdList = $filter('filter')($rootScope.loggedUser.permissionGroup.asset, function(data) {
            return data.permission == 'DOWNLOAD'
        })[0].format;
        if (length == '1') {
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                if (!$scope.downloadFormatErr) {
                    if (undefined == key[0].format && null == key[0].format) {
                        document.getElementById("tempbucketerr").innerHTML = "Please select the asset with formats"
                    } else {
                        if (!loggedUserDownloadFormatIdList.includes(key[0].formatId)) {
                            $scope.downloadFormatErr = !0
                        } else {
                            flag = !0
                        }
                    }
                }
            });
            if (!$scope.downloadFormatErr && flag) {
                var formatName = "";
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    formatName = key[0].format;
                    var filepath = key[0].isbn + "/" + key[0].formatId + "/";
                    $scope.fileList.push(filepath)
                });
                angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                $http({
                    method: 'POST',
                    url: '/getFormat',
                    data: {
                        formatName: formatName
                    }
                }).then(function(response) {
                    $scope.gridformat = response.data.data.formatId;
                    if (response.data.data.singleFile) {
                        $http({
                            method: 'POST',
                            url: '/download',
                            data: {
                                filePathList: $scope.fileList,
                                loggeduser: $rootScope.loggedUser.userId
                            }
                        }).then(function(response) {
                            $scope.fileList = [];
                            if (response.data.code == '200') {
                                var myEl = angular.element(document.querySelector('#singledownload'));
                                myEl.removeAttr('data-toggle', "modal");
                                myEl.removeAttr('data-target', "#single-download");
                                $('#single-download').modal('toggle');
                                $scope.modalFormatName = response.data.data.formatName;
                                $scope.modalFileName = response.data.data.filename;
                                $scope.modalUrl = response.data.data.url
                            }
                        })
                    } else {
                        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                        myEl.attr('data-target', "#download-file");
                        myEl.attr('data-toggle', "modal");
                        $('#download-file').modal('toggle');
                        var size = 0;
                        angular.forEach($rootScope.downloadUploadList, function(key, value) {
                            if (undefined != key[0].format && null != key[0].format) {
                                var filepath = key[0].isbn + "/" + key[0].format + "/";
                                $scope.fileList.push(filepath);
                                size = parseInt(size) + parseInt(key[0].formatSize)
                            }
                        });
                        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                        if (size > 1073741824) {
                            $rootScope.downloadButton = !1;
                            $rootScope.downloadFTPButton = !0
                        } else if (size < 1073741824) {
                            $rootScope.downloadButton = !0;
                            $rootScope.downloadFTPButton = !0
                        }
                    }
                })
            } else {
                document.getElementById("tempbucketerr").innerHTML = "Few file(s) are not eligible for download. Please uncheck the file(s) and proceed further."
            }
        } else if (length > '100') {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to download"
        } else if (length > '1') {
            var count = 0;
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                count++;
                if (!loggedUserDownloadFormatIdList.includes(key[0].formatId)) {
                    $scope.downloadFormatErr = !0;
                    document.getElementById("tempbucketerr").innerHTML = "Few file(s) are not eligible for download. Please uncheck the file(s) and proceed further."
                } else {
                    flag = !0
                }
            });
            if (!$scope.downloadFormatErr && flag && count != 0) {
                var myEl = angular.element(document.querySelector('#downloadfileModalId'));
                myEl.attr('data-target', "#download-file");
                myEl.attr('data-toggle', "modal");
                var size = 0;
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    if (undefined != key[0].format && null != key[0].format) {
                        var filepath = key[0].isbn + "/" + key[0].format + "/";
                        $scope.fileList.push(filepath);
                        size = parseInt(size) + parseInt(key[0].formatSize)
                    }
                });
                angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                if (size > 1073741824) {
                    $rootScope.downloadButton = !1;
                    $rootScope.downloadFTPButton = !0
                } else if (size < 1073741824) {
                    $rootScope.downloadButton = !0;
                    $rootScope.downloadFTPButton = !0
                }
            }
        } else {
            var myEl = angular.element(document.querySelector('#downloadfileModalId'));
            myEl.removeAttr('data-toggle', "modal");
            myEl.removeAttr('data-target', "#download-file");
            $rootScope.shelfDownErr = !0;
            document.getElementById("tempbucketerr").innerHTML = "Please select the asset to download."
        }
    };
    $scope.commonUpload = function() {
        document.getElementById("tempbucketerr").innerHTML = "";
        if (Object.keys($rootScope.downloadUploadList).length >= 11) {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 10 records to upload"
        } else {
            window.location.assign("/#upload")
            $rootScope.uploadpagename = 'Asset'
        }
    }
    $scope.listDownload = function($event, result, format) {
        var list = [];
        var flag = !1;
        $scope.singledownloadFormatErr = !1;
        list.push(result.ISBN13 + "/" + format.formatId);
        var loggedUserDownloadFormatIdList = $filter('filter')($rootScope.loggedUser.permissionGroup.asset, function(data) {
            return data.permission == 'DOWNLOAD'
        })[0].format;
        if (!loggedUserDownloadFormatIdList.includes(format.formatId)) {
            $scope.singledownloadFormatErr = !0;
            setTimeout(function() {
                $scope.singledownloadFormatErr = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        } else {
            flag = !0
        }
        if (flag) {
            $http({
                method: 'POST',
                url: '/getFormat',
                data: {
                    formatName: format.formatName
                }
            }).then(function(response) {
                var isSingle = response.data.data.singleFile;
                if (isSingle) {
                    $http({
                        method: 'POST',
                        url: '/download',
                        data: {
                            filePathList: list,
                            loggeduser: $rootScope.loggedUser.userId
                        }
                    }).then(function(response) {
                        if (response.data.code == '200') {
                            var myEl = angular.element(document.querySelector('#singledownload'));
                            myEl.removeAttr('data-toggle', "modal");
                            myEl.removeAttr('data-target', "#single-download-grid");
                            $('#single-download-grid').modal('toggle');
                            $scope.modalFormatName = response.data.data.formatName;
                            $scope.modalFileName = response.data.data.filename;
                            $scope.modalUrl = response.data.data.url
                        }
                    })
                } else {
                    var downloadTransactionList = [];
                    downloadTransactionList.push({
                        "isbn": result.ISBN13,
                        "formatId": format.formatId
                    })
                    var uniqueId = $rootScope.loggedUser.userId + new Date().getTime();
                    if (format.size > 1073741824) {
                        $http({
                            method: 'POST',
                            url: '/saveDownloadData',
                            data: {
                                downloadData: downloadTransactionList,
                                versionId: "",
                                uniqueId: uniqueId,
                                userId: $rootScope.loggedUser.userId,
                                downloadStatus: "14",
                                downloadType: "FTP"
                            }
                        }).then(function(response) {
                            $rootScope.getDownloadNotification()
                        })
                    } else if (format.size < 1073741824) {
                        $http({
                            method: 'POST',
                            url: '/saveDownloadData',
                            data: {
                                downloadData: downloadTransactionList,
                                versionId: "",
                                uniqueId: uniqueId,
                                userId: $rootScope.loggedUser.userId,
                                downloadStatus: "14",
                                downloadType: "Asset Download"
                            }
                        }).then(function(response) {
                            $rootScope.getDownloadNotification();
                            $rootScope.showSuccessHTTPRequest = !0;
                            setTimeout(function() {
                                $rootScope.showSuccessHTTPRequest = !1;
                                $scope.$apply()
                            }, $rootScope.alertTimeoutInterval)
                        })
                    }
                }
                var downloadtemplateData = {};
                downloadtemplateData["[format-name]"] = format.formatName;
                downloadtemplateData["[file-size]"] = format.size;
                downloadtemplateData["[isbn]"] = result.ISBN13;
                downloadtemplateData["[title]"] = result.Title;
                downloadtemplateData["[author]"] = result.author;
                downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                if (format.size < 1073741824 || isSingle)
                    downloadtemplateData["[download-type]"] = "HTTP";
                else downloadtemplateData["[download-type]"] = "FTP";
                $http({
                    method: 'POST',
                    url: '/addTransactionDetails',
                    data: {
                        productIDValue: result.ISBN13,
                        formatName: format.formatName,
                        size: format.size,
                        formatId: format.formatId,
                        title: result.Title,
                        loggeduser: $rootScope.loggedUser.userId,
                        transactionStatus: "15",
                        transactionType: "FILE_DOWNLOAD",
                        templateData: downloadtemplateData,
                        ipAddress: $window.sessionStorage.userIP
                    }
                }).then(function(response) {});
                $http({
                    method: 'POST',
                    url: '/saveShelfTransaction',
                    data: {
                        isbn: result.ISBN13,
                        formatId: format.formatId,
                        loggedUser: $rootScope.loggedUser.userId,
                        action: "FILE_DOWNLOAD",
                        shelfType: "Asset_Book"
                    }
                }).then(function(response) {})
            })
        }
    }
    $scope.openUrl = function(modalUrl) {
        window.open(modalUrl, "_blank");
        var shelfList = [];
        var dbTransactionList = [];
        angular.forEach($rootScope.downloadUploadList, function(key, value) {
            var downloadtemplateData = {};
            downloadtemplateData["[format-name]"] = key[0].format;
            downloadtemplateData["[file-size]"] = key[0].formatSize;
            downloadtemplateData["[isbn]"] = key[0].isbn;
            downloadtemplateData["[title]"] = key[0].title;
            downloadtemplateData["[author]"] = key[0].author;
            downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
            downloadtemplateData["[download-type]"] = "HTTP";
            dbTransactionList.push({
                "isbn": key[0].isbn,
                "formatName": key[0].format,
                "formatSize": key[0].formatSize,
                "formatId": key[0].formatId,
                "title": key[0].title,
                "userId": $rootScope.loggedUser.userId,
                "transactionType": "FILE_DOWNLOAD",
                "transactionStatus": "15",
                "templateDataList": downloadtemplateData,
                "ipAddress": $window.sessionStorage.userIP
            })
            shelfList.push({
                "isbn": key[0].isbn,
                "formatId": key[0].formatId,
                "loggedUser": $rootScope.loggedUser.userId,
                "action": "FILE_DOWNLOAD",
                "shelfType": "Asset_Book"
            })
        });
        $http({
            method: 'POST',
            url: '/addBulkTransactionDetails',
            data: {
                transactionList: dbTransactionList
            }
        }).then(function(response) {});
        $http({
            method: 'POST',
            url: '/saveBulkShelfTransaction',
            data: {
                shelfList: shelfList
            }
        }).then(function(response) {})
    };
    $scope.updateBucketCheckbox = function(check) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'remove') {}
    };
    $scope.sharedownloadFile = function() {
        $scope.showshare = !0;
        document.getElementById("sharecheckbox").checked = !0
    };
    $scope.cancelDownloadpopup = function() {
        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
        myEl.removeAttr('data-toggle', "modal");
        myEl.removeAttr('data-target', "#download-file");
        $scope.shareemail = "";
        $scope.expiryTime = "";
        document.getElementById("sharecheckbox").checked = !1;
        $scope.showshare = !1;
        $scope.download_share_email_show = !1;
        $scope.download_share_email_error = "";
        $scope.download_share_email_valid_show = !1;
        $scope.download_share_email_valid_error = "";
        $scope.share_email_pattern_error = !1;
        $scope.share_email_pattern_error_msg = ""
    };
    $scope.senddownloadFile = function() {
        $scope.emailList = [];
        if ($scope.expiryTime == null || $scope.expiryTime == "" || $scope.expiryTime == undefined) {
            $scope.download_share_email_valid_show = !0;
            $scope.download_share_email_valid_error = "Please enter valid till"
        } else {
            $scope.download_share_email_valid_show = !1;
            $scope.download_share_email_valid_error = ""
        }
        if (sharecheckbox.checked || ($scope.shareemail != null && $scope.shareemail != "")) {
            $scope.download_share_email_show = !1;
            $scope.download_share_email_error = "";
            $scope.share_email_pattern_error = !1;
            $scope.share_email_pattern_error_msg = "";
            if (sharecheckbox.checked) {
                $scope.emailList.push($rootScope.loggedUser.emailId)
            }
            if ($scope.shareemail != null && $scope.shareemail != "") {
                if ($scope.shareemail.indexOf(',') != -1) {
                    var em = $scope.shareemail.split(',');
                    var valid = !0;
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    for (var i = 0; i < em.length; i++) {
                        if (em[i] == "" || !regex.test(em[i])) {
                            valid = !1
                        } else {
                            $scope.emailList.push(em[i])
                        }
                    }
                    if ($scope.emailList.length == 0) {
                        $scope.share_email_pattern_error = !0;
                        $scope.share_email_pattern_error_msg = "Please enter valid email"
                    } else {}
                } else {
                    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if ($scope.shareemail == "" || !regex.test($scope.shareemail)) {
                        $scope.share_email_pattern_error = !0;
                        $scope.share_email_pattern_error_msg = "Please enter valid email"
                    } else {
                        $scope.emailList.push($scope.shareemail)
                    }
                }
            }
            if ($scope.download_share_email_valid_show || $scope.download_share_email_show || $scope.share_email_pattern_error) {
                var myEl = angular.element(document.querySelector('#sendDownload'));
                myEl.removeAttr('data-dismiss', "modal")
            } else {
                var myEl = angular.element(document.querySelector('#sendDownload'));
                myEl.attr('data-dismiss', "modal");
                var expiryTime = $scope.expiryTime;
                $scope.shareemail = "";
                $scope.expiryTime = "";
                document.getElementById("sharecheckbox").checked = !1;
                $scope.showshare = !1;
                var size = 0;
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    if (undefined != key[0].format && null != key[0].format) {
                        size = parseInt(size) + parseInt(key[0].formatSize)
                    }
                });
                if (size > 4294967296) {
                    angular.forEach($scope.emailList, function(email) {
                        $http({
                            method: 'POST',
                            url: '/getPermissionGroup',
                            data: {
                                id: "DownloadShare"
                            }
                        }).then(function successCallback(response) {
                            if (response.data.code == '200') {
                                $http({
                                    method: 'POST',
                                    url: '/createUser',
                                    data: {
                                        emailId: email,
                                        permissionGroupId: response.data.data.config.permissionGroupId
                                    }
                                }).then(function successCallback(response) {
                                    $http({
                                        method: 'POST',
                                        url: '/sharedownloadtool',
                                        data: {
                                            emailId: email,
                                            userExpirydays: expiryTime
                                        }
                                    }).then(function(response) {
                                        if (response.data.code == '200') {
                                            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                                                var downloadtemplateData = {};
                                                downloadtemplateData["[format-name]"] = key[0].format;
                                                downloadtemplateData["[file-size]"] = key[0].formatSize;
                                                downloadtemplateData["[isbn]"] = key[0].isbn;
                                                downloadtemplateData["[title]"] = key[0].title;
                                                downloadtemplateData["[author]"] = key[0].author;
                                                downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                                                $http({
                                                    method: 'POST',
                                                    url: '/addTransactionDetails',
                                                    data: {
                                                        productIDValue: key[0].isbn,
                                                        formatName: key[0].format,
                                                        size: key[0].formatSize,
                                                        formatId: key[0].formatId,
                                                        loggeduser: response.data.data,
                                                        transactionStatus: "20",
                                                        transactionType: "FILE_SHARE",
                                                        templateData: downloadtemplateData
                                                    }
                                                }).then(function(response) {})
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    })
                } else {
                    if ($scope.emailList.length > 0) {
                        $http({
                            method: 'POST',
                            url: '/download',
                            data: {
                                filePathList: $scope.fileList,
                                loggeduser: $rootScope.loggedUser.userId
                            }
                        }).then(function(response) {
                            $scope.fileList = [];
                            if (response.data.code == '200') {
                                angular.forEach($scope.emailList, function(email) {
                                    $http({
                                        method: 'POST',
                                        url: '/sharedownloadtool',
                                        data: {
                                            downloadUrl: response.data.data.url,
                                            emailId: email,
                                            userExpirydays: expiryTime,
                                        }
                                    }).then(function(response) {
                                        if (response.data.code == '200') {
                                            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                                                var downloadtemplateData = {};
                                                downloadtemplateData["[format-name]"] = key[0].format;
                                                downloadtemplateData["[file-size]"] = key[0].formatSize;
                                                downloadtemplateData["[isbn]"] = key[0].isbn;
                                                downloadtemplateData["[title]"] = key[0].title;
                                                downloadtemplateData["[author]"] = key[0].author;
                                                downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                                                $http({
                                                    method: 'POST',
                                                    url: '/addTransactionDetails',
                                                    data: {
                                                        productIDValue: key[0].isbn,
                                                        formatName: key[0].format,
                                                        size: key[0].formatSize,
                                                        formatId: key[0].formatId,
                                                        loggeduser: $rootScope.loggedUser.userId,
                                                        transactionStatus: "20",
                                                        transactionType: "FILE_SHARE",
                                                        templateData: downloadtemplateData
                                                    }
                                                }).then(function(response) {})
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    }
                };
                $rootScope.showSuccessShareMail = !0;
                setTimeout(function() {
                    $rootScope.showSuccessShareMail = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        } else {
            $scope.download_share_email_show = !0;
            $scope.download_share_email_error = "Please enter valid emailid or select the checkbox"
        }
    };
    $scope.removeShareEmailError = function() {
        $scope.download_share_email_show = !1;
        $scope.download_share_email_error = "";
        $scope.download_share_email_single_show = !1;
        $scope.download_share_email_single_error = ""
    };
    $scope.removeShareEmailLinkError = function() {
        $scope.download_share_email_valid_show = !1;
        $scope.download_share_email_valid_single_show = !1
    };
    var timeout = null;
    $scope.tempcartdisable = !1;
    $scope.uncheckItem = function($event, isbn, title, author, format, formatSize, formatId) {
        $scope.tempcartdisable = !0;
        document.getElementById("tempbucketerr").innerHTML = "";
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === "add") {
            if (formatId != null) {
                $scope.temp = [];
                $scope.temp.push({
                    "isbn": isbn,
                    "title": title,
                    "author": author,
                    "format": format,
                    "formatSize": formatSize,
                    "formatId": formatId
                });
                $rootScope.downloadUploadList[isbn + "_" + formatId] = $scope.temp
            } else {
                $scope.temp = [];
                $scope.temp.push({
                    "isbn": isbn,
                    "title": title,
                    "author": author
                });
                $rootScope.downloadUploadList[isbn] = $scope.temp
            }
            localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList))
        } else if (action === 'remove') {
            if (null != formatId) {
                var unIbsn = isbn;
                var formatIdVal = formatId;
                delete $rootScope.downloadUploadList[unIbsn + "_" + formatIdVal]
            } else {
                delete $rootScope.downloadUploadList[isbn]
            }
            localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList))
        }
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.tempcartdisable = !1
        }, 500)
    };
    $rootScope.getApprovalFormats = function() {
        $http({
            method: 'GET',
            url: '/getApprovalFormats',
            data: null
        }).then(function(response) {
            $rootScope.getApprovalFormatList = response.data.data
        })
    }
    $rootScope.checkFormatApprovalAccess = function(format) {
        $scope.approvalAccess = !1;
        angular.forEach($rootScope.getApprovalFormatList, function(formatList) {
            if (formatList.formatId == format.formatId) {
                $scope.approvalAccess = !0
            }
        })
    }
    $rootScope.checkIndividualFormatApprovalAccess = function(format) {
        var flag = !1;
        angular.forEach($rootScope.getApprovalFormatList, function(formatList) {
            if (formatList.formatId == format.formatId) {
                flag = !0
            }
        });
        return flag
    }
    $scope.updateAssetApproval = function() {
        var isbn = $scope.assetstatus[0].isbn;
        var formatId = $scope.assetstatus[0].formatId;
        var formatStatus = $scope.assetstatus[0].formatStatus;
        $http({
            method: 'POST',
            url: '/updateAssetStatus',
            data: {
                productIDValue: isbn,
                formatId: formatId,
                formatStatus: formatStatus
            }
        }).then(function(response) {
            $scope.assetApprovalStatus = ""
            if (response.status == '200') {
                var downloadtemplateData = {};
                downloadtemplateData["[format-name]"] = $scope.assetstatus[0].formatName;
                downloadtemplateData["[file-size]"] = $scope.assetstatus[0].formatSize;
                downloadtemplateData["[isbn]"] = isbn;
                downloadtemplateData["[title]"] = $scope.assetstatus[0].title;
                downloadtemplateData["[author]"] = $scope.assetstatus[0].author;
                downloadtemplateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                $http({
                    method: 'POST',
                    url: '/addTransactionDetails',
                    data: {
                        productIDValue: isbn,
                        formatName: $scope.assetstatus[0].formatName,
                        size: $scope.assetstatus[0].formatSize,
                        formatId: formatId,
                        title: $scope.assetstatus[0].title,
                        loggeduser: $rootScope.loggedUser.userId,
                        transactionStatus: formatStatus,
                        transactionType: "FORMAT",
                        templateData: downloadtemplateData
                    }
                }).then(function(response) {
                    var result = $filter('filter')($scope.searchResult, function(d) {
                        return (d.ISBN13 === isbn)
                    })[0];
                    var result1 = $filter('filter')(result.Format, function(d) {
                        return (d.formatId === formatId)
                    })[0];
                    result1.formatStatus = formatStatus
                })
            }
        })
    };
    $scope.setApprovalStatus = function(event, result, format, formatStatus) {
        $scope.assetstatus = [];
        $scope.assetstatus.push({
            isbn: result.ISBN13,
            formatName: format.formatName,
            formatId: format.formatId,
            formatStatus: formatStatus,
            formatSize: format.size,
            title: result.Title,
            author: result.Author
        })
    };
    $scope.cancelAssetStatus = function() {
        $scope.assetApprovalStatus = "";
        var myEl = angular.element(document.querySelector('#downloadfileModalId'));
        myEl.removeAttr('data-toggle', "modal");
        myEl.removeAttr('data-target', "#single-download");
        $scope.singleshareemail = "";
        $scope.singleexpiryTime = "";
        document.getElementById("sharecheckbox1").checked = !1;
        $scope.singleshowshare = !1;
        $scope.download_share_email_single_show = !1;
        $scope.download_share_email_single_error = "";
        $scope.download_share_email_valid_single_show = !1;
        $scope.download_share_email_valid_single_error = "";
        $scope.share_email_pattern_single_error = !1;
        $scope.share_email_pattern_error_single_msg = ""
    };
    $scope.getAssetLoadmore = function(chk) {
        if ($rootScope.searchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            $rootScope.reqId = new Date().getTime();
            $rootScope.assetButtonText = "";
            var searchflag = $rootScope.searchFlag;
            var searchname = $rootScope.searchName;
            if (chk === "ASSET")
                $rootScope.viewSearch(searchflag, searchname, $rootScope.searchResult.length, !1, !1, !0);
            else $rootScope.viewSearch('G', '', $rootScope.searchResult.length, !1, !1, !0);
            setTimeout(function() {
                $rootScope.assetButtonText = "Load More"
            }, 500)
        }
    }
    $rootScope.downloadNotification = function() {
        angular.element(".download-up").removeClass("flashit")
    }
    $rootScope.downloadcompleted = !1;
    $rootScope.notificationList = [];
    $rootScope.pendingDownloadIdList = [];
    $rootScope.getDownloadNotification = function() {
        angular.element(".download-up").removeClass('flashit')
        $http({
            method: 'POST',
            url: '/getDownloadNotification'
        }).then(function(response) {
            $rootScope.notificationList = response.data.data;
            $rootScope.pendingDownloadRequest = false;
            if (response.data.data != null)
                var tempIdList = $filter('filter')(response.data.data, function(item) {
                    return item.downloadStatus == "14"
                }).map(function(item) {
                    return item.uniqueId
                });
            $.each($rootScope.pendingDownloadIdList, function(index, data) {
                if (!tempIdList.includes(data)) {
                    angular.element("#getDownloadNotification").addClass('open');
                    angular.element(".download-up").addClass("flashit");
                    return !1
                }
            })
            $rootScope.pendingDownloadIdList = tempIdList;
            $rootScope.dnCount = 0;
            if (null != $rootScope.notificationList) {
                angular.forEach($rootScope.notificationList, function(DNval) {
                    if (DNval.downloadLink == null) {
                        $rootScope.callAgain = !0
                    } else {
                        $rootScope.dnCount++
                    }
                })
            }
        })
    }
    $interval(function() {
        if ($rootScope.callAgain)
            $rootScope.getDownloadNotification()
    }, 1000 * 5);
    $rootScope.imAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.imgAllSelected = checkFlg;
        var filteredList = $filter('filter')($rootScope.imprintListGlobal, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.imprintGlobal), 'gi');
            return data.match(re)
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(imp) {
                document.getElementById(imp + "_Global").checked = !0;
                if ($rootScope.GlobalImprintList.indexOf(imp) == -1)
                    $rootScope.GlobalImprintList.push(imp)
            })
        } else {
            angular.forEach(filteredList, function(imp) {
                document.getElementById(imp + "_Global").checked = !1;
                if ($rootScope.GlobalImprintList.indexOf(imp) != -1)
                    $rootScope.GlobalImprintList = $filter('filter')($rootScope.GlobalImprintList, function(data) {
                        return data != imp
                    })
            })
        }
        $rootScope.searchFlag = 'I';
        $rootScope.resetAdvancedFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    $rootScope.mtAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.mtAllSelected = checkFlg;
        var filteredList = $filter('filter')($rootScope.othersList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.allMetadataGlobal), 'gi');
            return data.description.match(re)
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(val) {
                document.getElementById(val.description + "_Global").checked = !0;
                if ($rootScope.GlobalOthersCodeList.indexOf(val.code) == -1) {
                    $rootScope.GlobalOthersList.push(val);
                    $rootScope.GlobalOthersCodeList.push(val.code)
                }
            })
        } else {
            angular.forEach(filteredList, function(val) {
                document.getElementById(val.description + "_Global").checked = !1;
                if ($rootScope.GlobalOthersCodeList.indexOf(val.code) != -1)
                    $rootScope.GlobalOthersList = $filter('filter')($rootScope.GlobalOthersList, function(data) {
                        return data.code != val.code
                    });
                $rootScope.GlobalOthersCodeList = $filter('filter')($rootScope.GlobalOthersCodeList, function(data) {
                    return data != val.code
                })
            })
        }
        $rootScope.searchFlag = 'I';
        $rootScope.resetAdvancedFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
    }
    $rootScope.pCateoryAllSelect = function(chkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.pCateoryAllSelected = chkFlg;
        $rootScope.searchEnable = !0;
        if (chkFlg)
            $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "SELECT");
        else $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "UNSELECT");
        $rootScope.getSelectedSearchFilterProductCategories();
        setTimeout(function() {
            $rootScope.searchFlag = 'F';
            $rootScope.resetGlobalFilters();
            if ($rootScope.refreshSearch()) {
                $rootScope.commonAllFilter()
            }
        }, 100);
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.gridCheckCount = 0;
    $rootScope.regionAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.regionAllSelected = checkFlg;
        $rootScope.accountFilterList = [];
        $rootScope.selectedAccounts = [];
        var filteredAccountList = $rootScope.accountList;
        if (checkFlg) {
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("region_" + acl.accountId).checked = !0;
                $rootScope.accountFilterList.push(acl);
                $rootScope.selectedAccounts.push(acl.accountId)
            })
        } else {
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("region_" + acl.accountId).checked = !1
            })
        }
        $rootScope.getImprints();
        setTimeout(function() {
            $rootScope.getSelectedSearchFilterProductCategories();
            $rootScope.searchFlag = 'F';
            $rootScope.resetGlobalFilters();
            $rootScope.searchEnable = !0;
            if ($rootScope.refreshSearch()) {
                $rootScope.commonAllFilter()
            }
        }, 200);
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.imprintAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.imAllSelected = checkFlg;
        var filteredList = $filter('filter')($rootScope.imprintList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.imprintFilter), 'gi');
            return data.match(re)
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(imp) {
                document.getElementById("imprint_" + imp).checked = !0;
                if ($rootScope.imprintFilterList.indexOf(imp) == -1)
                    $rootScope.imprintFilterList.push(imp)
            })
        } else {
            angular.forEach(filteredList, function(imp) {
                document.getElementById("imprint_" + imp).checked = !1;
                $rootScope.imprintFilterList = $filter('filter')($rootScope.imprintFilterList, function(data) {
                    return data != imp
                })
            })
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.formatAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.formatCheckAll = checkFlg;
        var filteredList = $filter('filter')($rootScope.formatList, function(data) {
            var re = new RegExp(RegExp.escape($rootScope.search.formatFilter), 'gi');
            return data.formatName.match(re)
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(format) {
                format.sChecked = !0;
                if ($filter('filter')($rootScope.formatFilterList, function(data) {
                        return data.formatId == format.formatId
                    }).length == 0) {
                    $rootScope.formatFilterList.push(format)
                }
                if ($filter('filter')($rootScope.formatCodeList, function(data) {
                        return data == format.formatId
                    }).length == 0)
                    $rootScope.formatCodeList.push(format.formatId)
            })
        } else {
            angular.forEach(filteredList, function(format) {
                format.sChecked = !1;
                if ($filter('filter')($rootScope.formatFilterList, function(data) {
                        return data.formatId == format.formatId
                    }).length != 0)
                    $rootScope.formatFilterList = $filter('filter')($rootScope.formatFilterList, function(data) {
                        return data.formatId != format.formatId
                    });
                if ($rootScope.formatCodeList.indexOf(format.formatId) != -1)
                    $rootScope.formatCodeList = $filter('filter')($rootScope.formatCodeList, function(data) {
                        return data != format.formatId
                    })
            })
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.otherAllSelect = function($event, checkFlg) {
        $rootScope.reqId = new Date().getTime();
        $rootScope.search.otherAllSelect = checkFlg;
        $rootScope.othersFilterList = [];
        $rootScope.advancedOthersFilterList = [];
        if (checkFlg) {
            angular.forEach($rootScope.othersList, function(other) {
                document.getElementById("other_" + other.description).checked = !0;
                $rootScope.othersFilterList.push(other);
                $rootScope.advancedOthersFilterList.push(other.code)
            })
        } else {
            angular.forEach($rootScope.othersList, function(other) {
                document.getElementById("other_" + other.description).checked = !1
            })
        }
        $rootScope.searchFlag = 'F';
        $rootScope.resetGlobalFilters();
        $rootScope.searchEnable = !0;
        if ($rootScope.refreshSearch()) {
            $rootScope.commonAllFilter()
        }
        var container = document.getElementById("searchdataheight");
        container.scrollTop = 0
    }
    $rootScope.checkAccess = function(tabName) {
        try {
            var index = $scope.loggedUser.permissionGroup.administrator.indexOf(tabName);
            return index == -1 ? !1 : !0
        } catch (e) {}
    }
    $rootScope.checkAccessRoleMatser = function(tabName) {
        var returnFlg = !1;
        var roleId = $rootScope.loggedUser.permissionGroup.roleId;
        angular.forEach($rootScope.roleList, function(role) {
            if (role.roleId === roleId) {
                angular.forEach(role.module, function(module) {
                    angular.forEach(module.submodule, function(val) {
                        if (val.accessId == "ROLE") {
                            var index = val.activityAccess.indexOf(tabName);
                            if (index != -1)
                                returnFlg = !0;
                            return
                        }
                    })
                })
            }
        });
        return returnFlg
    }
    $rootScope.checkUserMappedRole = function(loggedRoleId) {
        var returnFlg = !1;
        if ($rootScope.permisssionGroupList != undefined) {
            returnFlg = $rootScope.permisssionGroupList.every(function(itm) {
                return itm.roleId != loggedRoleId
            })
        }
        return !returnFlg
    }
    $rootScope.openDefaultAdminTab = function() {
        try {
            if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('USER'))
                return "USER";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('ROLE'))
                return "ROLE";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('BUSINESS_RULE'))
                return "BUSINESS_RULE";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('METADATA'))
                return "METADATA";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('PRODUCT_CATEGORY'))
                return "PRODUCT_CATEGORY";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('ACCOUNT'))
                return "ACCOUNT";
            else if (-1 != $scope.loggedUser.permissionGroup.administrator.indexOf('PARTNER'))
                return "PARTNER";
            else {
                $scope.chkAdmin = !0;
                return "DEFAULT"
            }
        } catch (e) {
            return "DEFAULT"
        }
    }
    $rootScope.checkAccessBucket = function(tabName) {
        var returnFlg = !1;
        var roleId = $rootScope.loggedUser.permissionGroup.roleId;
        angular.forEach($rootScope.roleList, function(role) {
            if (role.roleId === roleId) {
                angular.forEach(role.module, function(module) {
                    angular.forEach($rootScope.moduleList, function(moduleAssets) {
                        if (moduleAssets.moduleName == "Assets") {
                            if (module.moduleId == moduleAssets.moduleId) {
                                angular.forEach(module.submodule, function(val) {
                                    var index = val.activityAccess.indexOf(tabName);
                                    if (index != -1)
                                        returnFlg = !0;
                                    return
                                })
                            }
                        }
                    })
                })
            }
        });
        return returnFlg
    }
    $rootScope.checkAccessRoleRelated = function(tabName) {
        var returnFlg = !1;
        var roleId = $rootScope.loggedUser.permissionGroup.roleId;
        angular.forEach($rootScope.roleList, function(role) {
            if (role.roleId === roleId) {
                angular.forEach(role.module, function(module) {
                    angular.forEach(module.submodule, function(val) {
                        if (val.accessId == "USER") {
                            var index = val.activityAccess.indexOf(tabName);
                            if (index != -1)
                                returnFlg = !0;
                            return
                        }
                    })
                })
            }
        });
        return returnFlg
    }
    $rootScope.checkReportAccessPermission = function(moduleId, accessId) {
        var returnFlg = !1;
        if ($rootScope.loggedUser != null) {
            var roleId = $rootScope.loggedUser.permissionGroup.roleId;
            angular.forEach($rootScope.roleList, function(role) {
                if (role.roleId === roleId) {
                    angular.forEach(role.module, function(module) {
                        if (module.moduleId === moduleId) {
                            angular.forEach(module.submodule, function(val) {
                                if (val.accessId == accessId) {
                                    var index = val.accessId.indexOf(accessId);
                                    if (index != -1)
                                        returnFlg = !0;
                                    return
                                }
                            })
                        }
                    })
                }
            })
        }
        return returnFlg
    }
    $rootScope.checkGlobalSearchAccess = function() {
        var returnFlg = !1;
        if ($rootScope.loggedUser != null) {
            var roleId = $rootScope.loggedUser.permissionGroup.roleId;
            angular.forEach($rootScope.roleList, function(role) {
                if (role.roleId === roleId) {
                    var moduleId = "";
                    var accessId = "";
                    var tabName = "";
                    if ($location.$$url.contains('metadata')) {
                        moduleId = "MOD00003";
                        accessId = "META_ACTIVITY";
                        tabName = "VIEW"
                    } else {
                        moduleId = "MOD00002";
                        accessId = "ASSET_ACTIVITY";
                        tabName = "VIEW"
                    }
                    angular.forEach(role.module, function(module) {
                        if (module.moduleId === moduleId) {
                            angular.forEach(module.submodule, function(val) {
                                if (val.accessId == accessId) {
                                    var index = val.activityAccess.indexOf(tabName);
                                    if (index != -1)
                                        returnFlg = !0;
                                    return
                                }
                            })
                        }
                    })
                }
            })
        }
        return returnFlg
    }
    $rootScope.isEditItem = [];
    $rootScope.isEditDuplicate = [];
    $rootScope.isEditMetaItem = [];
    $rootScope.isEditMetaDuplicate = [];
    $rootScope.renameClickView = !0;
    $rootScope.renameLabel = function(spaces) {
        return encodeURI(spaces)
    }
    $scope.changeRename = function(indexVal, name, check, pageName) {
        var changeNames = encodeURI(name);
        angular.element(".menu-side-edit-input").css("display", "none");
        angular.element(".sub-menu-title-label").css("display", "block")
        angular.element(".menu-action").removeClass("menu-action-list");
        if (pageName == 'Metadata') {
            $rootScope.existingSearchName = name;
            if (check) {
                document.getElementById("mdatarename_" + changeNames).style.display = "block"
                document.getElementById("searchmdataname_" + changeNames).style.display = "none"
                document.getElementById("iconmdata_" + changeNames).style.display = "none"
            }
        } else {
            $rootScope.existingSearchName = name;
            if (check) {
                document.getElementById("rename_" + changeNames).style.display = "block"
                document.getElementById("searchname_" + changeNames).style.display = "none"
                document.getElementById("icon_" + changeNames).style.display = "none"
            }
        }
    };
    $scope.duplicate = function($index, name, pageName) {
        angular.element(".menu-action").removeClass("menu-action-list");
        $rootScope.existingSearchName = name;
        if (pageName == 'Metadata') {
            $rootScope.isEditMetaDuplicate[$index] = !0;
            $rootScope.isEditMetaItem[$index] = !1;
            angular.forEach($rootScope.isEditMetaDuplicate, function(key, val) {
                if (val != $index)
                    $rootScope.isEditMetaDuplicate[val] = !1
            })
        } else {
            $rootScope.isEditDuplicate[$index] = !0;
            $rootScope.isEditItem[$index] = !1;
            angular.forEach($rootScope.isEditDuplicate, function(key, val) {
                if (val != $index)
                    $rootScope.isEditDuplicate[val] = !1
            })
        }
    };
    $rootScope.selectedCount = 0;
    $rootScope.formatMap = {};
    if (localStorage.getItem('selectedData') != "" && localStorage.getItem('selectedData') != null) {
        $rootScope.formatMap = JSON.parse(localStorage.getItem("selectedData"));
        $rootScope.selectedCount = Object.keys($rootScope.formatMap).length;
        angular.forEach($rootScope.formatMap, function(key, value) {
            $timeout(function() {
                if (key[0].formatId != null && key[0].formatId != undefined) {
                    if (document.getElementById("bucket_" + key[0].isbn + "_" + key[0].formatId))
                        document.getElementById("bucket_" + key[0].isbn + "_" + key[0].formatId).checked = !0
                } else {
                    if (document.getElementById("bucket_" + key[0].isbn + "_"))
                        document.getElementById("bucket_" + key[0].isbn + "_").checked = !0
                }
            }, 300)
        });
        $rootScope.downloadUploadList = angular.copy($rootScope.formatMap);
        localStorage.setItem('popup', angular.element($(".collection-drawer-mixin")).addClass('show-alert-view'))
    }
    $scope.showCheckBox = function() {
        angular.forEach($rootScope.formatMap, function(key, value) {
            $timeout(function() {
                if (null != key[0].formatId) {
                    if (document.getElementById("checkbox2_" + key[0].isbn))
                        document.getElementById("checkbox2_" + key[0].isbn).checked = !0;
                    if (document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId))
                        document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId).checked = !0
                } else {
                    if (document.getElementById("checkbox2_" + key[0].isbn))
                        document.getElementById("checkbox2_" + key[0].isbn).checked = !0
                }
            }, 100)
        })
    };
    $scope.updateFormatCheckBox = function($event, result, format, accountName) {
        $scope.downloadFormatErr = !1;
        $rootScope.hideAction = !1;
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        var checkbox = $event.target;
        $scope.reportSent = !0;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            angular.element($(".collection-drawer-mixin")).addClass('show-alert-view');
            document.getElementById("checkbox2_" + result.ISBN13).checked = !0;
            $scope.temp = [];
            $scope.temp.push({
                "isbn": result.ISBN13,
                "title": result.Title,
                "author": result.Author,
                "format": format.formatName,
                "formatSize": format.size,
                "formatId": format.formatId,
                "countryOfPublication": accountName,
                "ebookType":result['Ebook Type'],
                "discount":result.Discount
            });
            $rootScope.formatMap[result.ISBN13 + "_" + format.formatId] = $scope.temp;
            $rootScope.selectedCount++
                $timeout(function() {
                    document.getElementById("bucket_" + result.ISBN13 + "_" + format.formatId).checked = !0
                }, 300);
            localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
            $timeout(function() {
                $scope.reportSent = !1
            }, 300)
        } else if (action === 'remove') {
            $scope.reportSent = !1;
            var formatStatus = !1;
            angular.forEach(result.Format, function(value) {
                if (document.getElementById("format_" + result.ISBN13 + "_" + value.formatId).checked) {
                    formatStatus = !1
                } else {
                    formatStatus = !0
                }
            });
            document.getElementById("checkbox2_" + result.ISBN13).checked = !1;
            delete $rootScope.formatMap[result.ISBN13 + "_" + format.formatId];
            $rootScope.selectedCount--;
            localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
            document.getElementById("format_" + result.ISBN13 + "_" + format.formatId).checked = !1;
            document.getElementById("checkAll").checked = !1;
            if ($rootScope.selectedCount === 0) {
                document.getElementById("checkbox2_" + result.ISBN13).checked = !1;
                document.getElementById("format_" + result.ISBN13 + "_" + format.formatId).checked = !1;
                angular.element($(".collection-drawer-mixin")).removeClass('show-alert-view')
            }
        }
        $rootScope.downloadUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.formatMap, function(key, value) {
                if (undefined != key[0].formatId && null != key[0].formatId) {
                    if (document.getElementById("bucket_" + key[0].isbn + "_" + key[0].formatId).checked) {
                        $rootScope.downloadUploadList[key[0].isbn + "_" + key[0].formatId] = key
                    }
                } else {
                    if (document.getElementById("bucket_" + key[0].isbn + "_").checked) {
                        $rootScope.downloadUploadList[key[0].isbn] = key
                    }
                }
            });
            localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList));
            $rootScope.hideAction = !0
        }, 300)
    };
    $scope.updateCheckBox = function($event, result, format, accountName) {
        $rootScope.hideAction = !1;
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        var checkbox = $event.target;
        $scope.reportSent = !0;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            if (format != undefined && format.length > 0 && format.length != undefined) {
                angular.forEach(format, function(value) {
                    $scope.temp = [];
                    $scope.temp.push({
                        "isbn": result.ISBN13,
                        "title": result.Title,
                        "author": result.Author,
                        "format": value.formatName,
                        "formatSize": value.size,
                        "formatId": value.formatId,
                        "countryOfPublication": accountName,
                        "ebookType":result['Ebook Type'],
                        "discount":result.Discount
                    });
                    $rootScope.formatMap[result.ISBN13 + "_" + value.formatId] = $scope.temp;
                    localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                    $timeout(function() {
                        document.getElementById("format_" + result.ISBN13 + "_" + value.formatId).checked = !0;
                        document.getElementById("bucket_" + result.ISBN13 + "_" + value.formatId).checked = !0
                    }, 200)
                })
            } else {
                $scope.temp = [];
                $scope.temp.push({
                    "isbn": result.ISBN13,
                    "title": result.Title,
                    "author": result.Author,
                    "countryOfPublication": accountName,
                    "ebookType":result['Ebook Type'],
                    "discount":result.Discount
                });
                $timeout(function() {
                    document.getElementById("bucket_" + result.ISBN13 + "_").checked = !0
                }, 200);
                $rootScope.formatMap[result.ISBN13] = $scope.temp;
                localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap))
            }
            $timeout(function() {
                $scope.reportSent = !1
            }, $rootScope.alertTimeoutInterval)
        } else if (action === 'remove') {
            if (null != format && format != undefined && '' != format && format.length > 0) {
                angular.forEach(format, function(value) {
                    delete $rootScope.formatMap[result.ISBN13 + "_" + value.formatId];
                    localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                    document.getElementById("format_" + result.ISBN13 + "_" + value.formatId).checked = !1
                })
            } else {
                delete $rootScope.formatMap[result.ISBN13];
                localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap))
            }
            $scope.reportSent = !1
        }
        document.getElementById("checkAll").checked = !1;
        $rootScope.downloadUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.formatMap, function(key, value) {
                if (undefined != key[0].formatId && null != key[0].formatId) {
                    if (document.getElementById("bucket_" + key[0].isbn + "_" + key[0].formatId).checked) {
                        $rootScope.downloadUploadList[key[0].isbn + "_" + key[0].formatId] = key
                    }
                } else {
                    if (document.getElementById("bucket_" + key[0].isbn + "_").checked) {
                        $rootScope.downloadUploadList[key[0].isbn] = key
                    }
                }
            });
            localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList));
            $rootScope.hideAction = !0
        }, 300);
        $rootScope.selectedCount = 0;
        angular.forEach($rootScope.formatMap, function(key, value) {
            $rootScope.selectedCount++
        })
    };
    if (Object.keys($rootScope.downloadUploadList).length > 0) {
        $rootScope.hideAction = !0
    } else {
        $rootScope.hideAction = !1
    }
    $scope.updateAllCheckBox = function($event, result, accountName) {
        $rootScope.hideAction = !1;
        $rootScope.downloadUploadList = {};
        $scope.reportSent = !1;
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        var isbnId;
        var title;
        var authoer;
        if (action === 'add') {
            angular.forEach(result, function(value) {
                if (value.isActive) {
                    if (null != value.Format && undefined != value.Format && "" != value.Format) {
                        if (value.Format.length > 0 && value.Format.length != undefined && value.Format.length != null) {
                            angular.forEach(value.Format, function(val) {
                                console.log(JSON.stringify(value['Country Of Publication']))
                                document.getElementById("format_" + value.ISBN13 + "_" + val.formatId).checked = !0;
                                $scope.temp = [];
                                $scope.temp.push({
                                    "isbn": value.ISBN13,
                                    "title": value.Title,
                                    "author": value.Author,
                                    "format": val.formatName,
                                    "formatSize": val.size,
                                    "formatId": val.formatId,
                                    "countryOfPublication": value['Country Of Publication'],
                                    "ebookType":value['Ebook Type'],
                                    "discount":value.Discount
                                });
                                $rootScope.formatMap[value.ISBN13 + "_" + val.formatId] = $scope.temp;
                                localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                                $timeout(function() {
                                    document.getElementById("bucket_" + value.ISBN13 + "_" + val.formatId).checked = !0
                                }, 200)
                            })
                        }
                    } else {
                        $scope.temp = [];
                        $scope.temp.push({
                            "isbn": value.ISBN13,
                            "title": value.Title,
                            "author": value.Author,
                            "countryOfPublication": value['Country Of Publication'],
                            "ebookType":value['Ebook Type'],
                            "discount":value.Discount
                        });
                        $rootScope.formatMap[value.ISBN13] = $scope.temp;
                        localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                        $timeout(function() {
                            document.getElementById("bucket_" + value.ISBN13 + "_").checked = !0
                        }, 200)
                    }
                    document.getElementById("checkbox2_" + value.ISBN13).checked = !0
                }
            });
            $timeout(function() {
                $scope.reportSent = !1
            }, $rootScope.alertTimeoutInterval)
        } else if (action === 'remove') {
            angular.forEach(result, function(value) {
                if (value.isActive) {
                    angular.forEach(value.Format, function(val) {
                        document.getElementById("format_" + value.ISBN13 + "_" + val.formatId).checked = !1
                    });
                    document.getElementById("checkbox2_" + value.ISBN13).checked = !1
                }
            });
            $rootScope.formatMap = {};
            localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap))
        }
        $rootScope.downloadUploadList = {};
        $timeout(function() {
            angular.forEach($rootScope.formatMap, function(key, value) {
                if (undefined != key[0].formatId && null != key[0].formatId) {
                    if (document.getElementById("bucket_" + key[0].isbn + "_" + key[0].formatId).checked) {
                        $rootScope.downloadUploadList[key[0].isbn + "_" + key[0].formatId] = key
                    }
                } else {
                    if (document.getElementById("bucket_" + key[0].isbn + "_").checked) {
                        $rootScope.downloadUploadList[key[0].isbn] = key
                    }
                }
            });
            localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList));
            $rootScope.hideAction = !0
        }, 300);
        $rootScope.selectedCount = 0;
        angular.forEach($rootScope.formatMap, function(key, value) {
            $rootScope.selectedCount++
        })
    }
    var timeout = null;
    $scope.tempcartdisable = !1;
    $scope.removeItem = function(itemIndex, isbn, format, formatSize, formatId) {
        $scope.tempcartdisable = !0;
        var temp = {};
        $scope.downloadFormatErr = !1;
        temp = $rootScope.formatMap;
        var formatStatus = !1;
        if (null != formatId) {
            if (null != document.getElementById("format_" + isbn + "_" + formatId))
                document.getElementById("format_" + isbn + "_" + formatId).checked = !1;
            angular.forEach(temp, function(key, value) {
                if (key[0].isbn === isbn) {
                    if (null != document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId))
                        if (document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId).checked) {
                            formatStatus = !1
                        } else {
                            formatStatus = !0
                        }
                }
            });
            if (formatStatus) {
                delete $rootScope.formatMap[isbn + "_" + formatId];
                localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                document.getElementById("checkbox2_" + isbn).checked = !1;
                $rootScope.selectedCount--
            } else {
                delete $rootScope.formatMap[isbn + "_" + formatId];
                localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
                $rootScope.selectedCount--
            }
        } else {
            delete $rootScope.formatMap[isbn];
            if (null != document.getElementById("checkbox2_" + isbn))
                document.getElementById("checkbox2_" + isbn).checked = !1;
            localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
            $rootScope.selectedCount--
        }
        document.getElementById("checkAll").checked = !1;
        if ($rootScope.selectedCount == 0) {
            angular.element($(".collection-drawer-mixin")).removeClass('show-alert-view');
            $rootScope.formatMap = {};
            localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap))
        }
        if (undefined != formatId && null != formatId) {
            delete $rootScope.downloadUploadList[isbn + "_" + formatId]
        } else {
            delete $rootScope.downloadUploadList[isbn]
        }
        localStorage.setItem("checkedAssetData", JSON.stringify($rootScope.downloadUploadList));
        document.getElementById("tempbucketerr").innerHTML = "";
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.tempcartdisable = !1
        }, 500)
    }
    $scope.ClearBucket = function() {
        angular.forEach($rootScope.formatMap, function(key, value) {
            if (null != key[0].formatId) {
                if (document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId) != undefined)
                    document.getElementById("format_" + key[0].isbn + "_" + key[0].formatId).checked = !1
            }
            if (document.getElementById("checkbox2_" + key[0].isbn) != undefined)
                document.getElementById("checkbox2_" + key[0].isbn).checked = !1
        });
        angular.element($(".collection-drawer-mixin")).removeClass('show-alert-view');
        document.getElementById("checkAll").checked = !1;
        $rootScope.formatMap = {};
        localStorage.setItem("selectedData", JSON.stringify($rootScope.formatMap));
        $rootScope.selectedCount = 0;
        $rootScope.downloadUploadList = {};
        localStorage.removeItem("checkedAssetData");
        $rootScope.isbnValues = [];
        localStorage.getItem('isbnValues', $rootScope.isbnValues);
        $scope.selfReset()
    };
    $scope.show = function(event) {
        ModalService.showModal({
            templateUrl: 'modal.html',
            controller: "ModalController"
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {
                if (result == 'Yes') {
                    $scope.disabled = !0
                } else if (result == 'No') {
                    $scope.disabled = !1
                }
            })
        })
    };
    $('#changePasswordModal').on('shown.bs.modal', function() {
        $(this).find('input:first').focus()
    });
    $('#changePasswordModal').find('button:first').on('keydown', function(e) {
        if ($("this:focus") && (e.which == 9)) {
            e.preventDefault();
            $('#changePasswordModal').find('input:first').focus()
        }
    });
    $rootScope.toggleChangePasswordModal = function() {
        $scope.changePasswordForm.currentPassword = null;
        $scope.changePasswordForm.newPassword = null;
        $scope.changePasswordForm.confirmPassword = null;
        $scope.ChangePasswordForm.$setPristine();
        $scope.ChangePasswordForm.$setUntouched();
        $('#changePasswordModal').modal('toggle')
    }
    $rootScope.changePassword = function(ChangePasswordForm) {
        if ($scope.changePasswordForm.newPassword != $scope.changePasswordForm.confirmPassword) {
            $scope.changePasswordForm.error = !0;
            $scope.changePasswordForm.errorMsg = "UPDATEPASSWORD.ERROR.PASSWORD_NOTMATCH";
            $scope.changePasswordForm.newPassword = null;
            $scope.changePasswordForm.confirmPassword = null;
            $scope.ChangePasswordForm.$setUntouched();
            $('#changePasswordModal').find('input:first').focus()
        } else {
            $scope.changePasswordForm.loading = !0;
            $http({
                method: 'POST',
                url: '/changepassword',
                data: {
                    emailId: $scope.loggedUser.emailId,
                    oldPassword: $scope.changePasswordForm.currentPassword,
                    password: $scope.changePasswordForm.newPassword,
                    confirmPassword: $scope.changePasswordForm.confirmPassword
                }
            }).then(function(response) {
                $scope.changePasswordForm.loading = !1;
                if (response.data.code == '200') {
                    var status = response.data.status;
                    $scope.changePasswordForm.success = !0;
                    setTimeout(function() {
                        $scope.changePasswordForm.success = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval);
                    $rootScope.toggleChangePasswordModal()
                } else {
                    var status = response.data.status;
                    $scope.changePasswordForm.error = !0;
                    $scope.changePasswordForm.errorMsg = status;
                    $scope.changePasswordForm.currentPassword = "";
                    $scope.changePasswordForm.newPassword = "";
                    $scope.changePasswordForm.confirmPassword = "";
                    $scope.ChangePasswordForm.$setUntouched();
                    setTimeout(function() {
                        angular.element('#currentPassword').trigger('focus')
                    }, 10)
                }
            }, function errorCallback(error) {})
        }
    };
    $rootScope.saveUserName = function(EnterUserNameForm) {
        if (EnterUserNameForm.$valid) {
            $scope.enterUserNameForm.loading = !0;
            $http({
                method: 'POST',
                url: '/saveprofile',
                data: {
                    firstName: $scope.enterUserNameForm.userFirstName + " " + $scope.enterUserNameForm.userLastName,
                    firstNameFirst: $scope.enterUserNameForm.userFirstName,
                    firstNameLast: $scope.enterUserNameForm.userLastName,
                    contactNo: $scope.loggedUser.contactNo,
                    address: $scope.loggedUser.address,
                    city: $scope.loggedUser.city,
                    zipCode: $scope.loggedUser.zipCode
                }
            }).then(function(response) {
                $scope.enterUserNameForm.loading = !1;
                if (response.data.code == '200') {
                    $('#enterUserNameModal').modal('toggle');
                    $rootScope.accountUser()
                } else {
                    var status = response.data.status;
                    $scope.enterUserNameForm.error = !0;
                    $scope.enterUserNameForm.errorMsg = status
                }
            }, function errorCallback(error) {})
        }
    };
    $rootScope.getLoggedUserPermissionGroup = function() {
        $http({
            method: 'GET',
            url: '/permissionGroup?id=' + $rootScope.loggedUser.permissionGroupId
        }).then(function successCallback(response) {
            $rootScope.loggedUser.permissionGroup = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getRoles = function() {
        $http({
            method: 'GET',
            url: '/getRoles'
        }).then(function successCallback(response) {
            $rootScope.roleList = response.data.data;
            if ($rootScope.loggedUser != undefined && $rootScope.loggedUser != null) {
                $rootScope.loggedUserRole = $filter('filter')(response.data.data, function(data) {
                    return (data.roleId == $rootScope.loggedUser.permissionGroup.roleId)
                })[0];
                $rootScope.userRoleList = $filter('filter')(response.data.data, function(role) {
                    return (role.level == null || ($rootScope.loggedUserRole.level == null ? false : role.level >= $rootScope.loggedUserRole.level))
                })
            }
        }, function errorCallback(response) {})
    };
    $rootScope.getShelf = function() {
        try {
            $http({
                method: 'GET',
                url: '/getShelfDetails',
                data: {}
            }).then(function successCallback(response) {
                $rootScope.saveshelfList = response.data.data;
                $rootScope.saveshelfCountLength = response.data.data;
                $rootScope.shelfCount = $rootScope.saveshelfList.length;
                angular.forEach($rootScope.saveshelfList, function(val) {
                    $rootScope.shelfdetailsList = val.shelfdetails
                })
            }, function errorCallback(response) {})
        } catch (e) {}
    };
    $rootScope.getAccounts = function() {
        $rootScope.accountMetadataMappingFieldValueAvailableList = [];
        $http({
            method: 'GET',
            url: '/getAccounts'
        }).then(function successCallback(response) {
            $rootScope.accountList = response.data.data.accountList;
            $rootScope.accountMetadataMappedFieldName = response.data.data.metadataMappedFieldName;
            $rootScope.accountMetadataMappedFieldLabel = response.data.data.metadataMappedFieldLabel;
            $rootScope.accountMetadataMappingFieldValueList = response.data.data.metadataMappingFieldValueList;
            angular.forEach(response.data.data.metadataMappingFieldValueAvailableList, function(mappingValue) {
                if (mappingValue != null && mappingValue != 'null' && mappingValue.trim() != '')
                    $rootScope.accountMetadataMappingFieldValueAvailableList.push({
                        "name": mappingValue,
                        selected: !1
                    })
            })
        }, function errorCallback(response) {})
    };
    $rootScope.getImprints = function() {
        var accountArray = $rootScope.selectedAccounts;
        $http({
            method: 'GET',
            url: '/getImprintListForAccounts/' + accountArray.toString()
        }).then(function successCallback(response) {
            $rootScope.imprintList = response.data.data;
            var temp = $.grep($rootScope.imprintFilterList, function(element) {
                return $.inArray(element, $rootScope.imprintList) !== -1
            });
            $rootScope.imprintFilterList = temp;
            var filteredList = $filter('filter')($rootScope.imprintList, function(data) {
                var re = new RegExp(RegExp.escape($rootScope.search.imprintFilter), 'gi');
                return data.match(re)
            });
            if (document.getElementById("imAllSelected") != null && document.getElementById("imAllSelected") != undefined) {
                if (filteredList.length === $rootScope.imprintFilterList.length && filteredList.length != 0) {
                    document.getElementById("imAllSelected").checked = !0;
                    $rootScope.search.imAllSelected = !0
                } else {
                    document.getElementById("imAllSelected").checked = !1;
                    $rootScope.search.imAllSelected = !1
                }
            }
        }, function errorCallback(response) {})
    };
    $rootScope.getGlobalImprints = function() {
        var accountArray = [];
        $http({
            method: 'GET',
            url: '/getImprintListForAccounts/' + accountArray.toString()
        }).then(function successCallback(response) {
            $rootScope.imprintListGlobal = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getMetadataTypes = function() {
        $http({
            method: 'GET',
            url: '/getMetadataTypesFromConfig'
        }).then(function successCallback(response) {
            $rootScope.metadataTypeList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getProductCategories = function() {
        $http({
            method: 'GET',
            url: '/getProductCategories/' + $rootScope.selectedAccounts.toString()
        }).then(function successCallback(response) {
            $rootScope.productCategoryList = response.data.data.productCategoryList;
            $rootScope.productCatMappedField = response.data.data.mappedMetadataFieldName
        }, function errorCallback(response) {})
    };
    $rootScope.getProductCategoriesForSearch = function() {
        $rootScope.selectedProductCategoryArraySearch = [];
        if ($rootScope.productCategoryTreeList != undefined && $rootScope.productCategoryTreeList.length > 0) {
            $rootScope.getSelectedSearchFilterProductCategories()
        }
        $http({
            method: 'GET',
            url: '/getProductCategories/' + $rootScope.selectedAccounts.toString()
        }).then(function successCallback(response) {
            $rootScope.productCategorySearchList = response.data.data.productCategoryList;
            $rootScope.pCategoryFilterList = [];
            $rootScope.productCategoryTree = $rootScope.getNestedChildren(response.data.data.productCategoryList, null);
            $rootScope.productCategoryTreeList = angular.copy($rootScope.productCategoryTree);
            $rootScope.traverseSearchTree($rootScope.productCategoryTreeList, "POPULATEFOREDIT");
            if (document.getElementById("pCateoryAllSelected") != null && document.getElementById("pCateoryAllSelected") != undefined) {
                if ($rootScope.pCategoryFilterList.length === response.data.data.productCategoryList.length && response.data.data.productCategoryList.length != 0)
                    document.getElementById("pCateoryAllSelected").checked = !0;
                else document.getElementById("pCateoryAllSelected").checked = !1
            }
        }, function errorCallback(response) {})
    };
    $rootScope.getMetadataGroups = function() {
        $http({
            method: 'GET',
            url: '/getMetadataGroups'
        }).then(function successCallback(response) {
            $rootScope.metadataGroupList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getcMetadataGroups = function() {
        $http({
            method: 'GET',
            url: '/getcMetadataGroups'
        }).then(function successCallback(response) {
            $rootScope.cmetadataGroupList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getPartnerTypes = function() {
        $http({
            method: 'GET',
            url: '/getPartnerTypes'
        }).then(function successCallback(response) {
            $rootScope.partnerTypeList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getApplications = function() {
        $http({
            method: 'GET',
            url: '/getApplications'
        }).then(function successCallback(response) {
            $rootScope.applicationList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getModules = function() {
        $http({
            method: 'GET',
            url: '/getModules'
        }).then(function successCallback(response) {
            $rootScope.moduleList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getFormats = function() {
        $rootScope.loggedUserViewFormatIdList = [];
        $rootScope.loggedUserUploadFormatIdList = [];
        $rootScope.loggedUserDownloadFormatIdList = [];
        $rootScope.loggedUserShareFormatIdList = [];
        $rootScope.loggedUserDeleteFormatIdList = [];
        $rootScope.loggedUserApplicationList = [];
        $rootScope.viewFormatList = [];
        $rootScope.uploadFormatList = [];
        $rootScope.downloadFormatList = [];
        $rootScope.shareFormatList = [];
        $rootScope.deleteFormatList = [];
        $http({
            method: 'GET',
            url: '/getFormats'
        }).then(function successCallback(response) {
            $rootScope.formatList = response.data.data;
            if ($rootScope.loggedUser != undefined && $rootScope.loggedUser != null) {
                angular.forEach($rootScope.loggedUser.permissionGroup.asset, function(itm) {
                    if (itm.permission == 'VIEW') {
                        $rootScope.loggedUserViewFormatIdList = itm.format;
                        $rootScope.viewFormatList = $filter('filter')(response.data.data, function(data) {
                            return (itm.format.indexOf(data.formatId) > -1)
                        })
                    } else if (itm.permission == 'UPLOAD') {
                        $rootScope.loggedUserUploadFormatIdList = itm.format;
                        $rootScope.uploadFormatList = $filter('filter')(response.data.data, function(data) {
                            return (itm.format.indexOf(data.formatId) > -1)
                        })
                    } else if (itm.permission == 'DOWNLOAD') {
                        $rootScope.loggedUserDownloadFormatIdList = itm.format;
                        $rootScope.downloadFormatList = $filter('filter')(response.data.data, function(data) {
                            return (itm.format.indexOf(data.formatId) > -1)
                        })
                    } else if (itm.permission == 'SHARE') {
                        $rootScope.loggedUserShareFormatIdList = itm.format;
                        $rootScope.shareFormatList = $filter('filter')(response.data.data, function(data) {
                            return (itm.format.indexOf(data.formatId) > -1)
                        })
                    } else if (itm.permission == 'DELETE') {
                        $rootScope.loggedUserDeleteFormatIdList = itm.format;
                        $rootScope.deleteFormatList = $filter('filter')(response.data.data, function(data) {
                            return (itm.format.indexOf(data.formatId) > -1)
                        })
                    }
                });
                angular.forEach($rootScope.loggedUser.permissionGroup.application, function(appVal) {
                    $rootScope.loggedUserApplicationList.push(appVal)
                })
            }
        }, function errorCallback(response) {})
    };
    $rootScope.getReports = function() {
        $http({
            method: 'GET',
            url: '/getReports'
        }).then(function successCallback(response) {
            $rootScope.reportList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getAccessList = function() {
        $http({
            method: 'GET',
            url: '/getAccessList'
        }).then(function successCallback(response) {
            $rootScope.accessList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getPermissionGroups = function() {
        $http({
            method: 'GET',
            url: '/getPermissionGroups'
        }).then(function successCallback(response) {
            $rootScope.permisssionGroupList = response.data.data
        }, function errorCallback(response) {})
    };
    $scope.userAccountFilter = function(item) {
        var result = !1;
        try {
            angular.forEach($scope.loggedUser.permissionGroup.account, function(value) {
                if (value == item.accountId)
                    result = !0
            })
        } catch (e) {}
        return result
    }
    $rootScope.getMetadataFields = function() {
        $http({
            method: 'GET',
            url: '/getMetadataFields'
        }).then(function successCallback(response) {
            $rootScope.metadataFieldList = response.data.data
        }, function errorCallback(response) {})
    };
    $rootScope.getFormatTypes = function() {
        $http({
            method: 'GET',
            url: '/getFormatTypes'
        }).then(function successCallback(response) {
            $rootScope.formatTypeList = response.data.data
        }, function errorCallback(response) {})
    };
    $('#drm_Modal').on('shown.bs.modal', function() {
        $(this).find('input:first').focus()
    });
    $('#drm_Modal').find('button:first').on('keydown', function(e) {
        if ($("this:focus") && (e.which == 9)) {
            e.preventDefault();
            $('#drm_Modal').find('input:first').focus()
        }
    });
    $rootScope.drmOrderTypes = null;
    $rootScope.drmOrderType = null;
    $rootScope.setDRMOrderType = function(orderType) {
        $rootScope.drmOrderType = orderType
    }
    $rootScope.drmModal = function(checkParam) {
        var myEl = angular.element(document.querySelector('#drmModalId'));
        myEl.removeAttr('data-toggle', "modal");
        myEl.removeAttr('data-target', "#drm_Modal");
        var length = 0;
        if (checkParam === 'ASSET') {
            document.getElementById("tempbucketerr").innerHTML = "";
            length = Object.keys($rootScope.downloadUploadList).length
        } else {
            document.getElementById("tempbucketAssetShelferr").innerHTML = "";
            length = Object.keys($rootScope.downloadShelfUploadList).length
        }
        $rootScope.drmIsbnList = [];
        var drmFlg = !0;
        if (length > '0') {
            $http({
                method: 'GET',
                url: '/getDrmEligibleFormats'
            }).then(function successCallback(response) {
                if (response.data.code == "200") {
                    $rootScope.drmOrderTypes = response.data.data.orderTypes;
                    $rootScope.drmOrderType = $rootScope.drmOrderTypes[0];
                    if (checkParam === 'ASSET') {
                        $.each($rootScope.downloadUploadList, function(index, key, value) {
                            if (undefined == key[0].format || null == key[0].format || (response.data.data.eligibleFormats.indexOf(key[0].formatId) == -1)) {
                                drmFlg = !1;
                                return !1
                            } else {
                                var drmIsbn = {
                                    isbn: key[0].isbn,
                                    formatId: key[0].formatId
                                };
                                $rootScope.drmIsbnList.push(drmIsbn)
                            }
                        })
                    } else {
                        $.each($rootScope.downloadShelfUploadList, function(index, key, value) {
                            if (undefined == key[0].format || null == key[0].format || (response.data.data.eligibleFormats.indexOf(key[0].formatId) == -1)) {
                                drmFlg = !1;
                                return !1
                            } else {
                                var drmIsbn = {
                                    isbn: key[0].isbn,
                                    formatId: key[0].formatId
                                };
                                $rootScope.drmIsbnList.push(drmIsbn)
                            }
                        })
                    }
                    if (length > '10') {
                        if (checkParam === 'ASSET') {
                            document.getElementById("tempbucketerr").innerHTML = "Please select less than 10 records to drm request";
                            return !1
                        } else {
                            document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select less than 10 records to drm request";
                            return !1
                        }
                    }
                    if (drmFlg) {
                        myEl.attr('data-toggle', "modal");
                        myEl.attr('data-target', "#drm_Modal");
                        $('#drm_Modal').modal('toggle');
                        angular.element($(".collection-drawer-mixin")).removeClass('maximize')
                    } else {
                        myEl.removeAttr('data-toggle', "modal");
                        myEl.removeAttr('data-target', "#drm_Modal");
                        if (checkParam === 'ASSET')
                            document.getElementById("tempbucketerr").innerHTML = "Please select only assets with " + response.data.data.eligibleFormatNames.toString() + " formats";
                        else document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select only assets with " + response.data.data.eligibleFormatNames.toString() + " formats"
                    }
                } else {
                    if (checkParam === 'ASSET')
                        document.getElementById("tempbucketerr").innerHTML = "No Formats configured for DRM Request";
                    else document.getElementById("tempbucketAssetShelferr").innerHTML = "No Formats configured for DRM Request"
                }
            }, function errorCallback(response) {})
        } else {
            var myEl = angular.element(document.querySelector('#drmModalId'));
            myEl.removeAttr('data-toggle', "modal");
            myEl.removeAttr('data-target', "#drm_Modal");
            if (checkParam === 'ASSET')
                document.getElementById("tempbucketerr").innerHTML = "Please select the asset for DRM";
            else document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select the asset for DRM"
        }
    };
    $scope.drmNoOfDays = null;
    $scope.drmPrintPageCount = 0;
    $scope.drmCopyPageCount = 0;
    $scope.setRestrictionType = function() {
        if ($scope.drmRestrictionType === "READ") {
            $scope.drmPrintPageCount = null;
            $scope.drmCopyPageCount = null
        } else {
            $scope.drmNoOfDays = null;
            console.log($scope.drmPrintPageCount);
            if ($scope.drmPrintPageCount == 0) {
                $scope.drmPrintPageCount = null
            }
            if ($scope.drmCopyPageCount == 0) {
                $scope.drmCopyPageCount = null
            }
        }
    }
    $scope.cancelDRMSave = function() {
        $scope.drmEmailId = null;
        $scope.drmNoOfDevices = null;
        $scope.drmRestrictionType = null;
        $rootScope.drmOrderType = null;
        $scope.DRMForm.$setPristine();
        $scope.DRMForm.$setUntouched();
        $scope.DRMForm.$error = {};
        $scope.DRMForm.$submitted = !1;
        $('#drm_Modal').modal('toggle')
    };
    $scope.saveDRM = function() {
        $rootScope.createDRMLoading = !0;
        var drmEmailList = $scope.drmEmailId.split(",").map(function(item) {
            return item.trim()
        });
        drmEmailList = drmEmailList.filter(function(e) {
            return e
        });
        var drmSource = "Manage";
        var readPermission = !0;
        var noOfDays = null;
        var printCopyPermission = !1;
        var printPages = null;
        var copyPages = null;
        var alertText = "";
        if ($scope.drmRestrictionType === "READ") {
            noOfDays = angular.element('#drmNoOfDays').val();
            printPages = null;
            copyPages = null;
            alertText = "Limited"
        } else {
            noOfDays = 0;
            printCopyPermission = !0;
            printPages = angular.element('#drmPrintPageCount').val();
            copyPages = angular.element('#drmCopyPageCount').val();
            if (printPages == 0) {
                printPages = null
            }
            if (copyPages == 0) {
                copyPages = null
            }
            alertText = "Perpetual"
        }
        $http({
            method: 'POST',
            url: '/saveDRM',
            data: {
                drmSource: drmSource,
                isbnList: $rootScope.drmIsbnList,
                emailIdList: drmEmailList,
                noOfDevices: $scope.drmNoOfDevices,
                readPermission: readPermission,
                noOfDays: noOfDays,
                printCopyPermission: printCopyPermission,
                printPages: printPages,
                copyPages: copyPages,
                orderType: $rootScope.drmOrderType.value
            }
        }).then(function(response) {
            $rootScope.createDRMLoading = !1;
            $scope.cancelDRMSave();
            if (response.data.code == '200') {
                $scope.showDRMSuccessMsg = !0;
                $scope.DRMSuccessMsg = alertText + ' permission link is sent to "' + drmEmailList.toString() + '"';
                setTimeout(function() {
                    $scope.showDRMSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showDRMErrorMsg = !0;
                $scope.DRMErrorMsg = "Unable to send " + alertText + " permission link";
                setTimeout(function() {
                    $scope.showDRMErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {})
    }
    $rootScope.convertToDate = function(dateString) {
        if (dateString != null && dateString != null & dateString != "") {
            var pattern = /(\d{4})(\d{2})(\d{2})/;
            return new Date(dateString.replace(pattern, '$1-$2-$3'))
        } else {
            return ""
        }
    }
    $rootScope.getReportsList = function() {
        $http({
            method: 'POST',
            url: '/getReportsList',
            data: {
                advancedSearch: {}
            }
        }).then(function successCallback(response) {
            $rootScope.commonreportList = response.data.data;
            $rootScope.saveReportName = "Asset Activity"
        }, function errorCallback(response) {})
    };
    $rootScope.initBasicData = function() {
        if ($window.sessionStorage.device == "true") {
            $http({
                method: 'GET',
                url: '/getCodeLookUpValues',
                data: null
            }).then(function(response) {
                $rootScope.productsList = response.data.data
            });
            if ($location.$$path.contains("/view") != !0 && $location.$$path.contains("/widget/") != !0) {
                $scope.getDashBoard();
                $rootScope.getDownloadNotification();
                $rootScope.getRoles();
                $rootScope.getAccounts(!0);
                $rootScope.getImprints();
                $rootScope.getMetadataTypes();
                $rootScope.getProductCategories();
                $rootScope.getProductCategoriesForSearch();
                $rootScope.getMetadataGroups();
                $rootScope.getcMetadataGroups();
                $rootScope.getPartnerTypes();
                $rootScope.getApplications();
                $rootScope.getModules();
                $rootScope.getFormats();
                $rootScope.getReports();
                $rootScope.getAccessList();
                $rootScope.getPermissionGroups();
                $rootScope.getMetadataFields();
                $rootScope.getFormatTypes();
                $rootScope.getApprovalFormats();
                $rootScope.activityShelf();
                $rootScope.showLoader($('.body'), 1, 'win8_linear');
                $rootScope.getReportsList();
                setTimeout(function() {
                    $rootScope.InitBasicDataHeader();
                    $rootScope.getShelf()
                }, 500)
            }
        }
    }
    $rootScope.activityShelf = function() {
        var param = 'Asset';
        var param2 = 'Meta'
        $http({
            method: 'GET',
            url: '/activityList/' + param,
            data: null
        }).then(function(response) {
            $rootScope.shelfActivityLists = response.data
        });
        $http({
            method: 'GET',
            url: '/activityList/' + param2,
            data: null
        }).then(function(response) {
            $rootScope.shelfActivityMetaLists = response.data
        });
        $http({
            method: 'GET',
            url: '/remainderList',
            data: null
        }).then(function(response) {
            $rootScope.remainderLists = response.data
        })
    };
    $scope.selfShow = !1;
    $scope.editSaveShelfDetails = !1;
    $scope.newSaveShelfDetails = !1;
    $rootScope.saveShelf = function(val) {
        document.getElementById("tempbucketerr").innerHTML = "";
        angular.element(".self-content").toggle()
    };
    $rootScope.shelfData = {};
    $scope.shelfActionList = [];
    $rootScope.shAction = {};
    $scope.unCheckAction = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityLists, function(value) {
            document.getElementById("shelf_" + value.activityName).checked = !1
        })
    }
    $scope.unCheckActionsDisable = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityLists, function(value, key) {
            document.getElementById("shelf_" + value.activityName).disabled = !0
        })
    }
    $scope.unCheckActionEnable = function(shelf, shelfList) {
        angular.forEach($rootScope.shelfActivityLists, function(value, key) {
            document.getElementById("shelf_" + value.activityName).disabled = !1
        })
    }
    $scope.shelfNameChange = function(shelf, shelfList) {
        angular.forEach($rootScope.saveshelfList, function(value) {
            if ($scope.shelfData.shelfName === value.name) {
                $scope.shelfRemainderList = "";
                $scope.shelfComments = "";
                $scope.shelfActionList = [];
                $rootScope.shAction = {};
                $scope.unCheckAction(shelf, shelfList);
                $scope.unCheckActionEnable(shelf, shelfList);
                $timeout(function() {
                    angular.element($(".shelfactionselect")).addClass("shelfactionselect-disable");
                    angular.element($(".header-search-drop")).removeClass("active");
                    angular.element($(".shelf-remain")).addClass("non-editable")
                }, 10)
                $scope.shelfNameSelect(value, value.shelfdetails)
            } else if ($scope.shelfData.shelfName != value.name) {
                $scope.unCheckActionEnable(shelf, shelfList);
                angular.element($(".shelfactionselect")).removeClass("shelfactionselect-disable");
                angular.element($(".shelf-remain")).removeClass("non-editable")
            }
        })
    }
    $scope.shelfNameSelect = function(shelf, shelfList) {
        $scope.unCheckAction(shelf, shelfList);
        $rootScope.shelfData = {};
        $scope.shelfActionList = [];
        $rootScope.shAction = {};
        $scope.shelfName = "";
        $scope.shelfComments = "";
        angular.element($(".shelfactionselect")).addClass("shelfactionselect-disable");
        angular.element($(".header-search-drop")).removeClass("active");
        angular.element($(".shelf-remain")).addClass("non-editable");
        $scope.shelfData.shelfName = shelf.name;
        $scope.shelfRemainderList = shelf.remainder;
        $scope.shelfComments = shelf.comments;
        angular.forEach(shelfList, function(details) {
            angular.forEach(details.action, function(value, key) {
                if (key != null && key != "") {
                    document.getElementById("shelf_" + key).checked = !0;
                    document.getElementById("shelf_" + key).disabled = !0;
                    if ($scope.shelfActionList.indexOf(key) == -1) {
                        angular.forEach($rootScope.shelfActivityLists, function(data) {
                            if (data.activityName == key) {
                                if (!$scope.shelfActionList.includes(data.displayName))
                                    $scope.shelfActionList.push(data.displayName)
                            }
                        })
                        $rootScope.shAction[key] = value
                    }
                }
            })
        });
        $scope.unCheckActionsDisable(shelf, shelfList)
    };
    $scope.selfActionSelect = function(shelfAction, chk) {
        if (chk) {
            $scope.shelfActionList.push(shelfAction.displayName);
            $rootScope.shAction[shelfAction.activityName] = "InProgress"
        } else {
            var index = $scope.shelfActionList.indexOf(shelfAction.displayName);
            $scope.shelfActionList.splice(index, 1);
            delete $rootScope.shAction[shelfAction.activityName]
        }
    };
    $scope.selfRemainderSelect = function(remainderList) {
        $scope.shelfRemainderList = remainderList
    };
    $scope.saveDataShelf = function(shelf) {
        $scope.shelfComments = $("#shelfComments").val();
        $scope.updatedBy = $rootScope.loggedUser.userId;
        $scope.shelfDetails = [];
        $scope.action = [];
        if (Object.keys($rootScope.downloadUploadList).length > 100) {
            document.getElementById("tempbucketerr").innerHTML = "Please select less than 100 records to save shelf request";
            return !1
        }
        if (Object.keys($rootScope.downloadUploadList).length > 0) {
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                $scope.shelfDetails.push({
                    "isbn": key[0].isbn,
                    "title": key[0].title,
                    "author": key[0].author,
                    "formatName": key[0].format,
                    "formatId": key[0].formatId,
                    "formatSize": key[0].formatSize,
                    "action": $rootScope.shAction
                })
            })
            var shelfName = "";
            var shelfdocId = "";
            if ($rootScope.saveshelfList != undefined && $rootScope.saveshelfList != "")
                if ($rootScope.saveshelfList.length > 0) {
                    angular.forEach($rootScope.saveshelfList, function(value) {
                        if ($scope.shelfData.shelfName === value.name) {
                            shelfName = value.name;
                            shelfdocId = value.docId;
                            return !1
                        }
                    })
                }
            if (shelfName === $scope.shelfData.shelfName) {
                $http({
                    method: 'POST',
                    url: '/saveShelfDetails',
                    data: {
                        docId: shelfdocId,
                        name: $scope.shelfData.shelfName,
                        comments: $scope.shelfComments,
                        remainder: $scope.shelfRemainderList,
                        shelfType: "Assets_Book",
                        updatedBy: $scope.updatedBy,
                        shelfdetails: $scope.shelfDetails
                    }
                }).then(function(response) {
                    $rootScope.getShelf();
                    angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                    angular.element($(".self-content")).css("display", "none");
                    if (response.data.code == '200') {
                        $scope.editSaveShelfSuccessMsg = "SHELF_UPDATE_SUCCESSFULLY";
                        $scope.showeditSaveShelfDetails = !0;
                        setTimeout(function() {
                            $scope.showeditSaveShelfDetails = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    } else {
                        $scope.editSaveShelfError = !0;
                        $scope.editSaveShelfErrorMsg = "SHELF_UPDATE_FAILD";
                        setTimeout(function() {
                            $scope.editSaveShelfError = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                }, function errorCallback(error) {})
            } else {
                $http({
                    method: 'POST',
                    url: '/saveShelfDetails',
                    data: {
                        name: $scope.shelfData.shelfName,
                        comments: $scope.shelfComments,
                        remainder: $scope.shelfRemainderList,
                        shelfType: "Asset_Book",
                        updatedBy: $scope.updatedBy,
                        shelfdetails: $scope.shelfDetails
                    }
                }).then(function(response) {
                    $rootScope.getShelf();
                    angular.element($(".collection-drawer-mixin")).removeClass('maximize');
                    angular.element($(".self-content")).css("display", "none");
                    if (response.data.code == '200') {
                        $scope.newSaveShelfSuccessMsg = "SHELF_SAVE_SUCCESSFULLY";
                        $scope.shownewSaveShelfDetails = !0;
                        setTimeout(function() {
                            $scope.shownewSaveShelfDetails = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    } else {
                        $scope.errorshownewSaveShelfDetails = !0;
                        $scope.errornewSaveShelfDetails = "SHELF_SAVE_ERROR";
                        setTimeout(function() {
                            $scope.errorshownewSaveShelfDetails = !1;
                            $scope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                }, function errorCallback(error) {})
            }
        } else {
            document.getElementById("tempbucketerr").innerHTML = "No record selected";
            return !1
        }
        setTimeout(function() {
            $scope.selfReset()
        }, 100)
        $scope.showShelfError = !1
    }
    $scope.shelfNameErr = function() {
        $scope.showShelfError = !0
    }
    $scope.selfReset = function() {
        $scope.shelfData.shelfName = "";
        $scope.shelfRemainderList = "";
        $scope.shelfComments = "";
        document.getElementById("tempbucketerr").innerHTML = "";
        document.getElementById("shelfComments").value = "";
        $scope.shelfActionList = [];
        angular.forEach($rootScope.shelfActivityLists, function(shelfAction) {
            document.getElementById("shelf_" + shelfAction.activityName).checked = !1
        })
        angular.element($(".collection-drawer-mixin")).removeClass('maximize');
        angular.element($(".self-content")).css("display", "none");
        $scope.showShelfError = !1;
        angular.element($(".shelfactionselect")).removeClass("shelfactionselect-disable");
        angular.element($(".shelf-remain")).removeClass("non-editable")
    }
    $rootScope.stopDistribution = function() {
        if (Object.keys($rootScope.partList).length > 0) {
            $rootScope.partnerSelectErr = !1
        } else {
            $rootScope.partnerSelectErr = !0;
            return !1
        }
        $rootScope.partnerDetailsList = [];
        if (Object.keys($rootScope.partList).length > 0) {
            angular.forEach($rootScope.partList, function(key, value) {
                $rootScope.partnerDetailsList.push({
                    "partnerName": key.partnerName,
                    "partnerId": key.partnerId
                })
            })
        } else {
            return !1
        }
        $http({
            method: 'POST',
            url: '/stopDistribution',
            data: {
                isbn: $rootScope.rediIsbn,
                formatId: $rootScope.rediFirmatId,
                partnerDetails: $rootScope.partnerDetailsList
            }
        }).then(function(response) {
            $('#stopProgress').modal('toggle');
            $rootScope.distHostoryData = response.data.data;
            if (response.data.code == '200') {
                $rootScope.reDistriStopSuccessMsg = "DISTRIBUTION.STATUS.STOP.SUCESS";
                $rootScope.reDistriStopSuccessMsgDetails = !0;
                if ($location.$$url == '/asset') {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.format.code == $rootScope.rediFirmatId) {
                            key.transactionStatus = "16"
                        }
                    })
                } else {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.isbn == $rootScope.rediIsbn) {
                            key.transactionStatus = "16"
                        }
                    })
                }
                setTimeout(function() {
                    $rootScope.reDistriStopSuccessMsgDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.errorreDistriDetails = !0;
                $rootScope.errorReDistStopDetails = "DISTRIBUTION.STATUS.STOP.ERROR";
                setTimeout(function() {
                    $rootScope.errorreDistriDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {});
        $rootScope.partList = {}
    }
    $http({
        method: 'GET',
        url: '/getPartners/false/null'
    }).then(function(response) {
        $rootScope.distColumnPartners = response.data.data
    }, function errorCallback(error) {});
    $rootScope.reDataDistributionList = [];
    $rootScope.partnerDistributionList = function(isbn, formatId, distrlist, transactionStatus, page) {
        $rootScope.distriPage = page;
        $rootScope.stopSearchPart = [];
        $rootScope.showBrChk = distrlist.isBusinessRule;
        $rootScope.rediIsbn = isbn;
        if (undefined === formatId) {
            $rootScope.rediFirmatId = null;
            $rootScope.rediFormartName = null
        } else {
            $rootScope.rediFirmatId = formatId;
            $rootScope.rediFormartName = distrlist.format.description
        }
        $rootScope.rediPartId = distrlist.partnerId;
        $rootScope.rediTitle = distrlist.title;
        $http({
            method: 'POST',
            url: '/getPartnerDataByIsbnFormatId',
            data: {
                isbn: isbn,
                formatId: $rootScope.rediFirmatId,
                distributionStatus: transactionStatus
            }
        }).then(function(response) {
            $rootScope.reDataDistributionList = response.data.data
        })
    }
    $rootScope.showDistHistory = function(isbn, formatId) {
        $rootScope.distHostoryData = {};
        $rootScope.histriIsbn = isbn;
        $rootScope.histriFirmatId = formatId;
        $http({
            method: 'POST',
            url: '/showDistHistory',
            data: {
                isbn: isbn,
                formatId: formatId
            }
        }).then(function(response) {
            $rootScope.distHostoryData = response.data.data
        });
        var container = document.getElementById("distributiondatahistory");
        setTimeout(function() {
            container.scrollTop = 0
        }, 400)
    }
    $rootScope.dataDistributionReset = function() {
        angular.forEach($rootScope.partList, function(key, value) {
            document.getElementById("stop_" + key.partnerId).checked = !1
        });
        $rootScope.partList = {};
        $rootScope.stopSearchPart = [];
        $rootScope.takeSearchPart = [];
        $rootScope.reDistriPriSelect = "";
        $rootScope.reDataDistributionList = "";
        document.getElementById("takedowncomment").value = "";
        document.getElementById("stopSelectAll").checked = !1;
        document.getElementById("redisSelectAll").checked = !1;
        document.getElementById("takeSelectAll").checked = !1;
        if ($rootScope.showBrChk === !1) {
            document.getElementById("notabussi").checked = !1
        }
    }
    $rootScope.partList = {};
    $rootScope.stopSearchPart = [];
    $rootScope.reDistriPartner = function(distributionlist, chk) {
        $rootScope.partnerSelectErr = !1;
        if (chk.target.checked) {
            $rootScope.partList[distributionlist.partnerId] = distributionlist
        } else {
            delete $rootScope.partList[distributionlist.partnerId];
            document.getElementById("stopSelectAll").checked = !1
        }
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        });
        if (Object.keys($rootScope.partList).length <= 0) {
            document.getElementById("stopSelectAll").checked = !1
        }
        if ($rootScope.reDataDistributionList.length === Object.keys($rootScope.partList).length) {
            document.getElementById("stopSelectAll").checked = !0
        }
    }
    $rootScope.partTypeRemove = function(rmvpart, partnerid) {
        delete $rootScope.partList[partnerid];
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        });
        document.getElementById("stop_" + partnerid).checked = !1;
        document.getElementById("stopSelectAll").checked = !1
    }
    $rootScope.reDistriStopAllPartnerType = function(event) {
        if (event.target.checked) {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("stop_" + itm.partnerId).checked = !0;
                $rootScope.partList[itm.partnerId] = itm
            })
        } else {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("stop_" + itm.partnerId).checked = !1;
                delete $rootScope.partList[itm.partnerId]
            })
        }
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        })
    }
    $rootScope.reDistributionPartner = function(reDistributionlist, chk) {
        $rootScope.partnerSelectErr = !1;
        if (chk.target.checked) {
            $rootScope.partList[reDistributionlist.partnerId] = reDistributionlist
        } else {
            document.getElementById("redisSelectAll").checked = !1;
            delete $rootScope.partList[reDistributionlist.partnerId]
        }
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        });
        if (Object.keys($rootScope.partList).length <= 0) {
            document.getElementById("redisSelectAll").checked = !1
        }
        if ($rootScope.reDataDistributionList.length === Object.keys($rootScope.partList).length) {
            document.getElementById("redisSelectAll").checked = !0
        }
    }
    $rootScope.reDistributionStopAllPartnerType = function(event) {
        if (event.target.checked) {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("redis_" + itm.partnerId).checked = !0;
                $rootScope.partList[itm.partnerId] = itm
            })
        } else {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("redis_" + itm.partnerId).checked = !1;
                delete $rootScope.partList[itm.partnerId]
            })
        }
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        })
    }
    $rootScope.redistpartTypeRemove = function(rmvpart, partnerid) {
        delete $rootScope.partList[partnerid];
        $rootScope.stopSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.stopSearchPart.push(key.partnerName)
        });
        document.getElementById("redis_" + partnerid).checked = !1;
        document.getElementById("redisSelectAll").checked = !1
    }
    $rootScope.redistriPrioritySelect = function(select) {
        $rootScope.reDistriPriSelect = select
    }
    $rootScope.reDistriBrStatus = function(event) {
        if (event.target.checked) {
            $rootScope.reDistriBrStatusUsrSelct = !0
        } else {
            $rootScope.reDistriBrStatusUsrSelct = !1
        }
    }
    $rootScope.reDistributionStatusChange = function() {
        if (Object.keys($rootScope.partList).length > 0) {
            $rootScope.partnerSelectErr = !1
        } else {
            $rootScope.partnerSelectErr = !0;
            return !1
        }
        $rootScope.partnerDetailsList = [];
        if (Object.keys($rootScope.partList).length > 0) {
            angular.forEach($rootScope.partList, function(key, value) {
                $rootScope.partnerDetailsList.push({
                    "partner": key.partnerName,
                    "partnerId": key.partnerId
                })
            })
        } else {
            return !1
        }
        var brStatus = !1;
        if ($rootScope.showBrChk) {
            brStatus = !0
        } else {
            brStatus = $rootScope.reDistriBrStatusUsrSelct
        }
        var mCheck = !1;
        if (null == $rootScope.rediFirmatId) {
            mCheck = !0
        }
        $http({
            method: 'POST',
            url: '/reDistribute',
            data: {
                isbn: $rootScope.rediIsbn,
                formatId: $rootScope.rediFirmatId,
                format: $rootScope.rediFormartName,
                partnerDetails: $rootScope.partnerDetailsList,
                title: $rootScope.rediTitle,
                userName: $rootScope.loggedUser.firstName,
                emailId: $rootScope.loggedUser.emailId,
                userId: $rootScope.loggedUser.userId,
                brStatus: brStatus,
                priority: $rootScope.reDistriPriSelect,
                metadataCheck: mCheck
            }
        }).then(function(response) {
            $rootScope.dataDistributionReset();
            $('#redistribute').modal('toggle');
            $rootScope.distHostoryData = response.data.data;
            if (response.data.code == '200') {
                $rootScope.reDistributionSuccessMsgDetails = !0;
                $rootScope.reDistributionSuccessMsg = "REDISTRIBUTION.STATUS.SUCESS";
                if ($location.$$url == '/asset') {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.format.code == $rootScope.rediFirmatId) {
                            key.transactionStatus = "02"
                        }
                    })
                } else {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.isbn == $rootScope.rediIsbn) {
                            key.transactionStatus = "02"
                        }
                    })
                }
                setTimeout(function() {
                    $rootScope.reDistributionSuccessMsgDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.errorreDistributionDetails = !0;
                $rootScope.errorreDistributionMsgDetails = "DISTRIBUTION.STATUS.ERROR";
                setTimeout(function() {
                    $rootScope.errorreDistributionDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {});
        $rootScope.partList = {};
        $rootScope.reDistriPriSelect = null
    }
    $rootScope.takeDownPartner = function(takedownpartlist, chk) {
        if (chk.target.checked) {
            $rootScope.partList[takedownpartlist.partnerId] = takedownpartlist
        } else {
            document.getElementById("takeSelectAll").checked = !1;
            delete $rootScope.partList[takedownpartlist.partnerId]
        }
        $rootScope.takeSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.takeSearchPart.push(key.partnerName)
        });
        if (Object.keys($rootScope.partList).length <= 0) {
            document.getElementById("takeSelectAll").checked = !1
        }
        if ($rootScope.reDataDistributionList.length === Object.keys($rootScope.partList).length) {
            document.getElementById("takeSelectAll").checked = !0
        }
    }
    $rootScope.takeDownAllPartner = function(event) {
        if (event.target.checked) {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("takedown_" + itm.partnerId).checked = !0;
                $rootScope.partList[itm.partnerId] = itm
            })
        } else {
            angular.forEach($rootScope.reDataDistributionList, function(itm) {
                document.getElementById("takedown_" + itm.partnerId).checked = !1;
                delete $rootScope.partList[itm.partnerId]
            })
        }
        $rootScope.takeSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.takeSearchPart.push(key.partnerName)
        })
    }
    $rootScope.TakeDownpartTypeRemove = function(rmvpart, partnerid) {
        delete $rootScope.partList[partnerid];
        $rootScope.takeSearchPart = [];
        angular.forEach($rootScope.partList, function(key, value) {
            $rootScope.takeSearchPart.push(key.partnerName)
        });
        document.getElementById("takedown_" + partnerid).checked = !1;
        document.getElementById("takeSelectAll").checked = !1
    }
    $rootScope.TakeDownDistributionStatusChange = function() {
        $rootScope.partnerSelectErr = !1;
        if (Object.keys($rootScope.partList).length > 0) {
            $rootScope.partnerSelectErr = !1
        } else {
            $rootScope.partnerSelectErr = !0;
            return !1
        }
        $rootScope.partnerDetailsList = [];
        $rootScope.takedowncomment = document.getElementById("takedowncomment").value;
        if (Object.keys($rootScope.partList).length > 0) {
            angular.forEach($rootScope.partList, function(key, value) {
                $rootScope.partnerDetailsList.push({
                    "partner": key.partnerName,
                    "partnerId": key.partnerId
                })
            })
        } else {
            return !1
        }
        $http({
            method: 'POST',
            url: '/removeFromSaleDistribution',
            data: {
                isbn: $rootScope.rediIsbn,
                formatId: $rootScope.rediFirmatId,
                format: $rootScope.rediFormartName,
                partnerDetails: $rootScope.partnerDetailsList,
                remarks: $rootScope.takedowncomment,
                userId: $rootScope.loggedUser.userId,
                emailId: $rootScope.loggedUser.emailId,
                userName: $rootScope.loggedUser.firstName,
                title: $rootScope.rediTitle
            }
        }).then(function(response) {
            $rootScope.distHostoryData = response.data.data;
            $rootScope.dataDistributionReset();
            $('#takeDown').modal('toggle');
            if (response.data.code == '200') {
                $rootScope.takeDownDistributionSuccessMsgDetails = !0;
                $rootScope.takeDownDistributionSuccessMsg = "REDISTRIBUTION.TAKEDOWN.SUCESS";
                if ($location.$$url == '/asset') {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.format.code == $rootScope.rediFirmatId) {
                            key.transactionStatus = "03"
                        }
                    })
                } else {
                    var prod = $filter('filter')($rootScope.searchResult, function(itm) {
                        return itm.ISBN13 == $rootScope.rediIsbn
                    })[0];
                    angular.forEach(prod.Distribution, function(key) {
                        if (key.isbn == $rootScope.rediIsbn) {
                            key.transactionStatus = "03"
                        }
                    })
                }
                setTimeout(function() {
                    $rootScope.takeDownDistributionSuccessMsgDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.errortakeDownDistributionDetails = !0;
                $rootScope.errortakeDownDistributionMsg = "DISTRIBUTION.TAKEDOWN.ERROR";
                setTimeout(function() {
                    $rootScope.errortakeDownDistributionDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {});
        $rootScope.partList = {}
    }
    $rootScope.updatePrioritySelect = function(select) {
        $rootScope.distriPrioritySelected = select
    }
    $rootScope.setTesting = function(val, partId) {
        $rootScope.distriPrioritySelected = val;
        $rootScope.histriPartnerId = partId
    }
    $rootScope.updatePriority = function() {
        $http({
            method: 'POST',
            url: '/updatePriority',
            data: {
                isbn: $rootScope.histriIsbn,
                formatId: $rootScope.histriFirmatId,
                partnerId: $rootScope.histriPartnerId,
                priority: $rootScope.distriPrioritySelected
            }
        }).then(function(response) {
            if (response.data.code == '200') {
                $rootScope.sucessUpdatePriDistriDetai = !0;
                $rootScope.sucessUpdatePriDistriDetaimsg = "Update priority Sucessfully";
                $rootScope.showDistHistory = response.data.data;
                $rootScope.distHostoryData = response.data.data;
                $rootScope.sucessUpdatePriDistriDetai = !0;
                $rootScope.sucessUpdatePriDistriDetaimsg = "Update priority Sucessfully";
                setTimeout(function() {
                    $rootScope.sucessUpdatePriDistriDetai = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.errorupdatePriDistriDetai = !0;
                $rootScope.errorupdatePriDistriDetaimsg = "REDISTRIBUTION.UPDATE.PRIORITY.ERROR";
                setTimeout(function() {
                    $rootScope.errorupdatePriDistriDetai = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {})
    }
    $rootScope.updatePriorityReset = function() {
        $rootScope.distriPrioritySelected = ""
    }
    $rootScope.fetchIsbnHistory = function(isbn) {
        $rootScope.fetchIsbnHistoryisbn = isbn;
        $rootScope.titleActionFilter = [];
        $rootScope.shelfData.shelfActionLists = '';
        $http({
            method: 'POST',
            url: '/fetchIsbnHistory',
            data: {
                isbn: isbn
            }
        }).then(function(response) {
            $rootScope.titleShowIsbnHistory = response.data.data;
            if ($rootScope.titleShowIsbnHistory.length > 0)
                angular.element('#titleShowIsbnHistory').modal('toggle')
        })
    }
    $rootScope.fetchAssetBinding = function(isbn) {
        $rootScope.showLoader($('.asset-binding-loader'), 1, 'win8_linear');
        $rootScope.assetBindingData = null;
        $rootScope.assetBindingIsbn = isbn;
        angular.element('#fetchAssetBinding').modal('toggle');
        $http({
            method: 'GET',
            url: '/assetBinding/' + isbn,
            data: null
        }).then(function successCallback(response) {
            $rootScope.assetBindingData = response.data.data;
            $rootScope.hideLoader('asset-binding-loader');
            angular.forEach($rootScope.assetBindingData, function(key, value) {
                $rootScope.assetBindingParent = key.parent
            });
            if ($rootScope.assetBindingIsbn == $rootScope.assetBindingParent) {
                $rootScope.sameAssetBinding = $rootScope.assetBindingIsbn + "*";
                return !1
            } else {
                $rootScope.sameAssetBinding = $rootScope.assetBindingIsbn
            }
        }, function errorCallback(response) {})
    }
    $rootScope.sorterFunc = function(binding) {
        return parseInt(binding['Publication Date'])
    };
    $scope.checkAllVersionFormatPermission = !1;
    $scope.fetchAssetVersion = function(result, format) {
        $scope.isSingleFile = format.singleFile;
        $rootScope.assetVersionDetails = {};
        $scope.showSearch = !1;
        $scope.fileType = "allversion";
        $scope.assetDetail = {
            "isbn": result.ISBN13,
            "title": result.Title,
            "author": result.Author,
            "assetType": format.formatName,
            "formatId": format.formatId
        }
        $scope.initialPath = result.ISBN13 + "/" + format.formatName;
        $scope.rootPath = result.ISBN13 + "/" + format.formatName;
        $scope.tmprootPath = $scope.rootPath.substr($scope.rootPath.indexOf("/") + 1);
        $http({
            method: 'POST',
            url: '/fetchAssetVersion',
            data: {
                rootPath: $scope.rootPath
            }
        }).then(function(response) {
            $rootScope.assetVersionDetails = response.data.data;
            $rootScope.showNoResultAllVer = !0
        });
        if (!$rootScope.loggedUserDownloadFormatIdList.includes($scope.assetDetail.formatId)) {
            $scope.checkAllVersionFormatPermission = !1
        } else {
            $scope.checkAllVersionFormatPermission = !0
        }
    }
    $scope.fetchsingleAsset = function(navlist) {
        $rootScope.assetVersionDetails = {}
        var currentAsset = $scope.rootPath.substr($scope.rootPath.lastIndexOf("/") + 1);
        if (navlist.name != currentAsset) {
            $scope.rootPath = $scope.rootPath + "/" + navlist.name
        }
        $scope.tmprootPath = $scope.rootPath.substr($scope.rootPath.indexOf("/") + 1);
        $scope.checkfileType()
    }
    $scope.searchAsset = function() {
        $scope.showSearch = !0
    }
    $scope.checkfileType = function() {
        if ($scope.fileType == "allversion") {
            var versionUrl = '/fetchAssetVersion';
            $rootScope.newFileFilter = !1;
            angular.element('#alldivTableCell').addClass('leftdivTableCell')
        } else if ($scope.fileType == "newfile") {
            var versionUrl = '/newFileVersion';
            $rootScope.newFileFilter = !0;
            angular.element('#alldivTableCell').removeClass('leftdivTableCell')
        }
        $http({
            method: 'POST',
            url: versionUrl,
            data: {
                rootPath: $scope.rootPath
            }
        }).then(function(response) {
            $rootScope.assetVersionDetails = response.data.data
        })
    }
    $scope.fetchoneLevelBack = function() {
        $rootScope.assetVersionDetails = {}
        if ($scope.initialPath != $scope.rootPath) {
            $scope.rootPath = $scope.rootPath.substr(0, $scope.rootPath.lastIndexOf("/"))
            $scope.tmprootPath = $scope.rootPath.substr($scope.rootPath.indexOf("/") + 1)
        }
        $scope.checkfileType()
    }
    $scope.columnSearchList = [];
    $scope.getcolumnSearchFilter = function(type) {
        var searchFilter = {};
        searchFilter[$scope.columnAssetVersionFilterSearch[type]] = type;
        var fileName = $scope.filterListData.fileName == undefined ? [] : $scope.filterListData.fileName;
        var createdBy = $scope.filterListData.createdBy == undefined ? [] : $scope.filterListData.createdBy;
        var modifiedBy = $scope.filterListData.modifiedBy == undefined ? [] : $scope.filterListData.modifiedBy;
        var createdFrom = $scope.filterListData.createdFrom == undefined ? [] : $scope.filterListData.createdFrom;
        var createdTo = $scope.filterListData.createdTo == undefined ? [] : $scope.filterListData.createdTo;
        var modifiedFrom = $scope.filterListData.modifiedFrom == undefined ? [] : $scope.filterListData.modifiedFrom;
        var modifiedTo = $scope.filterListData.modifiedTo == undefined ? [] : $scope.filterListData.modifiedTo;
        $http({
            method: 'POST',
            url: '/assetversionColumnSearchFilter',
            data: {
                "columnSearchData": searchFilter,
                "fileNameList": fileName,
                "createdByList": createdBy,
                "modifiedByList": modifiedBy,
                "createdFromList": createdFrom,
                "createdToList": createdTo,
                "modifiedFromList": modifiedFrom,
                "modifiedToList": modifiedTo,
                "rootPath": $scope.rootPath
            }
        }).then(function(response) {
            $scope.columnSearchList[type] = response.data.data;
            angular.forEach(eval(type), function(value, key) {
                angular.forEach($scope.columnSearchList[type], function(value1, key1) {
                    if (value == value1[type]) {
                        value1.selected = !0
                    }
                })
            })
        })
    }
    $scope.finaldateFormat = function(input) {
        if (input == null)
            return null;
        var d = new Date(input);
        var curr_date = ("0" + d.getDate()).slice(-2);
        var curr_month = ("0" + (d.getMonth() + 1)).slice(-2)
        var curr_year = d.getFullYear();
        return curr_year + "-" + curr_month + "-" + curr_date
    }
    $scope.filterListData = {}
    $rootScope.checkallColumnFilter = function(fileType, $event) {
        angular.forEach($scope.columnSearchList[fileType], function(value, key) {
            $scope.checkColumnFilter(fileType, value, $event, 'checkbox')
            var ischeckedall = $event.target.checked
            if (ischeckedall) {
                value.selected = !0
            } else {
                value.selected = !1
            }
        })
    }
    $scope.checkColumnFilter = function(type, details, $event, inputType) {
        var searchData = {};
        if ($scope.filterListData[type] == undefined) {
            $scope.filterListData[type] = []
        }
        if (inputType == "date") {
            searchData[$scope.finaldateFormat(details)] = type;
            $scope.filterListData[type] = (details != "" && details != null) ? [$scope.finaldateFormat(details)] : []
        } else {
            var ischecked = $event.target.checked;
            if (ischecked) {
                $scope.filterListData[type].push(details[type])
                searchData[details[type]] = type
            } else {
                for (var i = 0; i < $scope.filterListData[type].length; i++) {
                    var cur = $scope.filterListData[type][i];
                    if (cur == details[type]) {
                        $scope.filterListData[type].splice(i, 1);
                        break
                    }
                }
                searchData[null] = type
            }
        }
        var fileName = $scope.filterListData.fileName == undefined ? [] : $scope.filterListData.fileName;
        var createdBy = $scope.filterListData.createdBy == undefined ? [] : $scope.filterListData.createdBy;
        var modifiedBy = $scope.filterListData.modifiedBy == undefined ? [] : $scope.filterListData.modifiedBy;
        var createdFrom = $scope.filterListData.createdFrom == undefined ? [] : $scope.filterListData.createdFrom;
        var createdTo = $scope.filterListData.createdTo == undefined ? [] : $scope.filterListData.createdTo;
        var modifiedFrom = $scope.filterListData.modifiedFrom == undefined ? [] : $scope.filterListData.modifiedFrom;
        var modifiedTo = $scope.filterListData.modifiedTo == undefined ? [] : $scope.filterListData.modifiedTo;
        $http({
            method: 'POST',
            url: '/assetversionColumnSearchData',
            data: {
                "columnSearchData": searchData,
                "fileNameList": fileName,
                "createdByList": createdBy,
                "modifiedByList": modifiedBy,
                "createdFromList": createdFrom,
                "createdToList": createdTo,
                "modifiedFromList": modifiedFrom,
                "modifiedToList": modifiedTo,
                "rootPath": $scope.rootPath
            }
        }).then(function(response) {
            $rootScope.assetVersionDetails = response.data.data;
            if ($rootScope.assetVersionDetails.assetList == null) {
                $rootScope.showNoResultAllVer = !0
            }
        })
    }
    $rootScope.assetVersionfilterApplied = function(fieldName, fieldType) {
        var flag = !1;
        if (fieldType == 'date') {
            if (fieldName == "createdBy") {
                var fromField = "createdFrom";
                var toField = "createdTo"
            } else {
                var fromField = "modifiedFrom";
                var toField = "modifiedTo"
            }
            if ($scope.filterListData != undefined && $scope.filterListData != null && Object.keys($scope.filterListData).length != 0) {
                if ($scope.filterListData[fieldName] != null && $scope.filterListData[fieldName] != undefined && Object.keys($scope.filterListData[fieldName]).length != 0 || $scope.filterListData[fromField] != null && $scope.filterListData[fromField] != undefined && Object.keys($scope.filterListData[fromField]).length != 0 || $scope.filterListData[toField] != null && $scope.filterListData[toField] != undefined && Object.keys($scope.filterListData[toField]).length != 0)
                    flag = !0
            }
        } else {
            if ($scope.filterListData != undefined && $scope.filterListData != null && Object.keys($scope.filterListData).length != 0) {
                if ($scope.filterListData[fieldName] != null && $scope.filterListData[fieldName] != undefined && Object.keys($scope.filterListData[fieldName]).length != 0)
                    flag = !0
            }
        }
        return flag
    }
    $scope.columnAssetVersionFilterSearch = {};
    $scope.checkAll = {};
    $rootScope.assetVersionResetFilter = function(fieldName, fieldType) {
        if (fieldName == "createdBy") {
            $scope.createdFrom = null;
            $scope.createdTo = null;
            $scope.filterListData.createdFrom = $scope.filterListData.createdFrom == undefined ? [] : [];
            $scope.filterListData.createdTo = $scope.filterListData.createdTo == undefined ? [] : []
        } else if (fieldName == "modifiedBy") {
            $scope.modifiedFrom = null;
            $scope.modifiedTo = null;
            $scope.filterListData.modifiedFrom = $scope.filterListData.modifiedFrom == undefined ? [] : [];
            $scope.filterListData.modifiedTo = $scope.filterListData.modifiedTo == undefined ? [] : []
        }
        $scope.checkAll[fieldName] = {};
        $scope.filterListData[fieldName] = [];
        $scope.columnAssetVersionFilterSearch[fieldName] = "";
        var filterCount = 0;
        angular.forEach($scope.filterListData, function(value, key) {
            if (value.length > 0) {
                filterCount++
            }
        });
        if (filterCount == 0) {
            $scope.checkfileType()
        } else {
            var fileName = $scope.filterListData.fileName == undefined ? [] : $scope.filterListData.fileName;
            var createdBy = $scope.filterListData.createdBy == undefined ? [] : $scope.filterListData.createdBy;
            var modifiedBy = $scope.filterListData.modifiedBy == undefined ? [] : $scope.filterListData.modifiedBy;
            var createdFrom = $scope.filterListData.createdFrom == undefined ? [] : $scope.filterListData.createdFrom;
            var createdTo = $scope.filterListData.createdTo == undefined ? [] : $scope.filterListData.createdTo;
            var modifiedFrom = $scope.filterListData.modifiedFrom == undefined ? [] : $scope.filterListData.modifiedFrom;
            var modifiedTo = $scope.filterListData.modifiedTo == undefined ? [] : $scope.filterListData.modifiedTo;
            $http({
                method: 'POST',
                url: '/assetversionColumnSearchData',
                data: {
                    "columnSearchData": {
                        "": fieldName
                    },
                    "fileNameList": fileName,
                    "createdByList": createdBy,
                    "modifiedByList": modifiedBy,
                    "createdFromList": createdFrom,
                    "createdToList": createdTo,
                    "modifiedFromList": modifiedFrom,
                    "modifiedToList": modifiedTo,
                    "rootPath": $scope.rootPath
                }
            }).then(function(response) {
                $rootScope.assetVersionDetails = response.data.data
            })
        }
    }
    $('#assetVersionModal').on('hidden.bs.modal', function() {
        $scope.checkAll = [];
        $scope.filterListData = {};
        $scope.columnSearchList = {};
        $scope.columnAssetVersionFilterSearch = {};
        $rootScope.assetVersionDetails = {};
        $scope.checkfileType()
    })
    $rootScope.assetDeleteModal = function(paramCheck) {
        $rootScope.setParam = paramCheck;
        $rootScope.deleteReqList = "LATEST VERSION";
        var length = 0;
        if (paramCheck === 'ASSET') {
            document.getElementById("tempbucketerr").innerHTML = "";
            length = Object.keys($rootScope.downloadUploadList).length
        } else {
            document.getElementById("tempbucketAssetShelferr").innerHTML = "";
            length = Object.keys($rootScope.downloadShelfUploadList).length
        }
        if (length == '0') {
            if (paramCheck === 'ASSET') {
                document.getElementById("tempbucketerr").innerHTML = "Please select the asset to delete";
                return !1
            } else {
                document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select the asset to delete";
                return !1
            }
        } else if (length > '10') {
            if (paramCheck === 'ASSET') {
                document.getElementById("tempbucketerr").innerHTML = "Please select less than 10 records to delete";
                return !1
            } else {
                document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select less than 10 records to delete";
                return !1
            }
        }
        var count = 0;
        if (paramCheck === 'ASSET') {
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                if (!key[0].format) {
                    count++
                }
            })
        } else {
            angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
                if (!key[0].format) {
                    count++
                }
            })
        }
        if (count > 0) {
            if (paramCheck === 'ASSET') {
                document.getElementById("tempbucketerr").innerHTML = "Please select Format";
                return !1
            } else {
                document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select Format";
                return !1
            }
        } else {
            angular.element(".collection-drawer-mixin").removeClass('maximize');
            $('#assetdeleterequest').modal('toggle')
        }
    };
    $scope.assetDlteReqAllFrmt = function(chk) {
        $rootScope.deleteReqList = chk
    };
    $rootScope.assetDlteAllFrmt = [];
    $scope.deleteRequest = function() {
        var paramCheck = $rootScope.setParam;
        var comments = angular.element("#deleteReqCmt").val();
        if ($rootScope.deleteReqList === 'LATEST VERSION') {
            if (paramCheck === 'ASSET') {
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    $rootScope.assetDlteAllFrmt.push({
                        "isbn": key[0].isbn,
                        "title": key[0].title,
                        "author": key[0].author,
                        "formatName": key[0].format,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId
                    })
                })
            } else {
                angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
                    $rootScope.assetDlteAllFrmt.push({
                        "isbn": key[0].isbn,
                        "title": key[0].title,
                        "author": key[0].author,
                        "formatName": key[0].format,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId
                    })
                })
            }
        } else {
            if (paramCheck === 'ASSET') {
                angular.forEach($rootScope.downloadUploadList, function(key, value) {
                    $rootScope.assetDlteAllFrmt.push({
                        "isbn": key[0].isbn,
                        "title": key[0].title,
                        "author": key[0].author,
                        "formatName": key[0].format,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId
                    })
                })
            } else {
                angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
                    $rootScope.assetDlteAllFrmt.push({
                        "isbn": key[0].isbn,
                        "title": key[0].title,
                        "author": key[0].author,
                        "formatName": key[0].format,
                        "formatId": key[0].formatId,
                        "loggedUser": $rootScope.loggedUser.userId
                    })
                })
            }
        }
        $http({
            method: 'POST',
            url: '/insertAssetDeleteRequest',
            data: {
                "requestType": $scope.deleteReqList,
                "comments": comments,
                "assetData": $rootScope.assetDlteAllFrmt
            }
        }).then(function(response) {
            $rootScope.assetDlteAllFrmt = [];
            angular.element($(".collection-drawer-mixin")).removeClass('maximize');
            if (response.data.code == '200') {
                if (paramCheck === 'ASSET') {
                    angular.forEach($rootScope.downloadUploadList, function(key, value) {
                        var downloadtemplateData = {};
                        downloadtemplateData["[format-name]"] = key[0].format;
                        downloadtemplateData["[isbn]"] = key[0].isbn;
                        downloadtemplateData["[title]"] = key[0].title;
                        downloadtemplateData["[author]"] = key[0].author;
                        downloadtemplateData["[approved-by]"] = $rootScope.loggedUser.firstName;
                        $http({
                            method: 'POST',
                            url: '/saveTransaction',
                            data: {
                                isbn: key[0].isbn,
                                format: {
                                    "formatName": key[0].format,
                                    "formatId": key[0].formatId
                                },
                                title: key[0].title,
                                userId: $rootScope.loggedUser.userId,
                                transactionStatus: "21",
                                transactionType: "ASSET_DELETE_REQUEST",
                                templateData: downloadtemplateData
                            }
                        }).then(function(response) {})
                    })
                } else {
                    angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
                        var downloadtemplateData = {};
                        downloadtemplateData["[format-name]"] = key[0].format;
                        downloadtemplateData["[isbn]"] = key[0].isbn;
                        downloadtemplateData["[title]"] = key[0].title;
                        downloadtemplateData["[author]"] = key[0].author;
                        downloadtemplateData["[approved-by]"] = $rootScope.loggedUser.firstName;
                        $http({
                            method: 'POST',
                            url: '/saveTransaction',
                            data: {
                                isbn: key[0].isbn,
                                format: {
                                    "formatName": key[0].format,
                                    "formatId": key[0].formatId
                                },
                                title: key[0].title,
                                userId: $rootScope.loggedUser.userId,
                                transactionStatus: "21",
                                transactionType: "ASSET_DELETE_REQUEST",
                                templateData: downloadtemplateData
                            }
                        }).then(function(response) {})
                    })
                }
                $rootScope.assetDltSuccessDetails = !0;
                $rootScope.assetDltSuccessMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.assetDltSuccessDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.assetDltErrDetails = !0;
                $rootScope.assetDltErrMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.assetDltErrDetails = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {});
        angular.element("#assetdeleterequest").modal("toggle");
        $scope.assetDlteAllFrmt = [];
        angular.element("#deleteReqCmt").val("")
    }
    $scope.deleteRequestReset = function() {
        $scope.assetDlteAllFrmt = [];
        angular.element("#deleteReqCmt").val("")
    }
    $scope.assetFolderGetFolList = function(folder) {
        var folderName = folder.replace("_folder", "");
        if ($scope.assetappendFolderName == null || $scope.appendFolderName == "") {
            $scope.assetappendFolderName = folder
        } else {
            $scope.assetappendFolderName = $scope.assetappendFolderName + "/" + folder
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.multiFolderStrFrmtNme,
                productIDValue: $scope.multiFolderStrIsbn,
                formatId: $scope.multiFolderStrFrmtId,
                folder: folderName
            }
        }).then(function(response) {
            $scope.assetFolderStrData = response.data.data
        })
    };
    $scope.AssetReturnFolder = function() {
        var folder = $scope.assetappendFolderName.split('/');
        folder.pop();
        if (folder == "") {
            $scope.assetappendFolderName = ""
        } else {
            $scope.assetappendFolderName = folder.join('/')
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.multiFolderStrFrmtNme,
                productIDValue: $scope.multiFolderStrIsbn,
                formatId: $scope.multiFolderStrFrmtId,
                folder: $scope.assetappendFolderName
            }
        }).then(function(response) {
            $scope.assetFolderStrData = response.data.data
        })
    }
    $scope.setWMSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#wmSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.orderTypeSelection = "Select";
    $scope.selectedFormatId = "";
    $scope.wmModal = function(checkParam) {
        var myEl = angular.element(document.querySelector('#wmModalId'));
        myEl.removeAttr('data-toggle', "modal");
        myEl.removeAttr('data-target', "#wm_Modal");
        var length = 0;
        if (checkParam === 'ASSET') {
            document.getElementById("tempbucketerr").innerHTML = "";
            length = Object.keys($rootScope.downloadUploadList).length
        } else {
            document.getElementById("tempbucketAssetShelferr").innerHTML = "";
            length = Object.keys($rootScope.downloadShelfUploadList).length
        }
        $rootScope.wmIsbnList = [];
        $rootScope.wmFormatList = [];
        $rootScope.myData = {};
        var wmFlg = !0;
        $rootScope.IsbnList = "";
        if (length > '0') {
            $http({
                method: 'GET',
                url: '/getWMEligibleFormats'
            }).then(function successCallback(response) {
                $scope.validFormatIds = [];
                $scope.validFormatTypes = [];
                angular.forEach(response.data.data.eligibleFormats, function(val) {
                    $scope.validFormatIds.push(val.displayFormatId);
                    $scope.validFormatTypes.push(val.watermarkType)
                });
                if (response.data.code == "200") {
                    if (checkParam === 'ASSET') {
                        $.each($rootScope.downloadUploadList, function(index, key, value) {
                            if (undefined == key[0].format || null == key[0].format || ($scope.validFormatIds.indexOf(key[0].formatId) == -1)) {
                                wmFlg = !1;
                                return !1
                            } else {
                                angular.forEach(response.data.data.eligibleFormats, function(val) {
                                    if (key[0].formatId === val.displayFormatId) {
                                        if (undefined == $rootScope.myData[key[0].isbn]) {
                                            $rootScope.myData[key[0].isbn] = val.formatMap
                                        } else {
                                            var data = $rootScope.myData[key[0].isbn];
                                            $rootScope.myData[key[0].isbn] = data + "+" + val.formatMap
                                        }
                                    }
                                })
                            }
                        })
                    } else {
                        $.each($rootScope.downloadShelfUploadList, function(index, key, value) {
                            if (undefined == key[0].format || null == key[0].format || ($scope.validFormatIds.indexOf(key[0].formatId) == -1)) {
                                wmFlg = !1;
                                return !1
                            } else {
                                angular.forEach(response.data.data.eligibleFormats, function(val) {
                                    if (key[0].formatId === val.displayFormatId) {
                                        if (undefined == $rootScope.myData[key[0].isbn]) {
                                            $rootScope.myData[key[0].isbn] = val.formatMap
                                        } else {
                                            var data = $rootScope.myData[key[0].isbn];
                                            $rootScope.myData[key[0].isbn] = data + "+" + val.formatMap
                                        }
                                    }
                                })
                            }
                        })
                    }
                    angular.forEach($rootScope.myData, function(key, value) {
                        $rootScope.wmIsbnList.push(value);
                        $rootScope.wmFormatList.push(key)
                    })
                    if (length > '10') {
                        if (checkParam === 'ASSET') {
                            document.getElementById("tempbucketerr").innerHTML = "Please select less than 10 records to watermark request ";
                            return !1
                        } else {
                            document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select less than 10 records to watermark request ";
                            return !1
                        }
                    }
                    if (wmFlg) {
                        myEl.attr('data-toggle', "modal");
                        myEl.attr('data-target', "#wm_Modal");
                        $('#wm_Modal').modal('toggle');
                        angular.element($(".collection-drawer-mixin")).removeClass('maximize')
                    } else {
                        myEl.removeAttr('data-toggle', "modal");
                        myEl.removeAttr('data-target', "#wm_Modal");
                        if (checkParam === 'ASSET')
                            document.getElementById("tempbucketerr").innerHTML = "Please select only assets with " + $scope.validFormatTypes.toString() + " formats";
                        else document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select only assets with " + $scope.validFormatTypes.toString() + " formats"
                    }
                } else {
                    if (checkParam === 'ASSET')
                        document.getElementById("tempbucketerr").innerHTML = "No Formats configured for Water-Mark Request";
                    else document.getElementById("tempbucketAssetShelferr").innerHTML = "No Formats configured for Water-Mark Request"
                }
            }, function errorCallback(response) {})
        } else {
            var myEl = angular.element(document.querySelector('#wmModalId'));
            myEl.removeAttr('data-toggle', "modal");
            myEl.removeAttr('data-target', "#wm_Modal");
            if (checkParam === 'ASSET')
                document.getElementById("tempbucketerr").innerHTML = "Please select the asset for Water-Mark";
            else document.getElementById("tempbucketAssetShelferr").innerHTML = "Please select the asset for Water-Mark"
        }
    };
    $rootScope.disabledBtnClick = function() {
        $rootScope.userDisableBtn = !0;
        $timeout(function() {
            $rootScope.userDisableBtn = !1
        }, 5000)
    }
    $rootScope.disabledBtnClickQuick = function() {
        $rootScope.userDisableBtnQuick = !0;
        $timeout(function() {
            $rootScope.userDisableBtnQuick = !1
        }, 3000)
    }
    $scope.saveWM = function() {
        angular.element(document.getElementById('wmSendButton'))[0].disabled = !0;
        $scope.loadingWM = !0;
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        today = mm + '/' + dd + '/' + yyyy;
        var uniqueId = 'order-' + Math.random().toString(36).substr(2, 16);
        var wmEmailList = $scope.wmEmailId.split(",").map(function(item) {
            return item.trim()
        });
        wmEmailList = wmEmailList.filter(function(e) {
            return e
        });
        var emailIds = "";
        angular.forEach(wmEmailList, function(email) {
            if ("" === emailIds) {
                emailIds = email
            } else {
                emailIds = emailIds + "," + email
            }
        })
        var drmSource = "Bloomsbury.com";
        $http({
            method: 'POST',
            url: '/saveWaterMark',
            data: {
                drmSource: drmSource,
                isbn: $rootScope.wmIsbnList.toString(),
                deviceFormat: $rootScope.wmFormatList.toString(),
                clientEmail: emailIds,
                clientName: $scope.wmClientName,
                clientId: $rootScope.loggedUser.userId,
                orderId: uniqueId,
                orderDate: today,
                orderType: $scope.orderTypeSelection.code,
            }
        }).then(function(response) {
            $scope.loadingWM = !1;
            $scope.cancelWMSave();
            var alertText = "";
            if (response.data.code == '200') {
                $rootScope.showWMSuccessMsg = !0;
                $rootScope.WMSuccessMsg = "SUCESS_WATERMARK_REQUEST";
                setTimeout(function() {
                    $rootScope.showWMSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.showWMErrorMsg = !0;
                $rootScope.WMErrorMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showWMErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {})
    }
    $scope.cancelWMSave = function() {
        $scope.wmClientName = null;
        $scope.wmEmailId = null;
        $scope.orderTypeSelection = "Select";
        $rootScope.wmIsbnList = [];
        $rootScope.wmFormatList = [];
        $scope.WMForm.$setPristine();
        $scope.WMForm.$setUntouched();
        $scope.WMForm.$error = {};
        $scope.WMForm.$submitted = !1;
        $('#wm_Modal').modal('toggle')
    };
    $scope.waterMrkOrderType = [{
        code: "REVIEW",
        description: "Review",
    }, {
        code: "PAID",
        description: "Paid",
    }, {
        code: "AUTHOR-COPY",
        description: "Author Copy",
    }, {
        code: "ACADEMIC-REVIEW",
        description: "Academic Review",
    }]
    $scope.setOrderType = function(val) {
        $scope.orderTypeSelection = val
    }
    $scope.columSearchFilter = function(fieldname, lookup) {
        if (lookup == !0) {
            if (fieldname == "Uploaded") {
                fieldname = "Uploaded By"
            }
            var suggestionText = $rootScope.columnFilterSearch[fieldname] == undefined ? "" : $rootScope.columnFilterSearch[fieldname];
            $rootScope.getColumnFilterSuggestions(fieldname, suggestionText, lookup)
        }
        angular.element('.header-filter-dropdown').removeClass("active")
    }
    $scope.reportHeaderFilter = function() {
        angular.element(".search-dropdown-content").removeClass('active')
    }


    $scope.check = function(form) {
            if (form.password.$valid) {
                return !1
            } else {
                return !0
            }
        };
        $rootScope.forgotPopup;
        $scope.loginBtnStatus = !0;
        $scope.get_action = function(form) {
            if (form.$valid) {
                $scope.loading = !0;
                $scope.loginBtnStatus = !0;
               $scope.Login(form)
                        }
                  
        }
    
        $rootScope.isAuthenticated = !1;
        $scope.Login = function(form) {
            $http({
                method: 'POST',
                url: '/login',
                data: {
                    emailId:$rootScope.loggedUser.emailId,
                    password: $scope.password,
                    clientIp: $window.sessionStorage.userIP
                }
            }).then(function(response) {
                $scope.loading = !1;
                $scope.loginBtnStatus = !1;
                if (response.data.status == 'success' || response.data.status == 'LOGIN.SUCCESS') {
                    angular.element("#reloadrequest").modal('toggle');
                    $rootScope.isAuthenticated = !0;
                    $window.sessionStorage.device = $rootScope.isAuthenticated;
                    localStorage.clear();
                    location.reload();
                    $scope.login_error = "";
                     location.href = '/'
                } else {
                    var status = response.data.status;
                    form.$setValidity('error', !1);
                    form.password.$setValidity('captcha_validation', !0);
                    $scope.login_error = status;
                    $scope.loading = !1
                }
            }, function(response) {})
        };

        $scope.removeremember = function() {
            $cookies.remove("cmusername");
            $cookies.remove("remember")
        }
        $scope.pwdformvalidate = function(forgotForm) {
            if (forgotForm.$error.error) {
                forgotForm.$error.error = !1;
                forgotForm.$valid = !0
            }
        }
        $scope.formvalidate = function(loginForm) {
            if (loginForm.$error.error) {
                loginForm.$error.error = !1;
                loginForm.$valid = !0;
                loginForm.password.$setValidity('captcha_validation', !0)
            }
        }
        $scope.showpCFtpPassword = function (ftpType) {
            var p = document.getElementById("password");
            p.setAttribute('type', 'text');
        }

    $scope.hidepCFtpPassword = function (ftpType) {
        var p = document.getElementById("password");
        p.setAttribute('type', 'password');
    }

    $scope.dropCallback = function(index, item, external, type) {
        // Return false here to cancel drop. Return true if you insert the item yourself.
        // roll down and delete any empty columns//
        var model = $scope.models.dropzones;
        for (var y in model.B) {
          for (var zz in model.B[y].columns) {
            var myColumns = [];
            var foundThem = false;
            if (Array.isArray(model.B[y].columns[zz])) {
              $scope.models.dropzones.B[y].columns.splice(zz, 1);
            } 
          }
        }
        
        return item;
      };
  
      $scope.$watch('gridHeaders', function(model) {
        $scope.modelAsJson = angular.toJson(model, true);
      }, true);
 
    angular.element(document).ready(function() {
        angular.element(document).click(function(e) {
            if (e.target.id != 'nav-bar' && e.target.id != 'master-multi-dropdown' && e.target.id != 'txtSearch' && !angular.element(e.target).parents().hasClass('drop-gear') && !angular.element(e.target).parents().hasClass('search-box')) {
                $(".nav-select-menu").removeClass("active");
                $(".header-dropdown-select").removeClass("active");
                $(".dropdown-toggle").removeClass("active");
                $(".multi-dropdown").removeClass("open");
                $(".single-select-dropdown").removeClass("active")
            }
        });
        angular.element(document).click(function(e) {
            angular.element(".menu-side-edit-input").css("display", "none");
            angular.element(".sub-menu-title-label").css("display", "block");
            angular.element(".menu-side-edit-inputs" + $rootScope.reportIndex).hide();
            angular.element(".sub-menu-title-label").show()
        });
        angular.element(".dropdown-notification").click(function() {
            angular.element('.header-filter-dropdown').removeClass("active");
            angular.element('.header-filter').removeClass("active");
            angular.element(".single-select-dropdown").removeClass("active");
            angular.element(".dropdown-toggle").removeClass("active");
            angular.element(".search-dropdown-content").removeClass("active");
            angular.element(".gear-Select").removeClass("active");
            angular.element(".menu-action").removeClass('menu-action-list');
            angular.element(".menu-accordion").removeClass('menu-action-list');
            angular.element(".isbn-icon").removeClass('active');
            angular.element(".has-sub").removeClass('open')
        });
        angular.element(".single-dropdown").click(function() {
            angular.element(".gear-Select").removeClass("active");
            angular.element(".gear-Select").removeClass("active");
            angular.element(".menu-action").removeClass('menu-action-list');
            angular.element(".menu-accordion").removeClass('menu-action-list')
        });
        angular.element(document).ready(function() {
            angular.element(".header-dropdown,.dropdown-user-link").click(function() {
                angular.element(".dropdown").removeClass("open");
                angular.element('.header-filter-dropdown').removeClass("active");
                angular.element('.header-filter').removeClass("active");
                angular.element(".gear-Select").removeClass("active");
                angular.element(".menu-action").removeClass('menu-action-list');
                angular.element(".menu-accordion").removeClass('menu-action-list')
            })
            angular.element(".dropdown-user-link").click(function() {
                angular.element(".single-select-dropdown").removeClass("active");
                angular.element(".dropdown-toggle").removeClass("active");
                angular.element(".dropdown-user").addClass("open");
                angular.element(".gear-Select").removeClass("active")
            })
        });
        angular.element(document).click(function(e) {
            if (!angular.element(e.target).parents().hasClass('filter-container') && !angular.element(e.target).parents().hasClass('multi-dropdown') && !angular.element(e.target).parents().hasClass('label') && !angular.element(e.target).parents().hasClass('search-box') && !angular.element(e.target).parents().hasClass('filter-bottom-button')) {
                angular.element(".info-details-content").removeClass("active");
                angular.element(".header-filter-dropdown").removeClass("active");
                angular.element('.header-filter').removeClass("active");
                angular.element(".search-dropdown-content").removeClass("active")
            }
        });
        angular.element(document).click(function(e) {
            if (!angular.element(e.target).parents().hasClass('menu-action-dropdown') && !angular.element(e.target).parents().hasClass('view-right')) {
                angular.element(".menu-action").removeClass('menu-action-list');
                angular.element(".menu-accordion").removeClass('menu-action-list');
                angular.element(".asset-more").removeClass('active');
                angular.element(".isbn-icon").removeClass('active');
                angular.element(".drop-cp-menu").removeClass("active")
            }
        });
        $scope.sideLeftSub = function() {
            angular.element('.header-filter-dropdown').removeClass("active");
            angular.element('.header-filter').removeClass("active");
            angular.element(".single-select-dropdown").removeClass("active");
            angular.element(".dropdown-toggle").removeClass("active");
            angular.element(".search-dropdown-content").removeClass("active");
            angular.element(".gear-Select").removeClass("active");
            angular.element(".menu-action").removeClass('menu-action-list');
            angular.element(".menu-accordion").removeClass('menu-action-list');
            angular.element(".isbn-icon").removeClass('active');
            angular.element(".dropdown-notification").removeClass('open')
        }
        var d = new Date();
        var fullyear = d.getFullYear();
        $rootScope.fullYear = fullyear
    });
    $('#datetimepicker').datetimepicker({
        minDate: new Date(),
        format: 'DD/MM/YYYY',
    });
    
    
   
    
    $rootScope.toggleChart = function(){
        angular.element('#chartmodal').slideToggle();
    }
    $rootScope.titleActionFilter = [];
    $rootScope.titleActionSelct = function(slt, chk) {
        if (chk) {
            angular.forEach($rootScope.titleShowIsbnHistory, function(item) {
                if (item.transactionType == slt)
                    item.selected = !0
            })
        } else {
            angular.forEach($rootScope.titleShowIsbnHistory, function(item) {
                if (item.transactionType == slt)
                    item.selected = !1
            })
        }
        if (chk) {
            $rootScope.titleActionFilter.push(slt)
        } else {
            $rootScope.titleActionFilter = $filter('filter')($rootScope.titleActionFilter, function(data) {
                return (data != slt)
            })
        }
        angular.element("#titledatashowisbnhistory").scrollLeft(0);
        var container = document.getElementById("titledatashowisbnhistory");
        container.scrollTop = 0
    }
    $rootScope.histDataFilter = function(data) {
        var result = !1;
        if ($rootScope.titleActionFilter.length == 0 || $rootScope.titleActionFilter.indexOf(data.transactionType) != -1) {
            result = !0
        }
        return result
    }
}]);
app.directive('modal', function() {
    return {
        template: '<div class="modal fade">' + '<div class="modal-dialog">' + '<div class="modal-content">' + '<div class="modal-header">' + '<button type="button" class="modal-close" data-dismiss="modal" aria-hidden="true"> <i class="cp-close"></i> </button>' + '<h5 class="modal-title">{{ title }}</h5>' + '</div>' + '<div class="modal-body" ng-transclude></div>' + '</div>' + '</div>' + '</div>',
        restrict: 'E',
        transclude: !0,
        replace: !0,
        scope: !0,
        link: function postLink(scope, element, attrs) {
            scope.title = attrs.title;
            scope.$watch(attrs.visible, function(value) {
                if (value == !0)
                    $(element).modal('show');
                else $(element).modal('hide')
            });
            $(element).on('shown.bs.modal', function() {
                scope.$apply(function() {
                    scope.$parent[attrs.visible] = !0
                })
            });
            $(element).on('hidden.bs.modal', function() {
                scope.$apply(function() {
                    scope.$parent[attrs.visible] = !1
                })
            })
        }
    }
});
app.directive('singleSelectDropdown', function() {
    return {
        link: function(scope, element, attrs) {
            element.unbind('click').bind('click', function(e) {
                e.stopPropagation();
                angular.element(jQuery(".single-select-dropdown,.multi-select-dropdown,.toggle-select")).not(element.parent('.single-dropdown').children('.single-select-dropdown,.toggle-select')).removeClass('active');
                element.toggleClass('active');
                element.parent('.single-dropdown').children('.single-select-dropdown').toggleClass('active');
                element.parent('.single-dropdown').children('.single-select-dropdown').focus()
            })
        },
    }
});
app.directive('columnSelectDropdown', function() {
    return {
        link: function(scope, element, attrs) {
            element.unbind('click').bind('click', function(e) {
                e.stopPropagation();
                angular.element('.gear-Select').toggleClass('active');
                angular.element('.column-filter-dropdown').toggleClass('active')
            })
        },
    }
});
app.directive('singleSelectDropdownSearch', function() {
    return {
        link: function(scope, element, attrs) {
            element.unbind('click').bind('click', function() {
                angular.element(jQuery(".single-select-dropdown,.multi-select-dropdown,.toggle-select")).not(element.parent('.single-dropdown').children('.single-select-dropdown,.toggle-select')).removeClass('active');
                element.toggleClass('active');
                element.parent('.single-dropdown').children('.single-select-dropdown').toggleClass('active');
                element.parent('.single-dropdown').children('.single-select-dropdown').focus()
            })
        },
    }
});
app.directive('singleSelectDropdownItem', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.closest('.single-select-dropdown').removeClass('active')
            })
        },
    }
});
app.directive('multiSelectDropdown', function() {
    return {
        link: function(scope, element, attrs) {
            element.unbind('click').bind('click', function(event) {
                angular.element(jQuery(".single-select-dropdown,.multi-select-dropdown,.toggle-select")).not(element.parent('.multi-dropdown').children('.multi-select-dropdown,.toggle-select')).removeClass('active');
                element.parent('.multi-dropdown').children('.multi-select-dropdown').toggleClass('active');
                element.parent('.multi-dropdown').children('.multi-select-dropdown').focus()
            })
        },
    }
});
app.directive('menuAction', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element(".isbn-icon").not(element).removeClass('active');
                element.children('i').addClass("active");
                angular.element(".menu-action").removeClass("menu-action-list");
                element.next(".menu-action").addClass("menu-action-list");
                angular.element(".main-menu").addClass("menu-action-list")
            })
        },
    }
});
app.directive('menuActionClose', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element(".isbn-icon").removeClass('active');
                element.parents(".menu-action").removeClass("menu-action-list");
                angular.element(".main-menu").removeClass("menu-action-list")
            })
        },
    }
});
app.directive('scrollBodyY', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('perfectScrollbar', function() {
                suppressScrollY: !0
            })
        },
    }
});
app.directive('scrollBodyX', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('perfectScrollbar', function() {
                suppressScrollX: !0
            })
        },
    }
});
app.directive('switch', function() {
    return {
        restrict: 'AE',
        replace: !0,
        transclude: !0,
        template: function(element, attrs) {
            var html = '';
            html += '<span';
            html += ' class="switch' + (attrs.class ? ' ' + attrs.class : '') + '"';
            html += attrs.ngModel ? ' ng-click="' + attrs.disabled + ' ? ' + attrs.ngModel + ' : ' + attrs.ngModel + '=!' + attrs.ngModel + (attrs.ngChange ? '; ' + attrs.ngChange + '()"' : '"') : '';
            html += ' ng-class="{ checked:' + attrs.ngModel + ', disabled:' + attrs.disabled + ' }"';
            html += '>';
            html += '<small></small>';
            html += '<input type="checkbox"';
            html += attrs.id ? ' id="' + attrs.id + '"' : '';
            html += attrs.name ? ' name="' + attrs.name + '"' : '';
            html += attrs.ngModel ? ' ng-model="' + attrs.ngModel + '"' : '';
            html += ' style="display:none" />';
            html += '<span  ><i style="line-height:1.5;color:white" class="cp-checkmark"></i></span>'
            html += '</span>';
            return html
        }
    }
});
app.directive('isActive', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent().children('li').removeClass('active');
                element.addClass('active')
            })
        },
    }
});
app.directive('folderOpen', function($parse) {
    return {
        link: function(scope, element, attrs) {
            element.on('click', function(e) {
                angular.element($(".single-select-dropdown")).removeClass('active');
                var ele = e.target;
                angular.element(ele).toggleClass('folder-open');
                e.stopPropagation()
            })
        },
    }
});
app.directive('drawerHeader', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".collection-drawer-mixin")).toggleClass('maximize')
            })
        },
    }
});
app.directive('drawerHeaderToggle', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent('.collection-drawer-contend').children(".drawer-header").removeClass('active');
                element.addClass('active');
                angular.element($(".collection-drawer-mixin")).addClass('maximize')
            })
        },
    }
});
app.directive('cpMore', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element(".isbn-icon").not(element).removeClass('active');
                element.addClass("active");
                angular.element(".drop-cp-menu").not(element.next('.drop-cp-menu')).removeClass('active');
                element.next('.drop-cp-menu').toggleClass('active')
            })
        },
    }
});
app.directive('removeBorderbox', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent().parent('.row-border-box').remove()
            })
        },
    }
});
app.directive('cpMoreItem', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.closest('.drop-cp-menu').removeClass('active')
            })
        },
    }
});
app.controller('ModalController', function($scope, close) {
    $scope.close = function(result) {
        close(result, 500)
    }
});
app.filter('bytes', function() {
    return function(bytes, precision) {
        if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) return '-';
        if (typeof precision === 'undefined') precision = 1;
        var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'],
            number = Math.floor(Math.log(bytes) / Math.log(1024));
        return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) + ' ' + units[number]
    }
});
app.directive('openFilterDropdown', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element(".header-filter").not(element).removeClass('active');
                angular.element(".header-filter-dropdown").not(element.next('.header-filter-dropdown')).removeClass('active');
                element.toggleClass('active');
                element.parent('.filter-dropdown').children('.header-filter-dropdown').toggleClass('active')
            })
        },
    }
});
app.directive('filterClose', function() {
    return {
        restrict: 'C',
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.closest(".filter-dropdown").children('.header-filter').removeClass('active');
                element.closest(".header-filter-dropdown").removeClass('active')
            })
        },
    }
});
app.directive('password', function() {
    return {
        link: function(scope, element, attrs) {
            element.unbind('focus').bind('focus', function(event) {
                element.prop('type', 'password')
            })
        },
    }
});
app.directive('numbersOnly', function() {
    return {
        require: '?ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return
            }
            ngModelCtrl.$parsers.push(function(val) {
                if (angular.isUndefined(val)) {
                    var val = ''
                }
                var clean = val.replace(/[^-0-9\.]/g, '');
                var negativeCheck = clean.split('-');
                var decimalCheck = clean.split('.');
                if (!angular.isUndefined(negativeCheck[1])) {
                    negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                    clean = negativeCheck[0] + '-' + negativeCheck[1];
                    if (negativeCheck[0].length > 0) {
                        clean = negativeCheck[0]
                    }
                }
                if (!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0, 2);
                    clean = decimalCheck[0] + '.' + decimalCheck[1]
                }
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render()
                }
                return clean
            });
            element.bind('keypress', function(event) {
                if (event.keyCode === 32 || event.keyCode === 45 || event.keyCode === 46 || event.charCode === 45 || event.charCode === 46) {
                    event.preventDefault()
                }
            })
        }
    }
});
app.directive('onScrollToBottom', function($document, $rootScope) {
    return {
        restrict: 'A',
        link: function($scope, element, attrs) {
            $('#divTableBody').bind('scroll', function() {
                var searchflag = $rootScope.searchFlag;
                var searchname = $rootScope.searchName;
                if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                    $rootScope.LastCurrentIndex = $rootScope.currentIndexLast;
                    $rootScope.skipCountScroll = $rootScope.LastCurrentIndex;
                    if ($rootScope.currentIndexLast < $rootScope.searchCount) {
                        if ($rootScope.searchCount.toString() === $rootScope.searchResult.length.toString()) {
                            return
                        }
                        $rootScope.currentIndexLast = $rootScope.searchResult.length;
                        return !1
                    } else {
                        return !1
                    }
                }
            })
        }
    }
});
app.directive('newDateFocus', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent().parent().children('.newdate').focus();
                element.parent().children('.newdate').focus()
            })
        },
    }
});
app.directive('dateFocus', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent().parent().children('.datepicker').focus();
                element.parent().children('.angDatePicker').focus();
                element.parent().children('.datepicker').focus()
            })
        },
    }
});
app.directive('commonScrollTop', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('keyup', function() {
                var container = element.parents('.search-dropdown-content').children('.dropdown-status-set');
                container[0].scrollTop = 0
            })
        },
    }
});
app.directive('customScrollTop', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('keyup', function() {
                var container = element.parents('.parent-filter-group').children('.child-dropdown-status');
                container[0].scrollTop = 0
            })
        },
    }
});
app.directive('commonTableScrollTop', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element("#assetdivTableBody").scrollLeft(0);
                var container = document.getElementById("assetdivTableBody");
                container.scrollTop = 0
            })
        },
    }
});
app.directive('closeNotification', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".dropdown-notification")).removeClass('open')
            })
        },
    }
});
app.directive('assetScrollTop', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                var container = document.getElementById("titledatashowisbnhistory");
                container.scrollTop = 0;
                angular.element('#titleShowIsbnHistory').modal('toggle')
            })
        },
    }
});
app.directive('leftMenuClickClose', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element(".dropdown").removeClass("open");
                angular.element(".gear-Select").removeClass("active");
                angular.element('.header-filter-dropdown').removeClass("active");
                angular.element('.header-filter').removeClass("active");
                angular.element(".single-select-dropdown").removeClass("active");
                angular.element(".multi-select-dropdown").removeClass("active");
                angular.element(".dropdown-toggle").removeClass("active");
                angular.element(".isbn-icon").removeClass('active')
            })
        },
    }
});
app.directive('searchDataHeight', function() {
    return {
        link: function(scope, elem, attrs) {
            scope.$watch(function() {
                if (elem.height() > 100) {
                    angular.element(".searchdataheight").addClass('save-search-data');
                }
            })
        }
    }
});
app.directive('namingConvention', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".info-details-content")).toggleClass('active')
            })
        },
    }
});
app.filter("ColumnSearchFilter", function() {
    return function(input) {
        var out = [];
        for (var i = input.length - 1; i >= 0; i--) {
            out.push(input[i])
        }
        return out
    }
});
app.filter('unique', function() {
    return function(collection, keyname) {
        var output = [],
            keys = [];
        angular.forEach(collection, function(item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item)
            }
        });
        return output
    }
});
app.factory('socket', function(socketFactory) {
    return socketFactory({})
})
app.directive('newlineToComma', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function(inputValue) {
                var transformedInput = (!inputValue) ? '' : inputValue.replace(/\r\n|\n/g, ',');
                modelCtrl.$setViewValue(transformedInput);
                modelCtrl.$render();
                return transformedInput
            })
        }
    }
})
app.directive("scroll", function($window) {
    return function(scope, element, attrs) {
        angular.element(".divTableBody.responsiveScroll").bind("scroll", function() {
            if (this.scrollTop >= 500) {
                angular.element(".navbar-container").addClass('bg-green');
                angular.element(".table-top-hide").hide();
                angular.element(".tab-titles").css("height", "0");
                angular.element(".table-top-show").show();
                angular.element(".body").addClass('menu-collapsed');
                angular.element(".content-wrapper").addClass('padding0');
                angular.element(".body").removeClass('menu-expanded');
                angular.element(".nav-menu-main").removeClass('is-active');
                angular.element('.brand-logo').attr('src', 'resources/images/cp-logo-small.png')
            } else {
                angular.element(".navbar-container").removeClass('bg-green');
                angular.element(".table-top-hide").show();
                angular.element(".tab-titles").css("height", "auto");
                angular.element(".table-top-show").hide();
                angular.element(".content-wrapper").removeClass('padding0');
                angular.element(".body").removeClass('menu-collapsed');
                angular.element(".nav-menu-main").addClass('is-active');
                angular.element('.brand-logo').attr('src', 'resources/images/cp-logo-light.png')
            }
            scope.$apply()
        })
    }
});
app.directive('scroll', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".info-details-content")).toggleClass('active')
            })
        },
    }
});
app.directive('mainMenuLink', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parent(".nav-item").children('.menu_list').toggleClass('open')
            })
        },
    }
});
app.directive('menuOption', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".menu-action")).removeClass('open-action');
                element.parents(".sub_main_menu_li").children('.menu-action').toggleClass('open-action')
            })
        },
    }
});
app.directive('dragDrop', function() {
   
    return {
        scope:{},
        //controller: 'BaseController',
        link: function($rootScope, element, attrs) {
            element.bind('drag', function() {
               
                element.on('dragend', function(event) {
                    event = event.originalEvent || event;
                    if (!event._dndHandle) {
                        $rootScope.searchSaveEnable = true;
                      event.stopPropagation();
                    }
                  });
            })
        },
    }
});


app.directive('liActive', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                angular.element($(".menu_list_action")).removeClass('active');
                element.addClass('active')
            })
        },
    }
});
app.directive('closeOverlay', function() {
    return {
        link: function(scope, element, attrs) {
            element.bind('click', function() {
                element.parents(".collection-drawer-mixin").removeClass('maximize')
            })
        },
    }
});
app.directive('characterOnly', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z]/g, '');
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render()
                }
                return transformedInput
            }
            ngModelCtrl.$parsers.push(fromUser)
        }
    }
});
app.directive('numberCharacter', function() {
    function link(scope, elem, attrs, ngModel) {
        ngModel.$parsers.push(function(viewValue) {
            var reg = /^[a-zA-Z0-9.]*$/;
            if (viewValue.match(reg)) {
                return viewValue
            }
            var transformedValue = ngModel.$modelValue;
            ngModel.$setViewValue(transformedValue);
            ngModel.$render();
            return transformedValue
        })
    }
    return {
        restrict: 'A',
        require: 'ngModel',
        link: link
    }
});
app.directive('floatingLabel', ['$rootScope', function floatingLabel($rootScope) {
    function generateNgModelKey(inputBox) {
        var inputId = inputBox.attr('id') || '',
            inputName = inputBox.attr('name') || '';
        return 'input_' + (inputId ? inputId : inputName)
    }
    return {
        restrict: 'A',
        scope: !0,
        compile: function($element, $attrs) {
            var templateAttributes = [],
                template, attr;
            if (!$attrs.placeholder) {
                return
            }
            for (attr in $attrs) {
                if ($attrs.hasOwnProperty(attr) && attr.substr(0, 1) !== '$') {
                    templateAttributes.push(attr + '="' + $attrs[attr] + '"')
                }
            }
            if ($attrs.ngModel == undefined) {
                templateAttributes.push('ng-model="' + generateNgModelKey($element) + '"')
            } else {
                templateAttributes.push('ng-model="' + $attrs.ngModel + '"')
            }
            template = '<div class="floating-label">' + '<label for="' + $attrs.id + '"  ng-class="{ \'active\': showLabel }">' + $attrs.placeholder + '</label>' + '<input ' + templateAttributes.join(' ') + ' />' + '</div>';
            $element.replaceWith(angular.element(template));
            return {
                post: function($scope, $element, $attrs) {
                    var inputBox = $element.find('input'),
                        ngModelKey = inputBox.attr('ng-model');
                    $scope.$watch(ngModelKey, function(newValue) {
                        $scope.showLabel = (newValue && newValue.length >= 0) || (typeof newValue == 'number')
                    })
                }
            }
        }
    }
}])
