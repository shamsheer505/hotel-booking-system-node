/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
 ***********			********     	*************			*************	
19-05-2017			  1.0       	Saravanan K	  		Initial Version.
17-06-2017			  1.1       	Senthil J	  		Multilingual injection.
 ***********************************************************************************************************************/

var app = angular.module('ManageonCPLogin',
		[ 'pascalprecht.translate', 'ngRoute', 'ngCookies' ]).config(
		function($routeProvider) {

			$routeProvider
		     .when('/forgotpassword',{
		         templateUrl:"/views/forgotpassword.html",
		         controller:"LoginController",
		         title:"cP 4.0 - Forgot Password"
		            
		     })
		     .when('/userlogin',{
		         templateUrl:"/views/userlogin.html",
		         controller:"LoginController",
		         title:"cP 4.0 - Login"
		     })
		     .when('/resetpassword',{
		    	 templateUrl:"/views/resetpassword.html",
		         controller:"LoginController",
		         title:"cP 4.0 - Logins"
		     })
		     
		     .when('/',{
		         templateUrl:"/views/userlogin.html",
		         controller:"LoginController",
		         title:"cP 4.0 - Login"
		     })
		}).run(
		function($rootScope,$translate) {
			$rootScope.$on("$routeChangeSuccess", function(event, currentRoute,
					previousRoute) {
				if($rootScope.language==='undefined' || $rootScope.language ===undefined)
					$rootScope.language = 'en';
				$translate.use($rootScope.language);

			});
			
		});

app.config(function($translateProvider) {

	$translateProvider.useStaticFilesLoader({
		prefix : '../resources/lang/locale-',
		suffix : '.json'
	});
	
	$translateProvider.preferredLanguage('en');
	$translateProvider.useSanitizeValueStrategy('escape');

});
app.run(function($http,$rootScope) {
	  $http.defaults.headers.common.Authorization = $rootScope.token;
	});

app
		.controller(
				'LoginController',
				[
						'$scope',
						'$http',
						'$timeout',
						'$translate',
						'$rootScope',
						'$location',
						"$cookies",
						"$route",
						"$window",
						function($scope, $http, $timeout, $translate,
								$rootScope, $location, $cookies, $route,
								$window) {
							
							$.getJSON("https://jsonip.com?callback=?", function (data) {
							    $scope.userIP =  data.ip;
							   // alert(data.ip);
							    $window.sessionStorage.userIP = $scope.userIP;
							});
							
							
							$http.defaults.headers.common['Authorization'] = 'unregistred';

							/*Naren changes Start*/
							
							try{
								/*alert($location.search().lang);*/
								//alert($rootScope.language);
								if($location.search().lang!=undefined){
									
									$translate.use($location.search().lang);
									$rootScope.language=$location.search().lang;}
								}
								catch(e){console.log(e);}

							var screenHeight = $window.innerHeight
							var topvalue = screenHeight - 50;
							//console.log(screenHeight+"::"+topvalue)
							angular.element(document.querySelector('#footer'))
									.css('top', topvalue + "px");

							/*End*/
							$rootScope.forgotPopup;
							$scope.log_count = 0;
							$scope.loginBtnStatus = true;
							//alert("$localStorage.language::"+$localStorage.language);

							$scope.get_action = function(form) {

								/*  form.password.$setValidity('deactivated_user', true);
								  form.password.$setValidity('invalid_user', true);*/
								//   form.password.$setValidity('captcha_validation', true);
								//$scope.login_error=null;
								//form.$setValidity('error', true);
								
								if (form.$valid) {
									$scope.loading=true;
									$scope.loginBtnStatus = true;
									//alert($('div.g-recaptcha').is(":visible"))
									if ($('div.g-recaptcha').is(":visible")) {
										//alert("hsgsdg");
										var respValue = grecaptcha
												.getResponse();
										//alert(respValue);
										if (respValue.length == 0) {
											$scope.loginBtnStatus = false;
											swal(
													"Sorry!",
													"Please verify you are human !!!",
													"error");
											$scope.loading=false;
											$scope.loginBtnStatus = false;
											
										} else {
											$scope.Login(form);
										}
									} else {
										$scope.prograssing = false;
										$scope.Login(form);
									}
								}
							}
							$scope.password_expired = false;

					 
							$rootScope.languages = {
								'en' : 'English',
								'fr' : 'French'
							};
							
							
							
							$rootScope.updateLanguage = function(lang) {

								$rootScope.language = lang;
								$translate.use($rootScope.language);
								
								$http({
							        method : 'GET',
							        url: '/setLanguage?lang='+lang
							    }).then(function successCallback(response) {            
							    	console.log(response);
							     
							    }, function errorCallback(response) {
							    	console.log('Error status: ' + response.status);
							    });
								
							};

							$scope.check = function(form) {

								if (form.password.$valid && form.emailId.$valid) {
									return false;
								} else {
									return true;
								}
							};

							$scope.checkforgotpwd = function(form) {
								if (form.emailId.$valid) {
									return false;
								} else {
									return true;
								}
							};

							$scope.pwdformvalidate = function(forgotForm) {
								console.log(forgotForm.emailId);

								if (forgotForm.$error.error) {
									forgotForm.$error.error = false;
									//	forgotForm.emailId.$valid=true;
									forgotForm.$valid = true;
								}
							}

							$scope.formvalidate = function(loginForm) {

								if (loginForm.$error.error) {
									loginForm.$error.error = false;
									loginForm.$valid = true;
									loginForm.password.$setValidity(
											'captcha_validation', true);
								}
							}
							
							$rootScope.isAuthenticated = false;
							$scope.Login = function(form) {

								$http({
									method : 'POST',
									url : '/login',
									data : {
										emailId : $scope.emailId,
										password : $scope.password,
										clientIp : $window.sessionStorage.userIP
									}
								})
										.then(
												function(response) {
													$scope.loading=false;
													$scope.loginBtnStatus = false;
										 
														if (response.data.status == 'success' || 
																response.data.status == 'LOGIN.SUCCESS'){
															$rootScope.isAuthenticated = true;
															$window.sessionStorage.device = $rootScope.isAuthenticated;
															localStorage.clear();
														if ($scope.remember) {
															$scope
																	.rememberme($scope.emailId);
														} else {
															$scope
																	.removeremember();
														}
														$scope.login_error = "";
														$scope.log_count = 0;
														location.href = '/';
								 
													} else {
														$scope.log_count = $scope.log_count + 1;
														var status = response.data.status;
												 
														form.$setValidity(
																'error', false);
														form.password
																.$setValidity(
																		'captcha_validation',
																		true);
														$scope.login_error = status;
														$scope.loading= false;
														//grecaptcha.reset();
														
														try{
														var widgetId = grecaptcha.render("recaptcha");
														grecaptcha.reset(widgetId);
														}
														catch(e){}
													}

												}, function(response) {

												});
							};
							
							$scope.rememberme = function(emailid) {
								$cookies.put('cmusername', emailid);
								$cookies.put('remember', 'checked');
							};

							$scope.loadvalues = function() {
								$scope.emailId = $cookies.get("cmusername");
								//alert("$scope.emailId::"+$scope.emailId);
								if ($scope.emailId != null) {
									$("#checkid").show();
									$("#uncheckid").hide();
									$("#btn-check").attr("checked",
											$cookies.get("remember"));
								}
							}

							$scope.removeremember = function() {
								//if(!$scope.remember) {
								$cookies.remove("cmusername");
								$cookies.remove("remember");
								//}
							}

							$scope.changeremember = function() {
								if ($scope.remember != null) {
									if ($scope.remember) {
										$("#btn-check").attr("checked",
												"checked");
										$("#checkid").show();
										$("#uncheckid").hide();
									} else {
										$("#btn-check").removeAttr("checked");
										$("#checkid").hide();
										$("#uncheckid").show();
									}
								}
							}
							$scope.frg_count = 0;
							$scope.forgotpassword = function(form) {
						        
						        
								if (form.$valid) {
									$scope.loading=true;
									$rootScope.language=($rootScope.language===undefined||$rootScope.language==='undefined')?"en":$rootScope.language;
									$http({
										method : 'POST',
										url : '/forgotpassword',
										data : {
											emailId : $scope.emailId,
											lang : $rootScope.language
										}
									})
											.then(
													function(response) {
														$scope.loading=false;
														
														$scope.loginBtnStatus = false;
														if (response.data.status == 'FORGOTPASSWORD.SUCCESS.EMAIL_LINK') {
															$scope.login_error = "";
															$location.path('/');
															
															$rootScope.forgotPopup = true;
															setTimeout(function() {
																$rootScope.forgotPopup = false;
																$rootScope.$apply();
															},5000);
														} 
														// else {
														// 	/*$scope.frg_count = $scope.frg_count + 1;*/
														// 	form.$setValidity(
														// 			'error', false);
														// 	/*form.email1.$setValidity(
														// 					'captcha_validation',
														// 					true);*/
															
															
														// 	$scope.login_error = response.data.status;
														// //	$location.path('/');
															
														// 	/*$rootScope.forgotPopup = true;
														// 	setTimeout(function() {
														// 		$rootScope.forgotPopup = false;
														// 		$rootScope.$apply();
														// 	},2000);*/
														// }
														else if (response.data.status == 'FORGOTPASSWORD.ERROR.CHECK_USERNAME') {
															$scope.login_error = "";
															$location.path('/');
															$rootScope.forgotPopup = true;
															setTimeout(function() {
																$rootScope.forgotPopup = false;
																$rootScope.$apply();
															},5000);
														} else {
															form.$setValidity('error', false);
															$scope.login_error = response.data.status;
														}
													}, function(response) {

													});
								}
							};
							
						
							$scope.newPasswordvalidate = function(resetForm) {
								resetForm.$setValidity('error', true);
								if (resetForm.$error.error) {
									
									resetForm.newPassword.$error.error = false;
									resetForm.$valid = true;
								}
							}
							
							$scope.checkReset = function(resetForm) {

								if (resetForm.newPassword.$valid && resetForm.confirmPassword.$valid) {
									return false;
								} else {
									return true;
								}
							};
							 

							
							$scope.updatePassword = function(passwordUpdateForm) {
								var accesskey = $location.search().accesskey;//absUrl().split("=")[1];
								$scope.loading=true;
								if ($scope.confirmPassword != $scope.newPassword) {
									//alert('1');
									$scope.loading=false;
									passwordUpdateForm.$setValidity(
											'error', false);
									$scope.login_error = "UPDATEPASSWORD.ERROR.PASSWORD_NOTMATCH";
									
								} else {
									//alert('2');
									passwordUpdateForm.confirmPassword
											.$setValidity('error', true);
									if (passwordUpdateForm.$valid)
									{
										//alert('3');
										$scope.pageLoading = true;
										var options_args = {
											//    old_password: $scope.oldPassword,
											password : $scope.newPassword,
											confirmPassword : $scope.confirmPassword,
											accessKey : accesskey,
											lang : $rootScope.language
										};
										$http(
												{
													method : 'POST',
													url : '/setPasswordFirstTimeLogin/',
													data : options_args
												})
												.then(
														function(response) {
															$scope.loading=false;
															$scope.pageLoading = false;
															//alert(response.data.code)
															// this callback will be called asynchronously
															// when the response is available
															if (response.data.code == '200') {
																//alert("if")
																$scope.login_error = "";
																//$location.path = '/login';
																location.href = '/#';
																//$location.path('#/');
															} else {
																//alert("else")
																var status = response.data.status;
																//alert(status);
																passwordUpdateForm.$setValidity(
																		'error', false);
																
																$scope.login_error = status;
																console
																		.log($scope.login_error);
																$scope.loading=false;
																//passwordUpdateForm.$valid = false;
															}
														}, function(response) {
															// called asynchronously if an error occurs
															// or server returns response with an error status.
														});
									}
								}
							};
							$scope.invalid_user_validation_clear = function(
									form) {
								form.password.$setValidity('deactivated_user',
										true);
								form.password
										.$setValidity('invalid_user', true);
								form.password.$setValidity(
										'captcha_validation', true);
							};
							$scope.passwordValidationClear = function(form) {
								$scope.oldPassword = '';
								$scope.newPassword = '';
								$scope.confirmPassword = '';
								form.$setPristine();
								form.$setUntouched();
							}
							$scope.invalidPassValidationClear = function(form) {
								form.confirmPassword.$setValidity('notmatch',
										true);
								form.confirmPassword.$setValidity('pattern',
										true);
							};
							$scope.$watch('password_expired', function() {
								if ($scope.password_expired == true) {
									jQuery('#edit_password').modal('show');
								}
							});
							jQuery("#pass_exp_msg input").focus(function() {
								jQuery("#password_expired").slideUp();
							});
							$('[data-toggle="tooltip"]').tooltip();
							var d = new Date();
						    var fullyear = d.getFullYear();
						    $rootScope.fullYear = fullyear;
						} ])