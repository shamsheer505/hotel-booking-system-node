'use strict';
app.controller('PartnerController', ['$scope', '$http', '$rootScope', '$filter', '$timeout', function($scope, $http, $rootScope, $filter, $timeout) {
    $rootScope.testScroll();
    $scope.data = {};
    $scope.data.addpartner_open = !0;
    $scope.showCreatePartnerTypeButton = !0;
    $scope.showCreatePartnerGroupButton = !0;
    $scope.showCreatePartnerButton = !0;
    $scope.data.accountName = 'Select';
    $scope.data.accountId;
    $scope.data.partnerTypeName = 'Select';
    $scope.data.partnerTypeId;
    $scope.data.formatNames = [];
    $scope.editPartner;
    $scope.data.pgPartnerTypeName = 'Select';
    $scope.data.pgPartnerTypeId;
    $scope.data.pgPartnerList;
    $scope.data.newPgPartnerNames = [];
    $scope.editPartnerGroup;
    $scope.data.formatTypeId;
    $scope.data.formatTypeName = "Select";
    $scope.editPartnerType;
    $scope.partnerTypeDelete;
    $scope.partnerDelete;
    $scope.partnerGroupDelete;
    $scope.partnerActDeact;
    $scope.partnerList;
    $scope.partnerOrder = {
        field: 'partnerName',
        reverse: !1
    };
    $scope.setPartnerOrder = function(orderByField) {
        if (orderByField === $scope.partnerOrder.field)
            $scope.partnerOrder.reverse = !$scope.partnerOrder.reverse;
        else $scope.partnerOrder.field = orderByField
    }
    $scope.dynamicPartnerOrder = function(partner) {
        var order = partner[$scope.partnerOrder.field];
        return order
    }
    $scope.showFtpPassword = function() {
        if (!$scope.showCreatePartnerButton)
            $scope.data.ftpPassword = $scope.editPartner.erpepswr;
        var p = document.getElementById('ftpPassword');
        p.setAttribute('type', 'text')
    }
    $scope.hideFtpPassword = function() {
        if (!$scope.showCreatePartnerButton)
            $scope.data.ftpPassword = $scope.editPartner.ftpPassword;
        var p = document.getElementById('ftpPassword');
        p.setAttribute('type', 'password')
    }
    $scope.partnerExport = !1;
    $rootScope.exportFormat = null;
    $scope.exportPartners = function(exportType) {
    	$rootScope.exportFormat = exportType.type;
        $scope.getPartners(!0)
    }
    $scope.showDetails = function(e) {
        var delegateTarget = $(e.delegateTarget);
        var currentTarget = $(e.target);
        var target = $(e.target);
        var actionsDiv = $(e.target).parents().hasClass('tbody-actions')
        if (actionsDiv) {
            if ($(e.target).parents().hasClass('close') || e.target.id == 'closepartner') {
                var row = $(e.target).closest('.full-partners-tbody');
                if (target.hasClass('close')) {
                    row.removeClass('partner-expand-popup')
                } else {
                    row.removeClass('partner-expand-popup')
                }
            }
        } else {
            var row = $(e.target).closest('.full-partners-tbody');
            $(e.target).closest('.full-partners-tbody').addClass('partner-expand-popup');
            $(document).click(function(e) {
                if (!$(e.target).parents().hasClass('product-category-right')) {
                    $(".full-partners-tbody").removeClass("partner-expand-popup")
                }
            })
        }
    }
    $scope.partnerFormatListFilter = function(partner) {
        return function(format) {
            if (partner.formatId == null)
                return !1;
            else return partner.formatId.indexOf(format.formatId) != -1
        }
    }
    $scope.partnerGroupListFilter = function(pg) {
        return function(partner) {
            if (pg.partnerId == null)
                return !1;
            else return pg.partnerId.indexOf(partner.partnerId) != -1
        }
    }
    $scope.data.formatListLocal = angular.copy($rootScope.formatList);
    $scope.hidePartnerTypeDelete = function(pt) {
        try {
            var filteredList = $filter('filter')($scope.partnerList, function(itm) {
                return (itm.partnerTypeId == pt.partnerTypeId)
            })
            return filteredList.length !== 0
        } catch (e) {}
    }
    $scope.setAccountSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#accountSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setPartnerTypeSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#partnerSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setFormatSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#formatSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setPgPartnerTypeSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#pgPartnerTypeSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setPgPartnerSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#pgPartnerSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setFormatTypeSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#formatTypeSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setAccount = function(account) {
        $scope.data.accountId = account.accountId;
        $scope.data.accountName = account.accountName;
        $scope.data.CreatePartnerForm.$pristine = !1
    }
    $scope.setPartnerType = function(pt) {
        $scope.data.formatListLocal = angular.copy($filter('filter')($rootScope.formatList, function(itm) {
            return (itm.formatTypeId == pt.formatTypeId)
        }));
        $scope.data.formatAllSelected = !1;
        $scope.data.formatNames = [];
        $scope.data.partnerTypeName = pt.partnerTypeName;
        $scope.data.partnerTypeId = pt.partnerTypeId
    }
    $scope.setPgPartnerType = function(pt) {
        $scope.data.newPgPartnerNames = [];
        $scope.data.partnerAllSelected = !1;
        $scope.data.pgPartnerList = angular.copy($filter('filter')($scope.partnerList, function(itm) {
            return (itm.partnerTypeId == pt.partnerTypeId)
        }));
        $scope.data.pgPartnerTypeName = pt.partnerTypeName;
        $scope.data.pgPartnerTypeId = pt.partnerTypeId
    }
    $scope.setFormatType = function(formatType) {
        $scope.data.formatTypeId = formatType.formatTypeId;
        $scope.data.formatTypeName = formatType.formatTypeName;
        $scope.data.CreatePartnerTypeForm.$pristine = !1
    }
    $scope.toggleAllFormats = function() {
        var filteredList = $filter('filter')($scope.data.formatListLocal, function(data) {
            var re = new RegExp($scope.data.formatSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.data.formatNames = [];
        var toggleStatus = $scope.data.formatAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(format) {
                $scope.data.formatNames.push(format.formatName)
            })
        }
    }
    $scope.toggleAllPartners = function() {
        var filteredList = $filter('filter')($scope.data.pgPartnerList, function(data) {
            var re = new RegExp($scope.data.partnerSearch, 'gi');
            return data.partnerName.match(re)
        });
        $scope.data.newPgPartnerNames = [];
        var toggleStatus = $scope.data.partnerAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(partner) {
                $scope.data.newPgPartnerNames.push(partner.partnerName)
            })
        }
    };
    $scope.refreshPtMasterFormatList = function() {
        var filteredList = $filter('filter')($scope.data.formatListLocal, function(data) {
            var re = new RegExp($scope.data.formatSearch, 'gi');
            return data.formatName.match(re)
        });
        $timeout(function() {
            $scope.data.formatAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    };
    $scope.formatToggled = function(format, chk) {
        if (chk) {
            $scope.data.formatNames.push(format.formatName)
        } else {
            var index = $scope.data.formatNames.indexOf(format.formatName);
            $scope.data.formatNames.splice(index, 1)
        }
        $scope.refreshPtMasterFormatList()
    };
    $scope.refreshPtMasterPartnerList = function() {
        var filteredList = $filter('filter')($scope.data.pgPartnerList, function(data) {
            var re = new RegExp($scope.data.partnerSearch, 'gi');
            return data.partnerName.match(re)
        });
        $timeout(function() {
            $scope.data.partnerAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    };
    $scope.partnerToggled = function(partner, chk) {
        if (chk) {
            $scope.data.newPgPartnerNames.push(partner.partnerName)
        } else {
            var index = $scope.data.newPgPartnerNames.indexOf(partner.partnerName);
            $scope.data.newPgPartnerNames.splice(index, 1)
        }
        $scope.refreshPtMasterPartnerList()
    };
    $scope.cancelCreateEditPartnerOp = function() {
        $scope.data.addpartner_open = !1;
        $scope.showCreatePartnerButton = !0;
        $scope.data.accountName = 'Select';
        $scope.data.accountSearch = "";
        $scope.data.accountId = null;
        $scope.data.partnerTypeName = 'Select';
        $scope.data.partnerTypeSearch = "";
        $scope.data.partnerTypeId = null;
        $scope.data.channelName = "";
        $scope.data.partnerName = "";
        $scope.data.partnerEmail = "";
        $scope.data.formatListLocal = angular.copy($rootScope.formatList)
        $scope.data.formatNames = [];
        $scope.data.formatAllSelected = !1;
        $scope.data.formatSearch = "";
        $scope.data.ftpUrl = null;
        $scope.data.ftpPort = null;
        $scope.data.ftpUsername = null;
        $scope.data.ftpPassword = null;
        $scope.data.ftpFolder = null;
        $scope.data.ftpInstructions = null;
        $scope.editPartner = null;
        $scope.data.CreatePartnerForm.$setPristine();
        $scope.data.CreatePartnerForm.$setUntouched();
        $scope.data.CreatePartnerForm.$error = {};
        $scope.data.CreatePartnerForm.$submitted = !1
    };
    $scope.cancelCreateEditPartnerGroupOp = function() {
        $scope.data.partner_group = !1;
        $scope.showCreatePartnerGroupButton = !0;
        $scope.data.pgPartnerTypeName = 'Select';
        $scope.data.pgPartnerTypeId = null;
        $scope.data.pgPartnerList = angular.copy($scope.partnerList);
        $scope.data.newPgPartnerNames = [];
        $scope.data.partnerAllSelected = !1;
        $scope.data.createPartnerGroupName = "";
        $scope.editPartnerGroup = null;
        $scope.data.partnerSearch = "";
        $scope.data.pgPartnerTypeSearch = "";
        $scope.data.CreatePartnerGroupForm.$setPristine();
        $scope.data.CreatePartnerGroupForm.$setUntouched();
        $scope.data.CreatePartnerGroupForm.$error = {};
        $scope.data.CreatePartnerGroupForm.$submitted = !1
    };
    $scope.cancelCreateEditPartnerTypeOp = function() {
        $scope.data.partner_type = !1;
        $scope.formatTypeNonEditable = !1;
        $scope.showCreatePartnerTypeButton = !0;
        $scope.data.createPartnerTypeName = "";
        $scope.data.formatTypeId = null;
        $scope.data.formatTypeName = "Select";
        $scope.editPartnerType = null;
        $scope.data.formatTypeSearch = '';
        $scope.data.CreatePartnerTypeForm.$setPristine();
        $scope.data.CreatePartnerTypeForm.$setUntouched();
        $scope.data.CreatePartnerTypeForm.$error = {};
        $scope.data.CreatePartnerTypeForm.$submitted = !1
    };
    $scope.passDataToPartnerTypeDeleteModal = function(pt) {
        $scope.partnerTypeDelete = pt
    }
    $scope.passDataToPartnerDeleteModal = function(partner) {
        $scope.partnerDelete = partner
    }
    $scope.passDataToPartnerGroupDeleteModal = function(pg) {
        $scope.partnerGroupDelete = pg
    }
    $scope.passDataToActDeactModal = function(partner) {
        $scope.partnerActDeact = partner
    }
    $scope.closePartnerTypeDelete = function() {
        $scope.partnerTypeDelete = null;
        $('#partner-type-delete').modal('toggle');
        $rootScope.disabledBtnClickQuick()
    }
    $scope.closePartnerDelete = function() {
        $scope.partnerDelete = null;
        $('#partner-delete').modal('toggle');
        $rootScope.disabledBtnClickQuick()
    }
    $scope.closePartnerGroupDelete = function() {
        $scope.partnerGroupDelete = null;
        $('#partner-group-delete').modal('toggle');
        $rootScope.disabledBtnClickQuick()
    }
    $scope.closePartnerDeactivateModal = function() {
        $('#partner-deactivate').modal('toggle');
        $scope.getPartners(!1);
        $rootScope.disabledBtnClickQuick()
    }
    $scope.populatePartnerTypeForEdit = function(pt) {
        angular.element('html,body').animate({
            scrollTop: $(".product-category-container").offset().top - 30
        }, 'slow');
        $scope.cancelCreateEditPartnerTypeOp();
        $scope.editPartnerType = pt;
        $scope.formatTypeNonEditable = !1;
        $.each($rootScope.formatTypeList, function(index, formatType) {
            if (pt.formatTypeId == formatType.formatTypeId) {
                $scope.data.formatTypeId = formatType.formatTypeId;
                $scope.data.formatTypeName = formatType.formatTypeName;
                return !1
            }
        })
        $.each($scope.partnerList, function(index, partner) {
            if (pt.partnerTypeId == partner.partnerTypeId) {
                $scope.formatTypeNonEditable = !0;
                return !1
            }
        })
        $scope.data.createPartnerTypeName = pt.partnerTypeName;
        $scope.showCreatePartnerTypeButton = !1;
        $scope.data.partner_type = !0;
        $scope.data.partner_group = !1;
        $scope.data.addpartner_open = !1
    };
    $scope.populatePartnerGroupForEdit = function(pg) {
        angular.element('html,body').animate({
            scrollTop: $(".product-category-container").offset().top - 14
        }, 'slow');
        $scope.cancelCreateEditPartnerGroupOp();
        $scope.editPartnerGroup = pg;
        $scope.data.newPgPartnerNames = [];
        $scope.data.partnerAllSelected = !1;
        $scope.data.pgPartnerList = angular.copy($filter('filter')($scope.partnerList, function(itm) {
            return (itm.partnerTypeId == pg.partnerTypeId)
        }));
        $.each($rootScope.partnerTypeList, function(index, pt) {
            if (pt.partnerTypeId == pg.partnerTypeId) {
                $scope.data.pgPartnerTypeName = pt.partnerTypeName;
                $scope.data.pgPartnerTypeId = pt.partnerTypeId;
                return !1
            }
        })
        $.each(pg.partnerId, function(index, partnerId) {
            $.each($scope.data.pgPartnerList, function(index, partner) {
                if (partner.partnerId == partnerId) {
                    partner.selected = !0;
                    $scope.data.newPgPartnerNames.push(partner.partnerName)
                }
            })
        })
        $scope.data.createPartnerGroupName = pg.partnerGroupName;
        $scope.data.partnerAllSelected = $scope.data.pgPartnerList.every(function(itm) {
            return itm.selected
        })
        $scope.showCreatePartnerGroupButton = !1;
        $scope.data.partner_type = !1;
        $scope.data.partner_group = !0;
        $scope.data.addpartner_open = !1
    };
    $scope.populatePartnerForEdit = function(partner) {
        $scope.cancelCreateEditPartnerOp();
        $scope.editPartner = partner;
        $scope.data.formatNames = [];
        $scope.data.formatAllSelected = !1;
        $.each($rootScope.accountList, function(index, account) {
            if (partner.accountId == account.accountId) {
                $scope.data.accountName = account.accountName;
                $scope.data.accountId = account.accountId;
                return !1
            }
        })
        $.each($rootScope.partnerTypeList, function(index, pt) {
            if (pt.partnerTypeId == partner.partnerTypeId) {
                $scope.data.partnerTypeName = pt.partnerTypeName;
                $scope.data.partnerTypeId = pt.partnerTypeId;
                $scope.data.formatListLocal = angular.copy($filter('filter')($rootScope.formatList, function(itm) {
                    return (itm.formatTypeId == pt.formatTypeId)
                }));
                return !1
            }
        })
        if (partner.formatId != null) {
            $.each(partner.formatId, function(index, formatId) {
                $.each($scope.data.formatListLocal, function(index, format) {
                    if (format.formatId == formatId) {
                        format.selected = !0;
                        $scope.data.formatNames.push(format.formatName)
                    }
                })
            })
        }
        $scope.data.channelName = partner.channelName;
        $scope.data.partnerName = partner.partnerName;
        $scope.data.partnerEmail = (partner.emailId == null || partner.emailId == undefined) ? null : partner.emailId.toString();
        $scope.data.formatAllSelected = $scope.data.formatListLocal.every(function(itm) {
            return itm.selected
        })
        $scope.data.ftpUrl = partner.ftpUrl;
        $scope.data.ftpPort = partner.ftpPort;
        $scope.data.ftpUsername = partner.ftpUserName;
        $scope.data.ftpPassword = partner.ftpPassword;
        $scope.data.ftpFolder = partner.ftpFolderName;
        $scope.data.ftpInstructions = partner.ftpInstructions;
        $scope.showCreatePartnerButton = !1;
        $scope.data.partner_type = !1;
        $scope.data.partner_group = !1;
        $scope.data.addpartner_open = !0;
        angular.element('html,body').animate({
            scrollTop: $(".tab-menu-container").offset().top + 30
        }, 'slow')
    };
    $scope.getPartners = function(exportFlg) {
        $rootScope.showLoader($('.app-content'), 1, 'win8_linear');
        if (exportFlg) {
            $scope.showPartnerSuccessMsgExport = !0;
            $scope.partnerSuccessMsgExport = "EXPORT_REQUEST_SUCCESS";
            setTimeout(function() {
                $scope.showPartnerSuccessMsgExport = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        }
        $http({
            method: 'GET',
            url: '/getPartners/' + exportFlg +'/' + $rootScope.exportFormat
        }).then(function successCallback(response) {
            if (exportFlg) {
                $rootScope.getDownloadNotification();
                angular.element("#getDownloadNotification").addClass('open');
                angular.element(".download-up").addClass("flashit")
            }
            $scope.partnerList = response.data.data;
            $scope.data.pgPartnerList = angular.copy(response.data.data)
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        });
        $rootScope.hideLoader('app-content')
    };
    $scope.getPartnerGroups = function() {
        $http({
            method: 'GET',
            url: '/getPartnerGroups'
        }).then(function successCallback(response) {
            $scope.partnerGroupList = response.data.data
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    };
    $scope.createPartner = function() {
        $scope.createPartnerLoading = !0;
        var formatArray = [];
        angular.forEach($scope.data.formatListLocal, function(itm) {
            if (itm.selected == !0) {
                formatArray.push(itm.formatId)
            }
        });
        var partnerEmailList = null;
        if ($scope.data.partnerEmail != null && $scope.data.partnerEmail != undefined) {
            partnerEmailList = $scope.data.partnerEmail.split(",").map(function(item) {
                return item.trim()
            })
        }
        $http({
            method: 'POST',
            url: '/savePartner',
            data: {
                accountId: $scope.data.accountId,
                partnerTypeId: $scope.data.partnerTypeId,
                channelName: $scope.data.channelName,
                partnerName: $scope.data.partnerName,
                formatId: formatArray,
                emailId: partnerEmailList,
                ftpUrl: $scope.data.ftpUrl,
                ftpPort: $scope.data.ftpPort,
                ftpUserName: $scope.data.ftpUsername,
                ftpPassword: $scope.data.ftpPassword,
                ftpFolderName: $scope.data.ftpFolder,
                ftpInstructions: $scope.data.ftpInstructions
            }
        }).then(function(response) {
            $scope.createPartnerLoading = !1;
            if (response.data.code == '200') {
                $scope.cancelCreateEditPartnerOp();
                $scope.getPartners(!1);
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $scope.createPartnerType = function() {
        $scope.createPtLoading = !0;
        $http({
            method: 'POST',
            url: '/savePartnerType',
            data: {
                partnerTypeName: $scope.data.createPartnerTypeName,
                formatTypeId: $scope.data.formatTypeId
            }
        }).then(function(response) {
            $scope.createPtLoading = !1;
            if (response.data.code == '200') {
                $rootScope.getPartnerTypes();
                $scope.cancelCreateEditPartnerTypeOp();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $scope.createPartnerGroup = function() {
        $scope.createPgLoading = !0;
        var partnerArray = [];
        angular.forEach($scope.data.pgPartnerList, function(itm) {
            if (itm.selected == !0) {
                partnerArray.push(itm.partnerId)
            }
        });
        $http({
            method: 'POST',
            url: '/savePartnerGroup',
            data: {
                partnerGroupName: $scope.data.createPartnerGroupName,
                partnerTypeId: $scope.data.pgPartnerTypeId,
                partnerId: partnerArray
            }
        }).then(function(response) {
            $scope.createPgLoading = !1;
            if (response.data.code == '200') {
                $scope.getPartnerGroups();
                $scope.cancelCreateEditPartnerGroupOp();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $scope.deletePartnerType = function() {
        $http({
            method: 'POST',
            url: '/deletePartnerType/' + $scope.partnerTypeDelete.partnerTypeId,
        }).then(function successCallback(response) {
            $scope.closePartnerTypeDelete();
            if (response.data.code == '204' || response.data.code == '200') {
                $rootScope.getPartnerTypes();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        });
        $rootScope.disabledBtnClick()
    }
    $scope.deletePartner = function() {
        $http({
            method: 'POST',
            url: '/deletePartner/' + $scope.partnerDelete.partnerId,
        }).then(function successCallback(response) {
            $scope.closePartnerDelete();
            if (response.data.code == '204' || response.data.code == '200') {
                $scope.getPartners(!1);
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        });
        $rootScope.disabledBtnClick()
    }
    $scope.deletePartnerGroup = function() {
        $http({
            method: 'POST',
            url: '/deletePartnerGroup/' + $scope.partnerGroupDelete.partnerGroupId,
        }).then(function successCallback(response) {
            $scope.closePartnerGroupDelete();
            if (response.data.code == '204' || response.data.code == '200') {
                $scope.getPartnerGroups();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.activateDeactivatePartner = function() {
        var actVal;
        if ($scope.partnerActDeact.isActive == !0)
            actVal = 1;
        else actVal = 0;
        $http({
            method: 'POST',
            url: '/activateDeactivatePartner/' + actVal + '/' + $scope.partnerActDeact.partnerId
        }).then(function successCallback(response) {
            $scope.getPartners(!1);
            $scope.closePartnerDeactivateModal();
            if (response.data.code == '200') {
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        });
        $rootScope.disabledBtnClick()
    }
    $scope.editPartnerOp = function() {
        $scope.editPartnerLoading = !0;
        var formatArray = [];
        angular.forEach($scope.data.formatListLocal, function(itm) {
            if (itm.selected == !0) {
                formatArray.push(itm.formatId)
            }
        });
        var partnerEmailList = null;
        if ($scope.data.partnerEmail != null && $scope.data.partnerEmail != undefined) {
            partnerEmailList = $scope.data.partnerEmail.split(",").map(function(item) {
                return item.trim()
            })
        }
        $http({
            method: 'POST',
            url: '/editPartner/' + $scope.editPartner.partnerId,
            data: {
                accountId: $scope.data.accountId,
                partnerTypeId: $scope.data.partnerTypeId,
                channelName: $scope.data.channelName,
                partnerName: $scope.data.partnerName,
                formatId: formatArray,
                emailId: partnerEmailList,
                ftpUrl: $scope.data.ftpUrl,
                ftpPort: $scope.data.ftpPort,
                ftpUserName: $scope.data.ftpUsername,
                ftpFolderName: $scope.data.ftpFolder,
                ftpInstructions: $scope.data.ftpInstructions
            }
        }).then(function(response) {
            $scope.editPartnerLoading = !1;
            if (response.data.code == '200') {
                $scope.getPartners(!1);
                $scope.cancelCreateEditPartnerOp();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $scope.editPartnerTypeOp = function() {
        $scope.editPtLoading = !0;
        $http({
            method: 'POST',
            url: '/editPartnerType/' + $scope.editPartnerType.partnerTypeId,
            data: {
                partnerTypeName: $scope.data.createPartnerTypeName,
                formatTypeId: $scope.data.formatTypeId
            }
        }).then(function(response) {
            $scope.editPtLoading = !1;
            if (response.data.code == '200') {
                $rootScope.getPartnerTypes();
                $scope.cancelCreateEditPartnerTypeOp();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $scope.editPartnerGroupOp = function() {
        $scope.editPgLoading = !0;
        var partnerArray = [];
        angular.forEach($scope.data.pgPartnerList, function(itm) {
            if (itm.selected == !0) {
                partnerArray.push(itm.partnerId)
            }
        });
        $http({
            method: 'POST',
            url: '/editPartnerGroup/' + $scope.editPartnerGroup.partnerGroupId,
            data: {
                partnerGroupName: $scope.data.createPartnerGroupName,
                partnerTypeId: $scope.data.pgPartnerTypeId,
                partnerId: partnerArray
            }
        }).then(function(response) {
            $scope.editPgLoading = !1;
            if (response.data.code == '200') {
                $scope.getPartnerGroups();
                $scope.cancelCreateEditPartnerGroupOp();
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(error) {
            console.log('Error status: ' + error.status)
        })
    }
    $('#change-ftp-password').on('shown.bs.modal', function() {
        $(this).find('input:first').focus()
    });
    $('#change-ftp-password').find('button:first').on('keydown', function(e) {
        if ($("this:focus") && (e.which == 9)) {
            e.preventDefault();
            $('#change-ftp-password').find('input:first').focus()
        }
    });
    $scope.changeFtpPasswordForm = {};
    $scope.toggleChangeFtpPasswordModal = function() {
        $scope.changeFtpPasswordForm.newPassword = null;
        $scope.ChangeFtpPasswordForm.$setPristine();
        $scope.ChangeFtpPasswordForm.$setUntouched();
        $('#change-ftp-password').modal('toggle')
    }
    $scope.changeFtpPassword = function(ChangeFtpPasswordForm) {
        $scope.changeFtpPasswordForm.loading = !0;
        $http({
            method: 'POST',
            url: '/changePartnerFtppassword/' + $scope.editPartner.partnerId,
            data: {
                ftpPassword: $scope.changeFtpPasswordForm.newPassword
            }
        }).then(function(response) {
            $scope.changeFtpPasswordForm.loading = !1;
            if (response.data.code == '200') {
                $scope.getPartners(!1);
                $scope.editPartner.ftpPassword = response.data.data.ftpPassword;
                $scope.editPartner.erpepswr = response.data.data.erpepswr;
                $scope.data.ftpPassword = response.data.data.ftpPassword;
                $scope.showPartnerSuccessMsg = !0;
                $scope.partnerSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $scope.toggleChangeFtpPasswordModal()
            } else {
                $scope.showPartnerErrorMsg = !0;
                $scope.partnerErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showPartnerErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $scope.changeFtpPasswordForm.newPassword = "";
                $scope.ChangeFtpPasswordForm.$setUntouched();
                setTimeout(function() {
                    angular.element('#currentPassword').trigger('focus')
                }, 10)
            }
        }, function errorCallback(error) {})
    };
    $scope.getPartners(!1);
    $scope.getPartnerGroups()
}])