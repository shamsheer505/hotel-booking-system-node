app.controller('manualDistributionController', ['$scope', '$http', '$timeout', '$rootScope', '$location', "$route", "$window", "$compile", "$parse", "$filter", function($scope, $http, $timeout, $rootScope, $location, $route, $window, $compile, $parse, $filter) {
    $rootScope.testScroll();
    $scope.failureManualDistMsg;
    $rootScope.errorRibbon = !1;
    $scope.proceedDistribution = function() {
        var checkboxCount = angular.element(".brCheckbox").length;
        if (checkboxCount > 0) {
            $http({
                method: 'POST',
                url: '/saveManualDistData',
                data: {
                    partnerDetails: $rootScope.Partn,
                    userId: $rootScope.loggedUser.userId,
                    emailId: $rootScope.loggedUser.emailId,
                    userName: $rootScope.loggedUser.firstName
                }
            }).then(function(response) {});
            $location.url('/asset');
            $rootScope.searchClearAll();
            $rootScope.toggleDistributionMsg()
        } else {
            $scope.failureManualDistMsg = !0;
            $scope.failureManualDistMsgContent = "Atleast one Partner should be selected!";
            setTimeout(function() {
                $scope.failureManualDistMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        }
    }
    $scope.getDistributionStatus = function() {
        $http({
            method: 'POST',
            url: '/getDistributionStatus',
            data: {
                partnerDetails: $rootScope.Partn
            }
        }).then(function(response) {
            $rootScope.Partn = response.data.data
        })
    }
    $scope.part = {};
    $scope.partGrp = {};
    $scope.finalPartnerDetails = {};
    $scope.BrAll = {};
    $scope.changePriority = function(roleName, currentRow) {
        $.each($rootScope.Partn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.formatId == currentRow.formatId && value.partnerTypeId == currentRow.partnerTypeId) {
                $rootScope.Partn[key].priority = roleName
            }
        })
    }
    $scope.setBrStatus = function(currentRow, selectedPartner, event) {
        var checkAll = !1;
        if (event == !0 || event == !1) {
            isChecked = event
        } else {
            isChecked = event.target.checked
        }
        $.each($rootScope.Partn, function(key, value) {
            if (value.partnerTypeId == currentRow.partnerTypeId) {
                if (value.isbn == currentRow.isbn && value.formatId == currentRow.formatId) {
                    $.each(value.partnerDetails, function(key1, value1) {
                        if (selectedPartner.partnerId == value1.partnerId) {
                            $rootScope.Partn[key].partnerDetails[key1].brStatus = isChecked
                        }
                    })
                }
                var filteredList = $filter('filter')($rootScope.Partn[key].partnerDetails, function(data) {
                    return (data.formatIds.indexOf($rootScope.Partn[key].formatId) >= 0 && data.brStatus)
                });
                var unfilteredList = $filter('filter')($rootScope.Partn[key].partnerDetails, function(data) {
                    return (data.formatIds.indexOf($rootScope.Partn[key].formatId) == -1)
                });
                if (filteredList == undefined) {
                    $scope.BrAll[currentRow.partnerTypeId] = !1;
                    return !1
                } else {
                    if (((filteredList.length + unfilteredList.length) == $rootScope.Partn[key].partnerDetails.length) && (filteredList.length != 0)) {
                        $scope.BrAll[currentRow.partnerTypeId] = !0
                    } else {
                        $scope.BrAll[currentRow.partnerTypeId] = !1;
                        return !1
                    }
                }
            }
        })
    }
    $scope.toggleAllBrStatus = function(partnerTypeId, event) {
        isChecked = event.target.checked;
        $scope.BrAll[partnerTypeId] = isChecked;
        $.each($rootScope.Partn, function(key, value) {
            if (value.partnerTypeId == partnerTypeId) {
                $.each(value.partnerDetails, function(key1, value1) {
                    $rootScope.Partn[key].partnerDetails[key1].brStatus = isChecked
                })
            }
        })
    }
    $scope.verifyChecked = function(PartLst, partnerTypeId, partnerId, partnerGrp) {
        if (PartLst.selected == !0 && PartLst.partnerTypeId == partnerTypeId && PartLst.partnerId == partnerId) {
            return !0
        }
        if (partnerGrp.length > 0) {
            for (i = 0; i < partnerGrp.length; i++) {
                if (partnerGrp[i].selected == !0 && partnerGrp[i].partnerTypeId == partnerTypeId) {
                    var inde = partnerGrp[i].partnerIds.indexOf(partnerId);
                    if (inde >= 0) {
                        return !0
                    }
                }
            }
        }
        return !1
    }
    $scope.setHeight = function(event) {
        var par_height = $(event.currentTarget).closest('.divTableCell').height();
        $(event.currentTarget).parent().parent().children(".multi-select-dropdown").css("top", par_height + 5)
    }
    $scope.checkAllprtToggled = function(parr, prts, event) {
        angular.forEach(prts, function(pData, ppdata) {
            if (pData.formatIds.indexOf(parr.formatId) >= 0) {
                $('#' + parr.isbn + "_" + parr.formatId + "_" + pData.partnerId).prop('checked', event.target.checked);
                $scope.prtToggled(parr, pData, event)
            }
        });
        var ischecked = event.target.checked;
        if (ischecked == !1) {
            $scope.BrAll[parr.partnerTypeId] = !1
        }
    }
    $scope.prtToggled = function(currentRow, currentTag, event) {
        var ischecked = event.target.checked;
        $.each($rootScope.Partn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.formatId == currentRow.formatId && value.partnerTypeId == currentRow.partnerTypeId) {
                if (!$rootScope.Partn[key].hasOwnProperty("partnerDetails")) {
                    $rootScope.Partn[key].partnerDetails = []
                } else if ($rootScope.Partn[key].partnerDetails == null) {
                    $rootScope.Partn[key].partnerDetails = []
                }
                var index = $rootScope.Partn[key].partnerDetails.findIndex(function(item, index) {
                    return ((item.partnerId === currentTag.partnerId)) ? !0 : !1
                });
                if (ischecked) {
                    if (index == -1) {
                        $rootScope.Partn[key].partnerDetails.push({
                            partnerId: currentTag.partnerId,
                            partner: currentTag.partnerName,
                            formatIds: currentTag.formatIds,
                            isGroup: !1
                        });
                        $http({
                            method: 'POST',
                            url: '/getDistributionStatus',
                            data: {
                                partnerDetails: $rootScope.Partn
                            }
                        }).then(function(response) {
                            var resultdata = response.data.data;
                            var distStatus = "";
                            for (i = 0; i < resultdata.length; i++) {
                                if (value.isbn == resultdata[i].isbn && value.formatId == resultdata[i].formatId && value.partnerTypeId == resultdata[i].partnerTypeId) {
                                    for (j = 0; j < resultdata[i].partnerDetails.length; j++) {
                                        if (currentTag.partnerId) {
                                            distStatus = resultdata[i].partnerDetails[j].distributionStatus
                                        }
                                    }
                                }
                            }
                            angular.forEach($rootScope.Partn, function(pData, ppdata) {
                                if (value.isbn == pData.isbn && value.formatId == pData.formatId && value.partnerTypeId == pData.partnerTypeId) {
                                    angular.forEach(pData.partnerDetails, function(partData, data) {
                                        if (currentTag.partnerId === partData.partnerId) {
                                            $rootScope.Partn[ppdata].partnerDetails[data].distributionStatus = distStatus
                                        }
                                    })
                                }
                            })
                        })
                    }
                } else {
                    if (index > -1) {
                        $rootScope.Partn[key].partnerDetails.splice(index, 1);
                        for (i = 0; i < $scope.partnerList.length; i++) {
                            if (currentTag.partnerTypeId == $scope.partnerList[i].partnerTypeId) {
                                for (j = 0; j < $scope.partnerList[i].partners.length; j++) {
                                    if (currentTag.partnerId == $scope.partnerList[i].partners[j].partnerId) {}
                                }
                            }
                        }
                    }
                }
            }
        })
        $scope.setBrStatus(currentRow, currentTag, event)
    }
    if ($location.$$url == '/manual-distribution') {
        if ($rootScope.manualDistribution != 'click') {
            $http({
                method: 'POST',
                url: '/getEligiblePartners',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $rootScope.partnerList = response.data.data
            });
            $scope.formatData = [];
            angular.forEach($rootScope.downloadUploadList, function(key, value) {
                $scope.formatData.push({
                    isbn: key[0].isbn,
                    format: key[0].format,
                    formatId: key[0].formatId,
                    title: key[0].title,
                    countryOfPublication: key[0].countryOfPublication,
                    ebookType: key[0].ebookType,
                    discount: key[0].discount
                })
            });
            $http({
                method: 'POST',
                url: '/getEligibleFormats',
                data: {
                    userId: $rootScope.loggedUser.userId
                }
            }).then(function(response) {
                $scope.validFormats = [];
                var count = 0;
                angular.forEach($scope.formatData, function(formats) {
                    var check = !0;
                    angular.forEach(response.data.data, function(item) {
                        if (check) {
                            if (formats.formatId === item.formatId) {
                                $scope.validFormats.push(formats);
                                count++;
                                check = !1
                            }
                        }
                    })
                });
                if (count === $scope.formatData.length) {
                    $http({
                        method: 'POST',
                        url: '/getFormatGridData',
                        data: {
                            partnerDetails: $scope.validFormats,
                            userId: $rootScope.loggedUser.userId
                        }
                    }).then(function(response) {
                        $rootScope.Partn = response.data.data;
                        angular.forEach($rootScope.Partn,function(obj){
                            angular.forEach($scope.formatData,function(innerobj){
                                if(innerobj.isbn == obj.isbn){
                                   obj.ebookType = innerobj.ebookType;
                                   obj.discount = innerobj.discount;
                                }
                            })
                        })
                        angular.forEach($rootScope.partnerList, function(prList) {
                            angular.forEach(response.data.data, function(resData) {
                                if (prList.partnerTypeId == resData.partnerTypeId) {
                                    prList.count = prList.count + 1
                                }
                            })
                        })
                    })
                } else {
                    angular.forEach($scope.formatData, function(formats) {
                        var id = "";
                        if ($scope.validFormats.indexOf(formats) == -1) {
                            document.getElementById("tempbucketerr").innerHTML = "Few file(s) are not eligible for distribution. Please uncheck the file(s) and proceed further.";
                            if (undefined == formats.formatId) {
                                angular.element("#" + formats.isbn + "_").children('.divTableCell').css('background', 'pink')
                            } else {
                                var id = formats.isbn + "_" + formats.formatId;
                                angular.element("#" + id).children('.divTableCell').css('background', 'pink')
                            }
                        }
                    })
                }
            })
        }
    }
    $scope.isObjectEmpty = function(val) {
        angular.forEach($scope.Partn, function(data) {
            if (val.partnerTypeId == data.partnerTypeId)
                $scope.isShow = data.partnerTypeId
        })
        return $scope.isShow
    }
    $scope.cpRemove = function(currentPartnerType, currentRow, currentTag) {
        var currentPartnerTypeId = currentPartnerType.partnerTypeId;
        $.each($scope.Partn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.formatId == currentRow.formatId && value.partnerTypeId == currentRow.partnerTypeId) {
                angular.forEach(value.partnerDetails, function(keys, vals) {
                    $scope.partIdss = keys.partnerId;
                    $scope.idss = 'checkAll_' + $scope.partIdss;
                    if (currentTag.partnerId == $scope.partIdss) {
                        $scope.fullId = value.isbn + "_" + value.formatId + "_" + keys.partnerId;
                        $timeout(function() {
                            document.getElementById($scope.fullId).checked = !1
                        }, 100)
                    }
                    $timeout(function() {
                        $.each($scope.finalPartnerDetails[currentPartnerTypeId], function(index, row) {
                            if (row.partnerId == currentTag.partnerId && row.isGroup == !1) {
                                $scope.finalPartnerDetails[currentPartnerTypeId].splice(index, 1)
                            }
                        })
                    }, 100)
                })
                var index = $scope.Partn[key].partnerDetails.indexOf(currentTag);
                for (i = 0; i < $scope.partnerList.length; i++) {
                    if (currentPartnerType.partnerTypeId == $scope.partnerList[i].partnerTypeId) {
                        for (j = 0; j < $scope.partnerList[i].partners.length; j++) {
                            if (currentTag.partnerId == $scope.partnerList[i].partners[j].partnerId) {
                                $scope.partnerList[i].partners[j].selected = !1;
                                $scope.part[currentRow.partnerTypeId] = !1
                            }
                        }
                    }
                }
                $scope.Partn[key].partnerDetails.splice(index, 1);
                if ($scope.Partn[key].partnerDetails >= 0) {
                    $scope.BrAll[currentRow.partnerTypeId] = !1
                }
                return !1
            }
        })
    }
    $scope.cpClose = function(currentRow) {
        for (i = 0; i < $scope.Partn.length; i++) {
            if ($scope.Partn[i].isbn == currentRow.isbn && $scope.Partn[i].formatId == currentRow.formatId && $scope.Partn[i].partnerTypeId == currentRow.partnerTypeId) {
                $scope.Partn.splice(i, 1)
            }
        }
    }
    $scope.toggleAllPartnersType = function(CurrentPartner) {
        if (Object.keys($scope.finalPartnerDetails).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.finalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var toggleStatus = $scope.part[CurrentPartner.partnerTypeId];
        angular.forEach(CurrentPartner.partners, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(CurrentPartner.partners, function(prt) {
                var index = $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].findIndex(function(item, index) {
                    return ((item.partnerId === prt.partnerId) && (item.isGroup === !1)) ? !0 : !1
                });
                if (index == -1) {
                    $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].push({
                        partnerId: prt.partnerId,
                        partner: prt.partnerName,
                        formatIds: prt.formatIds,
                        isGroup: !1
                    })
                }
            })
        } else {
            $scope.BrAll[CurrentPartner.partnerTypeId] = !1;
            $.each(CurrentPartner.partners, function(index, prtrow) {
                $.each($scope.finalPartnerDetails[CurrentPartner.partnerTypeId], function(index1, res) {
                    if (prtrow.partnerId == res.partnerId && res.isGroup == !1) {
                        $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].splice(index1, 1);
                        return !1
                    }
                })
            })
        }
        angular.forEach($rootScope.Partn, function(value, key) {
            value.partnerDetails = angular.copy($scope.finalPartnerDetails[value.partnerTypeId])
        });
        $scope.getDistributionStatus();
        $timeout(function() {
            $.each($rootScope.Partn, function(index, row) {
                if (row.partnerTypeId == CurrentPartner.partnerTypeId) {
                    $.each(row.partnerDetails, function(key, value) {
                        $scope.setBrStatus(row, value, toggleStatus)
                    })
                }
            })
        }, 300)
    }
    $scope.partnersListToggled = function(currentPartner, partnersType, chk, partnerId) {
        if (Object.keys($scope.finalPartnerDetails).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.finalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerTypeId = currentPartner.partnerTypeId;
        $scope.part[currentPartner.partnerTypeId] = currentPartner.partners.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            var index = $scope.finalPartnerDetails[currentPartnerTypeId].findIndex(function(item, index) {
                return ((item.partnerId === partnersType.partnerId) && (item.isGroup === !1)) ? !0 : !1
            });
            if (index == -1) {
                $scope.finalPartnerDetails[currentPartnerTypeId].push({
                    partnerId: partnersType.partnerId,
                    partner: partnersType.partnerName,
                    formatIds: partnersType.formatIds,
                    isGroup: !1
                })
            }
        } else {
            $.each($scope.finalPartnerDetails[currentPartnerTypeId], function(index, row) {
                if (row.partnerId == partnersType.partnerId && row.isGroup == !1) {
                    $scope.finalPartnerDetails[currentPartnerTypeId].splice(index, 1);
                    return !1
                }
            })
        }
        $scope.pushPopPartners(partnersType, chk, !1);
        $scope.getDistributionStatus();
        $timeout(function() {
            $.each($rootScope.Partn, function(index, row) {
                if (row.partnerTypeId == partnersType.partnerTypeId) {
                    $.each(row.partnerDetails, function(key, value) {
                        if (value.partnerId == partnerId) {
                            $scope.setBrStatus(row, value, chk)
                        }
                    })
                }
            })
        }, 300)
    }
    $scope.pushPopPartners = function(parDetails, chk, isgroup) {
        if (chk) {
            angular.forEach($rootScope.Partn, function(value, key) {
                if (value.partnerDetails && (parDetails.partnerTypeId == value.partnerTypeId)) {
                    var index = value.partnerDetails.findIndex(function(item, index) {
                        return (item.partnerId === parDetails.partnerId) ? !0 : !1
                    });
                    if (index == -1) {
                        value.partnerDetails.push({
                            partnerId: parDetails.partnerId,
                            partner: parDetails.partnerName,
                            formatIds: parDetails.formatIds,
                            isGroup: isgroup
                        })
                    }
                } else {
                    value.partnerDetails = angular.copy($scope.finalPartnerDetails[value.partnerTypeId])
                }
            })
        } else {
            angular.forEach($rootScope.Partn, function(value, key) {
                if (parDetails.partnerTypeId == value.partnerTypeId) {
                    var index = value.partnerDetails.findIndex(function(item, index) {
                        return (item.partnerId === parDetails.partnerId) ? !0 : !1
                    });
                    if (index >= 0) {
                        value.partnerDetails.splice(index, 1)
                    }
                }
            })
        }
    }
    $scope.toggleAllPartnersGrp = function(CurrentPartner) {
        if (Object.keys($scope.finalPartnerDetails).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.finalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var toggleStatus = $scope.partGrp[CurrentPartner.partnerTypeId];
        angular.forEach(CurrentPartner.partnerGrps, function(grp) {
            grp.selected = toggleStatus
        });
        angular.forEach(CurrentPartner.partnerGrps, function(prtgrp) {
            angular.forEach(prtgrp.partners, function(prt) {
                if (toggleStatus) {
                    var index = $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].findIndex(function(item, index) {
                        return ((item.partnerId === prt.partnerId) && (item.isGroup === !0)) ? !0 : !1
                    });
                    if (index == -1) {
                        $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].push({
                            partnerId: prt.partnerId,
                            partner: prt.partnerName,
                            formatIds: prt.formatIds,
                            isGroup: !0
                        })
                    }
                } else {
                    $.each($scope.finalPartnerDetails[CurrentPartner.partnerTypeId], function(index1, res) {
                        if (prt.partnerId == res.partnerId && res.isGroup == !0) {
                            $scope.finalPartnerDetails[CurrentPartner.partnerTypeId].splice(index1, 1);
                            return !1
                        }
                    })
                }
            })
        })
        angular.forEach($rootScope.Partn, function(value, key) {
            value.partnerDetails = angular.copy($scope.finalPartnerDetails[value.partnerTypeId])
        });
        $scope.getDistributionStatus()
    }
    $scope.partnersGrpToggled = function(currentPartner, partnersGrp, chk) {
        if (Object.keys($scope.finalPartnerDetails).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.finalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerTypeId = currentPartner.partnerTypeId;
        $scope.partGrp[currentPartner.partnerTypeId] = currentPartner.partnerGrps.every(function(itm) {
            return itm.selected
        })
        angular.forEach(partnersGrp.partners, function(prt) {
            if (chk) {
                var index = $scope.finalPartnerDetails[currentPartnerTypeId].findIndex(function(item, index) {
                    return ((item.partnerId === prt.partnerId) && (item.isGroup === !0)) ? !0 : !1
                });
                if (index == -1) {
                    $scope.finalPartnerDetails[partnersGrp.partnerTypeId].push({
                        partnerId: prt.partnerId,
                        partner: prt.partnerName,
                        formatIds: prt.formatIds,
                        isGroup: !0
                    })
                }
            } else {
                $.each($scope.finalPartnerDetails[partnersGrp.partnerTypeId], function(index, row) {
                    if (prt.partnerId == row.partnerId && row.isGroup == !0) {
                        $scope.finalPartnerDetails[partnersGrp.partnerTypeId].splice(index, 1);
                        return !1
                    }
                })
            }
            $scope.pushPopPartners(prt, chk, !0)
        })
        $scope.getDistributionStatus()
    }
    $scope.$watch('finalPartnerDetails', function(newVal, oldVal) {
        $scope.finalPartnerNames = {}
        if (Object.keys($scope.finalPartnerNames).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.finalPartnerNames[prtList.partnerTypeId] = {}
                $scope.finalPartnerNames[prtList.partnerTypeId] = {}
            })
        }
        angular.forEach(newVal, function(value, key) {
            var values = "";
            if (value.length > 0) {
                angular.forEach(value, function(value1, key1) {
                    values += value[key1].partner + ", "
                });
                $scope.finalPartnerNames[key] = values
            }
        })
    }, !0)
}])