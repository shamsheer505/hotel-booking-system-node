app.controller('FileUploadController', ['$scope', '$http', '$timeout', '$rootScope', '$location', 'Idle', '$window', function($scope, $http, $timeout, $rootScope, $location, Idle, $window) {
    $rootScope.testScroll();
    $rootScope.data = {};
    $scope.fileList = [];
    $scope.formatId = "";
    $scope.existingFiles = [];
    $scope.existingformat = [];
    $scope.bucketexistinglist = [];
    $scope.selectedFormat = {};
    $scope.gridfolderenable = {};
    $scope.foldernames = {};
    $scope.griddataList = {};
    $scope.gridFormatId = {};
    $scope.appendFolderName = {};
    $scope.gridfolderId = "";
    $scope.fileListnew = [];
    $scope.appendPath = "";
    $scope.bucketList = [];
    $scope.assetApprovalList = ['Pending Approval', 'QA Failed', 'Approved'];
    if ($rootScope.uploadpagename == 'Asset') {
        $rootScope.downloadUploadList = JSON.parse(localStorage.getItem("checkedAssetData"));
        angular.forEach($rootScope.downloadUploadList, function(key, value) {
            $scope.bucketList.push({
                isbn: key[0].isbn,
                title: key[0].title,
                author: key[0].author,
                formatName: key[0].format,
                formatId: key[0].formatId,
            });
            if (Object.keys($rootScope.downloadUploadList).length == $scope.bucketList.length) {
                $http({
                    method: 'POST',
                    url: '/bucketUploadDetails',
                    data: {
                        bucketDetailList: $scope.bucketList
                    }
                }).then(function(response) {
                    if (response.data.code == '200') {
                        $scope.fileList = response.data.data;
                        angular.forEach($scope.fileList, function(list) {
                            if (list.singleFile) {
                                var path = list.isbn + "/" + list.formatName;
                                $scope.existingformat.push(path)
                            }
                        })
                    }
                })
            }
        })
    } else if ($rootScope.uploadpagename == 'Shelf') {
        $rootScope.downloadShelfUploadList = JSON.parse(localStorage.getItem("checkedShelfData"));
        angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
            $scope.bucketList.push({
                isbn: key[0].isbn,
                title: key[0].title,
                author: key[0].author,
                formatName: key[0].format,
                formatId: key[0].formatId,
            });
            if (Object.keys($rootScope.downloadShelfUploadList).length == $scope.bucketList.length) {
                $http({
                    method: 'POST',
                    url: '/bucketUploadDetails',
                    data: {
                        bucketDetailList: $scope.bucketList
                    }
                }).then(function(response) {
                    if (response.data.code == '200') {
                        $scope.fileList = response.data.data;
                        angular.forEach($scope.fileList, function(list) {
                            if (list.singleFile) {
                                var path = list.isbn + "/" + list.formatName;
                                $scope.existingformat.push(path)
                            }
                        })
                    }
                })
            }
        })
    }
    $scope.fileuploadlist = [];
    $scope.formatenable = !1;
    $scope.folderenable = !1;
    $scope.uploadfile = {};
    $scope.disableele = function() {
        $('#formatdiv').addClass("")
    }
    $rootScope.Idlewatch = function(flag) {
        if (flag == !0)
            Idle.watch();
        else Idle.unwatch()
    }
    $scope.formvalidate = function(Form) {
        if (Form.$error.error) {
            Form.$error.error = !1;
            Form.$valid = !0
        }
    }
    $scope.checkIsbn = function(form) {
        if ($scope.isbn != "") {
            $http({
                method: 'POST',
                url: '/checkIsbn',
                data: {
                    productIDValue: $scope.isbn
                }
            }).then(function(response) {
                if (response.data.code == '200') {
                    $scope.author = ""
                    $scope.title = ""
                    $scope.checkStatusColor('ISBN');
                    angular.forEach(response.data.data.product.contributor, function(contrib) {
                        if (contrib.personName != null) {
                            if ("" == $scope.author) {
                                $scope.author = contrib.personName
                            } else {
                                $scope.author = $scope.author + ", " + contrib.personName
                            }
                        }
                    });
                    angular.forEach(response.data.data.product.title, function(title) {
                        if (null != title.titleType && title.titleType == "01") {
                            $scope.title = title.titleText
                        }
                    })
                } else {
                    form.$setValidity('error', !1);
                    $scope.upload_error_isbn = "Please enter valid isbn";
                    $scope.formatenable = !1
                }
            })
        }
    }
    $scope.changeisbn = function(Form) {
        $scope.formatId = "";
        if (Form.$error.error) {
            Form.$error.error = !1;
            Form.$valid = !0;
            $scope.upload_error_isbn = "";
            $scope.upload_error_blank_isbn = "";
            $scope.upload_error_formatid = ""
        }
        if ($scope.isbn === "") {
            $scope.formatenable = !1
        } else {
            $scope.formatenable = !0
        }
        $scope.existinglist = [];
        $scope.newlist = [];
        $http({
            method: 'POST',
            url: '/getProductForm',
            data: {
                productIDValue: $scope.isbn
            }
        }).then(function(response) {
            $scope.formatlist = response.data.data;
            $http({
                method: 'POST',
                url: '/isbnformatlist',
                data: {
                    productIDValue: $scope.isbn,
                    productFormatList: $scope.formatlist
                }
            }).then(function(response) {
                $scope.isbnformatlist = response.data.data
            })
        })
    }
    $scope.uploadAlert = "";
    $scope.getSelectedItem = function(val, form) {
        $scope.uploadAlertShow = !1;
        $scope.uploadAlert = "";
        $scope.formvalidate(form);
        var previousFormatId = $scope.formatId;
        $scope.formatId = val;
        if ($scope.formatId === "") {
            $scope.folderenable = !1
        }
        var path = $scope.isbn + "/" + $scope.formatId;
        var previousPath = $scope.isbn + "/" + previousFormatId;
        $http({
            method: 'POST',
            url: '/getFormat',
            data: {
                formatName: $scope.formatId
            }
        }).then(function(response) {
            $scope.format = response.data.data.formatId;
            if (response.data.data.singleFile) {
                $scope.folderenable = !1;
                if ($scope.existingformat.length > 0) {
                    if (!($scope.existingformat.indexOf(path) == -1)) {
                        $scope.formatId = "";
                        $scope.uploadAlertShow = !0;
                        $scope.uploadAlert = "Format has already selected. Please choose different format";
                        angular.forEach($scope.existingformat, function(format, index) {
                            if (format == previousPath) {
                                $scope.existingformat.splice(index, 1)
                            }
                        })
                    } else {
                        angular.forEach($scope.existingformat, function(format, index) {
                            if (format == previousPath) {
                                $scope.existingformat.splice(index, 1)
                            }
                        });
                        $scope.existingformat.push(path)
                    }
                } else {
                    $scope.existingformat.push(path)
                }
            } else {
                $scope.folderenable = !0;
                $http({
                    method: 'POST',
                    url: '/getFolderlist',
                    data: {
                        formatId: $scope.format,
                        productIDValue: $scope.isbn,
                        formatName: $scope.formatId
                    }
                }).then(function(response) {
                    $scope.dataList = response.data.data
                })
            }
        })
    }
    $scope.getTopFolList = function(list) {
        $scope.selectAll = !1;
        var folder = list.name.replace("_folder", "");
        if ($scope.appendTopFolderName == null || $scope.appendTopFolderName == "") {
            $scope.appendTopFolderName = folder
        } else {
            $scope.appendTopFolderName = $scope.appendTopFolderName + "/" + folder
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.formatId,
                productIDValue: $scope.isbn,
                formatId: $scope.format,
                folder: $scope.appendTopFolderName
            }
        }).then(function(response) {
            $scope.dataList = response.data.data
        })
    }
    $scope.upOneLevelTop = function() {
        var folder = $scope.appendTopFolderName.split('/');
        folder.pop();
        if (folder == "") {
            $scope.appendTopFolderName = ""
        } else {
            $scope.appendTopFolderName = folder.join('/')
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.formatId,
                productIDValue: $scope.isbn,
                formatId: $scope.format,
                folder: $scope.appendTopFolderName
            }
        }).then(function(response) {
            $scope.dataList = response.data.data
        })
    }
    $scope.createNewFolderTop = function(TopfolderId) {
        $scope.selectFolderAlert = "";
        $scope.selectFoldershow = !1;
        var emptyfolder = !1;
        var nofolder = !1;
        var check = !0;
        var folderCount = 0;
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        if (!angular.equals({}, $scope.dataList)) {
            if ($scope.dataList.length > 0) {
                angular.forEach($scope.dataList, function(name) {
                    if (name.checked == !0) {
                        if (name.name.contains("_folder")) {
                            folderCount++
                        } else {
                            emptyfolder = !0
                        }
                    } else {
                        nofolder = !0
                    }
                })
            } else {
                nofolder = !0
            }
        } else {
            $scope.folderId = TopfolderId;
            $scope.fileListnew.push({
                isbn: $scope.isbn,
                formatId: $scope.format,
                formatName: $scope.formatId,
                folder: $scope.folderId,
                filename: null,
                fullpath: $scope.folderId,
                length: $scope.count,
                randomkey: randomkey,
                bucketexistinglist: $scope.isbnformatlist,
                bucketformatlist: $scope.formatlist,
                singleFile: !1
            })
        }
        if (folderCount >= 2) {
            $scope.selectFoldershow = !0;
            $scope.selectFolderAlert = "Please select any one folder";
            $scope.appendTopFolderName = "";
            $scope.folderId = "";
            $scope.TopfolderId = ""
        } else if ((nofolder || emptyfolder) && folderCount < 1) {
            $scope.folderId = TopfolderId;
            $scope.fileListnew.push({
                isbn: $scope.isbn,
                formatId: $scope.format,
                formatName: $scope.formatId,
                folder: $scope.folderId,
                filename: null,
                fullpath: $scope.folderId,
                length: $scope.count,
                randomkey: randomkey,
                bucketexistinglist: $scope.isbnformatlist,
                bucketformatlist: $scope.formatlist,
                singleFile: !1
            })
        } else {
            if ($scope.appendTopFolderName != undefined)
                $scope.folderId = $scope.appendTopFolderName + TopfolderId;
            else $scope.folderId = TopfolderId;
            angular.forEach($scope.fileListnew, function(file, index) {
                angular.forEach($scope.dataList, function(name) {
                    if (name.checked == !0) {
                        if (name.name.contains("_folder")) {
                            if (file.folder === name.name.replace("_folder", "")) {
                                $scope.fileListnew[index].folder = file.folder + "/" + $scope.folderId;
                                $scope.fileListnew[index].fullpath = file.fullpath + "/" + $scope.folderId
                            }
                        }
                    }
                })
            })
        }
    }
    $scope.getSelectedFolderTop = function(list, position, event, griddataList) {
        $scope.selectFolderAlert = "";
        $scope.selectFoldershow = !1;
        $scope.selectSameFolderAlert = "";
        $scope.selectSameFoldershow = !1;
        var folder = $scope.appendTopFolderName;
        if (folder == "" || folder == undefined) {
            var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + list.replace("_folder", "")
        } else {
            var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + folder + "/" + list.replace("_folder", "")
        }
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        if (event.target.checked) {
            $scope.checkStatusColor("FOLDER");
            if (list.contains("_folder")) {
                var fol = list.replace("_folder", "");
                if (folder != null && folder != "")
                    var folder1 = folder + "/" + fol;
                else var folder1 = fol;
                $scope.fileListnew.push({
                    isbn: $scope.isbn,
                    formatId: $scope.format,
                    formatName: $scope.formatId,
                    folder: folder1,
                    filename: null,
                    fullpath: folder1,
                    length: $scope.count,
                    randomkey: randomkey,
                    bucketexistinglist: $scope.isbnformatlist,
                    bucketformatlist: $scope.formatlist,
                    singleFile: !1
                })
            } else {
                if ($scope.existingFiles.length > 0) {
                    if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                        $scope.selectSameFolderAlert = "File has already selected. Please choose different file";
                        $scope.selectSameFoldershow = !0;
                        document.getElementById(event.target.id).checked = !1
                    } else {
                        $scope.existingFiles.push(FilePath);
                        if (folder != null && folder != "") {
                            var fullpath = folder + "/" + list
                        } else {
                            var fullpath = list
                        }
                        $scope.fileListnew.push({
                            isbn: $scope.isbn,
                            formatId: $scope.format,
                            formatName: $scope.formatId,
                            folder: folder,
                            filename: list,
                            fullpath: fullpath,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.isbnformatlist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: !1
                        })
                    }
                } else {
                    $scope.existingFiles.push(FilePath);
                    if (folder != null && folder != "") {
                        var fullpath = folder + "/" + list
                    } else {
                        var fullpath = list
                    }
                    $scope.fileListnew.push({
                        isbn: $scope.isbn,
                        formatId: $scope.format,
                        formatName: $scope.formatId,
                        folder: folder,
                        filename: list,
                        fullpath: fullpath,
                        length: $scope.count,
                        randomkey: randomkey,
                        bucketexistinglist: $scope.isbnformatlist,
                        bucketformatlist: $scope.formatlist,
                        singleFile: !1
                    })
                }
            }
        } else {
            angular.forEach($scope.existingFiles, function(file, index) {
                if (file == FilePath) {
                    $scope.existingFiles.splice(index, 1)
                }
            });
            angular.forEach($scope.fileListnew, function(file, index) {
                var path = file.isbn + "/" + file.formatName + "/" + file.fullpath
                if (path == FilePath) {
                    $scope.fileListnew.splice(index, 1)
                }
            });
            if ($scope.fileListnew.length == 0) {
                var myEl3 = angular.element(document.querySelector('#chkFolder'));
                myEl3.removeClass('active')
            }
        }
        var arr = $.map($scope.fileListnew, function(o) {
            return o.fullpath
        })
        if ($scope.appendPath == "") {
            var firstElem = arr.pop();
            $scope.appendPath = firstElem
        } else {
            if (arr.length > 1)
                var lastElem = " , " + arr.pop();
            else var lastElem = arr.pop();
            $scope.appendPath = arr.join(", ") + lastElem
        }
    }
    $scope.topSelectAll = function($event) {
        $scope.selectAllFolderAlert = "";
        $scope.selectAllFoldershow = !1;
        var folder = $scope.appendTopFolderName;
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'true' : 'false');
        if (action === 'true') {
            angular.forEach($scope.dataList, function(list, index) {
                list.checked = !0;
                if (folder == "" || folder == undefined) {
                    var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + list.name.replace("_folder", "")
                } else {
                    var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + folder + "/" + list.name.replace("_folder", "")
                }
                if (list.name.contains("_folder")) {
                    var fol = list.name.replace("_folder", "");
                    if (folder != null && folder != "")
                        var folder1 = folder + "/" + fol;
                    else var folder1 = fol;
                    $scope.fileListnew.push({
                        isbn: $scope.isbn,
                        formatId: $scope.format,
                        formatName: $scope.formatId,
                        folder: folder1,
                        filename: null,
                        fullpath: folder1,
                        length: $scope.count,
                        randomkey: randomkey,
                        bucketexistinglist: $scope.isbnformatlist,
                        bucketformatlist: $scope.formatlist,
                        singleFile: !1
                    })
                } else {
                    if ($scope.existingFiles.length > 0) {
                        if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                            $scope.selectAllFolderAlert = "File has already selected. Please choose different file";
                            $scope.selectAllFoldershow = !0;
                            document.getElementById(event.target.id).checked = !1
                        } else {
                            $scope.existingFiles.push(FilePath);
                            if (folder != null && folder != "") {
                                var fullpath = folder + "/" + list.name
                            } else {
                                var fullpath = list.name
                            }
                            $scope.fileListnew.push({
                                isbn: $scope.isbn,
                                formatId: $scope.format,
                                formatName: $scope.formatId,
                                folder: folder,
                                filename: list.name,
                                fullpath: fullpath,
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.isbnformatlist,
                                bucketformatlist: $scope.formatlist,
                                singleFile: !1
                            })
                        }
                    } else {
                        $scope.existingFiles.push(FilePath);
                        if (folder != null && folder != "") {
                            var fullpath = folder + "/" + list.name
                        } else {
                            var fullpath = list.name
                        }
                        $scope.fileListnew.push({
                            isbn: $scope.isbn,
                            formatId: $scope.format,
                            formatName: $scope.formatId,
                            folder: folder,
                            filename: list.name,
                            fullpath: fullpath,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.isbnformatlist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: !1
                        })
                    }
                }
            })
        } else if (action === 'false') {
            angular.forEach($scope.dataList, function(list, index) {
                angular.forEach($scope.existingFiles, function(file, index) {
                    if (file == FilePath) {
                        $scope.existingFiles.splice(index, 1)
                    }
                });
                angular.forEach($scope.fileListnew, function(file, index) {
                    var path = file.isbn + "/" + file.formatName + "/" + list.name.replace("_folder", "")
                    if (path == FilePath) {
                        $scope.fileListnew.splice(index, 1)
                    }
                });
                file.checked = !1
            })
        }
        var arr = $.map($scope.fileListnew, function(o) {
            return o.fullpath
        })
        if ($scope.appendPath == "") {
            var firstElem = arr.pop();
            $scope.appendPath = firstElem
        } else {
            var lastElem = " , " + arr.pop();
            $scope.appendPath = arr.join(", ") + lastElem
        }
    }
    $scope.uploadFormatAlertGridShow = {};
    $scope.uploadFormatAlertGrid = {}
    $scope.uploadFileAlertGridShow = {};
    $scope.uploadFileAlertGrid = {}
    $scope.browseInvalidFileshow = {};
    $scope.browseInvalidFileAlert = {};
    $scope.browseSameFileshow = {};
    $scope.browseSameFileAlert = {};
    $scope.browseFileshow = {};
    $scope.browseFileAlert = {};
    $scope.getGridSelectedItem = function(fil, val, form, randomkey) {
        $scope.uploadFormatAlertGridShow[randomkey] = !1;
        $scope.uploadFormatAlertGrid[randomkey] = "";
        delete $scope.uploadfile[randomkey];
        var path = fil.isbn + "/" + val;
        $http({
            method: 'POST',
            url: '/getFormat',
            data: {
                formatName: val
            }
        }).then(function(response) {
            $scope.gridformat = response.data.data.formatId;
            if (response.data.data.singleFile) {
                if ($scope.existingformat.length > 0) {
                    if (!($scope.existingformat.indexOf(path) == -1)) {
                        $scope.uploadFormatAlertGridShow[randomkey] = !0;
                        $scope.uploadFormatAlertGrid[randomkey] = "Format has already selected. Please choose different format";
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == randomkey) {
                                var previousPath = file.isbn + "/" + file.formatName;
                                angular.forEach($scope.existingformat, function(format, index) {
                                    if (format == previousPath) {
                                        $scope.existingformat.splice(index, 1)
                                    }
                                });
                                $scope.fileList[index].formatId = null;
                                $scope.fileList[index].formatName = null;
                                $scope.fileList[index].folder = null;
                                $scope.fileList[index].fullpath = null;
                                $scope.fileList[index].filename = null;
                                $scope.fileList[index].singleFile = !0
                            }
                        })
                    } else {
                        var formatpath = fil.isbn + "/" + fil.formatName;
                        angular.forEach($scope.existingformat, function(format, index) {
                            if (format == formatpath) {
                                $scope.existingformat.splice(index, 1)
                            }
                        });
                        $scope.existingformat.push(path);
                        $scope.selectedFormat[randomkey] = val;
                        $scope.gridfolderenable[randomkey] = !1;
                        $http({
                            method: 'POST',
                            url: '/getFilenameByFormatId',
                            data: {
                                formatName: $scope.selectedFormat[randomkey],
                                productIDValue: fil.isbn
                            }
                        }).then(function(response) {
                            $scope.foldernames[randomkey] = response.data.data[0];
                            angular.forEach($scope.fileList, function(file, index) {
                                if (file.randomkey == randomkey) {
                                    $scope.fileList[index].isbn = fil.isbn;
                                    $scope.fileList[index].formatId = $scope.gridformat;
                                    $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                                    $scope.fileList[index].folder = null;
                                    $scope.fileList[index].fullpath = null;
                                    $scope.fileList[index].filename = $scope.foldernames[randomkey];
                                    $scope.fileList[index].randomkey = randomkey;
                                    $scope.fileList[index].singleFile = !0
                                }
                            })
                        })
                    }
                } else {
                    var formatpath = fil.isbn + "/" + fil.formatName;
                    angular.forEach($scope.existingformat, function(format, index) {
                        if (format == formatpath) {
                            $scope.existingformat.splice(index, 1)
                        }
                    });
                    $scope.existingformat.push(path);
                    $scope.selectedFormat[randomkey] = val;
                    $http({
                        method: 'POST',
                        url: '/getFilenameByFormatId',
                        data: {
                            formatName: $scope.selectedFormat[randomkey],
                            productIDValue: fil.isbn
                        }
                    }).then(function(response) {
                        $scope.foldernames[randomkey] = response.data.data[0];
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == randomkey) {
                                $scope.fileList[index].isbn = fil.isbn;
                                $scope.fileList[index].formatId = $scope.gridformat;
                                $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                                $scope.fileList[index].folder = null;
                                $scope.fileList[index].fullpath = null;
                                $scope.fileList[index].filename = $scope.foldernames[randomkey];
                                $scope.fileList[index].randomkey = randomkey;
                                $scope.fileList[index].singleFile = !0
                            }
                        })
                    })
                }
            } else {
                var formatpath = fil.isbn + "/" + fil.formatName;
                angular.forEach($scope.existingformat, function(format, index) {
                    if (format == formatpath) {
                        $scope.existingformat.splice(index, 1)
                    }
                });
                $scope.existingformat.push(path);
                $scope.selectedFormat[randomkey] = val;
                $http({
                    method: 'POST',
                    url: '/getFolderlist',
                    data: {
                        formatName: $scope.selectedFormat[randomkey],
                        productIDValue: fil.isbn,
                        formatId: $scope.gridformat
                    }
                }).then(function(response) {
                    angular.forEach($scope.fileList, function(file, index) {
                        if (file.randomkey == randomkey) {
                            $scope.fileList[index].isbn = fil.isbn;
                            $scope.fileList[index].formatId = $scope.gridformat;
                            $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                            $scope.fileList[index].folder = null;
                            $scope.fileList[index].fullpath = null;
                            $scope.fileList[index].filename = null;
                            $scope.fileList[index].randomkey = randomkey;
                            $scope.fileList[index].singleFile = !1;
                            $scope.fileList[index].folderList = response.data.data
                        }
                    });
                    $scope.gridfolderenable[randomkey] = !0
                })
            }
        })
    }
    $scope.addfiledetails = function(form) {
        $scope.selectFolderAlert = "";
        $scope.selectFoldershow = !1;
        if ($scope.isbn == null || $scope.isbn == "") {
            form.$setValidity('error', !1);
            $scope.upload_error_blank_isbn = "Please enter isbn"
        } else if ($scope.formatId === "" || $scope.formatId === "undefined") {
            form.$setValidity('error', !1);
            $scope.upload_error_formatid = "Please select formatId"
        } else {
            var randomkey = Math.floor((Math.random() * 1000) + 1);
            $http({
                method: 'POST',
                url: '/getFormat',
                data: {
                    formatName: $scope.formatId
                }
            }).then(function(response) {
                $scope.format = response.data.data.formatId;
                if (response.data.data.singleFile) {
                    var isSingle = response.data.data.singleFile;
                    $scope.formatenable = !1;
                    $http({
                        method: 'POST',
                        url: '/getFilenameByFormatId',
                        data: {
                            formatName: $scope.formatId,
                            productIDValue: $scope.isbn
                        }
                    }).then(function(response) {
                        $scope.foldernamesTop = response.data.data[0];
                        $scope.fileList.push({
                            isbn: $scope.isbn,
                            title: $scope.title,
                            author: $scope.author,
                            formatId: $scope.format,
                            folder: null,
                            formatName: $scope.formatId,
                            filename: $scope.foldernamesTop,
                            fullpath: $scope.foldernamesTop,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.isbnformatlist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: isSingle,
                            assetStatus: "Pending Approval",
                            assetStatusCode: "12"
                        });
                        $('#isbn' + $scope.isbn).val("");
                        $scope.isbn = "";
                        $scope.formatenable = !1;
                        $scope.formatId = "";
                        $scope.folderId = "";
                        $scope.appendPath = "";
                        $scope.appendTopFolderName = "";
                        $scope.folderenable = !1
                    })
                } else {
                    $scope.formatenable = !0;
                    $http({
                        method: 'POST',
                        url: '/getFolderlist',
                        data: {
                            formatName: $scope.formatId,
                            productIDValue: $scope.isbn,
                            formatId: $scope.format
                        }
                    }).then(function(response) {
                        if ($scope.fileListnew.length > 0) {
                            angular.forEach($scope.fileListnew, function(filenew, index) {
                                $scope.fileListnew[index].folderList = response.data.data
                            });
                            $scope.fileList = $scope.fileList.concat($scope.fileListnew);
                            $scope.fileListnew = []
                        } else {
                            $scope.fileList.push({
                                isbn: $scope.isbn,
                                title: $scope.title,
                                author: $scope.author,
                                formatId: $scope.format,
                                folder: null,
                                formatName: $scope.formatId,
                                filename: null,
                                fullpath: null,
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.isbnformatlist,
                                bucketformatlist: $scope.formatlist,
                                singleFile: isSingle,
                                folderList: response.data.data,
                                assetStatus: "Pending Approval",
                                assetStatusCode: "12"
                            })
                        }
                        $('#isbn' + $scope.isbn).val("");
                        $scope.isbn = "";
                        $scope.formatenable = !1;
                        $scope.formatId = "";
                        $scope.folderId = "";
                        $scope.appendPath = "";
                        $scope.appendTopFolderName = "";
                        $scope.folderenable = !1
                    })
                }
            });
            var myEl1 = angular.element(document.querySelector('#chkISBN'));
            myEl1.removeClass('active');
            var myEl2 = angular.element(document.querySelector('#chkFormatType'));
            myEl2.removeClass('active');
            var myEl3 = angular.element(document.querySelector('#chkFolder'));
            myEl3.removeClass('active');
            var myEl4 = angular.element(document.querySelector('#chkBrowse'));
            myEl4.removeClass('active')
        }
    }
    $scope.sizefilter = function(size) {
        if (isNaN(size))
            size = 0;
        if (size < 1024) {
            $scope.filteredsize = size + ' Bytes';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Kb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Mb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Gb';
            return $scope.filteredsize
        }
        size /= 1024;
        $scope.filteredsize = size.toFixed(2) + ' Tb';
        return $scope.filteredsize
    }
    $scope.getFolList = function(list, fil, formatName, appendFolderName) {
        var folder = list.replace("_folder", "");
        if ($scope.appendFolderName[fil.randomkey] == null || $scope.appendFolderName[fil.randomkey] == "") {
            $scope.appendFolderName[fil.randomkey] = folder
        } else {
            $scope.appendFolderName[fil.randomkey] = $scope.appendFolderName[fil.randomkey] + "/" + folder
        }
        if (formatName == null) {
            var newformatname = fil.formatName
        } else {
            var newformatname = formatName
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: newformatname,
                productIDValue: fil.isbn,
                formatId: fil.formatId,
                folder: $scope.appendFolderName[fil.randomkey]
            }
        }).then(function(response) {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].folderList = response.data.data
                }
            })
        })
    }
    $scope.setAssetStatus = function(status, fil) {
        $http({
            method: 'POST',
            url: '/getAssetStatus',
            data: {
                formatStatus: status,
                formatStatusType: "FORMAT"
            }
        }).then(function(response) {
            $scope.status = response.data.data;
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].assetStatusCode = $scope.status;
                    $scope.fileList[index].assetStatus = status
                }
            })
        })
    }
    $scope.upOneLevel = function(fil, formatName, appendFolderName) {
        var folder = $scope.appendFolderName[fil.randomkey].split('/');
        folder.pop();
        if (folder == "") {
            $scope.appendFolderName[fil.randomkey] = ""
        } else {
            $scope.appendFolderName[fil.randomkey] = folder.join('/')
        }
        if (formatName == null) {
            var newformatname = fil.formatName
        } else {
            var newformatname = formatName
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: newformatname,
                productIDValue: fil.isbn,
                formatId: fil.formatId,
                folder: $scope.appendFolderName[fil.randomkey]
            }
        }).then(function(response) {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].folderList = response.data.data
                }
            })
        })
    }
    $scope.getSelectedFolder = function(list, fil, position, event) {
        $scope.uploadFileAlertGridShow[fil.randomkey] = !1;
        $scope.uploadFileAlertGrid[fil.randomkey] = "";
        var folder = $scope.appendFolderName[fil.randomkey];
        if (folder == "" || folder == undefined) {
            var FilePath = fil.isbn + "/" + fil.formatName + "/" + list.replace("_folder", "")
        } else {
            var FilePath = fil.isbn + "/" + fil.formatName + "/" + folder + "/" + list.replace("_folder", "")
        }
        if (event.target.checked) {
            if (list.contains("_folder")) {
                angular.forEach(fil.folderList, function(file, index) {
                    if (position != index) {
                        file.checked = "false"
                    }
                    var index1 = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.fullpath);
                    $scope.existingFiles.splice(index1, 1)
                });
                angular.forEach($scope.fileList, function(file, index) {
                    if (file.randomkey == fil.randomkey) {
                        var fol = list.replace("_folder", "");
                        if (folder != null && folder != "") {
                            $scope.fileList[index].folder = folder + "/" + fol;
                            $scope.fileList[index].fullpath = $scope.fileList[index].folder
                        } else {
                            $scope.fileList[index].folder = fol;
                            $scope.fileList[index].fullpath = $scope.fileList[index].folder
                        }
                        $scope.fileList[index].filename = null
                    }
                })
            } else {
                if ($scope.existingFiles.length > 0) {
                    if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                        $scope.uploadFileAlertGridShow[fil.randomkey] = !0;
                        $scope.uploadFileAlertGrid[fil.randomkey] = "File has already selected. Please choose different file";
                        document.getElementById(event.target.id).checked = !1;
                        var index1 = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.fullpath);
                        if (index1 != -1)
                            $scope.existingFiles.splice(index1, 1)
                        angular.forEach(fil.folderList, function(file, index) {
                            if (position != index) {
                                file.checked = "false"
                            }
                        });
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == fil.randomkey) {
                                $scope.fileList[index].fullpath = null;
                                $scope.fileList[index].folder = null;
                                $scope.fileList[index].filename = null
                            }
                        })
                    } else {
                        angular.forEach(fil.folderList, function(file, index) {
                            if (position != index) {
                                file.checked = "false"
                            }
                            var index1 = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.fullpath);
                            if (index1 != -1)
                                $scope.existingFiles.splice(index1, 1)
                        });
                        $scope.existingFiles.push(FilePath);
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == fil.randomkey) {
                                if (!list.contains("_folder")) {
                                    if (folder != null && folder != "") {
                                        $scope.fileList[index].folder = folder;
                                        $scope.fileList[index].fullpath = folder + "/" + list
                                    } else {
                                        $scope.fileList[index].fullpath = list
                                    }
                                    $scope.fileList[index].filename = list
                                } else {
                                    var fol = list.replace("_folder", "");
                                    if (folder != null && folder != "")
                                        $scope.fileList[index].folder = folder + "/" + fol;
                                    else $scope.fileList[index].folder = fol;
                                    $scope.fileList[index].filename = null;
                                    $scope.fileList[index].fullpath = $scope.fileList[index].folder
                                }
                            }
                        })
                    }
                } else {
                    $scope.existingFiles.push(FilePath);
                    angular.forEach(fil.folderList, function(file, index) {
                        if (position != index) {
                            file.checked = "false"
                        }
                    });
                    angular.forEach($scope.fileList, function(file, index) {
                        if (file.randomkey == fil.randomkey) {
                            if (!list.contains("_folder")) {
                                if (folder != null && folder != "") {
                                    $scope.fileList[index].folder = folder;
                                    $scope.fileList[index].fullpath = folder + "/" + list
                                } else {
                                    $scope.fileList[index].fullpath = list
                                }
                                $scope.fileList[index].filename = list
                            } else {
                                var fol = list.replace("_folder", "");
                                if (folder != null && folder != "")
                                    $scope.fileList[index].folder = folder + "/" + fol;
                                else $scope.fileList[index].folder = fol;
                                $scope.fileList[index].filename = null;
                                $scope.fileList[index].fullpath = $scope.fileList[index].folder
                            }
                        }
                    })
                }
            }
        } else {
            angular.forEach($scope.existingFiles, function(file, index) {
                if (file == FilePath) {
                    $scope.existingFiles.splice(index, 1)
                }
            });
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].folder = null;
                    $scope.fileList[index].filename = null;
                    $scope.fileList[index].fullpath = null
                }
            })
        }
    }
    $scope.createNewFolder = function(fil, gridfolderId) {
        var emptyfolder = !1;
        var nofolder = !1;
        var check = !0;
        if (!angular.equals({}, fil.folderList)) {
            if (fil.folderList.length > 0) {
                angular.forEach(fil.folderList, function(name) {
                    if (name[1] == !0) {
                        if (name[0].contains("_folder")) {
                            angular.forEach($scope.fileList, function(file, index) {
                                if (file.randomkey == fil.randomkey) {
                                    var fol = file.folder + "/" + gridfolderId;
                                    $scope.fileList[index].folder = fol;
                                    $scope.fileList[index].fullpath = fol
                                }
                            })
                        } else {
                            emptyfolder = !0
                        }
                    } else {
                        nofolder = !0
                    }
                })
            } else {
                nofolder = !0
            }
        } else {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    if (file.randomkey == fil.randomkey) {
                        if (file.folder == null)
                            var fol = gridfolderId;
                        else var fol = file.folder + "/" + gridfolderId;
                        $scope.fileList[index].folder = fol;
                        $scope.fileList[index].fullpath = fol
                    }
                }
            })
        }
        if (nofolder || emptyfolder) {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    if (file.folder == null)
                        var fol = gridfolderId;
                    else var fol = file.folder + "/" + gridfolderId;
                    $scope.fileList[index].folder = fol;
                    $scope.fileList[index].fullpath = fol
                }
            })
        }
    }
    $scope.addComments = function(fil, comments) {
        angular.forEach($scope.fileList, function(file, index) {
            if (file.randomkey == fil.randomkey) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].comments = comments
                }
            }
        })
    }
    $scope.uploadEmailList = [];
    $rootScope.addEmailIds = [];
    $scope.multipartupload = function(filesel, filelist) {
        var notificationEmailList = document.getElementById('uploadEmail').value.split(",").map(function(item) {
            return item.trim()
        });
        notificationEmailList = notificationEmailList.filter(function(e) {
            return e
        });
        $rootScope.addEmailIds = [];
        angular.forEach(notificationEmailList, function(email) {
            if (!$rootScope.addEmailIds.includes(email)) {
                $rootScope.addEmailIds.push(email)
            }
        })
        $rootScope.Idlewatch(!1);
        var files, file_id = 0;
        $http({
            method: 'POST',
            url: '/generateFileUploadLink',
            data: null
        }).then(function(response) {
            var accessKey = response.data.data.accessKey;
            var bucketName = response.data.data.bucketName;
            var region = response.data.data.region;
            var signerUrl = "/fileUploadSignature";
            var filePromises = [],
                allCompleted
            COOKIE = 'evaporate_example', cookie_data = {
                persist: "off"
            }, cookie_options = {
                expires: 1
            };
            var count = 0;
//Added by shamsheer for JIRA : 4126 -changes starts here
angular.forEach(filelist,function(fil,index){
	
	if(fil.indexOfArray != undefined){
	if(fil.indexOfArray != null && fil.indexOfArray !=""){

		filelist.splice(fil.indexOfArray,1);
	}
}
});

//Added by shamsheer for JIRA : 4126 -changes ends here
            angular.forEach(filelist, function(fileli, index) {
                var len = fileli.randomkey;
                if (filesel[len] != undefined) {
                    var formatIndex = $scope.existingformat.indexOf(fileli.isbn + "/" + fileli.formatName);
                    if (fileli.folder == null || fileli.folder == "")
                        var fileIndex = $scope.existingFiles.indexOf(fileli.isbn + "/" + fileli.formatName + "/" + filesel[fileli.randomkey].name);
                    else var fileIndex = $scope.existingFiles.indexOf(fileli.isbn + "/" + fileli.formatName + "/" + fileli.folder + "/" + filesel[fileli.randomkey].name);
                    if (formatIndex != -1)
                        $scope.existingformat.splice(formatIndex, 1);
                    if (fileIndex != -1)
                        $scope.existingFiles.splice(fileIndex, 1);
                    $scope.fileuploadlist.push({
                        file1: filesel[len],
                        randomkey: fileli.randomkey,
                        convertedSize: $scope.sizefilter(filesel[len].size),
                        fileindex: index
                    });
                    $scope.fileList = $scope.fileList.filter(function(obj) {
                        return obj.randomkey !== len
                    });
                    if (fileli.folder == null || fileli.folder == '')
                        var directoryName = fileli.isbn + "/" + fileli.formatName + "/"
                    else var directoryName = fileli.isbn + "/" + fileli.formatName + "/" + fileli.folder + "/"
                    Evaporate.create({
                        signerUrl: signerUrl,
                        aws_key: accessKey,
                        bucket: bucketName,
                        cloudfront: !1,
                        s3Acceleration: !0,
                        awsSignatureVersion: '4',
                        awsRegion: region,
                        directoryName: directoryName,
                        projectId: $scope.project_id,
                        computeContentMd5: !0,
                        cryptoMd5Method: function(data) {
                            return AWS.util.crypto.md5(data, 'base64')
                        },
                        cryptoHexEncodedHash256: function(data) {
                            return AWS.util.crypto.sha256(data, 'hex')
                        },
                        logging: !1,
                        s3FileCacheHoursAgo: 1,
                        allowS3ExistenceOptimization: !0
                    }).then(function(_e_) {
                        var name = filesel[len].name;
                        var size = $scope.sizefilter(filesel[len].size);
                        var byteSize = filesel[len].size;
                        var fileKey = bucketName + '/' + name;
                        callback_methods = callbacks(filesel[len], fileKey, fileli.randomkey, index);
                        var promise = _e_.add({
                            name: name,
                            file: filesel[len],
                            started: callback_methods.started,
                            complete: callback_methods.complete,
                            progress: callback_methods.progress,
                            paused: callback_methods.paused,
                            pausing: callback_methods.pausing,
                            resumed: callback_methods.resumed,
                            cancelled: callback_methods.cancelled
                        }, {
                            bucket: bucketName,
                            aws_key: accessKey
                        }).then((function(requestedName) {
                            return function(awsKey) {
                                if (awsKey === requestedName) {
                                    $scope.uploadEmailList.push({
                                        isbn: fileli.isbn,
                                        title: fileli.title,
                                        author: fileli.author,
                                        formatName: fileli.formatName,
                                        fileName: name,
                                        fileSize: size
                                    });
                                    $scope.templateData = {};
                                    $scope.templateData["[file-name]"] = name;
                                    $scope.templateData["[format-name]"] = fileli.formatName;
                                    $scope.templateData["[file-size]"] = size;
                                    $scope.templateData["[isbn]"] = fileli.isbn;
                                    $scope.templateData["[title]"] = fileli.title;
                                    $scope.templateData["[author]"] = fileli.author;
                                    $scope.templateData["[uploaded-by]"] = $rootScope.loggedUser.firstName;
                                    $scope.templateData["[upload-type]"] = "Manual Upload";
                                    $http({
                                        method: 'POST',
                                        url: '/addfileobjects',
                                        data: {
                                            productIDValue: fileli.isbn,
                                            loggeduser: $rootScope.loggedUser.userId,
                                            filename: name,
                                            formatName: fileli.formatName,
                                            size: byteSize,
                                            bucket: bucketName,
                                            folder: fileli.folder,
                                            formatStatus: fileli.assetStatusCode,
                                            comments: fileli.comments,
                                            transactionStatus: fileli.assetStatusCode,
                                            title: fileli.title,
                                            templateData: $scope.templateData,
                                            ipAddress: $window.sessionStorage.userIP,
                                            additionaleMailList: $rootScope.addEmailIds
                                        }
                                    }).then(function(response) {});
                                    $http({
                                        method: 'POST',
                                        url: '/saveShelfTransaction',
                                        data: {
                                            isbn: fileli.isbn,
                                            formatId: fileli.formatId,
                                            loggedUser: $rootScope.loggedUser.userId,
                                            action: "FILE_UPLOAD",
                                            shelfType: "Asset_Book"
                                        }
                                    }).then(function(response) {})
                                } else {}
                            }
                        })(name));
                        filePromises.push(promise);
                        allCompleted = Promise.all(filePromises).then(function() {
                            $rootScope.Idlewatch(!0);
                            count++;
                            console.log('All files were uploaded successfully.');
                            if (count == filelist.length) {
                                $http({
                                    method: 'POST',
                                    url: '/uploadMail',
                                    data: {
                                        uploadMailList: $scope.uploadEmailList,
                                        loggeduser: $rootScope.loggedUser.firstName,
                                        loggedUserEmail: $rootScope.loggedUser.emailId,
                                        additionaleMailList: $rootScope.addEmailIds,
                                        loggedUserId: $rootScope.loggedUser.userId
                                    }
                                }).then(function(response) {
                                    count = 0;
                                    $scope.uploadEmailList = []
                                })
                            }
                        }, function(reason) {
                            count++;
                            if (count == filelist.length) {
                                $http({
                                    method: 'POST',
                                    url: '/uploadMail',
                                    data: {
                                        uploadMailList: $scope.uploadEmailList,
                                        loggeduser: $rootScope.loggedUser.firstName,
                                        loggedUserEmail: $rootScope.loggedUser.emailId,
                                        additionaleMailList: $rootScope.addEmailIds,
                                        loggedUserId: $rootScope.loggedUser.userId
                                    }
                                }).then(function(response) {
                                    count = 0;
                                    $scope.uploadEmailList = []
                                })
                            }
                        });

                        function callbacks(file, fileKey, randomkey, fileindex) {
                            $('#show_cancel_' + fileindex + randomkey).click(function() {
                                _e_.cancel(fileKey)
                            });
                            $('#show_pause_' + fileindex + randomkey).click(function() {
                                _e_.pause(fileKey)
                            });
                            $('#show_resume_' + fileindex + randomkey).click(function() {
                                _e_.resume(fileKey)
                            });
                            var clock = new ProgressBar.Line(angular.element(document.getElementById('progressbar_' + fileindex + randomkey))[0], {
                                strokeWidth: 0,
                                duration: 350,
                                text: {
                                    value: ''
                                },
                                step: function(state, bar) {
                                    var bar1 = (bar.value() * 100).toFixed(0) + '%';
                                    $('#progressbar_' + fileindex + randomkey).css('width', bar1)
                                }
                            });
                            var speed = angular.element(document.getElementById('filesize_show_' + fileindex + randomkey));
                            var time = angular.element(document.getElementById('time_show_' + fileindex + randomkey));

                            function markComplete(className) {
                                progress_clock.addClass(className);
                                status.text(className)
                            }
                            return {
                                started: function(fid) {
                                    angular.element($("#progressClock_" + fileindex + randomkey)).addClass('evaporating');
                                    angular.element($("#progressClock_" + fileindex + randomkey)).addClass('Progress');
                                    $('#show_cancel_' + fileindex + randomkey).show();
                                    $('#show_pause_' + fileindex + randomkey).show();
                                    $('#show_close_' + fileindex + randomkey).hide();
                                    $('#selected_show_' + fileindex + randomkey).hide();
                                    $('#title_show_' + fileindex + randomkey).show();
                                    $('#progress_show_' + fileindex + randomkey).show();
                                    $('#filesize_show_' + fileindex + randomkey).show();
                                    $('#show_resume_' + fileindex + randomkey).hide();
                                    $('#cancel_text_show_' + fileindex + randomkey).hide();
                                    var file_id = fid
                                },
                                progress: function(progressValue, data) {
                                    progress = progressValue;
                                    clock.animate(progressValue);
                                    $scope.fileloaded = data && data.loaded ? data.loaded : '';
                                    $scope.remainingTime = data && data.secondsLeft ? Math.round(data.secondsLeft / 60) : '';
                                    $scope.speed = data && data.speed ? data.readableSpeed + '/s' : '';
                                    if (data) {
                                        var xferRate = data.speed ? data.readableSpeed + "/s - " : '';
                                        var rate = data && data.loaded ? data.loaded : '';
                                        var ra = $scope.sizefilter(data.totalUploaded);
                                        var rr = " of " + $scope.sizefilter(file.size);
                                        var remaining = data.secondsLeft ? Math.round(data.secondsLeft / 60) + ' mins left' : '';
                                        speed.html(xferRate + ra + rr);
                                        time.html(remaining)
                                    }
                                },
                                complete: function(_xhr, awsKey, stats) {
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('Progress');
                                    angular.element($("#progressClock_" + fileindex + randomkey)).addClass("Completed");
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating');
                                    clock.animate(1);
                                    $('#show_cancel_' + fileindex + randomkey).hide();
                                    $('#show_pause_' + fileindex + randomkey).hide();
                                    $('#show_close_' + fileindex + randomkey).show();
                                    $('#selected_show_' + fileindex + randomkey).show();
                                    $('#title_show_' + fileindex + randomkey).hide();
                                    $('#progress_show_' + fileindex + randomkey).hide();
                                    $('#filesize_show_' + fileindex + randomkey).hide();
                                    $('#show_resume_' + fileindex + randomkey).hide();
                                    $('#cancel_text_show_' + fileindex + randomkey).hide();
                                    $('#time_show_' + fileindex + randomkey).hide()
                                },
                                pausing: function() {
                                    $('#show_resume_' + fileindex + randomkey).show();
                                    $('#show_pause_' + fileindex + randomkey).hide();
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning')
                                },
                                paused: function() {
                                    $('#show_resume_' + fileindex + randomkey).show();
                                    $('#show_pause_' + fileindex + randomkey).hide();
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning pausing')
                                },
                                resumed: function() {
                                    clock.animate(progress);
                                    $('#show_resume_' + fileindex + randomkey).hide();
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('pausing paused')
                                },
                                cancelled: function() {
                                    clock.animate(progress);
                                    angular.element($("#progressClock_" + fileindex + randomkey)).removeClass('evaporating warning paused pausing');
                                    $('#show_cancel_' + fileindex + randomkey).hide();
                                    $('#show_pause_' + fileindex + randomkey).hide();
                                    $('#show_resume_' + fileindex + randomkey).hide();
                                    $('#cancel_text_show_' + fileindex + randomkey).show();
                                    $('#title_show_' + fileindex + randomkey).hide();
                                    $('#progress_show_' + fileindex + randomkey).hide();
                                    $('#filesize_show_' + fileindex + randomkey).hide();
                                    $('#time_show_' + fileindex + randomkey).hide()
                                },
                            }
                        }
                    })
                }
            })
        }, function(response) {})
    }
    $scope.filterList = ['Completed', 'Progress', 'Failed'];
    $scope.cancelFile = function(file, index, uploadFile) {
        var elmn = angular.element(document.querySelector('#file_' + file.randomkey));
        elmn.remove();
        $scope.fileList.splice(index, 1);
        delete $scope.uploadfile[file.randomkey];
        var formatIndex = $scope.existingformat.indexOf(file.isbn + "/" + file.formatName);
        if (uploadFile != undefined)
            var fileIndex = $scope.existingFiles.indexOf(file.isbn + "/" + file.formatName + "/" + uploadFile.name);
        else var fileIndex = $scope.existingFiles.indexOf(file.isbn + "/" + file.formatName + "/" + file.filename);
        if (formatIndex != -1)
            $scope.existingformat.splice(formatIndex, 1);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1);
        $rootScope.data = {};
        $rootScope.uploadEmailForm = !1;
        document.getElementById("uploadChkHide").checked = !0
    };
    $scope.canceluploadList = function() {
        $rootScope.Idlewatch(!0);
        $scope.fileList = [];
        $scope.uploadfile = {};
        $scope.existingformat = [];
        $scope.existingFiles = []
    };
    $scope.clearAll = function(file, index) {
        var elmn = angular.element(document.querySelector('#file_' + file.randomkey));
        elmn.remove();
        $scope.fileList.splice(index, 1);
        $timeout(function() {
            $scope.searchString = ''
        }, 300)
    };
    $scope.cancelupload = function(file, index) {
        var elmn = angular.element(document.querySelector('#progressClock_' + file.fileindex + file.randomkey));
        elmn.remove();
        $scope.fileuploadlist.splice(index, 1)
    };
    $scope.downloadEnable = function(isbn, formatid, fileid) {
        $http({
            method: 'POST',
            url: '/download',
            data: {
                formatId: 'indesign',
                productIDValue: '9780748622017',
                filename: 'Defect-List-new.xlsx'
            }
        }).then(function(response) {
            $scope.downurl = response.data.data;
            $("#download_modal").css("display", "block")
        })
    }
    $scope.cancelFileModal = function(fil) {
        $scope.enableExistingFile = !1;
        var fileIndex = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.filename);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1)
    }
    $scope.replaceFileModal = function(files, fil) {
        $scope.enableExistingFile = !0;
        $scope.uploadfile[fil.randomkey] = files;
        var fileIndex = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.filename);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1)
    }
    $scope.browseFile = function(files, fil) {
        $scope.browseInvalidFileAlert[fil.randomkey] = "";
        $scope.browseInvalidFileshow[fil.randomkey] = !1;
        $scope.browseSameFileAlert[fil.randomkey] = "";
        $scope.browseSameFileshow[fil.randomkey] = !1;
        $scope.browseFileAlert[fil.randomkey] = "";
        $scope.browseFileshow[fil.randomkey] = !1;
        if (files != null) {
            var filename = files.name;
            var name_new = filename.substr(0, filename.lastIndexOf('.'));
            var rex = /^(([a-zA-Z0-9][a-zA-Z0-9_' -.]+[a-zA-Z0-9])|([a-zA-Z0-9]))+$/;
            if (!rex.test(name_new)) {
                $scope.browseInvalidFileAlert[fil.randomkey] = filename + " is not valid. Please upload files with valid name";
                $scope.browseInvalidFileshow[fil.randomkey] = !0;
                delete $scope.uploadfile[file.randomkey]
            } else {
                var index = filename.lastIndexOf(".");
                var extension = filename.substring(index, filename.length);
                var fullFilePath = fil.isbn + "/" + fil.formatName + "/" + files.name;
                $http({
                    method: 'POST',
                    url: '/checkFileFormat',
                    data: {
                        formatName: fil.formatName,
                        fileExtension: extension,
                        filename: filename,
                        productIDValue: fil.isbn
                    }
                }).then(function(response) {
                    if ("100" === response.data.code) {
                        $scope.files = files;
                        $scope.files1 = fil;
                        var fileType = response.data.data;
                        $scope.uploadfile[fil.randomkey] = files;
                    } else if ("200" === response.data.code) {
                        $scope.browseFileAlert[fil.randomkey] = response.data.status;
                        $scope.browseFileshow[fil.randomkey] = !0;
                        //Added by shamsheer for JIRA : 4126 -changes starts here
                        angular.forEach($scope.fileList,function(item,index){
                            if(item.formatId == response.data.data){
                            $scope.fileList[index].indexOfArray = index;        
                            }
                        });
                        //Added by shamsheer for JIRA : 4126 -changes ends here                     
                        delete $scope.uploadfile[fil.randomkey];
                    }
                });
                $scope.existingFiles.push(fullFilePath)
            }
        }
    };
    $scope.clearAll = function(val) {
        $timeout(function() {
            $scope.searchString = ''
        }, 300);
        $scope.fileuploadlist = []
    }
    $scope.check = function(form) {
        if (Object.keys($scope.uploadfile).length > 0) {
            return !0
        } else {
            return !1
        }
    };
    $scope.checkgridValidation = function(file) {
        if ($scope.selectedFormat[file.randomkey] != undefined || file.formatName != null) {
            return !0
        } else {
            return !1
        }
    }
    $scope.checkbrowseValidation = function() {
        if (($scope.isbn != undefined && $scope.isbn != "") && $scope.formatId != "") {
            return !0
        } else {
            return !1
        }
    }
    $scope.actionList = []
    $scope.filterUploads = function($event, val) {
        var isChecked = $event.target.checked;
        var index = $scope.actionList.indexOf(val);
        if (isChecked && index == -1) {
            $scope.actionList.push(val)
        } else {
            $scope.actionList.splice(index, 1)
        }
        angular.forEach($scope.filterList, function(data) {
            var i = $scope.actionList.indexOf(data);
            var result = document.getElementsByClassName(data);
            if (i >= 0) {
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            } else {
                angular.element(result).removeClass('active');
                angular.element(result).addClass('inactive')
            }
        });
        if ($scope.actionList.length == 0) {
            angular.forEach($scope.filterList, function(val) {
                var result = document.getElementsByClassName(val);
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            })
        }
    }
    $scope.filterUploadschkAll = function($event) {
        var isChecked = $event.target.checked;
        angular.forEach($scope.filterList, function(data) {
            var result = document.getElementsByClassName(data);
            if (isChecked) {
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            } else {
                angular.element(result).removeClass('active');
                angular.element(result).addClass('inactive')
            }
        })
    }
    $scope.checkStatusColor = function(chk) {
        if (chk === "ISBN") {
            var myEl = angular.element(document.querySelector('#chkISBN'));
            myEl.addClass('active')
        } else if (chk === "FORMATTYPE") {
            var myEl = angular.element(document.querySelector('#chkFormatType'));
            myEl.addClass('active')
        } else if (chk === "FOLDER") {
            var myEl = angular.element(document.querySelector('#chkFolder'));
            myEl.addClass('active')
        } else if (chk === 'BROWSE') {
            var myEl = angular.element(document.querySelector('#chkBrowse'));
            myEl.addClass('active')
        }
    }
}]);
app.directive("removeMe", function($rootScope) {
    return {
        link: function(scope, element, attrs) {
            element.bind("click", function() {
                element.parent().remove()
            })
        }
    }
})