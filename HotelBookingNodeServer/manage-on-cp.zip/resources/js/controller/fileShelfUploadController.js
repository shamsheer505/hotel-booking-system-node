app.controller('FileShelfUploadController', ['$scope', '$http', '$timeout', '$rootScope', '$location', function($scope, $http, $timeout, $rootScope, $location) {
    $rootScope.testScroll();
    $scope.fileList = [];
    $scope.formatId = "";
    $scope.existingFiles = [];
    $scope.existingformat = [];
    $scope.bucketexistinglist = [];
    $scope.selectedFormat = {};
    $scope.gridfolderenable = {};
    $scope.foldernames = {};
    $scope.griddataList = {};
    $scope.gridFormatId = {};
    $scope.appendFolderName = {};
    $scope.gridfolderId = "";
    $scope.fileListnew = [];
    $scope.appendPath = "";
    $scope.count = 0;
    $http({
        method: 'POST',
        url: '/formatlist',
        data: null
    }).then(function(response) {
        $scope.bucketformatlist = response.data.data;
        angular.forEach($rootScope.downloadShelfUploadList, function(key, value) {
            $scope.foldernames = {};
            $scope.bucketisbnformatlist = {};
            $scope.bucketexistinglistUI = {};
            $scope.bucketformatlistUI = {};
            var randomkey = Math.floor((Math.random() * 1000) + 1);
            $http({
                method: 'POST',
                url: '/isbnformatlist',
                data: {
                    productIDValue: key[0].isbn
                }
            }).then(function(response) {
                $scope.bucketisbnformatlist[randomkey] = response.data.data;
                $scope.bucketexistinglist = [];
                angular.forEach($scope.bucketformatlist, function(value1, key1) {
                    angular.forEach($scope.bucketisbnformatlist[randomkey], function(value2) {
                        if (key1 === value2) {
                            console.log("value1 if:  " + value1);
                            $scope.bucketexistinglist.push(value1)
                        }
                    })
                });
                $scope.bucketexistinglistUI[randomkey] = $scope.bucketexistinglist;
                $scope.bucketformatlistCopy = angular.copy($scope.bucketformatlist);
                angular.forEach($scope.bucketisbnformatlist[randomkey], function(value2) {
                    angular.forEach($scope.bucketformatlist, function(value1, key1) {
                        delete($scope.bucketformatlistCopy[value2])
                    })
                });
                $scope.bucketformatlistUI[randomkey] = $scope.bucketformatlistCopy;
                var path = key[0].isbn + "/" + key[0].format;
                $scope.existingformat.push(path);
                $http({
                    method: 'POST',
                    url: '/getFormat',
                    data: {
                        formatName: key[0].format
                    }
                }).then(function(response) {
                    $scope.gridFormatId[randomkey] = response.data.data.formatId;
                    if (response.data.data.singleFile) {
                        $scope.gridfolderenable[randomkey] = !1;
                        $http({
                            method: 'POST',
                            url: '/getFilenameByFormatId',
                            data: {
                                formatName: key[0].format,
                                productIDValue: key[0].isbn
                            }
                        }).then(function(response) {
                            $scope.foldernames[randomkey] = response.data.data[0];
                            $scope.fileList.push({
                                isbn: key[0].isbn,
                                formatId: key[0].formatId,
                                formatName: key[0].format,
                                folder: null,
                                filename: $scope.foldernames[randomkey],
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.bucketexistinglistUI[randomkey],
                                bucketformatlist: $scope.bucketformatlistUI[randomkey],
                                singleFile: response.data.data.singleFile
                            })
                        })
                    } else {
                        $http({
                            method: 'POST',
                            url: '/getFolderlist',
                            data: {
                                formatName: key[0].format,
                                productIDValue: key[0].isbn,
                                formatId: key[0].formatId
                            }
                        }).then(function(response) {
                            $scope.griddataList[randomkey] = response.data.data;
                            if ($scope.griddataList != null) {
                                $scope.gridfolderenable[randomkey] = !0
                            }
                            $scope.fileList.push({
                                isbn: key[0].isbn,
                                formatId: key[0].formatId,
                                formatName: key[0].format,
                                folder: null,
                                filename: null,
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.bucketexistinglistUI[randomkey],
                                bucketformatlist: $scope.bucketformatlistUI[randomkey],
                                singleFile: response.data.data.singleFile
                            })
                        })
                    }
                })
            });
            $scope.count = $scope.count + 1
        });
        console.log($scope.fileList)
    });
    $scope.fileuploadlist = [];
    $scope.formatenable = !1;
    $scope.folderenable = !1;
    $scope.uploadfile = {};
    $scope.disableele = function() {
        $('#formatdiv').addClass("")
    }
    $scope.formvalidate = function(Form) {
        if (Form.$error.error) {
            Form.$error.error = !1;
            Form.$valid = !0
        }
    }
    $scope.isbnformat = function() {
        $http({
            method: 'POST',
            url: '/isbnformatlist',
            data: null
        }).then(function(response) {
            $scope.isbnformatlist = response.data.data
        })
    }
    $scope.checkIsbn = function(form) {
        if ($scope.isbn != "") {
            $http({
                method: 'POST',
                url: '/checkIsbn',
                data: {
                    productIDValue: $scope.isbn
                }
            }).then(function(response) {
                if (!response.data.data) {
                    form.$setValidity('error', !1);
                    $scope.upload_error_isbn = "Please enter valid isbn"
                }
            })
        }
    }
    $scope.changeisbn = function(Form) {
        if (Form.$error.error) {
            Form.$error.error = !1;
            Form.$valid = !0;
            $scope.upload_error_isbn = "";
            $scope.upload_error_blank_isbn = "";
            $scope.upload_error_formatid = ""
        }
        if ($scope.isbn === "") {
            $scope.formatenable = !1
        } else {
            $scope.formatenable = !0
        }
        $scope.existinglist = [];
        $scope.newlist = [];
        $http({
            method: 'POST',
            url: '/formatlist',
            data: null
        }).then(function(response) {
            $scope.formatlist = response.data.data;
            console.log("formatlist::" + $scope.formatlist);
            $http({
                method: 'POST',
                url: '/isbnformatlist',
                data: {
                    productIDValue: $scope.isbn
                }
            }).then(function(response) {
                $scope.isbnformatlist = response.data.data;
                console.log("isbnformatlist::" + $scope.isbnformatlist);
                angular.forEach($scope.formatlist, function(value1, key1) {
                    angular.forEach($scope.isbnformatlist, function(value2) {
                        if (key1 === value2) {
                            console.log("value1 if:  " + value1);
                            $scope.existinglist.push(value1)
                        }
                    })
                });
                angular.forEach($scope.isbnformatlist, function(value2) {
                    angular.forEach($scope.formatlist, function(value1, key1) {
                        delete($scope.formatlist[value2])
                    })
                });
                console.log($scope.formatlist)
            })
        })
    }
    $scope.getSelectedItem = function(val, form) {
        $scope.formvalidate(form);
        $scope.formatId = val;
        if ($scope.formatId === "") {
            $scope.folderenable = !1
        }
        var path = $scope.isbn + "/" + $scope.formatId;
        $http({
            method: 'POST',
            url: '/getFormat',
            data: {
                formatName: $scope.formatId
            }
        }).then(function(response) {
            $scope.format = response.data.data.formatId;
            if (response.data.data.singleFile) {
                $scope.folderenable = !1;
                if ($scope.existingformat.length > 0) {
                    if (!($scope.existingformat.indexOf(path) == -1)) {
                        $scope.formatId = "";
                        alert("Format has already selected. Please choose different format")
                    }
                }
            } else {
                $scope.folderenable = !0;
                $http({
                    method: 'POST',
                    url: '/getFolderlist',
                    data: {
                        formatId: $scope.format,
                        productIDValue: $scope.isbn,
                        formatName: $scope.formatId
                    }
                }).then(function(response) {
                    $scope.dataList = response.data.data
                })
            }
        })
    }
    $scope.getTopFolList = function(list) {
        $scope.selectAll = !1;
        var folder = list.name.replace("_folder", "");
        if ($scope.appendTopFolderName == null || $scope.appendTopFolderName == "") {
            $scope.appendTopFolderName = folder
        } else {
            $scope.appendTopFolderName = $scope.appendTopFolderName + "/" + folder
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.formatId,
                productIDValue: $scope.isbn,
                formatId: $scope.format,
                folder: $scope.appendTopFolderName
            }
        }).then(function(response) {
            $scope.dataList = response.data.data
        })
    }
    $scope.upOneLevelTop = function() {
        var folder = $scope.appendTopFolderName.split('/');
        folder.pop();
        if (folder == "") {
            $scope.appendTopFolderName = ""
        } else {
            $scope.appendTopFolderName = folder.join('/')
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: $scope.formatId,
                productIDValue: $scope.isbn,
                formatId: $scope.format,
                folder: $scope.appendTopFolderName
            }
        }).then(function(response) {
            $scope.dataList = response.data.data
        })
    }
    $scope.createNewFolderTop = function(TopfolderId) {
        var emptyfolder = !1;
        var nofolder = !1;
        var check = !0;
        var folderCount = 0;
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        if (!angular.equals({}, $scope.dataList)) {
            angular.forEach($scope.dataList, function(name) {
                if (name.checked == !0) {
                    if (name.name.contains("_folder")) {
                        folderCount++
                    } else {
                        emptyfolder = !0
                    }
                } else {
                    nofolder = !0
                }
            })
        } else {
            $scope.folderId = TopfolderId;
            $scope.fileListnew.push({
                isbn: $scope.isbn,
                formatId: $scope.format,
                formatName: $scope.formatId,
                folder: $scope.folderId,
                filename: null,
                fullpath: $scope.folderId,
                length: $scope.count,
                randomkey: randomkey,
                bucketexistinglist: $scope.existinglist,
                bucketformatlist: $scope.formatlist,
                singleFile: !1
            })
        }
        if (folderCount >= 2) {
            alert("Please select any one folder");
            $scope.folderId = "";
            $scope.TopfolderId = ""
        } else if (nofolder || emptyfolder) {
            $scope.folderId = TopfolderId;
            $scope.fileListnew.push({
                isbn: $scope.isbn,
                formatId: $scope.format,
                formatName: $scope.formatId,
                folder: $scope.folderId,
                filename: null,
                fullpath: $scope.folderId,
                length: $scope.count,
                randomkey: randomkey,
                bucketexistinglist: $scope.existinglist,
                bucketformatlist: $scope.formatlist,
                singleFile: !1
            })
        } else {
            if ($scope.appendTopFolderName != undefined)
                $scope.folderId = $scope.appendTopFolderName + TopfolderId;
            else $scope.folderId = TopfolderId;
            angular.forEach($scope.fileListnew, function(file, index) {
                angular.forEach($scope.dataList, function(name) {
                    if (name.checked == !0) {
                        if (name.name.contains("_folder")) {
                            if (file.folder === name.name.replace("_folder", "")) {
                                $scope.fileListnew[index].folder = file.folder + "/" + $scope.folderId;
                                $scope.fileListnew[index].fullpath = file.fullpath + "/" + $scope.folderId
                            }
                        }
                    }
                })
            });
            console.log("sssss");
            console.log($scope.fileListnew)
        }
    }
    $scope.getSelectedFolderTop = function(list, position, event, griddataList) {
        var folder = $scope.appendTopFolderName;
        if (folder == "" || folder == undefined) {
            var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + list.replace("_folder", "")
        } else {
            var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + folder + "/" + list.replace("_folder", "")
        }
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        if (event.target.checked) {
            if (list.contains("_folder")) {
                var fol = list.replace("_folder", "");
                if (folder != null && folder != "")
                    var folder1 = folder + "/" + fol;
                else var folder1 = fol;
                $scope.fileListnew.push({
                    isbn: $scope.isbn,
                    formatId: $scope.format,
                    formatName: $scope.formatId,
                    folder: folder1,
                    filename: null,
                    fullpath: folder1,
                    length: $scope.count,
                    randomkey: randomkey,
                    bucketexistinglist: $scope.existinglist,
                    bucketformatlist: $scope.formatlist,
                    singleFile: !1
                })
            } else {
                if ($scope.existingFiles.length > 0) {
                    if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                        alert("File has already selected. Please choose different file");
                        document.getElementById(event.target.id).checked = !1
                    } else {
                        $scope.existingFiles.push(FilePath);
                        if (folder != null && folder != "") {
                            var fullpath = folder + "/" + list
                        } else {
                            var fullpath = list
                        }
                        $scope.fileListnew.push({
                            isbn: $scope.isbn,
                            formatId: $scope.format,
                            formatName: $scope.formatId,
                            folder: folder,
                            filename: list,
                            fullpath: fullpath,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.existinglist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: !1
                        })
                    }
                } else {
                    $scope.existingFiles.push(FilePath);
                    if (folder != null && folder != "") {
                        var fullpath = folder + "/" + list
                    } else {
                        var fullpath = list
                    }
                    $scope.fileListnew.push({
                        isbn: $scope.isbn,
                        formatId: $scope.format,
                        formatName: $scope.formatId,
                        folder: folder,
                        filename: list,
                        fullpath: fullpath,
                        length: $scope.count,
                        randomkey: randomkey,
                        bucketexistinglist: $scope.existinglist,
                        bucketformatlist: $scope.formatlist,
                        singleFile: !1
                    })
                }
            }
        } else {
            angular.forEach($scope.existingFiles, function(file, index) {
                if (file == FilePath) {
                    $scope.existingFiles.splice(index, 1)
                }
            });
            angular.forEach($scope.fileListnew, function(file, index) {
                var path = file.isbn + "/" + file.formatName + "/" + list.replace("_folder", "")
                if (path == FilePath) {
                    $scope.fileListnew.splice(index, 1)
                }
            })
        }
        var arr = $.map($scope.fileListnew, function(o) {
            return o.fullpath
        })
        if ($scope.appendPath == "") {
            var firstElem = arr.pop();
            $scope.appendPath = firstElem
        } else {
            var lastElem = " , " + arr.pop();
            $scope.appendPath = arr.join(", ") + lastElem
        }
        console.log($scope.fileListnew)
    }
    $scope.topSelectAll = function($event) {
        var folder = $scope.appendTopFolderName;
        var randomkey = Math.floor((Math.random() * 1000) + 1);
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'true' : 'false');
        if (action === 'true') {
            angular.forEach($scope.dataList, function(list, index) {
                list.checked = !0;
                if (folder == "" || folder == undefined) {
                    var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + list.name.replace("_folder", "")
                } else {
                    var FilePath = $scope.isbn + "/" + $scope.formatId + "/" + folder + "/" + list.name.replace("_folder", "")
                }
                if (list.name.contains("_folder")) {
                    var fol = list.name.replace("_folder", "");
                    if (folder != null && folder != "")
                        var folder1 = folder + "/" + fol;
                    else var folder1 = fol;
                    $scope.fileListnew.push({
                        isbn: $scope.isbn,
                        formatId: $scope.format,
                        formatName: $scope.formatId,
                        folder: folder1,
                        filename: null,
                        fullpath: folder1,
                        length: $scope.count,
                        randomkey: randomkey,
                        bucketexistinglist: $scope.existinglist,
                        bucketformatlist: $scope.formatlist,
                        singleFile: !1
                    })
                } else {
                    if ($scope.existingFiles.length > 0) {
                        if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                            alert("File has already selected. Please choose different file")
                            document.getElementById(event.target.id).checked = !1
                        } else {
                            $scope.existingFiles.push(FilePath);
                            if (folder != null && folder != "") {
                                var fullpath = folder + "/" + list.name
                            } else {
                                var fullpath = list.name
                            }
                            $scope.fileListnew.push({
                                isbn: $scope.isbn,
                                formatId: $scope.format,
                                formatName: $scope.formatId,
                                folder: folder,
                                filename: list.name,
                                fullpath: fullpath,
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.existinglist,
                                bucketformatlist: $scope.formatlist,
                                singleFile: !1
                            })
                        }
                    } else {
                        $scope.existingFiles.push(FilePath);
                        if (folder != null && folder != "") {
                            var fullpath = folder + "/" + list.name
                        } else {
                            var fullpath = list.name
                        }
                        $scope.fileListnew.push({
                            isbn: $scope.isbn,
                            formatId: $scope.format,
                            formatName: $scope.formatId,
                            folder: folder,
                            filename: list.name,
                            fullpath: fullpath,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.existinglist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: !1
                        })
                    }
                }
            })
        } else if (action === 'false') {
            angular.forEach($scope.dataList, function(list, index) {
                angular.forEach($scope.existingFiles, function(file, index) {
                    if (file == FilePath) {
                        $scope.existingFiles.splice(index, 1)
                    }
                });
                angular.forEach($scope.fileListnew, function(file, index) {
                    var path = file.isbn + "/" + file.formatName + "/" + list.name.replace("_folder", "")
                    if (path == FilePath) {
                        $scope.fileListnew.splice(index, 1)
                    }
                });
                file.checked = !1
            })
        }
        var arr = $.map($scope.fileListnew, function(o) {
            return o.fullpath
        })
        if ($scope.appendPath == "") {
            var firstElem = arr.pop();
            $scope.appendPath = firstElem
        } else {
            var lastElem = " , " + arr.pop();
            $scope.appendPath = arr.join(", ") + lastElem
        }
        console.log($scope.fileListnew)
    }
    $scope.getGridSelectedItem = function(fil, val, form, randomkey) {
        console.log($scope.fileList);
        delete $scope.uploadfile[randomkey];
        var path = fil.isbn + "/" + val;
        $http({
            method: 'POST',
            url: '/getFormat',
            data: {
                formatName: val
            }
        }).then(function(response) {
            $scope.gridformat = response.data.data.formatId;
            if (response.data.data.singleFile) {
                if ($scope.existingformat.length > 0) {
                    if (!($scope.existingformat.indexOf(path) == -1)) {
                        alert("Format has already selected. Please choose different format")
                    } else {
                        var formatpath = fil.isbn + "/" + fil.formatName;
                        angular.forEach($scope.existingformat, function(format, index) {
                            if (format == formatpath) {
                                $scope.existingformat.splice(index, 1)
                            }
                        });
                        $scope.existingformat.push(path);
                        $scope.selectedFormat[randomkey] = val;
                        $scope.gridfolderenable[randomkey] = !1;
                        $http({
                            method: 'POST',
                            url: '/getFilenameByFormatId',
                            data: {
                                formatName: $scope.selectedFormat[randomkey],
                                productIDValue: fil.isbn
                            }
                        }).then(function(response) {
                            $scope.foldernames[randomkey] = response.data.data[0];
                            angular.forEach($scope.fileList, function(file, index) {
                                if (file.randomkey == randomkey) {
                                    $scope.fileList[index].isbn = fil.isbn;
                                    $scope.fileList[index].formatId = $scope.gridformat;
                                    $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                                    $scope.fileList[index].folder = null;
                                    $scope.fileList[index].filename = $scope.foldernames[randomkey];
                                    $scope.fileList[index].randomkey = randomkey;
                                    $scope.fileList[index].singleFile = !0
                                }
                            })
                        })
                    }
                } else {
                    var formatpath = fil.isbn + "/" + fil.formatName;
                    angular.forEach($scope.existingformat, function(format, index) {
                        if (format == formatpath) {
                            $scope.existingformat.splice(index, 1)
                        }
                    });
                    $scope.existingformat.push(path);
                    $scope.selectedFormat[randomkey] = val;
                    $http({
                        method: 'POST',
                        url: '/getFilenameByFormatId',
                        data: {
                            formatName: $scope.selectedFormat[randomkey],
                            productIDValue: fil.isbn
                        }
                    }).then(function(response) {
                        $scope.foldernames[randomkey] = response.data.data[0];
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == randomkey) {
                                $scope.fileList[index].isbn = fil.isbn;
                                $scope.fileList[index].formatId = $scope.gridformat;
                                $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                                $scope.fileList[index].folder = null;
                                $scope.fileList[index].filename = $scope.foldernames[randomkey];
                                $scope.fileList[index].randomkey = randomkey;
                                $scope.fileList[index].singleFile = !0
                            }
                        })
                    })
                }
            } else {
                var formatpath = fil.isbn + "/" + fil.formatName;
                angular.forEach($scope.existingformat, function(format, index) {
                    if (format == formatpath) {
                        $scope.existingformat.splice(index, 1)
                    }
                });
                $scope.existingformat.push(path);
                $scope.selectedFormat[randomkey] = val;
                $http({
                    method: 'POST',
                    url: '/getFolderlist',
                    data: {
                        formatName: $scope.selectedFormat[randomkey],
                        productIDValue: fil.isbn,
                        formatId: $scope.gridformat
                    }
                }).then(function(response) {
                    $scope.griddataList[randomkey] = response.data.data;
                    angular.forEach($scope.fileList, function(file, index) {
                        if (file.randomkey == randomkey) {
                            $scope.fileList[index].isbn = fil.isbn;
                            $scope.fileList[index].formatId = $scope.gridformat;
                            $scope.fileList[index].formatName = $scope.selectedFormat[randomkey];
                            $scope.fileList[index].folder = null;
                            $scope.fileList[index].filename = null;
                            $scope.fileList[index].randomkey = randomkey;
                            $scope.fileList[index].singleFile = !1
                        }
                    });
                    $scope.gridfolderenable[randomkey] = !0
                })
            }
        })
    }
    $scope.getTreeView = function() {
        $http({
            method: 'POST',
            url: '/getTreeView',
            data: {
                filePathList: $scope.dataList
            }
        }).then(function(response) {})
    }
    $scope.addfiledetails = function(form) {
        if ($scope.isbn == null || $scope.isbn == "") {
            form.$setValidity('error', !1);
            $scope.upload_error_blank_isbn = "Please enter isbn"
        } else if ($scope.formatId === "" || $scope.formatId === "undefined") {
            form.$setValidity('error', !1);
            $scope.upload_error_formatid = "Please select formatId"
        } else {
            var fullFormatPath = $scope.isbn + "/" + $scope.formatId;
            $scope.existingformat.push(fullFormatPath);
            var randomkey = Math.floor((Math.random() * 1000) + 1);
            $http({
                method: 'POST',
                url: '/getFormat',
                data: {
                    formatName: $scope.formatId
                }
            }).then(function(response) {
                $scope.format = response.data.data.formatId;
                if (response.data.data.singleFile) {
                    $scope.formatenable = !1;
                    $http({
                        method: 'POST',
                        url: '/getFilenameByFormatId',
                        data: {
                            formatName: $scope.formatId,
                            productIDValue: $scope.isbn
                        }
                    }).then(function(response) {
                        $scope.foldernamesTop = response.data.data[0];
                        $scope.fileList.push({
                            isbn: $scope.isbn,
                            formatId: $scope.format,
                            folder: null,
                            formatName: $scope.formatId,
                            filename: $scope.foldernamesTop,
                            fullpath: $scope.foldernamesTop,
                            length: $scope.count,
                            randomkey: randomkey,
                            bucketexistinglist: $scope.existinglist,
                            bucketformatlist: $scope.formatlist,
                            singleFile: response.data.data.singleFile
                        });
                        $('#isbn' + $scope.isbn).val("");
                        $scope.isbn = "";
                        $scope.formatenable = !1;
                        $scope.formatId = "";
                        $scope.folderId = "";
                        $scope.appendPath = "";
                        $scope.appendTopFolderName = "";
                        $scope.folderenable = !1
                    })
                } else {
                    $scope.formatenable = !0;
                    $http({
                        method: 'POST',
                        url: '/getFolderlist',
                        data: {
                            formatName: $scope.formatId,
                            productIDValue: $scope.isbn,
                            formatId: $scope.format
                        }
                    }).then(function(response) {
                        if ($scope.fileListnew.length > 0) {
                            angular.forEach($scope.fileListnew, function(filenew) {
                                $scope.gridfolderenable[filenew.randomkey] = !0;
                                $scope.griddataList[filenew.randomkey] = response.data.data;
                                $scope.fileList = $scope.fileList.concat($scope.fileListnew);
                                $scope.fileListnew = []
                            })
                        } else {
                            $scope.gridfolderenable[randomkey] = !0;
                            $scope.griddataList[randomkey] = response.data.data;
                            $scope.fileList.push({
                                isbn: $scope.isbn,
                                formatId: $scope.format,
                                folder: null,
                                formatName: $scope.formatId,
                                filename: null,
                                fullpath: null,
                                length: $scope.count,
                                randomkey: randomkey,
                                bucketexistinglist: $scope.existinglist,
                                bucketformatlist: $scope.formatlist,
                                singleFile: !1
                            })
                        }
                        $('#isbn' + $scope.isbn).val("");
                        $scope.isbn = "";
                        $scope.formatenable = !1;
                        $scope.formatId = "";
                        $scope.folderId = "";
                        $scope.appendPath = "";
                        $scope.appendTopFolderName = "";
                        $scope.folderenable = !1
                    })
                }
            })
        }
    }
    $scope.sizefilter = function(size) {
        if (isNaN(size))
            size = 0;
        if (size < 1024) {
            $scope.filteredsize = size + ' Bytes';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Kb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Mb';
            return $scope.filteredsize
        }
        size /= 1024;
        if (size < 1024) {
            $scope.filteredsize = size.toFixed(2) + ' Gb';
            return $scope.filteredsize
        }
        size /= 1024;
        $scope.filteredsize = size.toFixed(2) + ' Tb';
        return $scope.filteredsize
    }
    $scope.getFolList = function(list, fil, formatName, appendFolderName) {
        var folder = list.replace("_folder", "");
        if ($scope.appendFolderName[fil.randomkey] == null || $scope.appendFolderName[fil.randomkey] == "") {
            $scope.appendFolderName[fil.randomkey] = folder
        } else {
            $scope.appendFolderName[fil.randomkey] = $scope.appendFolderName[fil.randomkey] + "/" + folder
        }
        if (formatName == null) {
            var newformatname = fil.formatName
        } else {
            var newformatname = formatName
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: newformatname,
                productIDValue: fil.isbn,
                formatId: fil.formatId,
                folder: $scope.appendFolderName[fil.randomkey]
            }
        }).then(function(response) {
            $scope.griddataList[fil.randomkey] = response.data.data
        })
    }
    $scope.upOneLevel = function(fil, formatName, appendFolderName) {
        var folder = $scope.appendFolderName[fil.randomkey].split('/');
        folder.pop();
        if (folder == "") {
            $scope.appendFolderName[fil.randomkey] = ""
        } else {
            $scope.appendFolderName[fil.randomkey] = folder.join('/')
        }
        if (formatName == null) {
            var newformatname = fil.formatName
        } else {
            var newformatname = formatName
        }
        $http({
            method: 'POST',
            url: '/getFolderlist',
            data: {
                formatName: newformatname,
                productIDValue: fil.isbn,
                formatId: fil.formatId,
                folder: $scope.appendFolderName[fil.randomkey]
            }
        }).then(function(response) {
            $scope.griddataList[fil.randomkey] = response.data.data
        })
    }
    $scope.getSelectedFolder = function(list, fil, position, event, griddataList) {
        var folder = $scope.appendFolderName[fil.randomkey];
        if (folder == "" || folder == undefined) {
            var FilePath = fil.isbn + "/" + fil.formatName + "/" + list.replace("_folder", "")
        } else {
            var FilePath = fil.isbn + "/" + fil.formatName + "/" + folder + "/" + list.replace("_folder", "")
        }
        if (event.target.checked) {
            if (list.contains("_folder")) {
                angular.forEach(griddataList, function(file, index) {
                    if (position != index) {
                        file.checked = "false"
                    }
                    var index1 = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.fullpath);
                    $scope.existingFiles.splice(index1, 1)
                });
                angular.forEach($scope.fileList, function(file, index) {
                    if (file.randomkey == fil.randomkey) {
                        var fol = list.replace("_folder", "");
                        if (folder != null && folder != "") {
                            $scope.fileList[index].folder = folder + "/" + fol;
                            $scope.fileList[index].fullpath = $scope.fileList[index].folder
                        } else {
                            $scope.fileList[index].folder = fol;
                            $scope.fileList[index].fullpath = $scope.fileList[index].folder
                        }
                        $scope.fileList[index].filename = null
                    }
                })
            } else {
                if ($scope.existingFiles.length > 0) {
                    if (!($scope.existingFiles.indexOf(FilePath) == -1)) {
                        alert("File has already selected. Please choose different file")
                        document.getElementById(event.target.id).checked = !1
                    } else {
                        angular.forEach(griddataList, function(file, index) {
                            if (position != index) {
                                file.checked = "false"
                            }
                            var index1 = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.fullpath);
                            $scope.existingFiles.splice(index1, 1)
                        });
                        $scope.existingFiles.push(FilePath);
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == fil.randomkey) {
                                if (!list.contains("_folder")) {
                                    if (folder != null && folder != "") {
                                        $scope.fileList[index].folder = folder;
                                        $scope.fileList[index].fullpath = folder + "/" + list
                                    } else {
                                        $scope.fileList[index].fullpath = list
                                    }
                                    $scope.fileList[index].filename = list
                                } else {
                                    var fol = list.replace("_folder", "");
                                    if (folder != null && folder != "")
                                        $scope.fileList[index].folder = folder + "/" + fol;
                                    else $scope.fileList[index].folder = fol;
                                    $scope.fileList[index].filename = null;
                                    $scope.fileList[index].fullpath = $scope.fileList[index].folder
                                }
                            }
                        })
                    }
                } else {
                    $scope.existingFiles.push(FilePath);
                    angular.forEach(griddataList, function(file, index) {
                        if (position != index) {
                            file.checked = "false"
                        }
                    });
                    angular.forEach($scope.fileList, function(file, index) {
                        if (file.randomkey == fil.randomkey) {
                            if (!list.contains("_folder")) {
                                if (folder != null && folder != "") {
                                    $scope.fileList[index].folder = folder;
                                    $scope.fileList[index].fullpath = folder + "/" + list
                                } else {
                                    $scope.fileList[index].fullpath = list
                                }
                                $scope.fileList[index].filename = list
                            } else {
                                var fol = list.replace("_folder", "");
                                if (folder != null && folder != "")
                                    $scope.fileList[index].folder = folder + "/" + fol;
                                else $scope.fileList[index].folder = fol;
                                $scope.fileList[index].filename = null;
                                $scope.fileList[index].fullpath = $scope.fileList[index].folder
                            }
                        }
                    })
                }
            }
        } else {
            angular.forEach($scope.existingFiles, function(file, index) {
                if (file == FilePath) {
                    $scope.existingFiles.splice(index, 1)
                }
            });
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    $scope.fileList[index].folder = null;
                    $scope.fileList[index].filename = null;
                    $scope.fileList[index].fullpath = null
                }
            })
        }
        console.log($scope.fileList)
    }
    $scope.createNewFolder = function(fil, gridfolderId) {
        var emptyfolder = !1;
        var nofolder = !1;
        var check = !0;
        if (!angular.equals({}, $scope.griddataList[fil.randomkey])) {
            angular.forEach($scope.griddataList[fil.randomkey], function(name) {
                if (name[1] == !0) {
                    if (name[0].contains("_folder")) {
                        angular.forEach($scope.fileList, function(file, index) {
                            if (file.randomkey == fil.randomkey) {
                                var fol = file.folder + "/" + gridfolderId;
                                $scope.fileList[index].folder = fol;
                                $scope.fileList[index].fullpath = fol
                            }
                        })
                    } else {
                        emptyfolder = !0
                    }
                } else {
                    nofolder = !0
                }
            })
        } else {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    if (file.randomkey == fil.randomkey) {
                        if (file.folder == null)
                            var fol = gridfolderId;
                        else var fol = file.folder + "/" + gridfolderId;
                        $scope.fileList[index].folder = fol;
                        $scope.fileList[index].fullpath = fol
                    }
                }
            })
        }
        if (nofolder || emptyfolder) {
            angular.forEach($scope.fileList, function(file, index) {
                if (file.randomkey == fil.randomkey) {
                    if (file.folder == null)
                        var fol = gridfolderId;
                    else var fol = file.folder + "/" + gridfolderId;
                    $scope.fileList[index].folder = fol;
                    $scope.fileList[index].fullpath = fol
                }
            })
        }
    }
    $scope.multipartupload = function(filesel, filelist) {
        var files, file_id = 0;
        $http({
            method: 'POST',
            url: '/generateFileUploadLink',
            data: null
        }).then(function(response) {
            var accessKey = response.data.data.accessKey;
            var bucketName = response.data.data.bucketName;
            var region = response.data.data.region;
            var signerUrl = "/fileUploadSignature";
            var filePromises = [],
                allCompleted
            COOKIE = 'evaporate_example', cookie_data = {
                persist: "off"
            }, cookie_options = {
                expires: 1
            };
            angular.forEach(filelist, function(fileli, index) {
                var len = fileli.randomkey;
                if (filesel[len] != undefined) {
                    var formatIndex = $scope.existingformat.indexOf(fileli.isbn + "/" + fileli.formatName);
                    if (fileli.folder == null || fileli.folder == "")
                        var fileIndex = $scope.existingFiles.indexOf(fileli.isbn + "/" + fileli.formatName + "/" + filesel[fileli.randomkey].name);
                    else var fileIndex = $scope.existingFiles.indexOf(fileli.isbn + "/" + fileli.formatName + "/" + fileli.folder + "/" + filesel[fileli.randomkey].name);
                    if (formatIndex != -1)
                        $scope.existingformat.splice(formatIndex, 1);
                    if (fileIndex != -1)
                        $scope.existingFiles.splice(fileIndex, 1);
                    $scope.fileuploadlist.push({
                        file1: filesel[len],
                        randomkey: fileli.randomkey,
                        convertedSize: $scope.sizefilter(filesel[len].size)
                    });
                    $scope.fileList = $scope.fileList.filter(function(obj) {
                        return obj.randomkey !== len
                    });
                    if (fileli.folder == null || fileli.folder == '')
                        var directoryName = fileli.isbn + "/" + fileli.formatName + "/"
                    else var directoryName = fileli.isbn + "/" + fileli.formatName + "/" + fileli.folder + "/"
                    Evaporate.create({
                        signerUrl: signerUrl,
                        aws_key: accessKey,
                        bucket: bucketName,
                        cloudfront: !1,
                        s3Acceleration: !0,
                        awsSignatureVersion: '4',
                        awsRegion: region,
                        directoryName: directoryName,
                        projectId: $scope.project_id,
                        computeContentMd5: !0,
                        cryptoMd5Method: function(data) {
                            return AWS.util.crypto.md5(data, 'base64')
                        },
                        cryptoHexEncodedHash256: function(data) {
                            return AWS.util.crypto.sha256(data, 'hex')
                        },
                        logging: !1,
                        s3FileCacheHoursAgo: 1,
                        allowS3ExistenceOptimization: !0
                    }).then(function(_e_) {
                        console.log(filesel[len].name);
                        var name = filesel[len].name;
                        var size = filesel[len].size;
                        var fileKey = bucketName + '/' + name;
                        callback_methods = callbacks(filesel[len], fileKey, fileli.randomkey);
                        var promise = _e_.add({
                            name: name,
                            file: filesel[len],
                            started: callback_methods.started,
                            complete: callback_methods.complete,
                            progress: callback_methods.progress,
                            paused: callback_methods.paused,
                            pausing: callback_methods.pausing,
                            resumed: callback_methods.resumed,
                            cancelled: callback_methods.cancelled
                        }, {
                            bucket: bucketName,
                            aws_key: accessKey
                        }).then((function(requestedName) {
                            return function(awsKey) {
                                if (awsKey === requestedName) {
                                    console.log(awsKey, 'successfully uploaded!')
                                } else {
                                    console.log('Did not re-upload', requestedName, 'because it exists as', awsKey)
                                }
                            }
                        })(name));
                        filePromises.push(promise);
                        allCompleted = Promise.all(filePromises).then(function() {
                            $http({
                                method: 'POST',
                                url: '/addfileobjects',
                                data: {
                                    productIDValue: fileli.isbn,
                                    loggeduser: $rootScope.loggedUser.userId,
                                    filename: name,
                                    formatName: fileli.formatName,
                                    size: size,
                                    bucket: bucketName,
                                    folder: fileli.folder,
                                    formatStatus: "12"
                                }
                            }).then(function(response) {
                                if (fileli.bucketexistinglist.length > 0) {
                                    $http({
                                        method: 'POST',
                                        url: '/saveShelfTransaction',
                                        data: {
                                            isbn: fileli.isbn,
                                            formatId: fileli.formatId,
                                            loggedUser: $rootScope.loggedUser.userId,
                                            action: "Upload"
                                        }
                                    }).then(function(response) {})
                                } else {
                                    $http({
                                        method: 'POST',
                                        url: '/saveShelfTransaction',
                                        data: {
                                            isbn: fileli.isbn,
                                            loggedUser: $rootScope.loggedUser.userId,
                                            action: "Upload"
                                        }
                                    }).then(function(response) {})
                                }
                            });
                            console.log('All files were uploaded successfully.')
                        }, function(reason) {
                            console.log('All files were not uploaded successfully:', reason)
                        });

                        function callbacks(file, fileKey, randomkey) {
                            $('#show_cancel_' + randomkey).click(function() {
                                console.log('canceling', fileKey);
                                _e_.cancel(fileKey)
                            });
                            $('#show_pause_' + randomkey).click(function() {
                                console.log('pausing', fileKey);
                                _e_.pause(fileKey)
                            });
                            $('#show_resume_' + randomkey).click(function() {
                                console.log('resuming', fileKey);
                                _e_.resume(fileKey)
                            });
                            var clock = new ProgressBar.Line(angular.element(document.getElementById('progressbar_' + randomkey))[0], {
                                strokeWidth: 0,
                                duration: 350,
                                text: {
                                    value: ''
                                },
                                step: function(state, bar) {
                                    var bar1 = (bar.value() * 100).toFixed(0) + '%';
                                    $('#progressbar_' + randomkey).css('width', bar1)
                                }
                            });
                            var speed = angular.element(document.getElementById('filesize_show_' + randomkey));
                            var time = angular.element(document.getElementById('time_show_' + randomkey));

                            function markComplete(className) {
                                progress_clock.addClass(className);
                                status.text(className)
                            }
                            return {
                                started: function(fid) {
                                    angular.element($("#progressClock_" + randomkey)).addClass('evaporating');
                                    angular.element($("#progressClock_" + randomkey)).addClass('Progress');
                                    $('#show_cancel_' + randomkey).show();
                                    $('#show_pause_' + randomkey).show();
                                    $('#show_view_' + randomkey).hide();
                                    $('#show_close_' + randomkey).hide();
                                    $('#selected_show_' + randomkey).hide();
                                    $('#title_show_' + randomkey).show();
                                    $('#progress_show_' + randomkey).show();
                                    $('#filesize_show_' + randomkey).show();
                                    $('#show_resume_' + randomkey).hide();
                                    $('#cancel_text_show_' + randomkey).hide();
                                    console.log('started', fid)
                                    var file_id = fid
                                },
                                progress: function(progressValue, data) {
                                    progress = progressValue;
                                    clock.animate(progressValue);
                                    $scope.fileloaded = data && data.loaded ? data.loaded : '';
                                    $scope.remainingTime = data && data.secondsLeft ? Math.round(data.secondsLeft / 60) : '';
                                    $scope.speed = data && data.speed ? data.readableSpeed + '/s' : '';
                                    if (data) {
                                        var xferRate = data.speed ? data.readableSpeed + "/s - " : '';
                                        var rate = data && data.loaded ? data.loaded : '';
                                        var ra = $scope.sizefilter(data.totalUploaded);
                                        var rr = " of " + $scope.sizefilter(file.size);
                                        var remaining = data.secondsLeft ? Math.round(data.secondsLeft / 60) + ' mins left' : '';
                                        speed.html(xferRate + ra + rr);
                                        time.html(remaining)
                                    }
                                },
                                complete: function(_xhr, awsKey, stats) {
                                    angular.element($("#progressClock_" + randomkey)).removeClass('Progress');
                                    angular.element($("#progressClock_" + randomkey)).addClass("Completed");
                                    angular.element($("#progressClock_" + randomkey)).removeClass('evaporating');
                                    clock.animate(1);
                                    console.log('Stats for', decodeURIComponent(awsKey), stats);
                                    $('#show_cancel_' + randomkey).hide();
                                    $('#show_pause_' + randomkey).hide();
                                    $('#show_view_' + randomkey).show();
                                    $('#show_close_' + randomkey).show();
                                    $('#selected_show_' + randomkey).show();
                                    $('#title_show_' + randomkey).hide();
                                    $('#progress_show_' + randomkey).hide();
                                    $('#filesize_show_' + randomkey).hide();
                                    $('#show_resume_' + randomkey).hide();
                                    $('#cancel_text_show_' + randomkey).hide();
                                    $('#time_show_' + randomkey).hide()
                                },
                                pausing: function() {
                                    $('#show_resume_' + randomkey).show();
                                    $('#show_pause_' + randomkey).hide();
                                    angular.element($("#progressClock_" + randomkey)).removeClass('evaporating warning')
                                },
                                paused: function() {
                                    $('#show_resume_' + randomkey).show();
                                    $('#show_pause_' + randomkey).hide();
                                    angular.element($("#progressClock_" + randomkey)).removeClass('evaporating warning pausing')
                                },
                                resumed: function() {
                                    clock.animate(progress);
                                    $('#show_resume_' + randomkey).hide();
                                    angular.element($("#progressClock_" + randomkey)).removeClass('pausing paused')
                                },
                                cancelled: function() {
                                    clock.animate(progress);
                                    angular.element($("#progressClock_" + randomkey)).removeClass('evaporating warning paused pausing');
                                    $('#show_cancel_' + randomkey).hide();
                                    $('#show_pause_' + randomkey).hide();
                                    $('#show_resume_' + randomkey).hide();
                                    $('#cancel_text_show_' + randomkey).show();
                                    $('#title_show_' + randomkey).hide();
                                    $('#progress_show_' + randomkey).hide();
                                    $('#filesize_show_' + randomkey).hide();
                                    $('#time_show_' + randomkey).hide()
                                },
                            }
                        }
                    })
                }
            })
        }, function(response) {})
    }
    $scope.filterList = ['Completed', 'Progress', 'Failed'];
    $scope.cancelFile = function(file, index, uploadFile) {
        var elmn = angular.element(document.querySelector('#file_' + file.randomkey));
        elmn.remove();
        $scope.fileList.splice(index, 1);
        delete $scope.uploadfile[file.randomkey];
        var formatIndex = $scope.existingformat.indexOf(file.isbn + "/" + file.formatName);
        var fileIndex = $scope.existingFiles.indexOf(file.isbn + "/" + file.formatName + "/" + uploadFile.name);
        if (formatIndex != -1)
            $scope.existingformat.splice(formatIndex, 1);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1)
    };
    $scope.canceluploadList = function() {
        $scope.fileList = [];
        $scope.uploadfile = {};
        $scope.existingformat = [];
        $scope.existingFiles = []
    };
    $scope.clearAll = function(file, index) {
        var elmn = angular.element(document.querySelector('#file_' + file.randomkey));
        elmn.remove();
        $scope.fileList.splice(index, 1);
        $timeout(function() {
            $scope.searchString = ''
        }, 300)
    };
    $scope.cancelupload = function(file, index) {
        var elmn = angular.element(document.querySelector('#progressClock_' + file.randomkey));
        elmn.remove();
        $scope.fileuploadlist.splice(index, 1)
    };
    $scope.downloadEnable = function(isbn, formatid, fileid) {
        $http({
            method: 'POST',
            url: '/download',
            data: {
                formatId: 'indesign',
                productIDValue: '9780748622017',
                filename: 'Defect-List-new.xlsx'
            }
        }).then(function(response) {
            $scope.downurl = response.data.data;
            $("#download_modal").css("display", "block")
        })
    }
    $scope.cancelFileModal = function(fil) {
        $scope.enableExistingFile = !1;
        var fileIndex = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.filename);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1)
    }
    $scope.replaceFileModal = function(files, fil) {
        $scope.enableExistingFile = !0;
        $scope.uploadfile[fil.randomkey] = files;
        var fileIndex = $scope.existingFiles.indexOf(fil.isbn + "/" + fil.formatName + "/" + fil.filename);
        if (fileIndex != -1)
            $scope.existingFiles.splice(fileIndex, 1)
    }
    $scope.browseFile = function(files, fil) {
        var filename = files.name;
        var index = filename.lastIndexOf(".");
        var extension = filename.substring(index, filename.length);
        var fullFilePath = fil.isbn + "/" + fil.formatName + "/" + files.name;
        if ($scope.existingFiles.length > 0) {
            if ($scope.existingFiles.indexOf(fullFilePath) == -1) {
                $http({
                    method: 'POST',
                    url: '/checkFileFormat',
                    data: {
                        formatName: fil.formatName,
                        fileExtension: extension
                    }
                }).then(function(response) {
                    if ("100" === response.data.code) {
                        $scope.files = files;
                        $scope.files1 = fil;
                        var fileType = response.data.data;
                        if (fileType === !0) {
                            if ("" === angular.lowercase(fil.filename) || undefined === angular.lowercase(fil.filename)) {
                                $scope.uploadfile[fil.randomkey] = files
                            } else {
                                if (angular.lowercase(fil.filename) === angular.lowercase(files.name)) {
                                    $("#existing-file").modal("show")
                                } else {
                                    alert("Please select same file")
                                }
                            }
                        } else {
                            $scope.uploadfile[fil.randomkey] = files
                        }
                    } else if ("200" === response.data.code) {
                        alert("Please select appropirate file format")
                    }
                })
            } else {
                alert("File is already selected. Please select different file")
            }
        } else {
            $http({
                method: 'POST',
                url: '/checkFileFormat',
                data: {
                    formatName: fil.formatName,
                    fileExtension: extension
                }
            }).then(function(response) {
                if ("100" === response.data.code) {
                    $scope.files = files;
                    $scope.files1 = fil;
                    var fileType = response.data.data;
                    if (fileType === !0) {
                        if ("" === angular.lowercase(fil.filename) || undefined === angular.lowercase(fil.filename)) {
                            $scope.uploadfile[fil.randomkey] = files
                        } else {
                            if (angular.lowercase(fil.filename) === angular.lowercase(files.name)) {
                                $("#existing-file").modal("show")
                            } else {
                                alert("Please select same file")
                            }
                        }
                    } else {
                        $scope.uploadfile[fil.randomkey] = files
                    }
                } else if ("200" === response.data.code) {
                    alert("Please select appropirate file format")
                }
            })
        }
        $scope.existingFiles.push(fullFilePath);
        console.log($scope.existingFiles)
    };
    $scope.clearAll = function(val) {
        $scope.fileuploadlist = [];
        $timeout(function() {
            $scope.searchString = ''
        }, 300)
    }
    $scope.check = function(form) {
        if (Object.keys($scope.uploadfile).length > 0) {
            return !0
        } else {
            return !1
        }
    };
    $scope.checkgridValidation = function(file) {
        if ($scope.selectedFormat[file.randomkey] != undefined || file.formatName != null) {
            return !0
        } else {
            return !1
        }
    }
    $scope.actionList = []
    $scope.filterUploads = function($event, val) {
        var isChecked = $event.target.checked;
        var index = $scope.actionList.indexOf(val);
        if (isChecked && index == -1) {
            $scope.actionList.push(val)
        } else {
            $scope.actionList.splice(index, 1)
        }
        angular.forEach($scope.filterList, function(data) {
            var i = $scope.actionList.indexOf(data);
            var result = document.getElementsByClassName(data);
            if (i >= 0) {
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            } else {
                angular.element(result).removeClass('active');
                angular.element(result).addClass('inactive')
            }
        });
        if ($scope.actionList.length == 0) {
            angular.forEach($scope.filterList, function(val) {
                var result = document.getElementsByClassName(val);
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            })
        }
    }
    $scope.filterUploadschkAll = function($event) {
        var isChecked = $event.target.checked;
        angular.forEach($scope.filterList, function(data) {
            var result = document.getElementsByClassName(data);
            if (isChecked) {
                angular.element(result).removeClass('inactive');
                angular.element(result).addClass('active')
            } else {
                angular.element(result).removeClass('active');
                angular.element(result).addClass('inactive')
            }
        })
    }
}]);
app.directive("removeMe", function($rootScope) {
    return {
        link: function(scope, element, attrs) {
            element.bind("click", function() {
                element.parent().remove()
            })
        }
    }
})