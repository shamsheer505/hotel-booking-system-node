app.controller("ReportController", ['$scope', '$http', '$timeout', '$rootScope', '$location', '$filter', function($scope, $http, $timeout, $rootScope, $location, $filter) {
    $rootScope.testScroll();
    $scope.showLoader = function(el, num, effect) {
        text = 'Extracting please wait...';
        fontSize = '';
        switch (num) {
            case 1:
                maxSize = '';
                textPos = 'vertical';
                break;
            case 2:
                text = '';
                maxSize = 30;
                textPos = 'vertical';
                break;
            case 3:
                maxSize = 30;
                textPos = 'horizontal';
                fontSize = '18px';
                break
        }
        el.waitMe({
            effect: effect,
            text: text,
            bg: 'rgba(255,255,255,1)',
            color: '#197535',
            maxSize: 500,
            source: '../../images/img.svg',
            textPos: textPos,
            fontSize: fontSize,
            onClose: function() {}
        })
    }
    $scope.hideLoader = function(classname) {
        $('.' + classname).waitMe('hide')
    }
    $scope.reportColumnFilterSearch = {};
    $rootScope.rptRegionFilterListNext = [];
    $rootScope.rptImprintFilterListNext = []
    $rootScope.selectedAccountsList = [];
    $rootScope.rptRegionFilterList = [];
    $rootScope.rptImprintFilterList = [];
    $rootScope.downloadType = [{'name':'CSV','type':'CSV'},
                                {'name':'Excel','type':'XLSX'}];
    $rootScope.rptDateFilterList = [];
    $rootScope.search.searchRPTValue = "";
    $rootScope.emptyAllRecords = function() {
        $scope.watermarkContent = !1;
        $rootScope.gridData = [];
        if ($rootScope.rptRegionFilterList.length > '0') {
            var filteredAccountList = $rootScope.accountList;
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("reportAccount_" + acl.accountName).checked = !1
            });
            $scope.rptRegionAllSelected = !1;
            document.getElementById("rptRegionAllSelected").checked = !1
        }
        if ($rootScope.rptImprintFilterList.length > '0') {
            angular.forEach($rootScope.rptImprintList, function(imp) {
                if (null != document.getElementById("reportImprint_" + imp))
                    document.getElementById("reportImprint_" + imp).checked = !1
            });
            $rootScope.rptImprintAllSelected = !1;
            document.getElementById("rptImprintAllSelected").checked = !1
        }
        $rootScope.search.rptpCateoryAllSelected = !1;
        $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "UNSELECT");
        $rootScope.searchKey = "";
        $rootScope.rptFromDate = null;
        $rootScope.rptToDate = null;
        $scope.dataDate.filterFromDate = "";
        $scope.dataDate.filterToDate = "";
        if (null != document.getElementById("reportFromDate"))
            document.getElementById("reportFromDate").value = "";
        if (null != document.getElementById("reportToDate"))
            document.getElementById("reportToDate").value = "";
        $rootScope.rptRegionFilterList = [];
        $rootScope.rptRegionFilterListNext = [];
        $rootScope.selectedAccountsList = [];
        $rootScope.rptImprintFilterList = [];
        $rootScope.RPTpCategoryFilterList = [];
        $rootScope.rptDateFilterList = [];
        $rootScope.RPTFromDateFilterList = {};
        $rootScope.RPTToDateFilterList = {}
        $rootScope.rptInColFilterList = {};
        $rootScope.rptInColumnFilterList = {};
        $rootScope.rptgHeadresAllSelect = {};
        $rootScope.rptColumnFilterValues = {};
        $rootScope.rptSearchColumnSuggestions = {};
        $rootScope.RPTHeadSearchList = {};
        $rootScope.hdSearch = [];
        $rootScope.search.searchRPTValue = "";
        angular.element($("#txtRPTSearch")).val('')
    }
    $rootScope.refreshRPTSearchImprintList = function(rptimprintFilter) {
        var filteredList = $filter('filter')($rootScope.imprintList, function(data) {
            var re = new RegExp(RegExp.escape($scope.rptimprintFilter), 'gi');
            return data.match(re)
        });
        var checkCount = 0;
        angular.forEach(filteredList, function(item) {
            if ($rootScope.rptImprintFilterList.indexOf(item) != -1) {
                if (null != document.getElementById("reportImprint_" + item));
                document.getElementById("reportImprint_" + item).checked = !0;
                checkCount++
            }
        });
        $timeout(function() {
            $scope.rptImprintAllSelected = ((checkCount == filteredList.length) && (checkCount != 0))
        }, 100)
    }
    $rootScope.getRptImprints = function() {
        var accountArray = $rootScope.selectedAccountsList;
        $http({
            method: 'GET',
            url: '/getImprintListForAccounts/' + accountArray.toString()
        }).then(function successCallback(response) {
            $rootScope.rptImprintList = response.data.data
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    };
    $rootScope.getRptImprints();
    $http({
        method: 'GET',
        url: '/getAccounts'
    }).then(function successCallback(response) {
        $scope.rptAccountList = response.data.data.accountList
    }, function errorCallback(response) {
        console.log('Error status: ' + response.status)
    });
    $rootScope.getRPTMetadataTypes = function() {
        $http({
            method: 'GET',
            url: '/getMetadataTypesFromConfig'
        }).then(function successCallback(response) {
            $scope.rptMetadataTypeList = response.data.data
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.getRPTMdataTypeValues = function(mDataType, mCategory, displayname, fieldDisplayName) {
        $rootScope.rptSearchEnable = !0;
        $rootScope.RPTHeadSearchList = {};
        $rootScope.RPTHeadSearchList[fieldDisplayName] = $rootScope.reportSearchKey;
        $rootScope.rTypeTitle = displayname;
        $rootScope.rMetaDataCategory = mCategory;
        $rootScope.rDataType = mDataType;
        $rootScope.rCategory = fieldDisplayName
    };
    $rootScope.loadReports = function(reportList) {
        $rootScope.savesReportId = undefined;
        $scope.reportColumnFilterSearch = {};
        $rootScope.rptLookUpSuggestions = {};
        $rootScope.emptyAllRecords();
        $rootScope.rptOpen = !1;
        $rootScope.showRptCountZero = !1;
        $rootScope.showLoader($('.chart-container'), 1, 'win8_linear');
        $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
        if (angular.element("#reportdivTableBody").is(":visible")) {
            angular.element("#reportdivTableBody").scrollLeft(0);
            var container = document.getElementById("reportdivTableBody");
            container.scrollTop = 0
        }
        $rootScope.saveReportName = reportList.reportName;
        $rootScope.reportId = reportList.reportId;
        $rootScope.reportPageNameBrad = reportList.reportName;
        $http({
            method: 'POST',
            url: '/getReportGridHeaders/',
            data: {
                pageName: $rootScope.reportId
            }
        }).then(function(response) {
            $rootScope.reportGridHeaders = response.data.data
        });
        $http({
            method: 'POST',
            url: '/loadAllReportChart',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                searchText: "",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                pageName: $rootScope.reportId,
                advancedSearch: {}
            }
        }).then(function(response) {
            $rootScope.labels = response.data.data.label;
            $rootScope.series = response.data.data.series;
            $rootScope.data = response.data.data.data;
            $rootScope.trends = response.data.data.trends;
            $rootScope.chartType = 'bar';
            eval('var obj=' + response.data.data.options);
            $scope.options = obj;
            angular.forEach($scope.options.title, function(key, val) {
                if (val === "text") {
                    $rootScope.commonHeader = key
                }
            })
            $rootScope.hideLoader('chart-container')
        });
        $http({
            method: 'POST',
            url: '/loadAllReportGrid',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                pageName: $rootScope.reportId,
                advancedSearch: {}
            }
        }).then(function(response) {
            $rootScope.reportResponseEnable();
            $scope.showLoadmore = !0;
            $rootScope.showRptCountZero = !0;
            $rootScope.gridData = response.data.data;
            $rootScope.rptSearchCount = response.data.searchCount;
            $rootScope.hideLoader('report-grid');
            $rootScope.reportLoadMore()
        });
        angular.element(".innerFilter.header-filter").removeClass('active');
        angular.element(".innerFilterDropdown.header-filter-dropdown").removeClass('active')
    }
    $rootScope.savedReports = function(reportList) {
        $scope.reportColumnFilterSearch = {};
        $rootScope.rptLookUpSuggestions = {};
        $rootScope.emptyAllRecords();
        $rootScope.copySavedReportList = angular.copy(reportList);
        $rootScope.rptOpen = !0;
        $rootScope.showRptCountZero = !1;
        $rootScope.showLoader($('.chart-container'), 1, 'win8_linear');
        $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
        if (angular.element("#reportdivTableBody").is(":visible")) {
            angular.element("#reportdivTableBody").scrollLeft(0);
            var container = document.getElementById("reportdivTableBody");
            container.scrollTop = 0
        }
        $rootScope.reportId = reportList.pageName;
        $rootScope.savesReportId = reportList.id;
        $rootScope.saveReportName = reportList.searchName;
        $rootScope.reportPageNameBrad = reportList.searchName;
        $http({
            method: 'POST',
            url: '/getReportGridHeaders/',
            data: {
                pageName: reportList.pageName
            }
        }).then(function(response) {
            $rootScope.reportGridHeaders = response.data.data
        });
        $http({
            method: 'POST',
            url: '/loadAllReportChart',
            data: {
                frequency: reportList.frequency,
                searchName: reportList.searchName,
                userId: reportList.userId,
                advancedSearch: reportList.advancedSearch,
                fieldDisplayName: reportList.fieldDisplayName,
                searchText: reportList.searchText,
                columnFilterValues: reportList.columnFilterValues,
                skipCount: reportList.skipCount,
                searchReultCount: reportList.searchReultCount,
                pageName: reportList.pageName,
                id: reportList.id,
                transDateFrom: reportList.transDateFrom,
                transDateTo: reportList.transDateTo
            }
        }).then(function(response) {
            $rootScope.labels = response.data.data.label;
            $rootScope.series = response.data.data.series;
            $rootScope.data = response.data.data.data;
            $rootScope.trends = response.data.data.trends;
            $rootScope.chartType = 'bar';
            eval('var obj=' + response.data.data.options);
            $scope.options = obj;
            angular.forEach($scope.options.title, function(key, val) {
                if (val === "text") {
                    $rootScope.commonHeader = key
                }
            })
            $rootScope.hideLoader('chart-container')
        });
        $http({
            method: 'POST',
            url: '/loadAllReportGrid',
            data: {
                frequency: reportList.frequency,
                searchName: reportList.searchName,
                userId: reportList.userId,
                advancedSearch: reportList.advancedSearch,
                fieldDisplayName: reportList.fieldDisplayName,
                searchText: reportList.searchText,
                columnFilterValues: reportList.columnFilterValues,
                skipCount: reportList.skipCount,
                searchReultCount: reportList.searchReultCount,
                pageName: reportList.pageName,
                id: reportList.id,
                transDateFrom: reportList.transDateFrom,
                transDateTo: reportList.transDateTo
            }
        }).then(function(response) {
            $rootScope.reportResponseEnable();
            $rootScope.gridData = [];
            $rootScope.gridData = response.data.data;
            $rootScope.rptSearchCount = response.data.searchCount;
            $rootScope.hideLoader('report-grid');
            $rootScope.reportLoadMore()
        });
        angular.element(".innerFilter.header-filter").removeClass('active');
        angular.element(".innerFilterDropdown.header-filter-dropdown").removeClass('active');
        if ($rootScope.gridData.length >= $rootScope.rptSearchCount) {
            $scope.showLoadmore = !1;
            $rootScope.gridData.length = $rootScope.rptSearchCount
        } else {
            $scope.showLoadmore = !0
        }
    }
    $rootScope.showLoadmore = !1;
    angular.element(".reportbutton-disable").removeClass('buttondisableds');
    $rootScope.rptRow = 0;
    $rootScope.rptRowPerPage = 50;
    $rootScope.buttonText = "Load More";
    $rootScope.rptSearchEnable = !1;
    $scope.reportCommonFilter = function(fieldName, searchKey) {
        $rootScope.rptSearchEnable = !1;
        angular.element(".reportbutton-disable").addClass('buttondisableds');
        $rootScope.rptFiledName = fieldName;
        var fieldName = (fieldName == null || fieldName == '') ? "ISBN13" : fieldName;
        setTimeout(function() {
            var container = document.getElementById("reportdivTableBody");
            angular.element("#reportdivTableBody").trigger('scroll');
            container.scrollTop = 0
        }, 200);
        $rootScope.showLoader($('.chart-container'), 1, 'win8_linear');
        $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
        if (fieldName == "" && fieldName == null) {
            fieldName = "ISBN13"
        } else if (fieldName == 'All') {
            fieldName = "ISBN13"
        }
        if (searchKey == "" || searchKey == null || searchKey == undefined) {
            searchKey = ""
        }
        $rootScope.rptLoading = !0;
        if (null != $rootScope.rptFromDate && null != $rootScope.rptToDate && "" != $rootScope.rptFromDate) {
            $rootScope.rptLoading = !0;
            var fromDate = document.getElementById("reportFromDate").value;
            var toDate = document.getElementById("reportToDate").value;
            if (fromDate != null && fromDate != undefined && toDate != null && toDate != undefined) {
                $http({
                    method: 'POST',
                    url: '/loadAllReportChart',
                    data: {
                        fieldDisplayName: fieldName,
                        searchText: searchKey,
                        pageName: $rootScope.reportId,
                        id: $rootScope.savesReportId,
                        advancedSearch: {
                            columnFilterValues: $rootScope.RPTHeadSearchList,
                            accounts: $rootScope.selectedAccountsList,
                            imprints: $rootScope.rptImprintFilterList,
                            productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                        },
                        columnFilterValues: $rootScope.rptColumnFilterValues,
                        transDateFrom: fromDate,
                        transDateTo: toDate
                    }
                }).then(function(response) {
                    $rootScope.labels = response.data.data.label;
                    $rootScope.series = response.data.data.series;
                    $rootScope.data = response.data.data.data;
                    $rootScope.trends = response.data.data.trends;
                    eval('var obj=' + response.data.data.options);
                    $scope.options = obj;
                    angular.forEach($scope.options.title, function(key, val) {
                        if (val === "text") {
                            $rootScope.commonHeader = key
                        }
                    })
                    $rootScope.hideLoader('chart-container')
                });
                $http({
                    method: 'POST',
                    url: '/loadAllReportGrid',
                    data: {
                        metaDataType: $rootScope.rDataType,
                        metaDataCategory: $rootScope.rMetaDataCategory,
                        fieldDisplayName: fieldName,
                        searchText: searchKey,
                        id: $rootScope.savesReportId,
                        isFiltered: !1,
                        skipCount: 0,
                        pageName: $rootScope.reportId,
                        advancedSearch: {
                            columnFilterValues: $rootScope.RPTHeadSearchList,
                            accounts: $rootScope.selectedAccountsList,
                            imprints: $rootScope.rptImprintFilterList,
                            productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                        },
                        columnFilterValues: $rootScope.rptColumnFilterValues,
                        transDateFrom: fromDate,
                        transDateTo: toDate
                    }
                }).then(function(response) {
                    $rootScope.reportResponseEnable();
                    $rootScope.gridData = response.data.data;
                    $rootScope.rptSearchCount = response.data.searchCount;
                    $rootScope.hideLoader('report-grid');
                    $rootScope.reportLoadMore()
                });
                $rootScope.rptLoading = !1
            }
        } else {
            $http({
                method: 'POST',
                url: '/loadAllReportChart',
                data: {
                    fieldDisplayName: fieldName,
                    searchText: searchKey,
                    pageName: $rootScope.reportId,
                    id: $rootScope.savesReportId,
                    advancedSearch: {
                        columnFilterValues: $rootScope.RPTHeadSearchList,
                        accounts: $rootScope.selectedAccountsList,
                        imprints: $rootScope.rptImprintFilterList,
                        productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                    },
                    columnFilterValues: $rootScope.rptColumnFilterValues
                }
            }).then(function(response) {
                $rootScope.labels = response.data.data.label;
                $rootScope.series = response.data.data.series;
                $rootScope.data = response.data.data.data;
                $rootScope.trends = response.data.data.trends;
                eval('var obj=' + response.data.data.options);
                $scope.options = obj;
                angular.forEach($scope.options.title, function(key, val) {
                    if (val === "text") {
                        $rootScope.commonHeader = key
                    }
                })
                $rootScope.hideLoader('chart-container')
            });
            $http({
                method: 'POST',
                url: '/loadAllReportGrid',
                data: {
                    metaDataType: $rootScope.rDataType,
                    metaDataCategory: $rootScope.rMetaDataCategory,
                    fieldDisplayName: fieldName,
                    id: $rootScope.savesReportId,
                    searchText: searchKey,
                    isFiltered: !1,
                    skipCount: 0,
                    pageName: $rootScope.reportId,
                    advancedSearch: {
                        columnFilterValues: $rootScope.RPTHeadSearchList,
                        accounts: $rootScope.selectedAccountsList,
                        imprints: $rootScope.rptImprintFilterList,
                        productCategories: $rootScope.selectedRPTProductCategoryArraySearch,
                        fieldName: $rootScope.hdSearch
                    },
                    columnFilterValues: $rootScope.rptColumnFilterValues,
                }
            }).then(function(response) {
                $rootScope.reportResponseEnable();
                $rootScope.gridData = response.data.data;
                $rootScope.rptSearchCount = response.data.searchCount;
                $rootScope.hideLoader('report-grid');
                $rootScope.reportLoadMore()
            });
            $rootScope.rptLoading = !1
        }
        angular.element(".innerFilter.header-filter").removeClass('active');
        angular.element(".innerFilterDropdown.header-filter-dropdown").removeClass('active')
    }
    $rootScope.reportResponseEnable = function() {
        $timeout(function() {
            angular.element(".reportbutton-disable").removeClass('buttondisableds')
        }, 1500)
    }
    $scope.colors = [{
        backgroundColor: '#dbdbdb',
        borderColor: '#dbdbdb'
    }, {
        backgroundColor: '#fc9090',
        borderColor: '#fc9090'
    }, {
        backgroundColor: '#f7c084',
        borderColor: '#f7c084'
    }, {
        backgroundColor: '#a9caea',
        borderColor: '#a9caea'
    }, {
        backgroundColor: '#bbdba7',
        borderColor: '#bbdba7'
    }]
    $scope.options = {
        scales: {
            xAxes: [{
                barPercentage: 0.5,
                categoryPercentage: 0.5,
                gridLines: {
                    display: !0,
                    color: "#f5f5f5"
                },
            }],
            yAxes: [{
                gridLines: {
                    color: "#f5f5f5"
                },
            }]
        },
        legend: {
            display: !0,
            labels: {
                fontColor: '#7c7c7c',
                boxWidth: 10,
            }
        }
    }
    $scope.newReportProductCategoryNames = [];
    $rootScope.getRPTSelectedSearchFilterProductCategories = function() {
        $rootScope.selectedRPTProductCategoryArraySearch = [];
        $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "GETSELECTED")
    };
    $rootScope.getRPTNestedChildren = function(arr, parent) {
        var out = [];
        for (var i in arr) {
            if (arr[i].parentId == parent) {
                var children = $scope.getRPTNestedChildren(arr, arr[i].productCategoryId)
                if (children.length) {
                    arr[i].children = children
                }
                out.push(arr[i])
            }
        }
        return out
    }
    $rootScope.traverseSearchTreeReport = function(arr, operation) {
        if (arr != undefined) {
            for (var i = 0, l = arr.length; i < l; i++) {
                var current = arr[i];
                if (operation == "GETSELECTED") {
                    if (current.selected) {
                        $rootScope.selectedRPTProductCategoryArraySearch.push(current.productCategoryId)
                    }
                } else if (operation == "UNSELECT") {
                    current.selected = !1;
                    $rootScope.RPTpCategoryFilterList = $filter('filter')($rootScope.RPTpCategoryFilterList, function(data) {
                        return data.productCategoryId != current.productCategoryId
                    })
                } else if (operation == "SELECT") {
                    current.selected = !0;
                    var tempList = $filter('filter')($rootScope.RPTpCategoryFilterList, function(data) {
                        return data.productCategoryId == current.productCategoryId
                    });
                    if (tempList.length == 0) {
                        $rootScope.RPTpCategoryFilterList.push(current)
                    }
                } else if (operation == "POPULATEFOREDIT") {
                    if ($rootScope.selectedRPTProductCategoryArraySearch.indexOf(current.productCategoryId) > -1) {
                        current.selected = !0;
                        var tempList = $filter('filter')($rootScope.RPTpCategoryFilterList, function(data) {
                            return data.productCategoryId == current.productCategoryId
                        });
                        if (tempList.length == 0) {
                            $rootScope.RPTpCategoryFilterList.push(current)
                        }
                    }
                }
                if (current.children && current.children.length > 0) {
                    $rootScope.traverseSearchTreeReport(current.children, operation)
                }
            }
        }
    }
    $rootScope.reportProductCategoryChildren = function(data, pCId) {
        if (!data.selected) {
            $rootScope.RPTpCategoryFilterList = $filter('filter')($rootScope.RPTpCategoryFilterList, function(current) {
                return current.productCategoryId != data.productCategoryId
            });
            if (data.children && data.children.length > 0) {
                $rootScope.traverseSearchTreeReport(data.children, "UNSELECT")
            }
        } else {
            $rootScope.RPTpCategoryFilterList.push(data);
            if (data.children && data.children.length > 0) {
                $rootScope.traverseSearchTreeReport(data.children, "SELECT")
            }
        }
        $rootScope.getRPTSelectedSearchFilterProductCategories();
        setTimeout(function() {
            document.getElementById("rptpCateoryAllSelected").checked = (($rootScope.RPTpCategoryFilterList.length === $rootScope.RPTProductCategorySearchList.length) && $rootScope.RPTProductCategorySearchList.length != 0);
            $rootScope.search.rptpCateoryAllSelected = (($rootScope.RPTpCategoryFilterList.length === $rootScope.RPTProductCategorySearchList.length) && $rootScope.RPTProductCategorySearchList.length != 0)
        }, 100);
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    };
    $rootScope.getReportProductCategoriesForSearch = function() {
        $rootScope.selectedRPTProductCategoryArraySearch = [];
        if ($rootScope.RPTproductCategoryTreeList != undefined && $rootScope.RPTproductCategoryTreeList.length > 0) {
            $rootScope.getRPTSelectedSearchFilterProductCategories()
        }
        $http({
            method: 'GET',
            url: '/getProductCategories/' + $rootScope.selectedAccountsList.toString()
        }).then(function successCallback(response) {
            $rootScope.RPTProductCategorySearchList = response.data.data.productCategoryList;
            $rootScope.RPTpCategoryFilterList = [];
            $rootScope.RPTproductCategoryTree = $rootScope.getRPTNestedChildren(response.data.data.productCategoryList, null);
            $rootScope.RPTproductCategoryTreeList = angular.copy($rootScope.RPTproductCategoryTree);
            $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "POPULATEFOREDIT");
            if (document.getElementById("rptpCateoryAllSelected") != null && document.getElementById("rptpCateoryAllSelected") != undefined) {
                if ($rootScope.RPTpCategoryFilterList.length === response.data.data.productCategoryList.length && response.data.data.productCategoryList.length != 0)
                    document.getElementById("rptpCateoryAllSelected").checked = !0;
                else document.getElementById("rptpCateoryAllSelected").checked = !1
            }
        }, function errorCallback(response) {})
    };
    $rootScope.getReportImprints = function() {
        var accountArray = $rootScope.selectedAccountsList;
        $http({
            method: 'GET',
            url: '/getImprintListForAccounts/' + accountArray.toString()
        }).then(function successCallback(response) {
            $rootScope.rptImprintList = response.data.data;
            var temp = $.grep($rootScope.rptImprintFilterList, function(element) {
                return $.inArray(element, $rootScope.rptImprintList) !== -1
            });
            $rootScope.rptImprintFilterList = temp;
            if ($rootScope.rptImprintList.length === $rootScope.rptImprintFilterList.length && $rootScope.rptImprintList.length != 0)
                $rootScope.rptImprintAllSelected = !0;
            else $rootScope.rptImprintAllSelected = !1
        }, function errorCallback(response) {})
    };
    $rootScope.RPTpCateoryAllSelect = function(chkFlg) {
        $rootScope.search.rptpCateoryAllSelected = chkFlg;
        if (chkFlg)
            $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "SELECT");
        else $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "UNSELECT");
        $rootScope.getRPTSelectedSearchFilterProductCategories();
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $scope.rptRegionAllSelect = function($event) {
        $rootScope.rptRegionFilterList = [];
        $rootScope.selectedAccountsList = [];
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        var filteredAccountList = $rootScope.accountList;
        if (action === 'add') {
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("reportAccount_" + acl.accountName).checked = !0;
                $rootScope.rptRegionFilterList.push(acl);
                $rootScope.selectedAccountsList.push(acl.accountId);
                $rootScope.selectedAccountsName.push(acl.accountName)
            })
        } else if (action === 'remove') {
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("reportAccount_" + acl.accountName).checked = !1
            });
            $rootScope.rptRegionFilterList = [];
            $rootScope.selectedAccountsName = [];
            $rootScope.selectedAccounts = []
        }
        $rootScope.getReportImprints();
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $rootScope.selectedAccountsName = [];
    $scope.chkAccountName = function(input, checkAcct) {
        var checkCount = 0;
        var filteredAccountList = $rootScope.accountList;
        angular.forEach(filteredAccountList, function(acl) {
            if (document.getElementById("reportAccount_" + acl.accountName).checked) checkCount++
        });
        $timeout(function() {
            $scope.rptRegionAllSelected = (checkCount === filteredAccountList.length)
        }, 100);
        if (checkAcct) {
            $rootScope.rptRegionFilterList.push(input);
            $rootScope.selectedAccountsList.push(input.accountId);
            $rootScope.selectedAccountsName.push(input.accountName)
        } else {
            $rootScope.rptRegionFilterList = $filter('filter')($rootScope.rptRegionFilterList, function(data) {
                return data.accountId != input.accountId
            });
            $rootScope.selectedAccountsList = $filter('filter')($rootScope.selectedAccountsList, function(data) {
                return data != input.accountId
            });
            $rootScope.selectedAccountsName = $filter('filter')($rootScope.selectedAccountsName, function(data) {
                return data != input.accountName
            })
        }
        $rootScope.getReportImprints();
        $rootScope.getReportProductCategoriesForSearch();
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $scope.rptImprintAllSelect = function($event, checkFlg, rptimprintFilter) {
        $scope.rptImprintAllSelected = checkFlg;
        var filteredList = $filter('filter')($rootScope.imprintList, function(data) {
            var re = new RegExp(RegExp.escape($scope.rptimprintFilter), 'gi');
            return data.match(re)
        });
        if (checkFlg) {
            angular.forEach(filteredList, function(imp) {
                document.getElementById("reportImprint_" + imp).checked = !0;
                if ($rootScope.rptImprintFilterList.indexOf(imp) == -1)
                    $rootScope.rptImprintFilterList.push(imp)
            })
        } else {
            angular.forEach(filteredList, function(imp) {
                document.getElementById("reportImprint_" + imp).checked = !1;
                $rootScope.rptImprintFilterList = $filter('filter')($rootScope.rptImprintFilterList, function(data) {
                    return data != imp
                })
            })
        }
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $scope.rptImprintTags = function(input, checkImprint) {
        var checkCount = 0;
        angular.forEach($rootScope.rptImprintList, function(item) {
            if (null != document.getElementById("reportImprint_" + item))
                if (document.getElementById("reportImprint_" + item).checked) {
                    checkCount++
                }
        });
        if (checkImprint) {
            $rootScope.rptImprintFilterList.push(input)
        } else {
            $rootScope.rptImprintFilterList.splice($rootScope.rptImprintFilterList.indexOf(input), 1)
        }
        $timeout(function() {
            $rootScope.rptImprintAllSelected = (checkCount === $rootScope.rptImprintList.length);
            document.getElementById("rptImprintAllSelected").checked = (checkCount === $rootScope.rptImprintList.length)
        }, 100);
        $rootScope.refreshRPTSearchImprintList();
        $rootScope.rptSearchEnable = !0;
        var fieldName = '';
        $rootScope.RptColumnserachText = "";
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    };
    $rootScope.rptDateTags = function(val, chek, date) {
        $rootScope.rptSearchEnable = !0;
        if (chek === 'fromDate') {
            if (val == "" || val == null || val == undefined)
                $rootScope.rptFromDate = null;
            else $rootScope.rptFromDate = val
        } else {
            if (val == "" || val == null || val == undefined)
                $rootScope.rptToDate = null;
            else $rootScope.rptToDate = val
        }
    }
    $scope.clearFilterValue = function(input, chk, fieldName) {
        if (chk === 'acts') {
            if ($rootScope.rptRegionFilterList.length > '0') {
                document.getElementById("reportAccount_" + input.accountName).checked = !1;
                $rootScope.rptRegionFilterList.splice($rootScope.rptRegionFilterList.indexOf(input), 1);
                $rootScope.selectedAccountsList.splice($rootScope.selectedAccountsList.indexOf(input.accountId), 1);
                $scope.rptRegionAllSelected = !1
            }
            if ($rootScope.rptRegionFilterList.length == '0') {
                $scope.rptRegionAllSelected = !1
            }
        } else if (chk === 'imprint') {
            if ($rootScope.rptImprintFilterList.length > '0') {
                if (null != document.getElementById("reportImprint_" + input))
                    document.getElementById("reportImprint_" + input).checked = !1;
                $rootScope.rptImprintFilterList.splice($rootScope.rptImprintFilterList.indexOf(input), 1);
                $rootScope.rptImprintAllSelected = !1;
                if (null != document.getElementById("rptImprintAllSelected"))
                    document.getElementById("rptImprintAllSelected").checked = !1
            }
            if ($rootScope.rptImprintFilterList.length == '0') {
                $rootScope.rptImprintAllSelected = !1
            }
            $rootScope.refreshRPTSearchImprintList()
        } else if (chk === 'PRODUCTCATEGORY') {
            $rootScope.RPTpCategoryFilterList = $filter('filter')($rootScope.RPTpCategoryFilterList, function(data) {
                return data.productCategoryId != input.productCategoryId
            });
            input.selected = !1;
            if (input.children && input.children.length > 0) {
                $rootScope.traverseSearchTreeReport(input.children, "UNSELECT")
            }
            $rootScope.search.rptpCateoryAllSelected = !1;
            $scope.getRPTSelectedSearchFilterProductCategories()
        } else if (chk === 'date') {
            $rootScope.rptFromDate = null;
            $rootScope.rptToDate = null;
            $scope.reportToDate = null;
            $scope.reportFromDate = null;
            document.getElementById("reportFromDate").value = "";
            document.getElementById("reportToDate").value = ""
        } else if (chk === 'searchKey') {
            $rootScope.search.searchRPTValue = "";
            angular.element($("#txtRPTSearch")).val('');
            delete $rootScope.RPTHeadSearchList[fieldName]
        }
        $rootScope.RptColumnserachText = '';
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $rootScope.reportLoadMore = function() {
        if ($rootScope.rptSearchCount == '0') {
            $scope.showLoadmore = !1
        }
        if (($rootScope.gridData.length || $rootScope.gridData == undefined) >= $rootScope.rptSearchCount) {
            $scope.showLoadmore = !1;
            $scope.rowperpage = 100;
            $rootScope.gridData.length = $rootScope.rptSearchCount
        } else {
            $scope.showLoadmore = !0;
            $scope.buttonText = "Load More"
        }
    }
    $scope.clearReport = function(chk) {
        $rootScope.RptColumnserachText = '';
        $rootScope.rptSearchEnable = !1;
        angular.element(".menu_list_action").removeClass('active');
        angular.element(".reportbutton-disable").addClass('buttondisableds');
        if ($rootScope.rptRegionFilterList.length > '0') {
            var filteredAccountList = $rootScope.accountList;
            angular.forEach(filteredAccountList, function(acl) {
                document.getElementById("reportAccount_" + acl.accountName).checked = !1
            });
            $scope.rptRegionAllSelected = !1;
            document.getElementById("rptRegionAllSelected").checked = !1
        }
        if ($rootScope.rptImprintFilterList.length > '0') {
            angular.forEach($rootScope.rptImprintList, function(imp) {
                if (null != document.getElementById("reportImprint_" + imp))
                    document.getElementById("reportImprint_" + imp).checked = !1
            });
            $rootScope.rptImprintAllSelected = !1;
            if (null != document.getElementById("rptImprintAllSelected"))
                document.getElementById("rptImprintAllSelected").checked = !1
        }
        $rootScope.search.rptpCateoryAllSelected = !1;
        $rootScope.traverseSearchTreeReport($rootScope.RPTproductCategoryTreeList, "UNSELECT");
        $rootScope.searchKey = "";
        $rootScope.rptFromDate = '';
        $rootScope.rptToDate = '';
        $scope.dataDate.filterFromDate = "";
        $scope.columnFromDateRPT = "";
        $scope.dataDate.filterToDate = "";
        $scope.columnToDateRPT = "";
        $scope.reportToDate = null;
        $scope.reportFromDate = null;
        document.getElementById("reportFromDate").value = "";
        document.getElementById("reportToDate").value = "";
        angular.forEach($rootScope.rptSearchColumnSuggestions, function(item) {
            angular.forEach(item, function(subitem) {
                subitem.selected = !1
            })
        });
        $scope.reportColumnFilterSearch = {};
        $rootScope.rptLookUpSuggestions = {};
        $rootScope.rptRegionFilterList = [];
        $rootScope.rptRegionFilterListNext = [];
        $rootScope.selectedAccountsList = [];
        $rootScope.rptImprintFilterList = [];
        $rootScope.RPTpCategoryFilterList = [];
        $rootScope.rptDateFilterList = [];
        $rootScope.rptInColFilterList = {};
        $rootScope.rptInColumnFilterList = {};
        $rootScope.rptgHeadresAllSelect = {};
        $rootScope.rptColumnFilterValues = {};
        $rootScope.rptSearchColumnSuggestions = {}
        $rootScope.RPTToDateFilterList = {};
        $rootScope.RPTFromDateFilterList = {};
        $rootScope.RPTHeadSearchList = {};
        $rootScope.hdSearch = [];
        $rootScope.search.searchRPTValue = "";
        angular.element($("#txtRPTSearch")).val('');
        $rootScope.showLoader($('.chart-container'), 1, 'win8_linear');
        $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/getReportGridHeaders/',
            data: {
                pageName: $rootScope.reportId
            }
        }).then(function(response) {
            $rootScope.reportGridHeaders = response.data.data
        });
        $http({
            method: 'POST',
            url: '/loadAllReportChart',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                searchText: "",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                advancedSearch: {},
                pageName: $rootScope.reportId
            }
        }).then(function(response) {
            $rootScope.labels = response.data.data.label;
            $rootScope.series = response.data.data.series;
            $rootScope.data = response.data.data.data;
            $rootScope.trends = response.data.data.trends;
            eval('var obj=' + response.data.data.options);
            $scope.options = obj;
            angular.forEach($scope.options.title, function(key, val) {
                if (val === "text") {
                    $rootScope.commonHeader = key
                }
            })
            $rootScope.hideLoader('chart-container')
        });
        $http({
            method: 'POST',
            url: '/loadAllReportGrid',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                searchText: "",
                isFiltered: !1,
                searchName: "",
                skipCount: 0,
                advancedSearch: {},
                pageName: $rootScope.reportId
            }
        }).then(function(response) {
            $rootScope.reportResponseEnable();
            $rootScope.gridData = response.data.data;
            $rootScope.rptSearchCount = response.data.searchCount;
            $rootScope.hideLoader('report-grid');
            $rootScope.reportLoadMore()
        });
        if (chk == '') {
            setTimeout(function() {
                angular.element(".innerFilter").addClass('active');
                angular.element(".innerFilterDropdown").addClass('active')
            }, 4000)
        }
    }
    $scope.count = 1
    $scope.showLoadmore = !1;
    $scope.row = 100;
    $scope.rowperpage = 0;
    $scope.buttonText = "Load More";
    $scope.getPosts = function() {
        $scope.rowperpage = $rootScope.gridData.length;
        $rootScope.showLoader($('.loader-report-table'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/loadAllReportGrid',
            data: {
                metaDataType: "BOOK",
                metaDataCategory: "ISBNs",
                fieldDisplayName: "ISBN13",
                isFiltered: !1,
                id: $rootScope.savesReportId,
                skipCount: $scope.rowperpage,
                advancedSearch: {
                    columnFilterValues: $rootScope.RPTHeadSearchList,
                    accounts: $rootScope.selectedAccountsList,
                    imprints: $rootScope.rptImprintFilterList
                },
                columnFilterValues: $rootScope.rptColumnFilterValues,
                transDateFrom: $rootScope.rptFromDate,
                transDateTo: $rootScope.rptToDate,
                pageName: $rootScope.reportId
            }
        }).then(function successCallback(response) {
            $timeout(function() {
                $rootScope.hideLoader('loader-report-table')
            }, 1000);
            if ($rootScope.gridData.length <= $rootScope.rptSearchCount) {
                if (response.data.data != '') {
                    if ($rootScope.gridData != undefined) {
                        $rootScope.reportResponseEnable();
                        setTimeout(function() {
                            $scope.$apply(function() {
                                angular.forEach(response.data.data, function(item) {
                                    $rootScope.gridData.push(item)
                                });
                                $rootScope.reportLoadMore()
                            })
                        }, 500)
                    } else {
                        $rootScope.reportResponseEnable();
                        $rootScope.gridData = response.data.data;
                        $scope.rowperpage = 100
                    }
                } else {
                    $scope.showLoadmore = !1;
                    $scope.rowperpage = 100
                }
            } else {
                $scope.showLoadmore = !1;
                $rootScope.gridData.length = $rootScope.rptSearchCount;
                $scope.rowperpage = 100
            }
        })
    };
    $rootScope.getReportProductCategoriesForSearch();
    $rootScope.rptSearchSuggestions = [];
    $rootScope.getHeaderSearchSuggestions = function(mType, mTypeCategory, fielddisplayname) {
        var user_id = $rootScope.loggedUser.userId;
        var searchKey = angular.element($("#txtRPTSearch")).val();
        if (searchKey.length !== 0) {
            if (searchKey.length >= 4) {
                $http({
                    method: 'POST',
                    url: '/reportHeaderSearchSuggestions',
                    data: {
                        metaDataType: mType,
                        metaDataCategory: "ISBNs",
                        fieldDisplayName: fielddisplayname,
                        pageName: $rootScope.reportId,
                        advancedSearch: {},
                        searchText: searchKey,
                        skipCount: 0
                    }
                }).then(function(response) {
                    $rootScope.rptSearchSuggestions[fielddisplayname] = response.data.data
                })
            } else {
                $rootScope.rptSearchSuggestions[fielddisplayname] = []
            }
        }
    };
    $scope.closeRPTSaveSearch = function() {
        $('#reportModal').modal('toggle');
        angular.element($("#Name")).val('')
    }
    $scope.resetRPTSaveSearch = function() {
        angular.element($("#saveRPTSearchName")).val('')
    }
    $rootScope.saveRPTSearch = function(fieldName) {
        var user_id = $rootScope.loggedUser.userId;
        $rootScope.existsRPTError = !1;
        $rootScope.isRPTEmpty = !1;
        if (fieldName === 'All') {
            if ($rootScope.rptFiledName == '' || $rootScope.rptFiledName == null || $rootScope.rptFiledName == undefined) {
                $rootScope.rptFiledName = 'ISBN13'
            }
            fieldName = $rootScope.rptFiledName
        }
        var searchname = angular.element($("#saveRPTSearchName")).val();
        if (searchname === undefined || searchname === '') {
            $rootScope.isRPTEmpty = !0;
            $rootScope.SearchNameEmpty = 'SEARCH_NAME_EMPTY'
        } else {
            $http({
                method: 'POST',
                url: '/saveReportSearch',
                data: {
                    pageName: $rootScope.reportId,
                    advancedSearch: {
                        columnFilterValues: $rootScope.RPTHeadSearchList,
                        accounts: $rootScope.selectedAccountsList,
                        imprints: $rootScope.rptImprintFilterList,
                        productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                    },
                    searchName: searchname,
                    fieldDisplayName: fieldName,
                    searchText: "",
                    columnFilterValues: $rootScope.rptColumnFilterValues,
                    transDateFrom: $rootScope.rptFromDate,
                    transDateTo: $rootScope.rptToDate,
                    id: $rootScope.savesReportId,
                }
            }).then(function(response) {
                $rootScope.getReportsList();
                if (response.data.code == '200') {
                    $rootScope.showRPTSuccessMsg = !0;
                    $rootScope.serachNameSuccessMsg = response.data.statusMessage;
                    setTimeout(() => {
                        $rootScope.showRPTSuccessMsg = !1;
                        $scope.$apply()
                    }, 2000)
                    $('#reportModal').modal('toggle');
                    $rootScope.saveRPTSearchName = "";
                    angular.element($("#saveRPTSearchName")).val('')
                } else {
                    $rootScope.existsRPTError = !0;
                    $rootScope.SearchNameExists = response.data.statusMessage;
                    setTimeout(() => {
                        $scope.showRPTErrorMsg = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            })
        }
    };
    $rootScope.reportColumSearchFilter = function(fieldName, lookup) {
        if (lookup == !0) {
            var suggestTxt = $scope.reportColumnFilterSearch[fieldName] == undefined ? "" : $scope.reportColumnFilterSearch[fieldName];
            $scope.callGetReportColumnFilterSuggestions(fieldName, suggestTxt, lookup)
        }
    }
    $rootScope.rptSearchColumnSuggestions = {};
    $rootScope.rptLookUpSuggestions = {};
    var timeout = null;
    $scope.getReportColumnFilterSuggestions = function(fieldName, suggestTxt, lookup) {
        if (lookup == !0) {
            $scope.callGetReportColumnFilterSuggestions(fieldName, suggestTxt, lookup)
        } else {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                $scope.callGetReportColumnFilterSuggestions(fieldName, suggestTxt, lookup)
            }, 800)
        }
    }
    $scope.callGetReportColumnFilterSuggestions = function(fieldName, suggestTxt, lookup) {
        $rootScope.rptFiledName = fieldName;
        if ($rootScope.rptLookUpSuggestions[fieldName] != undefined && Object.keys($rootScope.rptLookUpSuggestions[fieldName]).length > 0) {
            var filteredList = $filter('filter')($rootScope.rptLookUpSuggestions[fieldName], function(data) {
                var re = new RegExp(RegExp.escape($scope.reportColumnFilterSearch[fieldName]), 'gi');
                return data.description.match(re)
            });
            if (filteredList != null && filteredList.length > 0) {
                if ($rootScope.inColFilterList[fieldName] != undefined && $rootScope.inColFilterList[fieldName] != [] && $rootScope.inColFilterList[fieldName] != null) {
                    $.each(filteredList, function(index, data) {
                        if ($rootScope.rptInColumnFilterList[fieldName].indexOf(data.code) != -1) {
                            data.selected = !0
                        }
                    })
                }
                $rootScope.rptSearchColumnSuggestions[fieldName] = $filter('filter')(filteredList, function(data) {
                    return (data.code != null && data.code != undefined && data.code != "")
                })
                $rootScope.rptgHeadresAllSelect[fieldName] = $rootScope.rptSearchColumnSuggestions[fieldName].every(function(itm) {
                    return itm.selected
                })
            } else {
                $rootScope.rptSearchColumnSuggestions[fieldName] = filteredList;
                $rootScope.rptgHeadresAllSelect[fieldName] = !1
            }
            return !1
        } else {
            $http({
                method: 'POST',
                url: '/getReportColumnFilterSuggestions',
                data: {
                    metaDataType: "BOOK",
                    metaDataCategory: "ISBNs",
                    fieldDisplayName: fieldName,
                    searchText: suggestTxt,
                    id: $rootScope.savesReportId,
                    skipCount: 0,
                    advancedSearch: {
                        columnFilterValues: $rootScope.RPTHeadSearchList,
                        accounts: $rootScope.selectedAccountsList,
                        imprints: $rootScope.rptImprintFilterList,
                        productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                    },
                    columnFilterValues: $rootScope.rptColumnFilterValues,
                    pageName: $rootScope.reportId
                }
            }).then(function(response) {
                if (response.data.data != null && Object.keys(response.data.data).length > 0) {
                    if ($rootScope.rptInColFilterList[fieldName] != undefined && $rootScope.rptInColFilterList[fieldName] != [] && $rootScope.rptInColFilterList[fieldName] != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($rootScope.rptInColumnFilterList[fieldName].indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    if (lookup == !0) {
                        $rootScope.rptLookUpSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                            return (data.code != null && data.code != undefined && data.code != "")
                        })
                    } else {
                        $rootScope.rptLookUpSuggestions = {}
                    }
                    $rootScope.rptSearchColumnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $rootScope.rptgHeadresAllSelect[fieldName] = $rootScope.rptSearchColumnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                } else {
                    $rootScope.rptSearchColumnSuggestions[fieldName] = response.data.data;
                    $rootScope.rptgHeadresAllSelect[fieldName] = !1
                }
            })
        }
    };
    $rootScope.columnFilterCheck = function() {
        var filterCount = 0;
        if (Object.keys($rootScope.rptInColFilterList).length != 0) {
            $.each($rootScope.rptInColFilterList, function(index, fieldName) {
                if (fieldName != null && fieldName != undefined && Object.keys(fieldName).length != 0) {
                    filterCount = 1
                    return
                }
            })
        } else {
            filterCount = 0
        }
        return filterCount
    };
    $rootScope.rptInColFilterList = {};
    $rootScope.rptInColumnFilterList = {};
    $rootScope.rptgHeadresAllSelect = {};
    $rootScope.rptColumnFilterValues = {};
    $rootScope.fromDateRPTFilterList = {};
    $rootScope.toDateRPTFilterList = {};
    $scope.rptGridHeadresAllSelected = function(fieldName, chkFlg, searchKey) {
        if ($rootScope.rptSearchColumnSuggestions[fieldName] == undefined || $rootScope.rptSearchColumnSuggestions[fieldName] == []) {
            $rootScope.rptgHeadresAllSelect[fieldName] = !1
        } else {
            angular.forEach($rootScope.rptSearchColumnSuggestions[fieldName], function(itm) {
                itm.selected = chkFlg
            });
            if (chkFlg) {
                if ($rootScope.rptInColFilterList[fieldName] == undefined) {
                    $rootScope.rptInColumnFilterList[fieldName] = [];
                    $rootScope.rptInColFilterList[fieldName] = []
                }
                angular.forEach($rootScope.rptSearchColumnSuggestions[fieldName], function(input) {
                    if ($rootScope.rptInColumnFilterList[fieldName].indexOf(input.code) == -1) {
                        $rootScope.rptInColFilterList[fieldName].push(input);
                        $rootScope.rptInColumnFilterList[fieldName].push(input.code)
                    }
                })
            } else {
                angular.forEach($rootScope.rptSearchColumnSuggestions[fieldName], function(input) {
                    $rootScope.rptInColFilterList[fieldName] = $filter('filter')($rootScope.rptInColFilterList[fieldName], function(data) {
                        return (data.code != input.code)
                    });
                    $rootScope.rptInColumnFilterList[fieldName] = $filter('filter')($rootScope.rptInColumnFilterList[fieldName], function(data) {
                        return (data != input.code)
                    })
                })
            }
        }
        $rootScope.rptColumnFilterValues = $rootScope.rptInColumnFilterList;
        $rootScope.RptColumnserachText = "";
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $timeout(function() {
        $rootScope.rptRefreshSearch = function() {
            if ($rootScope.rptRegionFilterList.length != 0 || $rootScope.rptImprintFilterList.length != 0 || $rootScope.RPTpCategoryFilterList.length != 0 || $rootScope.columnFilterCheck() != 0 || $rootScope.dateColumnRPTSearch() || $rootScope.search.searchRPTValue != '' || $rootScope.rptFromDate != '' && $rootScope.rptFromDate != null || $rootScope.checkRptStatusFilterApplied()) {
                return !1
            } else {
                return !0
            }
        }
    }, 1500)
    $rootScope.checkRptStatusFilterApplied = function() {
        var flg = !1;
        if (Object.keys($rootScope.rptInColumnFilterList).length != 0) {
            $.each($rootScope.rptInColumnFilterList, function(index, fieldName) {
                if (fieldName != null && fieldName != undefined && Object.keys(fieldName).length != 0) {
                    flg = !0;
                    return
                }
            })
        }
        return flg
    };
    $rootScope.rptAddRemoveColumnTags = function(input, chkFlg, fieldName, serachKey) {
        $rootScope.rptFiledName = fieldName;
        $rootScope.rptSerachKey = serachKey;
        if (chkFlg) {
            if ($rootScope.rptInColFilterList[fieldName] == undefined) {
                $rootScope.rptInColumnFilterList[fieldName] = [];
                $rootScope.rptInColFilterList[fieldName] = []
            }
            $rootScope.rptInColFilterList[fieldName].push(input);
            $rootScope.rptInColumnFilterList[fieldName].push(input.code);
            $rootScope.rptgHeadresAllSelect[fieldName] = $rootScope.rptSearchColumnSuggestions[fieldName].every(function(itm) {
                return itm.selected
            })
        } else {
            $rootScope.rptgHeadresAllSelect[fieldName] = !1;
            $.each($rootScope.rptSearchColumnSuggestions[fieldName], function(index, data) {
                if (data.code == input.code) {
                    data.selected = !1;
                    return !1
                }
            });
            $rootScope.rptInColumnFilterList[fieldName] = $filter('filter')($rootScope.rptInColumnFilterList[fieldName], function(data) {
                return (data != input.code)
            });
            $rootScope.rptInColFilterList[fieldName] = $filter('filter')($rootScope.rptInColFilterList[fieldName], function(data) {
                return (data.code != input.code)
            })
        }
        if (Object.values($rootScope.rptInColumnFilterList[fieldName]).length == 0) {
            delete $rootScope.rptInColumnFilterList[fieldName];
            delete $rootScope.rptInColFilterList[fieldName]
        }
        $rootScope.rptColumnFilterValues[fieldName] = $rootScope.rptInColumnFilterList[fieldName];
        $rootScope.RptColumnserachText = "";
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, "")
        }
    };
    $rootScope.RPTDateFilterList = [];
    $rootScope.RPTFromDateFilterList = {};
    $rootScope.RPTToDateFilterList = {};
    $rootScope.filterDate = ["", ""];
    $rootScope.dateColumnRPTSearch = function() {
        var isMyObjectEmpty = !Object.keys($rootScope.RPTFromDateFilterList).length;
        if (isMyObjectEmpty)
            isMyObjectEmpty = !Object.keys($rootScope.RPTToDateFilterList).length;
        return !isMyObjectEmpty
    };
    $rootScope.rptAddDateFilter = function(fieldName, fieldType) {
        $rootScope.checkDatevalid = fieldName;
        if (undefined != $rootScope.RPTDateFilterList[fieldName]) {
            if (fieldType === 'FROM') {
                var fromDate = document.getElementById("filterFromDate_" + fieldName).value;
                $scope.columnFromDateRPT = fromDate;
                var data = $rootScope.RPTDateFilterList[fieldName];
                data[0] = fromDate;
                $rootScope.RPTDateFilterList[fieldName] = data;
                $rootScope.RPTFromDateFilterList[fieldName] = fromDate
            } else {
                var toDate = document.getElementById("filterToDate_" + fieldName).value;
                $scope.columnToDateRPT = toDate;
                var data = $rootScope.RPTDateFilterList[fieldName];
                data[1] = toDate;
                $rootScope.filterDate[1] = toDate;
                $rootScope.RPTDateFilterList[fieldName] = data;
                $rootScope.RPTToDateFilterList[fieldName] = toDate
            }
        } else {
            var myDate = ["", ""];
            if (fieldType === 'FROM') {
                var fromDate = document.getElementById("filterFromDate_" + fieldName).value;
                $scope.columnFromDateRPT = fromDate;
                myDate[0] = fromDate;
                $rootScope.RPTDateFilterList[fieldName] = myDate;
                $rootScope.RPTFromDateFilterList[fieldName] = fromDate
            } else {
                var toDate = document.getElementById("filterToDate_" + fieldName).value;
                $scope.columnToDateRPT = toDate;
                myDate[1] = toDate;
                $rootScope.RPTDateFilterList[fieldName] = myDate;
                $rootScope.RPTToDateFilterList[fieldName] = toDate
            }
        }
        $rootScope.rptColumnFilterValues[fieldName] = $rootScope.RPTDateFilterList[fieldName];
        $rootScope.RptColumnserachText = '';
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $scope.RptresetSaveSearch = function() {
        if ($rootScope.rptSearchEnable == !0) {
            angular.element("#searchrequest").modal('toggle')
        } else {
            angular.element("#reportModal").modal('toggle')
        }
    }
    $scope.dataDate = {};
    $rootScope.removeRPTDateFilter = function(fieldName, fieldType, dateVal) {
        if (fieldType === 'FROM') {
            var data = $rootScope.RPTDateFilterList[fieldName];
            data[0] = "";
            $rootScope.RPTDateFilterList[fieldName] = data;
            delete $rootScope.RPTFromDateFilterList[fieldName];
            document.getElementById("filterFromDate_" + fieldName).value = "";
            $scope.dataDate.filterFromDate = "";
            $scope.columnFromDateRPT = "";
            var check = $rootScope.RPTDateFilterList[fieldName];
            if ("" == check[0] && "" == check[1])
                delete $rootScope.RPTDateFilterList[fieldName]
        } else {
            var data = $rootScope.RPTDateFilterList[fieldName];
            data[1] = "";
            $rootScope.RPTDateFilterList[fieldName] = data;
            delete $rootScope.RPTToDateFilterList[fieldName]
            document.getElementById("filterToDate_" + fieldName).value = "";
            $scope.dataDate.filterToDate = "";
            $scope.columnToDateRPT = "";
            var check = $rootScope.RPTDateFilterList[fieldName];
            if ("" == check[0] && "" == check[1])
                delete $rootScope.RPTDateFilterList[fieldName]
        }
        $rootScope.rptColumnFilterValues[fieldName] = $rootScope.RPTDateFilterList[fieldName];
        $rootScope.RptColumnserachText = '';
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $rootScope.saveDuplicateRPTName = function(savedReportList, index) {
        var result = !0;
        $rootScope.isEditRpt[index] = !1;
        var dupName = $("#duplicate_" + savedReportList.id).val();
        if (result === !0) {
            $http({
                method: 'POST',
                url: '/duplicateSavedReport',
                data: {
                    frequency: savedReportList.frequency,
                    searchName: dupName,
                    userId: savedReportList.userId,
                    advancedSearch: savedReportList.advancedSearch,
                    fieldDisplayName: savedReportList.fieldDisplayName,
                    searchText: savedReportList.searchText,
                    columnFilterValues: savedReportList.columnFilterValues,
                    skipCount: savedReportList.skipCount,
                    searchReultCount: savedReportList.searchReultCount,
                    pageName: savedReportList.pageName,
                    id: savedReportList.id
                }
            }).then(function successCallback(response) {
                $("#duplicate_" + savedReportList.id).hide();
                $rootScope.getReportsList();
                if (response.data.code == '200') {
                    $rootScope.showRPTDupSuccessMsg = !0;
                    $rootScope.dupReportSuccessMsg = response.data.statusMessage;
                    setTimeout(function() {
                        $rootScope.showRPTDupSuccessMsg = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                } else {
                    $scope.showRPTDupErrorMsg = !0;
                    $rootScope.deleteReportErrorMsg = response.statusMessage;
                    setTimeout(function() {
                        $scope.showRPTDupErrorMsg = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                }
            }, function errorCallback(response) {})
        }
    };
    $rootScope.setARVal = [];
    $rootScope.setDRMVal = {};
    $rootScope.setWMVal = {};
    $scope.setAssetRequestVal = function(val) {
        $rootScope.setARVal = val
    }
    $scope.setDRMReorderVal = function(val, result, param) {
        if (param == 'DRM') {
            $rootScope.setDRMVal = val;
            $rootScope.setDRMISBN = result.ISBN13;
            $rootScope.setDRMEmailids = result.ClientEmail
        } else {
            $rootScope.setWMVal = val;
            $rootScope.setWMISBN = result.ISBN13
        }
    }
    $scope.assetDeleteApprovel = function(reason, param) {
        $http({
            method: 'GET',
            url: '/getAssetDelete/' + $rootScope.setARVal.assetDeleteRequestId,
        }).then(function successCallback(response) {
            $scope.getAssetDeleteVal = {}
            angular.forEach(response.data.data, function(val) {
                $scope.getAssetDeleteVal = val
            })
            if (response.data.code == '200') {
                $http({
                    method: 'POST',
                    url: '/assetDeleteApprovel',
                    data: {
                        "assetDeleteRequestId": $scope.getAssetDeleteVal.assetDeleteRequestId,
                        "isbn": $scope.getAssetDeleteVal.isbn,
                        "title": $scope.getAssetDeleteVal.title,
                        "author": $scope.getAssetDeleteVal.author,
                        "formatName": $scope.getAssetDeleteVal.formatName,
                        "formatId": $scope.getAssetDeleteVal.formatId,
                        "fileIds": $scope.getAssetDeleteVal.fileIds,
                        "removalStatus": $scope.getAssetDeleteVal.removalStatus,
                        "requestType": $scope.getAssetDeleteVal.requestType,
                        "comments": $scope.getAssetDeleteVal.comments,
                        "createdBy": $scope.getAssetDeleteVal.createdBy,
                        "approveComments": reason,
                        "modifiedBy": $rootScope.loggedUser.userId,
                        "loggedUser": $rootScope.loggedUser.userId,
                        "approveType": param
                    }
                }).then(function successCallback(response) {
                    $("#deleteApproveReason").val("");
                    if (response.data.code == '200') {
                        $rootScope.rptAssetDeleteUpdateSuccessMsg = !0;
                        $rootScope.assetDeleteUpdateSuccessMsg = response.data.statusMessage;
                        setTimeout(function() {
                            $rootScope.rptAssetDeleteUpdateSuccessMsg = !1;
                            $rootScope.$apply()
                        }, $rootScope.alertTimeoutInterval);
                        var result = $filter('filter')($rootScope.gridData, function(d) {
                            return (d.ISBN13 === $scope.getAssetDeleteVal.isbn)
                        })[0];
                        result.Action = param;
                        var tStatus = 0;
                        if (param === 'Approved') {
                            tStatus = '22'
                        } else {
                            tStatus = '23'
                        }
                        var downloadtemplateData = {};
                        downloadtemplateData["[format-name]"] = $scope.getAssetDeleteVal.formatName;
                        downloadtemplateData["[isbn]"] = $scope.getAssetDeleteVal.isbn;
                        downloadtemplateData["[title]"] = $scope.getAssetDeleteVal.title;
                        downloadtemplateData["[author]"] = $scope.getAssetDeleteVal.author;
                        downloadtemplateData["[approved-by]"] = $rootScope.loggedUser.firstName;
                        $http({
                            method: 'POST',
                            url: '/saveTransaction',
                            data: {
                                isbn: $scope.getAssetDeleteVal.isbn,
                                format: {
                                    "formatName": $scope.getAssetDeleteVal.formatName,
                                    "formatId": $scope.getAssetDeleteVal.formatId
                                },
                                title: $scope.getAssetDeleteVal.title,
                                userId: $rootScope.loggedUser.userId,
                                transactionStatus: tStatus,
                                transactionType: "ASSET_DELETE_APPROVE",
                                templateData: downloadtemplateData
                            }
                        }).then(function(response) {});
                        if (param === 'Approved') {
                            $http({
                                method: 'POST',
                                url: '/updateDeleteCompleteStatus',
                                data: {
                                    "isbn": $scope.getAssetDeleteVal.isbn,
                                    "formatId": $scope.getAssetDeleteVal.formatId,
                                    "action": "ASSET_DELETE",
                                    "shelfType": "Asset_Book"
                                }
                            }).then(function(response) {})
                        }
                    } else {
                        $rootScope.rptAssetDeleteUpdateErrorMsg = !0;
                        $rootScope.aDeleteUpdateErrorMsg = response.data.statusMessage;
                        setTimeout(function() {
                            $rootScope.rptAssetDeleteUpdateErrorMsg = !1;
                            $rootScope.$apply()
                        }, $rootScope.alertTimeoutInterval)
                    }
                }, function errorCallback(response) {})
            } else {}
        }, function errorCallback(response) {});
        $('#reptReqAssDlte').modal('toggle')
    }
    $scope.drmReorder = function() {
        $http({
            method: 'POST',
            url: '/drmReorder',
            data: {
                "_id": $rootScope.setDRMVal._id,
                "drmId": $rootScope.setDRMVal.drmId
            }
        }).then(function successCallback(response) {
            $rootScope.setDRMVal = {};
            $rootScope.setDRMISBN = "";
            $rootScope.setDRMEmailids = "";
            if (response.data.code == '200') {
                $rootScope.showRPTDRMReorderSuccessMsg = !0;
                $rootScope.RPTDRMReorderSuccessMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTDRMReorderSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.showRPTDRMReorderErrorMsg = !0;
                $rootScope.RPTDRMReorderErrorMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTDRMReorderErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $('#reptDRMReorder').modal('toggle')
        }, function errorCallback(response) {})
    }
    $scope.wmReorder = function() {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        today = mm + '/' + dd + '/' + yyyy;
        var uniqueId = 'WMORDER-' + Math.random().toString(36).substr(2, 16);
        $http({
            method: 'POST',
            url: '/wmReorder',
            data: {
                "_id": $rootScope.setWMVal._id,
                "watermarkId": $rootScope.setWMVal.watermarkId,
                "orderId": uniqueId
            }
        }).then(function successCallback(response) {
            $rootScope.setWMVal = {};
            $rootScope.setWMISBN = "";
            if (response.data.code == '200') {
                $rootScope.showRPTWMReorderSuccessMsg = !0;
                $rootScope.RPTWMReorderSuccessMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTWMReorderSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.showRPTWMReorderErrorMsg = !0;
                $rootScope.RPTDRMReorderErrorMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTWMReorderErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $('#reptWMReorder').modal('toggle')
        }, function errorCallback(response) {})
    }
    $rootScope.pendingDownloadRequest = false;
    $scope.downloadCSVFile = function(typeExport) {
        $rootScope.exportType = typeExport.type;
        if($rootScope.exportType == 'XLSX' && $rootScope.rptSearchCount > 1000000){
            angular.element("#exportLimitModal").modal('toggle');
            return !1
        }
        if ($rootScope.rptSearchEnable == !0) {
            angular.element("#searchrequest").modal('toggle');
            return !1
        }
        else if($rootScope.pendingDownloadRequest == true){
            angular.element("#downloadInprogress").modal('toggle')
            return !1
        }
        $rootScope.msg.showBaseSuccessMsg = !1;
        $rootScope.pendingDownloadRequest = true;
        var d = new Date();
        var n = d.getTimezoneOffset();
        $rootScope.rptTimeZoneGet = n;
        if ($rootScope.rptFiledName === null || $rootScope.rptFiledName === "" || $rootScope.rptFiledName === undefined) {
            $rootScope.rptFiledName = "ISBN13"
        }
        $rootScope.msg.showReportSuccessMsgExport = !0;
        $rootScope.msg.exportPlacedSucessmsg = "DOWNLOAD_EXPORT_SUCESS";
        setTimeout(function() {
            $rootScope.msg.showReportSuccessMsgExport = !1;
            $scope.$apply()
        }, $rootScope.alertTimeoutInterval)
        $http({
            method: 'POST',
            url: '/downloadCSVFile',
            data: {
                fieldDisplayName: $rootScope.rptFiledName,
                searchText: $rootScope.rptSerachKey,
                searchName: $rootScope.saveReportName,
                id: $rootScope.savesReportId,
                pageName: $rootScope.reportId,
                skipCount: 0,
                exportCheck: !0,
                exportType: $rootScope.exportType,
                timezone: $rootScope.rptTimeZoneGet,
                advancedSearch: {
                    columnFilterValues: $rootScope.RPTHeadSearchList,
                    accounts: $rootScope.selectedAccountsList,
                    imprints: $rootScope.rptImprintFilterList,
                    productCategories: $rootScope.selectedRPTProductCategoryArraySearch
                },
                columnFilterValues: $rootScope.rptColumnFilterValues,
                transDateFrom: $rootScope.rptFromDate,
                transDateTo: $rootScope.rptToDate,
            }
        }).then(function successCallback(response) {
            if (response.data.code == '200') {
                $rootScope.msg.showReportSuccessMsgExport = !1;
                $rootScope.msg.showCommonSuccessMsgExport = !0;
                $rootScope.msg.exportSucessmsg = "DOWNLOAD_EXPORT_SUCESS";
                $rootScope.getDownloadNotification();
                angular.element("#getDownloadNotification").addClass('open');
                angular.element(".download-up").addClass("flashit");
                setTimeout(function() {
                    $rootScope.msg.showCommonSuccessMsgExport = !1
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.msg.showCommonSuccessMsgExport = !1;
                $rootScope.msg.exportErromsg = !0;
                $rootScope.msg.exportErrorMsg = "Export request processed failed";
                setTimeout(function() {
                    $rootScope.msg.exportErromsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {})
    }
    $rootScope.RPTHeadSearchList = {};
    $rootScope.getRPTSearchSuggestions = function(fieldName) {
        var searchKey = angular.element($("#txtRPTSearch")).val();
        $rootScope.reportSearchKey = searchKey;
        $rootScope.rptSearchEnable = !0;
        $rootScope.RPTHeadSearchList = {};
        $rootScope.RPTHeadSearchList[fieldName] = searchKey;
        if ($rootScope.search.searchRPTValue.length < 1) {
            $rootScope.searchSuggestion = !0;
            $rootScope.search.globalSearchText = $rootScope.search.searchRPTValue;
            $rootScope.RptColumnserachText = "";
            $timeout(function() {
                var fieldNames = '';
                $rootScope.RptColumnserachText = "";
                if ($rootScope.rptRefreshSearch()) {
                    $scope.clearReport('')
                }
            }, 100)
        }
    }
    $rootScope.gridHeadersRPTResetFilter = function(fieldName, fieldType) {
        if (fieldName == 'Uploaded') {
            $rootScope.rptgHeadresAllSelect['Uploaded By'] = !1;
            angular.forEach(rptSearchColumnSuggestions['Uploaded By'], function(itm) {
                itm.selected = !1
            });
            delete $rootScope.rptInColFilterList['Uploaded By'];
            delete $rootScope.rptInColumnFilterList['Uploaded By'];
            delete $rootScope.RPTFromDateFilterList['Uploaded On'];
            delete $rootScope.RPTToDateFilterList['Uploaded On'];
            document.getElementById('Uploaded On' + "_From").value = "";
            document.getElementById('Uploaded On' + "_To").value = "";
            $rootScope.rptColumnFilterValues = $rootScope.rptInColumnFilterList
        } else {
            if (fieldType == 'date') {
                delete $rootScope.RPTFromDateFilterList[fieldName];
                $rootScope.RPTDateFilterList[fieldName] = $rootScope.RPTFromDateFilterList[fieldName]
                delete $rootScope.RPTToDateFilterList[fieldName];
                $rootScope.RPTDateFilterList[fieldName] = $rootScope.RPTToDateFilterList[fieldName];
                $rootScope.rptColumnFilterValues[fieldName] = $rootScope.RPTDateFilterList[fieldName];
                document.getElementById("filterFromDate_" + fieldName).value = "";
                document.getElementById("filterToDate_" + fieldName).value = "";
                $scope.dataDate.filterFromDate = "";
                $scope.dataDate.filterToDate = "";
                $scope.columnFromDateRPT = "";
                $scope.columnToDateRPT = "";
                $rootScope.rptColumnFilterValues[fieldName] = $rootScope.RPTDateFilterList[fieldName]
            } else if (fieldType == 'boolean') {
                delete $rootScope.rptInColFilterList[fieldName];
                delete $rootScope.rptInColumnFilterList[fieldName]
            } else {
                if (null != document.getElementById("reportISNBColumn_" + fieldName)) {
                    angular.element(document.getElementById("reportISNBColumn_" + fieldName).value = "")
                }
                $rootScope.rptgHeadresAllSelect[fieldName] = !1;
                angular.forEach($rootScope.rptSearchColumnSuggestions[fieldName], function(itm) {
                    itm.selected = !1
                });
                delete $rootScope.rptInColFilterList[fieldName];
                delete $rootScope.rptInColumnFilterList[fieldName];
                $rootScope.rptColumnFilterValues[fieldName] = $rootScope.rptInColumnFilterList[fieldName];
                $scope.reportColumnFilterSearch = {};
                $rootScope.rptLookUpSuggestions = {};
                angular.forEach($rootScope.rptSearchColumnSuggestions[fieldName], function(itm) {
                    itm.selected = !1
                });
                angular.forEach($rootScope.rptLookUpSuggestions[fieldName], function(itm) {
                    itm.selected = !1
                })
            }
        }
        Object.keys($rootScope.rptSearchColumnSuggestions).forEach(function(itm) {
            delete $rootScope.rptSearchColumnSuggestions[itm]
        });
        $rootScope.RptColumnserachText = '';
        $rootScope.rptSearchEnable = !0;
        if ($rootScope.rptRefreshSearch()) {
            $scope.reportCommonFilter(fieldName, $rootScope.RptColumnserachText)
        }
    }
    $rootScope.filterRPTApplied = function(fieldName, fieldType) {
        var flag = !1;
        if (fieldName == 'Uploaded') {
            if ($rootScope.rptInColFilterList != undefined && $rootScope.rptInColFilterList != null && Object.keys($rootScope.rptInColFilterList).length != 0) {
                if ($rootScope.rptInColFilterList['Uploaded By'] != null && $rootScope.rptInColFilterList['Uploaded By'] != undefined && Object.keys($rootScope.rptInColFilterList['Uploaded By']).length != 0)
                    flag = !0
            }
            if (!flag && ("Uploaded On" in $rootScope.RPTFromDateFilterList || "Uploaded On" in $rootScope.RPTToDateFilterList))
                flag = !0
        } else {
            if (fieldType == 'date') {
                if (!flag && (fieldName in $rootScope.RPTFromDateFilterList || fieldName in $rootScope.RPTToDateFilterList))
                    flag = !0
            } else {
                if ($rootScope.rptInColFilterList != undefined && $rootScope.rptInColFilterList != null && Object.keys($rootScope.rptInColFilterList).length != 0) {
                    if ($rootScope.rptInColFilterList[fieldName] != null && $rootScope.rptInColFilterList[fieldName] != undefined && Object.keys($rootScope.rptInColFilterList[fieldName]).length != 0)
                        flag = !0
                }
            }
        }
        return flag
    }
    $scope.pinDashBoardRPTName = function() {
        $http({
            method: 'POST',
            url: '/reportPinToDashBoard',
            data: {
                id: $rootScope.savesReportId
            }
        }).then(function successCallback(response) {
            if (response.data.code == '200') {
                $rootScope.showRPTPinDBSuccessMsg = !0;
                $rootScope.RPTPinDBSuccessMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTPinDBSuccessMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $rootScope.showRPTPinDBErrorMsg = !0;
                $rootScope.RPTPinDBErrorMsg = response.data.statusMessage;
                setTimeout(function() {
                    $rootScope.showRPTPinDBErrorMsg = !1;
                    $rootScope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {})
    }
    $scope.waterMarkShow = function() {
        $scope.watermarkContent = !0
    }
    $scope.watermarkClose = function() {
        $scope.watermarkContent = !1
    }
    $scope.showSuccessMsg = !1;
    $scope.extractBtnDisable = !0;
    $scope.showresultDetails = !1;
    $scope.uploadWatermarkfile = function($flow) {
        $scope.extractBtnDisable = !1;
        $scope.currentFileName = "";
        $scope.currentFileName = $flow.files[0].file.name;
        $scope.watermarkFile = $flow
    }
    $scope.extractWatermarkfile = function() {
        $scope.showresultDetails = !0;
        $scope.showLoader($('.watermark-file-details'), 1, 'win8_linear');
        var fd = new FormData();
        fd.append('file', $scope.watermarkFile.files[0].file);
        $http.post('/extractWatermark', fd, {
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        }).success(function(res) {
            $scope.showSuccessMsg = !0;
            setTimeout(function() {
                $scope.showSuccessMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
            $scope.watermarkMsg = res.statusMessage;
            $scope.watermarkDetails = res.data;
            $scope.hideLoader('watermark-file-details')
        }).error(function(x) {
            alert("error")
        })
    }
    if ($location.$$url == '/report') {
        if ($rootScope.reportPageClick != 'click') {
            angular.element("#report-submenu").click();
            $rootScope.rptReloadId = JSON.parse(localStorage.getItem('reportId'));
            if ($rootScope.rptReloadId.id == null) {
                $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
                $rootScope.loadAssetSummaryReports({
                    "reportId": $rootScope.rptReloadId.reportId,
                    "reportName": $rootScope.rptReloadId.reportName,
                    "isCursorFlag": !1,
                    "$$hashKey": "object:414"
                });
                $timeout(function() {
                    var id = $rootScope.rptReloadId.reportId;
                    var element = document.getElementById(id);
                    element.classList.add("active")
                }, 2000)
            } else {
                $rootScope.showLoader($('.report-grid'), 1, 'win8_linear');
                $rootScope.loadSavedReports($rootScope.rptReloadId);
                $timeout(function() {
                    var id = $rootScope.rptReloadId.searchName;
                    var element = document.getElementById('searchname_' + id);
                    element.classList.add("active")
                }, 2000)
            }
        } else {
            return !1
        }
    }
    
}])