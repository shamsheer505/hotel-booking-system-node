'use strict';
app.controller('UserMasterController', ['$scope', '$http', '$rootScope', '$filter', '$timeout', function($scope, $http, $rootScope, $filter, $timeout) {
    $rootScope.testScroll();
    $scope.showSuccessActivateMsg = !1;
    $scope.showErrorActivateMsg = !1;
    $scope.showSuccessDeactivateMsg = !1;
    $scope.showErrorDeactivateMsg = !1;
    $scope.showSuccessDeleteMsg = !1;
    $scope.showErrorDeleteMsg = !1;
    $scope.showCreateButton = !0;
    $scope.showEditButton = !1;
    $scope.showSuccessCreateMsg = !1;
    $scope.showErrorCreateMsg = !1;
    $scope.showSuccessEditMsg = !1;
    $scope.showErrorEditMsg = !1;
    $scope.disableEmail = !1;
    $scope.loggedUser;
    $scope.editUser = {};
    $scope.editUserId;
    $scope.newUserEmailId;
    $scope.newUserRole;
    $scope.newUserPermissionGroup;
    $scope.newUserRoleName = 'Select';
    $scope.newUserOtherAccounts = [];
    $scope.newUserAccountNames = [];
    $scope.newUserMetadataTypeNames = [];
    $scope.newUserOtherImprints = [];
    $scope.newUserImprintNames = [];
    $scope.newUserProductCategoryNames = [];
    $scope.newUserMetadataGroupNames = [];
    $scope.newUserPartnerTypeNames = [];
    $scope.newUserApplicationNames = [];
    $scope.newUserModuleNames = [];
    $scope.newUserReportNames = [];
    $scope.newUserAdminAccessNames = [];
    $scope.newUserActivityNames = [];
    $scope.vfAllSelected = !1;
    $scope.ufAllSelected = !1;
    $scope.dfAllSelected = !1;
    $scope.sfAllSelected = !1;
    $scope.dtfAllSelected = !1;
    $scope.assetModuleAccess = !1;
    $scope.reportModuleAccess = !1;
    $scope.roleReportList = [];
    $scope.userForm = {};
    $scope.userForm.pgFlg = 'NEW';
    $scope.userForm.newUserPermissionGroupName = null;
    $scope.userRolePgList = [];
    $scope.localProductCategoryList = [];
    $scope.loggedUserAccountList = [];
    $scope.userOrder = {
        field: 'firstName',
        reverse: !1
    };
    $scope.setUserOrder = function(orderByField, event) {
        if (!$(event.target).hasClass('cp-reset') && !$(event.target).parents().hasClass('multi-dropdown')) {
            if (orderByField === $scope.userOrder.field)
                $scope.userOrder.reverse = !$scope.userOrder.reverse;
            else $scope.userOrder.field = orderByField
        }
    }
    $scope.dynamicUserOrder = function(user) {
        var order = "";
        if ($scope.userOrder.field === "onlineStatus")
            order = user[$scope.userOrder.field] == null || user[$scope.userOrder.field] == undefined ? '~' : (Number(user[$scope.userOrder.field]) + 8).toString().split('').reverse().join('');
        else if ($scope.userOrder.field === "permissionGroup.permissionGroupName")
            order = user.permissionGroup.permissionGroupName == null || user.permissionGroup.permissionGroupName == undefined ? '~' : user.permissionGroup.permissionGroupName;
        else if ($scope.userOrder.field === "roleId") {
            var role = $filter('filter')($rootScope.roleList, function(data) {
                return (data.roleId == user.permissionGroup.roleId)
            })[0];
            order = role.roleName
        } else order = user[$scope.userOrder.field] == null || user[$scope.userOrder.field] == undefined ? '~' : user[$scope.userOrder.field];
        return order
    }
    setTimeout(function() {
        $scope.viewFormatListUser = angular.copy($rootScope.viewFormatList);
        $scope.uploadFormatListUser = [];
        $scope.downloadFormatListUser = [];
        $scope.shareFormatListUser = [];
        $scope.deleteFormatListUser = []
    }, 50);
    $scope.setAccountSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#accountSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setRoleSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#roleSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.setPgSrchTermFocus = function() {
        setTimeout(function() {
            angular.element('#pgSrchTerm').trigger('focus')
        }, 10)
    }
    $scope.getNestedChildren = function(arr, parent) {
        var out = [];
        for (var i in arr) {
            if (arr[i].parentId == parent) {
                var children = $scope.getNestedChildren(arr, arr[i].productCategoryId)
                if (children.length) {
                    arr[i].children = children
                }
                out.push(arr[i])
            }
        }
        return out
    }
    $scope.traverseTree = function(arr, operation) {
        for (var i = 0, l = arr.length; i < l; i++) {
            var current = arr[i];
            if (operation == "GETSELECTED") {
                if (current.selected)
                    $scope.selectedProductCategoryArray.push(current.productCategoryId)
            } else if (operation == "UNSELECT") {
                current.selected = !1;
                var index = $scope.newUserProductCategoryNames.indexOf(current.productCategoryName);
                $scope.newUserProductCategoryNames.splice(index, 1)
            } else if (operation == "SELECT") {
                current.selected = !0;
                $scope.newUserProductCategoryNames.push(current.productCategoryName)
            } else if (operation == "POPULATEFOREDIT") {
                if ($scope.editUser.permissionGroup.productCategory.indexOf(current.productCategoryId) > -1) {
                    current.selected = !0;
                    $scope.newUserProductCategoryNames.push(current.productCategoryName)
                }
            } else if (operation == "POPULATESELECTED") {
                if ($scope.selectedProductCategoryArray.indexOf(current.productCategoryId) > -1) {
                    current.selected = !0;
                    $scope.newUserProductCategoryNames.push(current.productCategoryName)
                }
            }
            if (current.children && current.children.length > 0) {
                $scope.traverseTree(current.children, operation)
            }
        }
    }
    $scope.getSelectedProductCategories = function() {
        $scope.selectedProductCategoryArray = [];
        $scope.traverseTree($scope.productCategoryTreeUser, "GETSELECTED")
    };
    $scope.toggleProductCategoryChildren = function(data) {
        if (!data.selected) {
            var index = $scope.newUserProductCategoryNames.indexOf(data.productCategoryName);
            $scope.newUserProductCategoryNames.splice(index, 1);
            if (data.children && data.children.length > 0) {
                $scope.traverseTree(data.children, "UNSELECT")
            }
        } else {
            $scope.newUserProductCategoryNames.push(data.productCategoryName);
            if (data.children && data.children.length > 0) {
                $scope.traverseTree(data.children, "SELECT")
            }
        }
        $scope.pcAllSelected = $scope.newUserProductCategoryNames.length == $scope.localProductCategoryList.length
    };
    $scope.userFilter = function(user) {
        var result = !1;
        $.each($scope.loggedUserAccountList, function(index, ac) {
            if (user.permissionGroup.account.indexOf(ac.accountId) > -1) {
                result = !0;
                return
            }
        });
        return result
    }
    $scope.hideSuccessActivateMsg = function() {
        $scope.showSuccessActivateMsg = !1
    }
    $scope.hideErrorActivateMsg = function() {
        $scope.showErrorActivateMsg = !1
    }
    $scope.hideSuccessDeactivateMsg = function() {
        $scope.showSuccessDeactivateMsg = !1
    }
    $scope.hideErrorDeactivateMsg = function() {
        $scope.showErrorDeactivateMsg = !1
    }
    $scope.hideSuccessDeleteMsg = function() {
        $scope.showSuccessDeleteMsg = !1
    }
    $scope.hideErrorDeleteMsg = function() {
        $scope.showErrorDeleteMsg = !1
    }
    $scope.hideSuccessResendMsg = function() {
        $scope.showSuccessResendMail = !1
    }
    $scope.hideErrorActivateMsg = function() {
        $scope.showErrorResendMail = !1
    }
    $scope.userRoleFilter = function(roleId) {
        return function(role) {
            return role.roleId == roleId
        }
    }
    $scope.closeUserDelete = function() {
        $rootScope.disableBtnClick();
        $scope.userDelete = null;
        $('#user-delete').modal('toggle');
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    $scope.closeUserUnlock = function() {
        $rootScope.disableBtnClick();
        $scope.userUnlock = null;
        $('#user-unlock').modal('toggle');
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    $scope.closeUserDeactivateModal = function() {
        $rootScope.disableBtnClick();
        $('#user-deactivate').modal('toggle');
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    $scope.closeUserCreateModal = function() {
        $rootScope.disableBtnClick();
        $('#new-user-creation').modal('toggle');
        $scope.clearNewUser()
    }
    $('#new-user-creation').on('shown.bs.modal', function() {
        if ($scope.disableEmail)
            $('#new-user-creation').find('#roleSpan').focus();
        else $('#new-user-creation').find('input:first').focus()
    });
    $('#new-user-creation').find('button:first').on('keydown', function(e) {
        if ($("this:focus") && (e.which == 9)) {
            e.preventDefault();
            if ($scope.disableEmail)
                $('#new-user-creation').find('#roleSpan').focus();
            else $('#new-user-creation').find('input:first').focus()
        }
    });
    $scope.resetPg = function() {
        if ($scope.editUser != undefined)
            $scope.editUser.permissionGroup = null;
        $scope.userForm.newUserPermissionGroupName = null;
        $scope.userForm.showDuplicatePgNameErrorMsg = !1;
        $scope.pgSearch = "";
        $scope.accountSearch = "";
        $scope.metadataTypeSearch = "";
        $scope.imprintSearch = "";
        $scope.productCatSearch = "";
        $scope.mgSearch = "";
        $scope.ptSearch = "";
        $scope.appSearch = "";
        $scope.modSearch = "";
        $scope.actSearch = "";
        $scope.viewFormatListUser = angular.copy($rootScope.viewFormatList);
        $scope.uploadFormatListUser = [];
        $scope.downloadFormatListUser = [];
        $scope.shareFormatListUser = [];
        $scope.deleteFormatListUser = [];
        $scope.newUserAccountNames = [];
        $scope.newUserImprintNames = [];
        $scope.newUserMetadataTypeNames = [];
        $scope.newUserProductCategoryNames = [];
        $scope.newUserMetadataGroupNames = [];
        $scope.newUserPartnerTypeNames = [];
        $scope.newUserApplicationNames = [];
        $scope.newUserReportNames = [];
        $scope.newUserAdminAccessNames = [];
        $scope.newUserActivityNames = [];
        $scope.newUserOtherAccounts = [];
        $scope.productCategoryTreeUser = [];
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.metadataTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.cmetadataGroupList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.partnerTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.applicationList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.roleReportList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.accessList, function(itm) {
            itm.selected = !1
        });
        $scope.imprintList = [];
        $scope.imprintAllSelected = !1;
        $scope.setCheckAllCheckBoxes()
    }
    $scope.clearNewUser = function() {
        $scope.editUser = {};
        $scope.createUserLoading = !1;
        $scope.userForm.pgFlg = 'NEW';
        $scope.showCreateButton = !0;
        $scope.showEditButton = !1;
        $scope.showDuplicateUserErrorMsg = !1;
        $scope.userForm.showDuplicatePgNameErrorMsg = !1;
        $scope.newUserEmailId = null;
        $scope.newUserRole = null;
        $scope.userForm.newUserPermissionGroupName = null;
        $scope.userRolePgList = [];
        $scope.roleSearch = "";
        $scope.pgSearch = "";
        $scope.accountSearch = "";
        $scope.metadataTypeSearch = "";
        $scope.imprintSearch = "";
        $scope.productCatSearch = "";
        $scope.mgSearch = "";
        $scope.ptSearch = "";
        $scope.appSearch = "";
        $scope.modSearch = "";
        $scope.actSearch = "";
        $scope.newUserRoleName = 'Select';
        $scope.viewFormatListUser = angular.copy($rootScope.viewFormatList);
        $scope.uploadFormatListUser = [];
        $scope.downloadFormatListUser = [];
        $scope.shareFormatListUser = [];
        $scope.deleteFormatListUser = [];
        $scope.newUserAccountNames = [];
        $scope.newUserImprintNames = [];
        $scope.newUserMetadataTypeNames = [];
        $scope.newUserProductCategoryNames = [];
        $scope.newUserMetadataGroupNames = [];
        $scope.newUserPartnerTypeNames = [];
        $scope.newUserApplicationNames = [];
        $scope.newUserModuleNames = [];
        $scope.newUserReportNames = [];
        $scope.newUserAdminAccessNames = [];
        $scope.newUserActivityNames = [];
        $scope.assetModuleAccess = !1;
        $scope.reportModuleAccess = !1;
        $scope.newUserOtherAccounts = [];
        $scope.refreshAccessLists();
        $scope.CreateUserModalForm.$setPristine();
        $scope.CreateUserModalForm.$setUntouched()
    };
    $scope.refreshAccessLists = function() {
        angular.element(".modal-create-user-left-top").css("display", "block");
        angular.element(".modal-create-user-left-top1").css("display", "none");
        $scope.disableEmail = !1;
        $scope.productCategoryTreeUser = [];
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.metadataTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.cmetadataGroupList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.partnerTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.applicationList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.moduleList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.roleReportList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.accessList, function(itm) {
            itm.selected = !1
        });
        $scope.imprintList = [];
        $scope.imprintAllSelected = !1;
        $scope.setCheckAllCheckBoxes()
    }
    $scope.populateUserForEdit = function(user) {
        $scope.clearNewUser();
        $scope.userForm.pgFlg = 'EXISTING';
        $scope.editUser = angular.copy(user);
        $scope.showCreateButton = !1;
        $scope.showEditButton = !0;
        $scope.roleSearch = "";
        $scope.pgSearch = "";
        $scope.accountSearch = "";
        $scope.metadataTypeSearch = "";
        $scope.imprintSearch = "";
        $scope.productCatSearch = "";
        $scope.mgSearch = "";
        $scope.ptSearch = "";
        $scope.appSearch = "";
        $scope.modSearch = "";
        $scope.actSearch = "";
        if ($scope.editUser.isRegistered == !0) {
            $scope.disableEmail = !0;
            $('#new-user-creation').find('#roleSpan').focus()
        } else $scope.disableEmail = !1;
        $scope.editUserId = $scope.editUser.userId;
        $scope.newUserEmailId = $scope.editUser.emailId;
        $scope.setNewUserRoleForEdit($filter('filter')($scope.userRoleList, function(data) {
            return (data.roleId == $scope.editUser.permissionGroup.roleId)
        })[0]);
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.account, function(accountId) {
            var otherAccountFlg = !0;
            angular.forEach($scope.loggedUserAccountList, function(account) {
                if (account.accountId == accountId) {
                    account.selected = !0;
                    otherAccountFlg = !1
                }
            });
            if (otherAccountFlg)
                $scope.newUserOtherAccounts.push(accountId)
        });
        $scope.retrieveImprintList();
        angular.forEach($scope.metadataTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.metadataType, function(mdtId) {
            angular.forEach($scope.metadataTypeList, function(metadataType) {
                if (metadataType.metadataTypeId == mdtId) {
                    metadataType.selected = !0
                }
            })
        });
        $scope.showProductCategoriesForSelection("POPULATEFOREDIT");
        angular.forEach($scope.cmetadataGroupList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.metadataGroup, function(mgId) {
            angular.forEach($scope.cmetadataGroupList, function(mg) {
                if (mg.groupNameId == mgId)
                    mg.selected = !0
            })
        });
        angular.forEach($scope.partnerTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.partnerType, function(ptId) {
            angular.forEach($scope.partnerTypeList, function(pt) {
                if (pt.partnerTypeId == ptId)
                    pt.selected = !0
            })
        });
        angular.forEach($scope.applicationList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.application, function(appId) {
            angular.forEach($scope.applicationList, function(app) {
                if (app.applicationId == appId)
                    app.selected = !0
            })
        });
        if ($scope.assetModuleAccess) {
            angular.forEach($scope.editUser.permissionGroup.asset, function(asset) {
                if (asset.permission == "VIEW" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'VIEW')) {
                    angular.forEach($scope.viewFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.viewFormatListUser, function(format) {
                            if (format.formatId == formatId) {
                                format.selected = !0;
                                var fm = angular.copy(format);
                                fm.selected = !1;
                                if ($rootScope.loggedUserUploadFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.uploadFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserDownloadFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.downloadFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserShareFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.shareFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserDeleteFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.deleteFormatListUser.push(angular.copy(fm))
                                }
                            }
                        })
                    })
                } else if (asset.permission == "UPLOAD" && ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'MANUAL_UPLOAD') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULK_UPLOAD'))) {
                    angular.forEach($scope.uploadFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.uploadFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "DOWNLOAD" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD')) {
                    angular.forEach($scope.downloadFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.downloadFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "SHARE" && ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD_SHARE') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULKUPLOAD_SHARE'))) {
                    angular.forEach($scope.shareFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.shareFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "DELETE" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DELETE')) {
                    angular.forEach($scope.deleteFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.deleteFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                }
            })
        }
        if ($scope.reportModuleAccess) {
            angular.forEach($scope.roleReportList, function(itm) {
                itm.selected = !1
            });
            angular.forEach($scope.editUser.permissionGroup.report, function(reportId) {
                angular.forEach($scope.roleReportList, function(report) {
                    if (report.reportId == reportId)
                        report.selected = !0
                })
            })
        }
        angular.forEach($scope.accessList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.administrator, function(accessId) {
            angular.forEach($scope.accessList, function(access) {
                if (access.accessId == accessId)
                    access.selected = !0
            })
        });
        $scope.setSelectTexts();
        $scope.setCheckAllCheckBoxes();
        angular.element(".modal-create-user-left-top").css("display", "none");
        angular.element(".modal-create-user-left-top1").css("display", "block")
    }
    $scope.setSelectTexts = function() {
        $scope.newUserAccountNames = [];
        angular.forEach($scope.loggedUserAccountList, function(account) {
            if (account.selected == !0) {
                $scope.newUserAccountNames.push(account.accountName)
            }
        });
        $scope.newUserMetadataTypeNames = [];
        angular.forEach($scope.metadataTypeList, function(mdt) {
            if (mdt.selected == !0) {
                $scope.newUserMetadataTypeNames.push(mdt.metadataTypeName)
            }
        });
        $scope.newUserMetadataGroupNames = [];
        angular.forEach($scope.cmetadataGroupList, function(mg) {
            if (mg.selected == !0) {
                $scope.newUserMetadataGroupNames.push(mg.groupName)
            }
        });
        $scope.newUserPartnerTypeNames = [];
        angular.forEach($scope.partnerTypeList, function(pt) {
            if (pt.selected == !0) {
                $scope.newUserPartnerTypeNames.push(pt.partnerTypeName)
            }
        });
        $scope.newUserApplicationNames = [];
        angular.forEach($scope.applicationList, function(app) {
            if (app.selected == !0) {
                $scope.newUserApplicationNames.push(app.applicationName)
            }
        });
        $scope.newUserReportNames = [];
        angular.forEach($scope.roleReportList, function(report) {
            if (report.selected == !0) {
                $scope.newUserReportNames.push(report.reportName)
            }
        });
        $scope.newUserAdminAccessNames = [];
        angular.forEach($scope.accessList, function(access) {
            if (access.selected == !0) {
                $scope.newUserAdminAccessNames.push(access.accessName)
            }
        })
    };
    $scope.setCheckAllCheckBoxes = function() {
        if ($scope.loggedUserAccountList != undefined && $scope.loggedUserAccountList != null)
            $scope.acntAllSelected = $scope.loggedUserAccountList.every(function(itm) {
                return itm.selected
            });
        $scope.mdtAllSelected = $scope.metadataTypeList.every(function(itm) {
            return itm.selected
        });
        $scope.pcAllSelected = $scope.editUser == undefined ? !1 : $scope.newUserProductCategoryNames.length == $scope.localProductCategoryList.length;
        $scope.mgAllSelected = $scope.cmetadataGroupList.every(function(itm) {
            return itm.selected
        });
        $scope.ptAllSelected = $scope.partnerTypeList.every(function(itm) {
            return itm.selected
        });
        $scope.appAllSelected = $scope.applicationList.every(function(itm) {
            return itm.selected
        });
        $scope.modAllSelected = $scope.moduleList.every(function(itm) {
            return itm.selected
        });
        $scope.reportAllSelected = $scope.roleReportList.every(function(itm) {
            return itm.selected
        });
        $scope.accessAllSelected = $scope.accessList.every(function(itm) {
            return itm.selected
        });
        $scope.vfAllSelected = $scope.viewFormatListUser.every(function(itm) {
            return itm.selected
        });
        $scope.ufAllSelected = $scope.uploadFormatListUser.every(function(itm) {
            return itm.selected
        });
        $scope.dfAllSelected = $scope.downloadFormatListUser.every(function(itm) {
            return itm.selected
        });
        $scope.sfAllSelected = $scope.shareFormatListUser.every(function(itm) {
            return itm.selected
        });
        $scope.dtfAllSelected = $scope.deleteFormatListUser.every(function(itm) {
            return itm.selected
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.passDataToDeleteModal = function(user) {
        $scope.userDelete = user
    }
    $scope.passDataToActDeactModal = function(user) {
        $scope.userActDeact = user
    }
    $scope.passDataToUnlockModal = function(user) {
        $scope.userUnlock = user
    }
    $scope.setNewUserPg = function(pg) {
        $scope.editUser.permissionGroup = pg;
        $scope.accountSearch = "";
        $scope.metadataTypeSearch = "";
        $scope.imprintSearch = "";
        $scope.productCatSearch = "";
        $scope.mgSearch = "";
        $scope.ptSearch = "";
        $scope.appSearch = "";
        $scope.modSearch = "";
        $scope.actSearch = "";
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.account, function(accountId) {
            var otherAccountFlg = !0;
            angular.forEach($scope.loggedUserAccountList, function(account) {
                if (account.accountId == accountId) {
                    account.selected = !0;
                    otherAccountFlg = !1
                }
            });
            if (otherAccountFlg)
                $scope.newUserOtherAccounts.push(accountId)
        });
        $scope.retrieveImprintList();
        angular.forEach($scope.metadataTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.metadataType, function(mdtId) {
            angular.forEach($scope.metadataTypeList, function(metadataType) {
                if (metadataType.metadataTypeId == mdtId) {
                    metadataType.selected = !0
                }
            })
        });
        $scope.showProductCategoriesForSelection("POPULATEFOREDIT");
        angular.forEach($scope.cmetadataGroupList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.metadataGroup, function(mgId) {
            angular.forEach($scope.cmetadataGroupList, function(mg) {
                if (mg.groupNameId == mgId)
                    mg.selected = !0
            })
        });
        angular.forEach($scope.partnerTypeList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.partnerType, function(ptId) {
            angular.forEach($scope.partnerTypeList, function(pt) {
                if (pt.partnerTypeId == ptId)
                    pt.selected = !0
            })
        });
        angular.forEach($scope.applicationList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.application, function(appId) {
            angular.forEach($scope.applicationList, function(app) {
                if (app.applicationId == appId)
                    app.selected = !0
            })
        });
        if ($scope.assetModuleAccess) {
            angular.forEach($scope.editUser.permissionGroup.asset, function(asset) {
                if (asset.permission == "VIEW" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'VIEW')) {
                    angular.forEach($scope.viewFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.viewFormatListUser, function(format) {
                            if (format.formatId == formatId) {
                                format.selected = !0;
                                var fm = angular.copy(format);
                                fm.selected = !1;
                                if ($rootScope.loggedUserUploadFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.uploadFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserDownloadFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.downloadFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserShareFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.shareFormatListUser.push(angular.copy(fm))
                                }
                                if ($rootScope.loggedUserDeleteFormatIdList.indexOf(format.formatId) > -1) {
                                    $scope.deleteFormatListUser.push(angular.copy(fm))
                                }
                            }
                        })
                    })
                } else if (asset.permission == "UPLOAD" && ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'MANUAL_UPLOAD') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULK_UPLOAD'))) {
                    angular.forEach($scope.uploadFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.uploadFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "DOWNLOAD" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD')) {
                    angular.forEach($scope.downloadFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.downloadFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "SHARE" && ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD_SHARE') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULKUPLOAD_SHARE'))) {
                    angular.forEach($scope.shareFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.shareFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                } else if (asset.permission == "DELETE" && $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DELETE')) {
                    angular.forEach($scope.deleteFormatListUser, function(itm) {
                        itm.selected = !1
                    });
                    angular.forEach(asset.format, function(formatId) {
                        angular.forEach($scope.deleteFormatListUser, function(format) {
                            if (format.formatId == formatId)
                                format.selected = !0
                        })
                    })
                }
            })
        }
        if ($scope.reportModuleAccess) {
            angular.forEach($scope.roleReportList, function(itm) {
                itm.selected = !1
            });
            angular.forEach($scope.editUser.permissionGroup.report, function(reportId) {
                angular.forEach($scope.roleReportList, function(report) {
                    if (report.reportId == reportId)
                        report.selected = !0
                })
            })
        }
        angular.forEach($scope.accessList, function(itm) {
            itm.selected = !1
        });
        angular.forEach($scope.editUser.permissionGroup.administrator, function(accessId) {
            angular.forEach($scope.accessList, function(access) {
                if (access.accessId == accessId)
                    access.selected = !0
            })
        });
        $scope.setSelectTexts();
        $scope.setCheckAllCheckBoxes()
    }
    $scope.setNewUserRole = function(role) {
        $scope.newUserRole = role;
        $scope.newUserRoleName = role.roleName;
        $scope.assetModuleAccess = !1;
        $scope.reportModuleAccess = !1;
        var arr = $scope.newUserRole.module;
        var roleModules = [];
        $scope.newUserModuleNames = [];
        $scope.userRolePgList = $filter('filter')($rootScope.permisssionGroupList, function(data) {
            return (data.roleId == role.roleId)
        });
        if ($scope.userForm.pgFlg == 'EXISTING')
            $scope.resetPg();
        angular.forEach(arr, function(mod) {
            roleModules.push(mod.moduleId);
            if (mod.moduleId == "MOD00004") {
                var reportListModule = $filter('filter')(mod.submodule, function(subMod) {
                    return (subMod.accessId == "REPORT_LIST")
                });
                if (reportListModule.length > 0) {
                    var reportList = angular.copy($rootScope.reportList);
                    $scope.roleReportList = $filter('filter')(reportList, function(report) {
                        if (reportListModule[0].activityAccess.indexOf(report.reportId) > -1)
                            return !0
                    })
                }
            }
        });
        angular.forEach($scope.moduleList, function(itm) {
            itm.selected = !1
        });
        angular.forEach(roleModules, function(moduleId) {
            if (moduleId == "MOD00002")
                $scope.assetModuleAccess = !0;
            else if (moduleId == "MOD00004") {
                $scope.reportModuleAccess = !0
            }
            angular.forEach($scope.moduleList, function(mod) {
                if (mod.moduleId == moduleId) {
                    mod.selected = !0;
                    $scope.newUserModuleNames.push(mod.moduleName)
                }
            })
        });
        $scope.uploadFormatListUser = [];
        $scope.downloadFormatListUser = [];
        $scope.shareFormatListUser = [];
        $scope.deleteFormatListUser = [];
        $scope.assetAllSelected = !1;
        $scope.toggleAllAssets();
        $scope.reportAllSelected = !1;
        $scope.toggleAllReports()
    }
    $scope.setNewUserRoleForEdit = function(role) {
        $scope.newUserRole = role;
        $scope.newUserRoleName = role.roleName;
        $scope.assetModuleAccess = !1;
        $scope.reportModuleAccess = !1;
        var arr = $scope.newUserRole.module;
        var roleModules = [];
        $scope.newUserModuleNames = [];
        $scope.userRolePgList = $filter('filter')($rootScope.permisssionGroupList, function(data) {
            return (data.roleId == role.roleId)
        });
        angular.forEach(arr, function(mod) {
            roleModules.push(mod.moduleId);
            if (mod.moduleId == "MOD00004") {
                var reportListModule = $filter('filter')(mod.submodule, function(subMod) {
                    return (subMod.accessId == "REPORT_LIST")
                });
                if (reportListModule.length > 0) {
                    var reportList = angular.copy($rootScope.reportList);
                    $scope.roleReportList = $filter('filter')(reportList, function(report) {
                        if (reportListModule[0].activityAccess.indexOf(report.reportId) > -1)
                            return !0
                    })
                }
            }
        });
        angular.forEach($scope.moduleList, function(itm) {
            itm.selected = !1
        });
        angular.forEach(roleModules, function(moduleId) {
            if (moduleId == "MOD00002")
                $scope.assetModuleAccess = !0;
            else if (moduleId == "MOD00004") {
                $scope.reportModuleAccess = !0
            }
            angular.forEach($scope.moduleList, function(mod) {
                if (mod.moduleId == moduleId) {
                    mod.selected = !0;
                    $scope.newUserModuleNames.push(mod.moduleName)
                }
            })
        });
        $scope.uploadFormatListUser = [];
        $scope.downloadFormatListUser = [];
        $scope.shareFormatListUser = [];
        $scope.deleteFormatListUser = [];
        $scope.assetAllSelected = !1;
        $scope.toggleAllAssets();
        $scope.reportAllSelected = !1;
        $scope.toggleAllReports()
    }
    $scope.getUsers = function() {
        $rootScope.showLoader($('.app-content'), 1, 'win8_linear');
        $http({
            method: 'GET',
            url: '/getUsers/' + $scope.skipCountForUserRow,
        }).then(function successCallback(response) {
            $scope.userList = response.data.data;
            $scope.userListCount = response.data.count;
            $scope.skipCountForUserRow = $scope.userList.length;
            $rootScope.hideLoader('app-content');
            $timeout(function() {
                angular.element(".index-table .divTableBody").trigger('scroll');
                angular.element("#assetdivTableBody").scrollTop(5)
            }, 100)
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    };
    $scope.skipCountForUserRow = 0;
    $scope.getUsersWithoutLoader = function() {
        $http({
            method: 'GET',
            url: '/getUsers'
        }).then(function successCallback(response) {
            $scope.userList = response.data.data
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    };
    $scope.deleteUser = function() {
        $rootScope.disableBtnClick();
        $http({
            method: 'POST',
            url: '/deleteUser/' + $scope.userDelete.userId,
        }).then(function successCallback(response) {
            $scope.closeUserDelete();
            if (response.data.code == '204' || response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.unlockUser = function() {
        $http({
            method: 'POST',
            url: '/unlockUser/' + $scope.userUnlock.userId,
        }).then(function successCallback(response) {
            $scope.closeUserUnlock();
            if (response.data.code == '204' || response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.activateDeactivateUser = function() {
        $rootScope.disableBtnClick();
        var actVal;
        if ($scope.userActDeact.isActive == !0)
            actVal = 1;
        else actVal = 0;
        $http({
            method: 'POST',
            url: '/activate/' + actVal + '/' + $scope.userActDeact.userId
        }).then(function successCallback(response) {
            $scope.closeUserDeactivateModal();
            if (response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.resendInvitationMail = function(user, i) {
        $scope['resendMailLoading_' + i] = !0;
        $http({
            method: 'POST',
            url: '/resendmail/' + user.userId,
            data: {
                userId: user.userId
            }
        }).then(function successCallback(response) {
            $scope['resendMailLoading_' + i] = !1;
            if (response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $scope.skipCountForUserRow = 0;
            $scope.getFilteredUsers(!1)
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.createPermissionGroup = function() {
        $scope.createUserLoading = !0;
        if ($scope.userForm.pgFlg == "NEW") {
            var accountArray = [];
            var metadataTypeArray = [];
            var imprintArray = [];
            var metadataGroupArray = [];
            var partnerTypeArray = [];
            var applicationArray = [];
            var reportArray = null;
            var adminAccessArray = [];
            var viewFormatArray = [];
            var uploadFormatArray = [];
            var downloadFormatArray = [];
            var shareFormatArray = [];
            var deleteFormatArray = [];
            var assetAccess = null;
            angular.forEach($scope.loggedUserAccountList, function(itm) {
                if (itm.selected == !0) {
                    accountArray.push(itm.accountId)
                }
            });
            angular.forEach($scope.metadataTypeList, function(itm) {
                if (itm.selected == !0) {
                    metadataTypeArray.push(itm.metadataTypeId)
                }
            });
            angular.forEach($scope.imprintList, function(itm) {
                if (itm.selected == !0) {
                    imprintArray.push(itm.imprintName)
                }
            });
            $scope.getSelectedProductCategories();
            angular.forEach($scope.cmetadataGroupList, function(itm) {
                if (itm.selected == !0) {
                    metadataGroupArray.push(itm.groupNameId)
                }
            });
            angular.forEach($scope.partnerTypeList, function(itm) {
                if (itm.selected == !0) {
                    partnerTypeArray.push(itm.partnerTypeId)
                }
            });
            angular.forEach($scope.applicationList, function(itm) {
                if (itm.selected == !0) {
                    applicationArray.push(itm.applicationId)
                }
            });
            if ($scope.reportModuleAccess) {
                reportArray = [];
                angular.forEach($scope.roleReportList, function(itm) {
                    if (itm.selected == !0) {
                        reportArray.push(itm.reportId)
                    }
                })
            }
            angular.forEach($scope.accessList, function(itm) {
                if (itm.selected == !0) {
                    adminAccessArray.push(itm.accessId)
                }
            });
            if ($scope.assetModuleAccess) {
                assetAccess = [];
                angular.forEach($scope.viewFormatListUser, function(itm) {
                    if (itm.selected == !0) {
                        viewFormatArray.push(itm.formatId)
                    }
                });
                assetAccess.push({
                    permission: "VIEW",
                    format: viewFormatArray
                });
                angular.forEach($scope.uploadFormatListUser, function(itm) {
                    if (itm.selected == !0) {
                        uploadFormatArray.push(itm.formatId)
                    }
                });
                assetAccess.push({
                    permission: "UPLOAD",
                    format: uploadFormatArray
                });
                angular.forEach($scope.downloadFormatListUser, function(itm) {
                    if (itm.selected == !0) {
                        downloadFormatArray.push(itm.formatId)
                    }
                });
                assetAccess.push({
                    permission: "DOWNLOAD",
                    format: downloadFormatArray
                });
                angular.forEach($scope.shareFormatListUser, function(itm) {
                    if (itm.selected == !0) {
                        shareFormatArray.push(itm.formatId)
                    }
                });
                assetAccess.push({
                    permission: "SHARE",
                    format: shareFormatArray
                });
                angular.forEach($scope.deleteFormatListUser, function(itm) {
                    if (itm.selected == !0) {
                        deleteFormatArray.push(itm.formatId)
                    }
                });
                assetAccess.push({
                    permission: "DELETE",
                    format: deleteFormatArray
                })
            }
            $http({
                method: 'POST',
                url: '/createPermissionGroup',
                data: {
                    permissionGroupName: $scope.userForm.newUserPermissionGroupName,
                    roleId: $scope.newUserRole.roleId,
                    account: accountArray,
                    metadataType: metadataTypeArray,
                    imprint: imprintArray,
                    productCategory: $scope.selectedProductCategoryArray,
                    metadataGroup: metadataGroupArray,
                    partnerType: partnerTypeArray,
                    application: applicationArray,
                    asset: assetAccess,
                    report: reportArray,
                    administrator: adminAccessArray
                }
            }).then(function successCallback(response) {
                if (response.data.code == '200') {
                    $scope.editUser.permissionGroup = response.data.data;
                    $rootScope.getPermissionGroups();
                    $scope.createUser()
                } else {
                    $scope.skipCountForUserRow = 0;
                    $scope.getFilteredUsers(!1);
                    $scope.showUserErrorMsg = !0;
                    $scope.userErrorMsg = "USER_LABEL_CREATE_ERROR";
                    setTimeout(function() {
                        $scope.showUserErrorMsg = !1;
                        $scope.$apply()
                    }, $rootScope.alertTimeoutInterval)
                    $scope.closeUserCreateModal()
                }
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        } else {
            $scope.createUser()
        }
    }
    $scope.createUser = function() {
        $http({
            method: 'POST',
            url: '/createUser',
            data: {
                emailId: $scope.newUserEmailId,
                permissionGroupId: $scope.editUser.permissionGroup.permissionGroupId
            }
        }).then(function successCallback(response) {
            $scope.createUserLoading = !1;
            $scope.skipCountForUserRow = 0;
            $scope.getFilteredUsers(!1);
            if (response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $scope.closeUserCreateModal()
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.editPermissionGroup = function() {
        var newAccountArray = [];
        var accountArray = [];
        var metadataTypeArray = [];
        var newImprintArray = [];
        var imprintArray = [];
        var metadataGroupArray = [];
        var partnerTypeArray = [];
        var applicationArray = [];
        var reportArray = null;
        var adminAccessArray = [];
        var viewFormatArray = [];
        var uploadFormatArray = [];
        var downloadFormatArray = [];
        var shareFormatArray = [];
        var deleteFormatArray = [];
        var assetAccess = null;
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            if (itm.selected == !0) {
                newAccountArray.push(itm.accountId)
            }
        });
        angular.forEach($scope.metadataTypeList, function(itm) {
            if (itm.selected == !0) {
                metadataTypeArray.push(itm.metadataTypeId)
            }
        });
        angular.forEach($scope.imprintList, function(itm) {
            if (itm.selected == !0) {
                newImprintArray.push(itm.imprintName)
            }
        });
        $scope.getSelectedProductCategories();
        angular.forEach($scope.cmetadataGroupList, function(itm) {
            if (itm.selected == !0) {
                metadataGroupArray.push(itm.groupNameId)
            }
        });
        angular.forEach($scope.partnerTypeList, function(itm) {
            if (itm.selected == !0) {
                partnerTypeArray.push(itm.partnerTypeId)
            }
        });
        angular.forEach($scope.applicationList, function(itm) {
            if (itm.selected == !0) {
                applicationArray.push(itm.applicationId)
            }
        });
        if ($scope.reportModuleAccess) {
            reportArray = [];
            angular.forEach($scope.roleReportList, function(itm) {
                if (itm.selected == !0) {
                    reportArray.push(itm.reportId)
                }
            })
        }
        angular.forEach($scope.accessList, function(itm) {
            if (itm.selected == !0) {
                adminAccessArray.push(itm.accessId)
            }
        });
        if ($scope.assetModuleAccess) {
            assetAccess = [];
            angular.forEach($scope.viewFormatListUser, function(itm) {
                if (itm.selected == !0) {
                    viewFormatArray.push(itm.formatId)
                }
            });
            assetAccess.push({
                permission: "VIEW",
                format: viewFormatArray
            });
            angular.forEach($scope.uploadFormatListUser, function(itm) {
                if (itm.selected == !0) {
                    uploadFormatArray.push(itm.formatId)
                }
            });
            assetAccess.push({
                permission: "UPLOAD",
                format: uploadFormatArray
            });
            angular.forEach($scope.downloadFormatListUser, function(itm) {
                if (itm.selected == !0) {
                    downloadFormatArray.push(itm.formatId)
                }
            });
            assetAccess.push({
                permission: "DOWNLOAD",
                format: downloadFormatArray
            });
            angular.forEach($scope.shareFormatListUser, function(itm) {
                if (itm.selected == !0) {
                    shareFormatArray.push(itm.formatId)
                }
            });
            assetAccess.push({
                permission: "SHARE",
                format: shareFormatArray
            });
            angular.forEach($scope.deleteFormatListUser, function(itm) {
                if (itm.selected == !0) {
                    deleteFormatArray.push(itm.formatId)
                }
            });
            assetAccess.push({
                permission: "DELETE",
                format: deleteFormatArray
            })
        }
        accountArray = newAccountArray.concat($scope.newUserOtherAccounts);
        imprintArray = newImprintArray.concat($scope.newUserOtherImprints);
        $scope.editUserLoading = !0;
        var url = "";
        var pgName = "";
        if ($scope.userForm.pgFlg == "EXISTING") {
            var editUserPg = $scope.editUser.permissionGroup.permissionGroupId;
            url = '/editPermissionGroup/' + editUserPg;
            pgName = $scope.editUser.permissionGroup.permissionGroupName
        } else {
            url = '/createPermissionGroup';
            pgName = $scope.userForm.newUserPermissionGroupName
        }
        $http({
            method: 'POST',
            url: url,
            data: {
                permissionGroupName: pgName,
                roleId: $scope.newUserRole.roleId,
                account: accountArray,
                metadataType: metadataTypeArray,
                imprint: imprintArray,
                productCategory: $scope.selectedProductCategoryArray,
                metadataGroup: metadataGroupArray,
                partnerType: partnerTypeArray,
                application: applicationArray,
                asset: assetAccess,
                report: reportArray,
                administrator: adminAccessArray
            }
        }).then(function successCallback(response) {
            if (response.data.code == '200') {
                $scope.editUser.permissionGroup = response.data.data;
                $rootScope.getPermissionGroups();
                $scope.editUserAccess()
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = "USER_LABEL_EDIT_ERROR";
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
                $scope.closeUserCreateModal()
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.editUserAccess = function() {
        var editUserId = $scope.editUser.userId;
        var loggedUserId = $scope.loggedUser.userId;
        $http({
            method: 'POST',
            url: '/editUser/' + editUserId,
            data: {
                emailId: $scope.newUserEmailId,
                permissionGroupId: $scope.editUser.permissionGroup.permissionGroupId
            }
        }).then(function successCallback(response) {
            $scope.editUserLoading = !1;
            $scope.skipCountForUserRow = 0;
            $scope.getFilteredUsers(!1);
            if (response.data.code == '200') {
                $scope.showUserSuccessMsg = !0;
                $scope.userSuccessMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserSuccessMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            } else {
                $scope.showUserErrorMsg = !0;
                $scope.userErrorMsg = response.data.status;
                setTimeout(function() {
                    $scope.showUserErrorMsg = !1;
                    $scope.$apply()
                }, $rootScope.alertTimeoutInterval)
            }
            $scope.closeUserCreateModal();
            if (editUserId == loggedUserId) {
                $rootScope.accountUser()
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.getAccounts = function() {
        $http({
            method: 'GET',
            url: '/getAccounts'
        }).then(function successCallback(response) {
            $scope.loggedUserAccountList = response.data.data.accountList
        }, function errorCallback(response) {})
    };
    $scope.showProductCategoriesForSelection = function(activityType) {
        $scope.selectedProductCategoryArray = [];
        if ($scope.localProductCategoryList != undefined && $scope.localProductCategoryList.length > 0) {
            $scope.getSelectedProductCategories()
        }
        var accountArray = [];
        var metadataTypeArray = [];
        $scope.newUserProductCategoryNames = [];
        angular.forEach($scope.metadataTypeList, function(itm) {
            if (itm.selected == !0) {
                metadataTypeArray.push(itm.metadataTypeId)
            }
        });
        var pcList = angular.copy($rootScope.productCategoryList);
        $scope.localProductCategoryList = $filter('filter')(pcList, function(pc) {
            return (metadataTypeArray.indexOf(pc.metadataTypeId) > -1)
        });
        $scope.productCategoryTreeUser = $scope.getNestedChildren($scope.localProductCategoryList, null);
        $scope.traverseTree($scope.productCategoryTreeUser, activityType);
        $scope.pcAllSelected = $scope.newUserProductCategoryNames.length == $scope.localProductCategoryList.length
    }
    $scope.refreshUserAccountList = function() {
        var filteredList = $filter('filter')($scope.loggedUserAccountList, function(data) {
            var re = new RegExp($scope.accountSearch, 'gi');
            return data.accountName.match(re)
        });
        $timeout(function() {
            $scope.acntAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.accountToggled = function(account, chk) {
        $scope.acntAllSelected = $scope.loggedUserAccountList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserAccountNames.push(account.accountName)
        } else {
            var index = $scope.newUserAccountNames.indexOf(account.accountName);
            $scope.newUserAccountNames.splice(index, 1)
        }
        $scope.refreshUserAccountList();
        $scope.retrieveImprintList()
    };
    $scope.retrieveImprintList = function() {
        var accountArray = [];
        var selectedImprints = [];
        $scope.newUserImprintNames = [];
        angular.forEach($scope.loggedUserAccountList, function(itm) {
            if (itm.selected == !0) {
                accountArray.push(itm.accountId)
            }
        });
        angular.forEach($scope.imprintList, function(itm) {
            if (itm.selected == !0) {
                selectedImprints.push(itm.imprintName)
            }
        });
        $scope.imprintList = [];
        $scope.imprintAllSelected = !1;
        if (accountArray.length != 0) {
            $scope.disableSaveCreateBtn = !0;
            $http({
                method: 'GET',
                url: '/getImprintListForAccounts/' + accountArray.toString()
            }).then(function successCallback(response) {
                angular.forEach(response.data.data, function(imprint) {
                    if (selectedImprints.indexOf(imprint) != -1) {
                        $scope.imprintList.push({
                            'imprintName': imprint,
                            selected: !0
                        });
                        $scope.newUserImprintNames.push(imprint)
                    } else {
                        $scope.imprintList.push({
                            'imprintName': imprint,
                            selected: !1
                        })
                    }
                })
                if ($scope.editUser != undefined && $scope.editUser != null && $scope.editUser.permissionGroup != null && $scope.editUser.permissionGroup != undefined)
                    $scope.setImprintsForEditUser();
                else $scope.imprintAllSelected = $scope.imprintList.every(function(itm) {
                    return itm.selected
                });
                $scope.disableSaveCreateBtn = !1
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        }
    };
    $scope.setImprintsForEditUser = function() {
        $scope.newUserOtherImprints = [];
        setTimeout(function() {
            angular.forEach($scope.imprintList, function(itm) {
                itm.selected = !1
            });
            angular.forEach($scope.editUser.permissionGroup.imprint, function(imprintName) {
                var otherImprintFlg = !0;
                angular.forEach($scope.imprintList, function(imprint) {
                    if (imprint.imprintName == imprintName) {
                        imprint.selected = !0;
                        $scope.newUserImprintNames.push(imprint.imprintName);
                        otherImprintFlg = !1
                    }
                });
                if (otherImprintFlg)
                    $scope.newUserOtherImprints.push(imprintName)
            });
            $scope.imprintAllSelected = $scope.imprintList.every(function(itm) {
                return itm.selected
            });
            $scope.$apply()
        }, 100)
    }
    $scope.refreshUserMetadataTypeList = function() {
        var filteredList = $filter('filter')($scope.metadataTypeList, function(data) {
            var re = new RegExp($scope.metadataTypeSearch, 'gi');
            return data.metadataTypeName.match(re)
        });
        $timeout(function() {
            $scope.mdtAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.metadataTypeToggled = function(metadataType, chk) {
        $scope.mdtAllSelected = $scope.metadataTypeList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserMetadataTypeNames.push(metadataType.metadataTypeName)
        } else {
            var index = $scope.newUserMetadataTypeNames.indexOf(metadataType.metadataTypeName);
            $scope.newUserMetadataTypeNames.splice(index, 1)
        }
        if ($scope.newUserAccountNames.length > 0 && $scope.newUserMetadataTypeNames.length > 0) {
            $scope.showProductCategoriesForSelection("POPULATESELECTED")
        } else {
            $scope.productCategoryTreeUser = []
        }
        $scope.refreshUserMetadataTypeList()
    };
    $scope.refreshUserImprintList = function() {
        var filteredList = $filter('filter')($scope.imprintList, function(data) {
            var re = new RegExp($scope.imprintSearch, 'gi');
            return data.imprintName.match(re)
        });
        $timeout(function() {
            $scope.imprintAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.imprintToggled = function(imprint, chk) {
        $scope.imprintAllSelected = $scope.imprintList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserImprintNames.push(imprint.imprintName)
        } else {
            var index = $scope.newUserImprintNames.indexOf(imprint.imprintName);
            $scope.newUserImprintNames.splice(index, 1)
        }
        $scope.refreshUserImprintList()
    };
    $scope.pcToggled = function(pc, chk) {
        $scope.pcAllSelected = $scope.productCategoryList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserProductCategoryNames.push(pc.productCategoryName)
        } else {
            var index = $scope.newUserProductCategoryNames.indexOf(pc.productCategoryName);
            $scope.newUserProductCategoryNames.splice(index, 1)
        }
    };
    $scope.refreshUserMetadataGroupList = function() {
        var filteredList = $filter('filter')($scope.cmetadataGroupList, function(data) {
            var re = new RegExp($scope.mgSearch, 'gi');
            return data.groupName.match(re)
        });
        $timeout(function() {
            $scope.mgAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.mgToggled = function(mg, chk) {
        $scope.mgAllSelected = $scope.cmetadataGroupList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserMetadataGroupNames.push(mg.groupName)
        } else {
            var index = $scope.newUserMetadataGroupNames.indexOf(mg.groupName);
            $scope.newUserMetadataGroupNames.splice(index, 1)
        }
        $scope.refreshUserMetadataGroupList()
    };
    $scope.refreshUserPartnerTypeList = function() {
        var filteredList = $filter('filter')($scope.partnerTypeList, function(data) {
            var re = new RegExp($scope.ptSearch, 'gi');
            return data.partnerTypeName.match(re)
        });
        $timeout(function() {
            $scope.ptAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.ptToggled = function(pt, chk) {
        $scope.ptAllSelected = $scope.partnerTypeList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserPartnerTypeNames.push(pt.partnerTypeName)
        } else {
            var index = $scope.newUserPartnerTypeNames.indexOf(pt.partnerTypeName);
            $scope.newUserPartnerTypeNames.splice(index, 1)
        }
        $scope.refreshUserPartnerTypeList()
    };
    $scope.refreshUserApplicationList = function() {
        var filteredList = $filter('filter')($scope.applicationList, function(data) {
            var re = new RegExp($scope.appSearch, 'gi');
            return data.applicationName.match(re)
        });
        $timeout(function() {
            $scope.appAllSelected = filteredList.every(function(itm) {
                return itm.selected
            }) && filteredList.length > 0
        }, 10)
    }
    $scope.appToggled = function(app, chk) {
        $scope.appAllSelected = $scope.applicationList.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            $scope.newUserApplicationNames.push(app.applicationName)
        } else {
            var index = $scope.newUserApplicationNames.indexOf(app.applicationName);
            $scope.newUserApplicationNames.splice(index, 1)
        }
        $scope.refreshUserApplicationList()
    };
    $scope.reportToggled = function(report, chk) {
        var filteredList = $filter('filter')($scope.roleReportList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.reportName.match(re)
        });
        $scope.reportAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setActivityAllSelected();
        if (chk) {
            $scope.newUserReportNames.push(report.reportName)
        } else {
            var index = $scope.newUserReportNames.indexOf(report.reportName);
            $scope.newUserReportNames.splice(index, 1)
        }
    };
    $scope.accessToggled = function(access, chk) {
        var filteredList = $filter('filter')($scope.accessList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.accessName.match(re)
        });
        $scope.accessAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setActivityAllSelected();
        if (chk) {
            $scope.newUserAdminAccessNames.push(access.accessName)
        } else {
            var index = $scope.newUserAdminAccessNames.indexOf(access.accessName);
            $scope.newUserAdminAccessNames.splice(index, 1)
        }
    };
    $scope.viewFormatToggled = function(format, chk) {
        var filteredList = $filter('filter')($scope.viewFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.vfAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        if (chk) {
            var fm = angular.copy(format);
            fm.selected = !1;
            if ($rootScope.loggedUserUploadFormatIdList.indexOf(format.formatId) > -1) {
                $scope.uploadFormatListUser.push(angular.copy(fm))
            }
            if ($rootScope.loggedUserDownloadFormatIdList.indexOf(format.formatId) > -1) {
                $scope.downloadFormatListUser.push(angular.copy(fm))
            }
            if ($rootScope.loggedUserShareFormatIdList.indexOf(format.formatId) > -1) {
                $scope.shareFormatListUser.push(angular.copy(fm))
            }
            if ($rootScope.loggedUserDeleteFormatIdList.indexOf(format.formatId) > -1) {
                $scope.deleteFormatListUser.push(angular.copy(fm))
            }
        } else {
            if ($rootScope.loggedUserUploadFormatIdList.indexOf(format.formatId) > -1) {
                $scope.uploadFormatListUser = $filter('filter')($scope.uploadFormatListUser, function(data) {
                    return (data.formatId != format.formatId)
                })
            }
            if ($rootScope.loggedUserDownloadFormatIdList.indexOf(format.formatId) > -1) {
                $scope.downloadFormatListUser = $filter('filter')($scope.downloadFormatListUser, function(data) {
                    return (data.formatId != format.formatId)
                })
            }
            if ($rootScope.loggedUserShareFormatIdList.indexOf(format.formatId) > -1) {
                $scope.shareFormatListUser = $filter('filter')($scope.shareFormatListUser, function(data) {
                    return (data.formatId != format.formatId)
                })
            }
            if ($rootScope.loggedUserDeleteFormatIdList.indexOf(format.formatId) > -1) {
                $scope.deleteFormatListUser = $filter('filter')($scope.deleteFormatListUser, function(data) {
                    return (data.formatId != format.formatId)
                })
            }
        }
        $scope.ufAllSelected = $scope.uploadFormatListUser.every(function(itm) {
            return itm.selected
        })
        $scope.dfAllSelected = $scope.downloadFormatListUser.every(function(itm) {
            return itm.selected
        })
        $scope.sfAllSelected = $scope.shareFormatListUser.every(function(itm) {
            return itm.selected
        })
        $scope.dtfAllSelected = $scope.deleteFormatListUser.every(function(itm) {
            return itm.selected
        })
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    };
    $scope.uploadFormatToggled = function(format, chk) {
        var filteredList = $filter('filter')($scope.uploadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.ufAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    };
    $scope.downloadFormatToggled = function(format, chk) {
        var filteredList = $filter('filter')($scope.downloadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.dfAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    };
    $scope.shareFormatToggled = function(format, chk) {
        var filteredList = $filter('filter')($scope.shareFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.sfAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    };
    $scope.deleteFormatToggled = function(format, chk) {
        var filteredList = $filter('filter')($scope.deleteFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.dtfAllSelected = filteredList.every(function(itm) {
            return itm.selected
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    };
    $scope.toggleAllAccounts = function() {
        var filteredList = $filter('filter')($scope.loggedUserAccountList, function(data) {
            var re = new RegExp($scope.accountSearch, 'gi');
            return data.accountName.match(re)
        });
        $scope.newUserAccountNames = [];
        var toggleStatus = $scope.acntAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(account) {
                $scope.newUserAccountNames.push(account.accountName)
            })
        }
        $scope.retrieveImprintList()
    }
    $scope.toggleAllMetadataTypes = function() {
        var filteredList = $filter('filter')($scope.metadataTypeList, function(data) {
            var re = new RegExp($scope.metadataTypeSearch, 'gi');
            return data.metadataTypeName.match(re)
        });
        $scope.newUserMetadataTypeNames = [];
        var toggleStatus = $scope.mdtAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(mdt) {
                $scope.newUserMetadataTypeNames.push(mdt.metadataTypeName)
            })
        }
        if ($scope.newUserAccountNames.length > 0 && $scope.newUserMetadataTypeNames.length > 0) {
            $scope.showProductCategoriesForSelection("POPULATESELECTED")
        } else {
            $scope.productCategoryTreeUser = []
        }
    }
    $scope.toggleAllImprints = function() {
        var filteredList = $filter('filter')($scope.imprintList, function(data) {
            var re = new RegExp($scope.imprintSearch, 'gi');
            return data.imprintName.match(re)
        });
        $scope.newUserImprintNames = [];
        var toggleStatus = $scope.imprintAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(imprint) {
                $scope.newUserImprintNames.push(imprint.imprintName)
            })
        }
    }
    $scope.toggleAllProductCategories = function() {
        $scope.newUserProductCategoryNames = [];
        var toggleStatus = $scope.pcAllSelected;
        if (toggleStatus)
            $scope.traverseTree($scope.productCategoryTreeUser, "SELECT");
        else $scope.traverseTree($scope.productCategoryTreeUser, "UNSELECT")
    }
    $scope.toggleAllMetadataGroups = function() {
        var filteredList = $filter('filter')($scope.cmetadataGroupList, function(data) {
            var re = new RegExp($scope.mgSearch, 'gi');
            return data.groupName.match(re)
        });
        $scope.newUserMetadataGroupNames = [];
        var toggleStatus = $scope.mgAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(mg) {
                $scope.newUserMetadataGroupNames.push(mg.groupName)
            })
        }
    }
    $scope.toggleAllPartnerTypes = function() {
        var filteredList = $filter('filter')($scope.partnerTypeList, function(data) {
            var re = new RegExp($scope.ptSearch, 'gi');
            return data.partnerTypeName.match(re)
        });
        $scope.newUserPartnerTypeNames = [];
        var toggleStatus = $scope.ptAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(pt) {
                $scope.newUserPartnerTypeNames.push(pt.partnerTypeName)
            })
        }
    }
    $scope.toggleAllApplications = function() {
        var filteredList = $filter('filter')($scope.applicationList, function(data) {
            var re = new RegExp($scope.appSearch, 'gi');
            return data.applicationName.match(re)
        });
        $scope.newUserApplicationNames = [];
        var toggleStatus = $scope.appAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        if (toggleStatus) {
            angular.forEach(filteredList, function(app) {
                $scope.newUserApplicationNames.push(app.applicationName)
            })
        }
    }
    $scope.toggleAllReports = function() {
        var filteredList = $filter('filter')($scope.roleReportList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.reportName.match(re)
        });
        $scope.newUserReportNames = [];
        var toggleStatus = $scope.reportAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllAdminAccess = function() {
        var filteredList = $filter('filter')($scope.accessList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.accessName.match(re)
        });
        $scope.newUserAdminAccessNames = [];
        var toggleStatus = $scope.accessAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllViewFormats = function() {
        var filteredList = $filter('filter')($scope.viewFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var toggleStatus = $scope.vfAllSelected;
        angular.forEach(filteredList, function(format) {
            format.selected = toggleStatus;
            if (toggleStatus) {
                var fm = angular.copy(format);
                fm.selected = !1;
                if ($rootScope.loggedUserUploadFormatIdList.indexOf(format.formatId) > -1 && $filter('filter')($scope.uploadFormatListUser, function(data) {
                        return (data.formatId == format.formatId)
                    }).length == 0) {
                    $scope.uploadFormatListUser.push(angular.copy(fm))
                }
                if ($rootScope.loggedUserDownloadFormatIdList.indexOf(format.formatId) > -1 && $filter('filter')($scope.downloadFormatListUser, function(data) {
                        return (data.formatId == format.formatId)
                    }).length == 0) {
                    $scope.downloadFormatListUser.push(angular.copy(fm))
                }
                if ($rootScope.loggedUserShareFormatIdList.indexOf(format.formatId) > -1 && $filter('filter')($scope.shareFormatListUser, function(data) {
                        return (data.formatId == format.formatId)
                    }).length == 0) {
                    $scope.shareFormatListUser.push(angular.copy(fm))
                }
                if ($rootScope.loggedUserDeleteFormatIdList.indexOf(format.formatId) > -1 && $filter('filter')($scope.deleteFormatListUser, function(data) {
                        return (data.formatId == format.formatId)
                    }).length == 0) {
                    $scope.deleteFormatListUser.push(angular.copy(fm))
                }
            } else {
                $scope.uploadFormatListUser = [];
                $scope.downloadFormatListUser = [];
                $scope.shareFormatListUser = [];
                $scope.deleteFormatListUser = []
            }
        });
        var ufilteredList = $filter('filter')($scope.uploadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var dfilteredList = $filter('filter')($scope.downloadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var sfilteredList = $filter('filter')($scope.shareFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var dtfilteredList = $filter('filter')($scope.deleteFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.ufAllSelected = ufilteredList.every(function(itm) {
            return itm.selected
        })
        $scope.dfAllSelected = dfilteredList.every(function(itm) {
            return itm.selected
        })
        $scope.sfAllSelected = sfilteredList.every(function(itm) {
            return itm.selected
        })
        $scope.dtfAllSelected = dtfilteredList.every(function(itm) {
            return itm.selected
        })
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllUploadFormats = function() {
        var filteredList = $filter('filter')($scope.uploadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var toggleStatus = $scope.ufAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllDownloadFormats = function() {
        var filteredList = $filter('filter')($scope.downloadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var toggleStatus = $scope.dfAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllShareFormats = function() {
        var filteredList = $filter('filter')($scope.shareFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var toggleStatus = $scope.sfAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllDeleteFormats = function() {
        var filteredList = $filter('filter')($scope.deleteFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        var toggleStatus = $scope.dtfAllSelected;
        angular.forEach(filteredList, function(itm) {
            itm.selected = toggleStatus
        });
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.toggleAllAssets = function() {
        var toggleStatus = $scope.assetAllSelected;
        if ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'VIEW')) {
            $scope.vfAllSelected = toggleStatus;
            $scope.toggleAllViewFormats()
        }
        if ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'MANUAL_UPLOAD') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULK_UPLOAD')) {
            $scope.ufAllSelected = toggleStatus;
            $scope.toggleAllUploadFormats()
        }
        if ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD')) {
            $scope.dfAllSelected = toggleStatus;
            $scope.toggleAllDownloadFormats()
        }
        if ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD_SHARE') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULKUPLOAD_SHARE')) {
            $scope.sfAllSelected = toggleStatus;
            $scope.toggleAllShareFormats()
        }
        if ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DELETE')) {
            $scope.dtfAllSelected = toggleStatus;
            $scope.toggleAllDeleteFormats()
        }
    }
    $scope.toggleAllActivities = function() {
        var toggleStatus = $scope.activityAllSelected;
        if ($scope.assetModuleAccess) {
            $scope.assetAllSelected = toggleStatus;
            $scope.toggleAllAssets()
        }
        if ($scope.assetModuleAccess) {
            $scope.reportAllSelected = toggleStatus;
            $scope.toggleAllReports()
        }
        $scope.accessAllSelected = toggleStatus;
        $scope.toggleAllAdminAccess()
    }
    $scope.refreshUserActivityList = function() {
        var rptFilteredList = $filter('filter')($scope.roleReportList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.reportName.match(re)
        });
        $scope.reportAllSelected = rptFilteredList.every(function(itm) {
            return itm.selected
        }) && rptFilteredList.length > 0;
        var accessFilteredList = $filter('filter')($scope.accessList, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.accessName.match(re)
        });
        $scope.accessAllSelected = accessFilteredList.every(function(itm) {
            return itm.selected
        }) && accessFilteredList.length > 0;
        var vfilteredList = $filter('filter')($scope.viewFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.vfAllSelected = vfilteredList.every(function(itm) {
            return itm.selected
        }) && vfilteredList.length > 0;
        var ufilteredList = $filter('filter')($scope.uploadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.ufAllSelected = ufilteredList.every(function(itm) {
            return itm.selected
        }) && ufilteredList.length > 0;
        var dfilteredList = $filter('filter')($scope.downloadFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.dfAllSelected = dfilteredList.every(function(itm) {
            return itm.selected
        }) && dfilteredList.length > 0;
        var sfilteredList = $filter('filter')($scope.shareFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.sfAllSelected = sfilteredList.every(function(itm) {
            return itm.selected
        }) && sfilteredList.length > 0;
        var dtfilteredList = $filter('filter')($scope.deleteFormatListUser, function(data) {
            var re = new RegExp($scope.actSearch, 'gi');
            return data.formatName.match(re)
        });
        $scope.dtfAllSelected = dtfilteredList.every(function(itm) {
            return itm.selected
        }) && dtfilteredList.length > 0;
        $scope.setAssetAllSelected();
        $scope.setActivityAllSelected()
    }
    $scope.setAssetAllSelected = function() {
        if (($scope.vfAllSelected || !$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'VIEW')) && ($scope.ufAllSelected || (!$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'MANUAL_UPLOAD') && !$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULK_UPLOAD'))) && ($scope.dfAllSelected || !$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD')) && ($scope.sfAllSelected || (!$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD_SHARE') && !$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULKUPLOAD_SHARE'))) && ($scope.dtfAllSelected || !$scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DELETE')))
            $scope.assetAllSelected = !0;
        else $scope.assetAllSelected = !1
    }
    $scope.setActivityAllSelected = function() {
        if (($scope.assetAllSelected || !$scope.assetModuleAccess) && ($scope.reportAllSelected || !$scope.reportModuleAccess) && $scope.accessAllSelected) {
            $scope.activityAllSelected = !0
        } else $scope.activityAllSelected = !1;
        if ($scope.assetModuleAccess && (($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'VIEW') && $filter('filter')($scope.viewFormatListUser, function(itm) {
                return (itm.selected)
            }).length > 0) || (($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'MANUAL_UPLOAD') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULK_UPLOAD')) && $filter('filter')($scope.uploadFormatListUser, function(itm) {
                return (itm.selected)
            }).length > 0) || ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD') && $filter('filter')($scope.downloadFormatListUser, function(itm) {
                return (itm.selected)
            }).length > 0) || (($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DOWNLOAD_SHARE') || $scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'BULKUPLOAD_SHARE')) && $filter('filter')($scope.shareFormatListUser, function(itm) {
                return (itm.selected)
            }).length > 0) || ($scope.checkAccessPermissionUser('MOD00002', 'ASSET_ACTIVITY', 'DELETE') && $filter('filter')($scope.deleteFormatListUser, function(itm) {
                return (itm.selected)
            }).length > 0))) {
            if ($scope.newUserActivityNames.indexOf("Assets") == -1)
                $scope.newUserActivityNames.push("Assets")
        } else {
            var index = $scope.newUserActivityNames.indexOf("Assets");
            if (index != -1)
                $scope.newUserActivityNames.splice(index, 1)
        }
        if ($scope.reportModuleAccess && $filter('filter')($scope.roleReportList, function(itm) {
                return (itm.selected)
            }).length > 0) {
            if ($scope.newUserActivityNames.indexOf("Reports") == -1)
                $scope.newUserActivityNames.push("Reports")
        } else {
            var index = $scope.newUserActivityNames.indexOf("Reports");
            if (index != -1)
                $scope.newUserActivityNames.splice(index, 1)
        }
        if ($filter('filter')($scope.accessList, function(itm) {
                return (itm.selected)
            }).length > 0) {
            if ($scope.newUserActivityNames.indexOf("Administrator") == -1)
                $scope.newUserActivityNames.push("Administrator")
        } else {
            var index = $scope.newUserActivityNames.indexOf("Administrator");
            if (index != -1)
                $scope.newUserActivityNames.splice(index, 1)
        }
    }
    $scope.checkForDuplicateEmail = function($event) {
        var userId = null;
        if ($scope.showEditButton)
            userId = $scope.editUserId;
        if ($event.target.value != "" || $event.target.value != null || $event.target.value != undefined) {
            var emailId = $event.target.value;
            $http({
                method: 'POST',
                url: '/checkForDuplicateUser',
                data: {
                    emailId: emailId,
                    userId: userId
                }
            }).then(function successCallback(response) {
                if (response.data.code != '404') {
                    $scope.showDuplicateUserErrorMsg = !0;
                    $scope.duplicateUserErrorMsg = response.data.status
                }
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        }
    }
    $scope.checkForDuplicatePgName = function($event) {
        if ($event.target.value != "" || $event.target.value != null || $event.target.value != undefined) {
            var pgName = $event.target.value;
            $http({
                method: 'POST',
                url: '/checkForDuplicatePgName',
                data: {
                    pgName: pgName
                }
            }).then(function successCallback(response) {
                if (response.data.code != '404') {
                    $scope.userForm.showDuplicatePgNameErrorMsg = !0;
                    $scope.duplicatePgNameErrorMsg = response.data.status
                }
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        }
    }
    $scope.checkAccessPermissionUser = function(moduleId, accessId, tabName) {
        var returnFlg = !1;
        if ($scope.newUserRole != undefined && $scope.newUserRole != null) {
            angular.forEach($scope.newUserRole.module, function(module) {
                if (module.moduleId === moduleId) {
                    angular.forEach(module.submodule, function(val) {
                        if (val.accessId == accessId) {
                            var index = val.activityAccess.indexOf(tabName);
                            if (index != -1)
                                returnFlg = !0;
                            return
                        }
                    })
                }
            })
        }
        return returnFlg
    }
    $scope.checkRoleLevel = function(roleId) {
        var role = $filter('filter')($rootScope.roleList, function(data) {
            return (data.roleId == roleId)
        })[0];
        if (role != undefined && (role.level == null || ($rootScope.loggedUserRole.level == null ? !1 : role.level >= $rootScope.loggedUserRole.level)))
            return !0;
        else return !1
    }
    $scope.userColumnSuggestions = {};
    $scope.userFilterSearch = {};
    $scope.gUserHeadresAllSelect = {};
    $scope.userNameFilterList = [];
    $scope.userEmailFilterList = [];
    $scope.userRoleFilterList = [];
    $scope.userPgFilterList = [];
    $scope.userStatusFilterList = [];
    $scope.userOnlineStatusFilterList = [];
    $scope.colUserFormatStatus = {};
    $scope.colUserOnlineStatus = {};
    $scope.createdFromDate = null;
    $scope.createdToDate = null;
    $scope.activatedFromDate = null;
    $scope.activatedToDate = null;
    var timeout = null;
    $scope.getUserColumnSuggestions = function(fieldName, suggestTxt) {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            $scope.callGetUserColumnSuggestions(fieldName, suggestTxt)
        }, 800)
    }
    $scope.callGetUserColumnSuggestions = function(fieldName, suggestTxt) {
        $http({
            method: 'POST',
            url: '/getUserColumnFilterSuggestions',
            data: {
                userNameFilterList: $scope.userNameFilterList,
                userEmailFilterList: $scope.userEmailFilterList,
                userRoleFilterList: $scope.userRoleFilterList,
                userPgFilterList: $scope.userPgFilterList,
                userStatusFilterList: $scope.userStatusFilterList,
                userOnlineStatusFilterList: $scope.userOnlineStatusFilterList,
                filterFieldName: fieldName,
                filterFieldText: suggestTxt,
                createdFromDate: $scope.createdFromDate,
                createdToDate: $scope.createdToDate,
                activatedFromDate: $scope.activatedFromDate,
                activatedToDate: $scope.activatedToDate
            }
        }).then(function(response) {
            if (response.data.data != null && Object.keys(response.data.data).length > 0) {
                if (fieldName == 'NAME') {
                    if ($scope.userNameFilterList != undefined && $scope.userNameFilterList != [] && $scope.userNameFilterList != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($scope.userNameFilterList.indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    $scope.userColumnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $scope.gUserHeadresAllSelect[fieldName] = $scope.userColumnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                } else if (fieldName == 'EMAIL') {
                    if ($scope.userEmailFilterList != undefined && $scope.userEmailFilterList != [] && $scope.userEmailFilterList != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($scope.userEmailFilterList.indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    $scope.userColumnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $scope.gUserHeadresAllSelect[fieldName] = $scope.userColumnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                } else if (fieldName == 'PG') {
                    if ($scope.userPgFilterList != undefined && $scope.userPgFilterList != [] && $scope.userPgFilterList != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($scope.userPgFilterList.indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    $scope.userColumnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $scope.gUserHeadresAllSelect[fieldName] = $scope.userColumnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                } else if (fieldName == 'ROLE') {
                    if ($scope.userRoleFilterList != undefined && $scope.userRoleFilterList != [] && $scope.userRoleFilterList != null) {
                        $.each(response.data.data, function(index, data) {
                            if ($scope.userRoleFilterList.indexOf(data.code) != -1) {
                                data.selected = !0
                            }
                        })
                    }
                    $scope.userColumnSuggestions[fieldName] = $filter('filter')(response.data.data, function(data) {
                        return (data.code != null && data.code != undefined && data.code != "")
                    })
                    $scope.gUserHeadresAllSelect[fieldName] = $scope.userColumnSuggestions[fieldName].every(function(itm) {
                        return itm.selected
                    })
                }
            } else {
                $scope.userColumnSuggestions[fieldName] = response.data.data;
                $scope.gUserHeadresAllSelect[fieldName] = !1
            }
        })
    }
    $scope.userfilterApplied = function(fieldName) {
        var flag = !1;
        if (fieldName == 'NAME') {
            if ($scope.userNameFilterList != null && $scope.userNameFilterList != undefined && $scope.userNameFilterList.length != 0)
                flag = !0
        } else if (fieldName == 'EMAIL') {
            if ($scope.userEmailFilterList != null && $scope.userEmailFilterList != undefined && $scope.userEmailFilterList.length != 0)
                flag = !0
        } else if (fieldName == 'ROLE') {
            if ($scope.userRoleFilterList != null && $scope.userRoleFilterList != undefined && $scope.userRoleFilterList.length != 0)
                flag = !0
        } else if (fieldName == 'PG') {
            if ($scope.userPgFilterList != null && $scope.userPgFilterList != undefined && $scope.userPgFilterList.length != 0)
                flag = !0
        } else if (fieldName == 'CREATED') {
            if ($scope.createdFromDate != null || $scope.createdToDate != null)
                flag = !0
        } else if (fieldName == 'ACTIVATED') {
            if (($scope.userStatusFilterList != null && $scope.userStatusFilterList != undefined && $scope.userStatusFilterList.length != 0) || $scope.activatedFromDate != null || $scope.activatedToDate != null)
                flag = !0
        } else if (fieldName == 'USER_STATUS') {
            if (($scope.userOnlineStatusFilterList != null && $scope.userOnlineStatusFilterList != undefined && $scope.userOnlineStatusFilterList.length != 0))
                flag = !0
        }
        return flag
    }

    $scope.clearAllUserMasterFilter = function(fieldName){

            $scope.gUserHeadresAllSelect['NAME'] = !1;
            angular.forEach($scope.userColumnSuggestions['NAME'], function(itm) {
                itm.selected = !1
            });
            $scope.userNameFilterList = []

            $scope.gUserHeadresAllSelect['EMAIL'] = !1;
            angular.forEach($scope.userColumnSuggestions['EMAIL'], function(itm) {
                itm.selected = !1
            });
            $scope.userEmailFilterList = []

            $scope.gUserHeadresAllSelect['ROLE'] = !1;
            angular.forEach($scope.userColumnSuggestions['ROLE'], function(itm) {
                itm.selected = !1
            });
            $scope.userRoleFilterList = []

            $scope.gUserHeadresAllSelect['PG'] = !1;
            angular.forEach($scope.userColumnSuggestions['PG'], function(itm) {
                itm.selected = !1
            });
            $scope.userPgFilterList = []

            $scope.createdFrom = null;
            $scope.createdTo = null;
            $scope.createdFromDate = null;
    		$scope.createdToDate = null;

            $scope.activatedFrom = null;
            $scope.activatedTo = null;
            $scope.activatedFromDate = null;
            $scope.activatedToDate = null;
            $scope.userStatusFilterList = [];
            angular.forEach($rootScope.statusList, function(fStatus) {
                if (fStatus.statusType == 'USER_TYPE') {
                    $scope.colUserFormatStatus[fStatus.code] = !1
                }
            })

            $scope.userOnlineStatusFilterList = [];
            angular.forEach($rootScope.statusList, function(fStatus) {
                if (fStatus.statusType == 'USER_STATUS') {
                    $scope.colUserOnlineStatus[fStatus.code] = !1
                }
            })
        
        $scope.userColumnSuggestions = {};
        $scope.userFilterSearch = {};
        $scope.gUserHeadresAllSelect = {};
        $scope.skipCountForUserRow = 0;

        var container = document.getElementById("userMasterTableBody");
        if ($scope.skipCountForUserRow == 0) {
            container.scrollTop = 0;
            container.scrollLeft = 0;
        }
        
        $scope.getUsers();
        //$scope.getFilteredUsers(!1)
    }

    $scope.addRemoveUserColumnTags = function(input, chkFlg, fieldName) {
        if (chkFlg) {
            if (fieldName == 'NAME') {
                $scope.userNameFilterList.push(input.code)
            } else if (fieldName == 'EMAIL') {
                $scope.userEmailFilterList.push(input.code)
            } else if (fieldName == 'ROLE') {
                $scope.userRoleFilterList.push(input.code)
            } else if (fieldName == 'PG') {
                $scope.userPgFilterList.push(input.code)
            } else if (fieldName == 'ACTIVATED') {
                $scope.userStatusFilterList.push(input.code)
            } else if (fieldName == 'USER_STATUS') {
                $scope.userOnlineStatusFilterList.push(input.code)
            }
            if (fieldName != 'ACTIVATED' && fieldName != 'USER_STATUS')
                $scope.gUserHeadresAllSelect[fieldName] = $scope.userColumnSuggestions[fieldName].every(function(itm) {
                    return itm.selected
                })
        } else {
            if (fieldName != 'ACTIVATED' && fieldName != 'USER_STATUS')
                $scope.gUserHeadresAllSelect[fieldName] = !1;
            if (fieldName == 'NAME') {
                $scope.userNameFilterList = $filter('filter')($scope.userNameFilterList, function(data) {
                    return (data != input.code)
                })
            } else if (fieldName == 'EMAIL') {
                $scope.userEmailFilterList = $filter('filter')($scope.userEmailFilterList, function(data) {
                    return (data != input.code)
                })
            } else if (fieldName == 'ROLE') {
                $scope.userRoleFilterList = $filter('filter')($scope.userRoleFilterList, function(data) {
                    return (data != input.code)
                })
            } else if (fieldName == 'PG') {
                $scope.userPgFilterList = $filter('filter')($scope.userPgFilterList, function(data) {
                    return (data != input.code)
                })
            } else if (fieldName == 'ACTIVATED') {
                $scope.colUserFormatStatus[input.code] = !1;
                $scope.userStatusFilterList = $filter('filter')($scope.userStatusFilterList, function(data) {
                    return (data != input.code)
                })
            } else if (fieldName == 'USER_STATUS') {
                $scope.colUserOnlineStatus[input.code] = !1;
                $scope.userOnlineStatusFilterList = $filter('filter')($scope.userOnlineStatusFilterList, function(data) {
                    return (data != input.code)
                })
            }
        }
        Object.keys($scope.userColumnSuggestions).forEach(function(itm) {
            if (itm != fieldName) delete $scope.userColumnSuggestions[itm]
        });
        Object.keys($scope.userFilterSearch).forEach(function(itm) {
            if (itm != fieldName) delete $scope.userFilterSearch[itm]
        });
        Object.keys($scope.gUserHeadresAllSelect).forEach(function(itm) {
            if (itm != fieldName) $scope.gUserHeadresAllSelect[itm] = !1
        });
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    };
    $scope.userGridHeadresAllSelected = function(fieldName, chkFlg) {
        if ($scope.userColumnSuggestions[fieldName] == undefined || $scope.userColumnSuggestions[fieldName] == []) {
            $scope.gUserHeadresAllSelect[fieldName] = !1
        } else {
            angular.forEach($scope.userColumnSuggestions[fieldName], function(itm) {
                itm.selected = chkFlg
            });
            if (chkFlg) {
                angular.forEach($scope.userColumnSuggestions[fieldName], function(input) {
                    if (fieldName == 'NAME') {
                        if ($scope.userNameFilterList.indexOf(input.code) == -1)
                            $scope.userNameFilterList.push(input.code)
                    } else if (fieldName == 'EMAIL') {
                        if ($scope.userEmailFilterList.indexOf(input.code) == -1)
                            $scope.userEmailFilterList.push(input.code)
                    } else if (fieldName == 'ROLE') {
                        if ($scope.userRoleFilterList.indexOf(input.code) == -1)
                            $scope.userRoleFilterList.push(input.code)
                    } else if (fieldName == 'PG') {
                        if ($scope.userPgFilterList.indexOf(input.code) == -1)
                            $scope.userPgFilterList.push(input.code)
                    }
                })
            } else {
                angular.forEach($scope.userColumnSuggestions[fieldName], function(input) {
                    if (fieldName == 'NAME') {
                        $scope.userNameFilterList = $filter('filter')($scope.userNameFilterList, function(data) {
                            return (data != input.code)
                        })
                    } else if (fieldName == 'EMAIL') {
                        $scope.userEmailFilterList = $filter('filter')($scope.userEmailFilterList, function(data) {
                            return (data != input.code)
                        })
                    } else if (fieldName == 'ROLE') {
                        $scope.userRoleFilterList = $filter('filter')($scope.userRoleFilterList, function(data) {
                            return (data != input.code)
                        })
                    } else if (fieldName == 'PG') {
                        $scope.userPgFilterList = $filter('filter')($scope.userPgFilterList, function(data) {
                            return (data != input.code)
                        })
                    }
                })
            }
        }
        Object.keys($scope.userColumnSuggestions).forEach(function(itm) {
            if (itm != fieldName) delete $scope.userColumnSuggestions[itm]
        });
        Object.keys($scope.userFilterSearch).forEach(function(itm) {
            if (itm != fieldName) delete $scope.userFilterSearch[itm]
        });
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    $rootScope.disableBtnClick = function() {
        $rootScope.deleteUserDisableBtn = !0;
        $timeout(function() {
            $rootScope.deleteUserDisableBtn = !1
        }, 2000)
    }
    $rootScope.userGridHeadersResetFilter = function(fieldName) {
        if (fieldName == 'NAME') {
            $scope.gUserHeadresAllSelect[fieldName] = !1;
            angular.forEach($scope.userColumnSuggestions[fieldName], function(itm) {
                itm.selected = !1
            });
            $scope.userNameFilterList = []
        } else if (fieldName == 'EMAIL') {
            $scope.gUserHeadresAllSelect[fieldName] = !1;
            angular.forEach($scope.userColumnSuggestions[fieldName], function(itm) {
                itm.selected = !1
            });
            $scope.userEmailFilterList = []
        } else if (fieldName == 'ROLE') {
            $scope.gUserHeadresAllSelect[fieldName] = !1;
            angular.forEach($scope.userColumnSuggestions[fieldName], function(itm) {
                itm.selected = !1
            });
            $scope.userRoleFilterList = []
        } else if (fieldName == 'PG') {
            $scope.gUserHeadresAllSelect[fieldName] = !1;
            angular.forEach($scope.userColumnSuggestions[fieldName], function(itm) {
                itm.selected = !1
            });
            $scope.userPgFilterList = []
        } else if (fieldName == 'CREATED') {
            $scope.createdFrom = null;
            $scope.createdTo = null
        } else if (fieldName == 'ACTIVATED') {
            $scope.activatedFrom = null;
            $scope.activatedTo = null;
            $scope.userStatusFilterList = [];
            angular.forEach($rootScope.statusList, function(fStatus) {
                if (fStatus.statusType == 'USER_TYPE') {
                    $scope.colUserFormatStatus[fStatus.code] = !1
                }
            })
        } else if (fieldName == 'USER_STATUS') {
            $scope.userOnlineStatusFilterList = [];
            angular.forEach($rootScope.statusList, function(fStatus) {
                if (fStatus.statusType == 'USER_STATUS') {
                    $scope.colUserOnlineStatus[fStatus.code] = !1
                }
            })
        }
        $scope.userColumnSuggestions = {};
        $scope.userFilterSearch = {};
        $scope.gUserHeadresAllSelect = {};
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    $rootScope.exportFormat = null;
    $scope.exportUsers = function(exportType) {
        $rootScope.exportFormat = exportType.type;
        $scope.getFilteredUsers(!0)
    }
    $scope.getFilteredUsers = function(exportFlg) {
        if ($scope.skipCountForUserRow != null && $scope.skipCountForUserRow != 0)
            $rootScope.showLoader($('.user-table-loader'), 1, 'win8_linear');
        $scope.setDateValues();
        $scope.userReqId = new Date().getTime();
        $scope.exportId = null;
        if (exportFlg) {
            $scope.skipCountForUserRow = 0;
            $scope.exportId = $scope.userReqId;
            $scope.showUserSuccessMsgExport = !0;
            $scope.userSuccessMsgExport = "EXPORT_REQUEST_SUCCESS";
            setTimeout(function() {
                $scope.showUserSuccessMsgExport = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        }
        $scope.userReqId = new Date().getTime();
        $http({
            method: 'POST',
            url: '/getFilteredUsers',
            data: {
                userNameFilterList: $scope.userNameFilterList,
                userEmailFilterList: $scope.userEmailFilterList,
                userRoleFilterList: $scope.userRoleFilterList,
                userPgFilterList: $scope.userPgFilterList,
                userStatusFilterList: $scope.userStatusFilterList,
                userOnlineStatusFilterList: $scope.userOnlineStatusFilterList,
                createdFromDate: $scope.createdFromDate,
                createdToDate: $scope.createdToDate,
                activatedFromDate: $scope.activatedFromDate,
                activatedToDate: $scope.activatedToDate,
                export: exportFlg,
                exportFormat : $rootScope.exportFormat,
                reqId: $scope.userReqId,
                skip: $scope.skipCountForUserRow
            }
        }).then(function(response) {
            var container = document.getElementById("userMasterTableBody");
            if ($scope.skipCountForUserRow == 0) {
                container.scrollTop = 0;
                $timeout(function() {
                    angular.element("#userMasterTableBody").trigger('scroll');
                    angular.element("#userMasterTableBody").scrollTop(5)
                }, 200)
            }
            if ($scope.userReqId == response.data.reqId) {
                if ($scope.userList != null && $scope.userList.length > 0 && response.data.data != null && response.data.data.length > 0) {
                    if ($scope.skipCountForUserRow == 0) {
                        $scope.userList = response.data.data;
                        $scope.skipCountForUserRow = $scope.userList.length;
                        $scope.userListCount = response.data.count
                    } else {
                        $scope.userList = $scope.userList.concat(response.data.data);
                        $scope.skipCountForUserRow = $scope.userList.length;
                        $scope.userListCount = response.data.count
                    }
                } else if (response.data.data != null) {
                    $scope.userList = response.data.data;
                    $scope.skipCountForUserRow = $scope.userList.length;
                    $scope.userListCount = response.data.count
                }
            }
            $rootScope.hideLoader('user-table-loader');
            if (exportFlg && $scope.exportId == response.data.reqId) {
                $rootScope.getDownloadNotification();
                angular.element("#getDownloadNotification").addClass('open');
                angular.element(".download-up").addClass("flashit")
            }
        }, function errorCallback(response) {
            console.log('Error status: ' + response.status)
        })
    }
    $scope.setDateValues = function() {
        if ($scope.createdFrom != undefined && $scope.createdFrom != null)
            $scope.createdFromDate = $scope.finaldateFormat($scope.createdFrom);
        else $scope.createdFromDate = null;
        if ($scope.createdTo != undefined && $scope.createdTo != null)
            $scope.createdToDate = $scope.finaldateFormat($scope.createdTo);
        else $scope.createdToDate = null;
        if ($scope.activatedFrom != undefined && $scope.activatedFrom != null)
            $scope.activatedFromDate = $scope.finaldateFormat($scope.activatedFrom);
        else $scope.activatedFromDate = null;
        if ($scope.activatedTo != undefined && $scope.activatedTo != null)
            $scope.activatedToDate = $scope.finaldateFormat($scope.activatedTo);
        else $scope.activatedToDate = null
    }
    $scope.finaldateFormat = function(input) {
        if (input == null)
            return null;
        var d = new Date(input);
        var curr_date = ("0" + d.getDate()).slice(-2);
        var curr_month = ("0" + (d.getMonth() + 1)).slice(-2);
        var curr_year = d.getFullYear();
        return curr_year + "/" + curr_month + "/" + curr_date
    }
    $scope.dateSelected = function() {
        $scope.userColumnSuggestions = {};
        $scope.userFilterSearch = {};
        $scope.gUserHeadresAllSelect = {};
        $scope.skipCountForUserRow = 0;
        $scope.getFilteredUsers(!1)
    }
    setTimeout(function() {
        $scope.getAccounts();
        $scope.getUsers()
    }, 200)
}]);
app.filter('nospace', function() {
    return function(value) {
        return (!value) ? '' : value.replace(/ /g, '')
    }
});
app.directive('noSpace', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function(inputValue) {
                var transformedInput = (!inputValue) ? '' : inputValue.replace(/ /g, '');
                modelCtrl.$setViewValue(transformedInput);
                modelCtrl.$render();
                return transformedInput
            })
        }
    }
})