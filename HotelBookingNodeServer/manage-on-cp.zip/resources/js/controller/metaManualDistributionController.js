app.controller('metaManualDistributionController', ['$scope', '$http', '$timeout', '$rootScope', '$location', "$route", "$window", "$compile", "$parse", "$filter", function($scope, $http, $timeout, $rootScope, $location, $route, $window, $compile, $parse, $filter) {
    $rootScope.testScroll();
    $scope.proceedDistribution = function() {
        var checkboxCount = angular.element(".brCheckbox").length;
        if (checkboxCount > 0) {
            $http({
                method: 'POST',
                url: '/saveManualDistData',
                data: {
                    partnerDetails: $rootScope.metaPartn,
                    userId: $rootScope.loggedUser.userId,
                    emailId: $rootScope.loggedUser.emailId,
                    userName: $rootScope.loggedUser.firstName,
                    metadataCheck: !0
                }
            }).then(function(response) {});
            $location.url('/metadata');
            $rootScope.searchClearAll();
            $rootScope.toggleMetaDistributionMsg()
        } else {
            $scope.failureManualDistMsg = !0;
            $scope.failureManualDistMsgContent = "Atleast one Partner should be selected!";
            setTimeout(function() {
                $scope.failureManualDistMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        }
    }
    $scope.proceedToTakeDownDistribution = function() {
       var checkboxCount = angular.element(".brCheckbox").length;
       if (checkboxCount > 0) {
           $http({
               method: 'POST',
               url: '/saveManualTakeDownDistData',
               data: {
                   partnerDetails: $rootScope.metaPartn,
                   userId: $rootScope.loggedUser.userId,
                   emailId: $rootScope.loggedUser.emailId,
                   userName: $rootScope.loggedUser.firstName,
                   metadataCheck: !0
               }
           }).then(function(response) {});
           $location.url('/metadata');
           $rootScope.searchClearAll();
           $rootScope.toggleMetaDistributionMsg()
       } else {
           $scope.failureManualDistMsg = !0;
           $scope.failureManualDistMsgContent = "Atleast one Partner should be selected!";
           setTimeout(function() {
               $scope.failureManualDistMsg = !1;
               $scope.$apply()
           }, $rootScope.alertTimeoutInterval)
       }
   }
    $scope.getMetaDistributionStatus = function() {
        $http({
            method: 'POST',
            url: '/getDistributionStatus',
            data: {
                partnerDetails: $rootScope.metaPartn
            }
        }).then(function(response) {
            $rootScope.metaPartn = response.data.data
        })
    }
    $scope.metaPartnerAll = {};
    $scope.metapartGrp = {};
    $scope.metafinalPartnerDetails = {};
    $scope.metaBrAll = {};
    $scope.changePriority = function(roleName, currentRow) {
        $.each($rootScope.metaPartn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.partnerTypeId == currentRow.partnerTypeId) {
                $rootScope.metaPartn[key].priority = roleName
            }
        })
    }
    $scope.setBrStatus = function(currentRow, selectedPartner, event) {
        if (event == !0 || event == !1) {
            isChecked = event
        } else {
            isChecked = event.target.checked
        }
        $.each($rootScope.metaPartn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.partnerTypeId == currentRow.partnerTypeId) {
                $.each(value.partnerDetails, function(key1, value1) {
                    if (selectedPartner.partnerId == value1.partnerId) {
                        $rootScope.metaPartn[key].partnerDetails[key1].brStatus = isChecked
                    }
                })
            }
            var filteredList = $filter('filter')($rootScope.metaPartn[key].partnerDetails, function(data) {
                return data.brStatus
            });
            if (filteredList == undefined) {
                $scope.metaBrAll[currentRow.partnerTypeId] = !1;
                return !1
            } else {
                if ((filteredList.length == $rootScope.metaPartn[key].partnerDetails.length) && (filteredList.length != 0)) {
                    $scope.metaBrAll[currentRow.partnerTypeId] = !0
                } else {
                    $scope.metaBrAll[currentRow.partnerTypeId] = !1;
                    return !1
                }
            }
        })
    }
    $scope.toggleAllBrStatus = function(partnerTypeId, event) {
        isChecked = event.target.checked;
        $scope.metaBrAll[partnerTypeId] = isChecked;
        $.each($rootScope.metaPartn, function(key, value) {
            if (value.partnerTypeId == partnerTypeId) {
                $.each(value.partnerDetails, function(key1, value1) {
                    $rootScope.metaPartn[key].partnerDetails[key1].brStatus = isChecked
                })
            }
        })
    }
    $scope.verifyChecked = function(PartLst, partnerTypeId, partnerId, partnerGrp) {
        if (PartLst.selected == !0 && PartLst.partnerTypeId == partnerTypeId && PartLst.partnerId == partnerId) {
            return !0
        }
        if (partnerGrp.length > 0) {
            for (i = 0; i < partnerGrp.length; i++) {
                if (partnerGrp[i].selected == !0 && partnerGrp[i].partnerTypeId == partnerTypeId) {
                    var inde = partnerGrp[i].partnerIds.indexOf(partnerId);
                    if (inde >= 0) {
                        return !0
                    }
                }
            }
        }
        return !1
    }
    $scope.setHeight = function(event) {
        var par_height = $(event.currentTarget).closest('.divTableCell').height();
        $(event.currentTarget).parent().parent().children(".multi-select-dropdown").css("top", par_height + 5)
    }
    $scope.checkAllprtToggled = function(parr, prts, event) {
        angular.forEach(prts, function(pData, ppdata) {
            var frmtId = parr.formatId == undefined ? "" : parr.formatId;
            $('#' + parr.isbn + "_" + frmtId + "_" + pData.partnerId).prop('checked', event.target.checked);
            $scope.prtToggled(parr, pData, event)
        });
        var ischecked = event.target.checked;
        if (ischecked == !1) {
            $scope.metaBrAll[parr.partnerTypeId] = !1
        }
    }
    $scope.prtToggled = function(currentRow, currentTag, event) {
        var ischecked = event.target.checked;
        $.each($rootScope.metaPartn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.partnerTypeId == currentRow.partnerTypeId) {
                if (!$rootScope.metaPartn[key].hasOwnProperty("partnerDetails")) {
                    $rootScope.metaPartn[key].partnerDetails = []
                }
                var index = $rootScope.metaPartn[key].partnerDetails.findIndex(function(item, index) {
                    return ((item.partnerId === currentTag.partnerId)) ? !0 : !1
                });
                if (ischecked) {
                    if (index == -1) {
                        $rootScope.metaPartn[key].partnerDetails.push({
                            partnerId: currentTag.partnerId,
                            partner: currentTag.partnerName,
                            isGroup: !1
                        });
                        $http({
                            method: 'POST',
                            url: '/getDistributionStatus',
                            data: {
                                partnerDetails: $rootScope.metaPartn
                            }
                        }).then(function(response) {
                            var resultdata = response.data.data;
                            var distStatus = "";
                            for (i = 0; i < resultdata.length; i++) {
                                if (value.isbn == resultdata[i].isbn && value.partnerTypeId == resultdata[i].partnerTypeId) {
                                    for (j = 0; j < resultdata[i].partnerDetails.length; j++) {
                                        if (currentTag.partnerId) {
                                            distStatus = resultdata[i].partnerDetails[j].distributionStatus
                                        }
                                    }
                                }
                            }
                            angular.forEach($rootScope.metaPartn, function(pData, ppdata) {
                                if (value.isbn == pData.isbn && value.partnerTypeId == pData.partnerTypeId) {
                                    angular.forEach(pData.partnerDetails, function(partData, data) {
                                        if (currentTag.partnerId === partData.partnerId) {
                                            $rootScope.metaPartn[ppdata].partnerDetails[data].distributionStatus = distStatus
                                        }
                                    })
                                }
                            })
                        })
                    }
                } else {
                    if (index > -1) {
                        $rootScope.metaPartn[key].partnerDetails.splice(index, 1);
                        for (i = 0; i < $scope.metaPartnerList.length; i++) {
                            if (currentTag.partnerTypeId == $scope.metaPartnerList[i].partnerTypeId) {
                                for (j = 0; j < $scope.metaPartnerList[i].partners.length; j++) {
                                    if (currentTag.partnerId == $scope.metaPartnerList[i].partners[j].partnerId) {
                                        $scope.metaPartnerAll[currentRow.partnerTypeId] = !1
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })
        $scope.setBrStatus(currentRow, currentTag, event)
    }
    $scope.cpRemove = function(currentPartnerType, currentRow, currentTag) {
        $.each($scope.metaPartn, function(key, value) {
            if (value.isbn == currentRow.isbn && value.partnerTypeId == currentRow.partnerTypeId) {
                var index = $scope.metaPartn[key].partnerDetails.indexOf(currentTag);
                for (i = 0; i < $scope.metaPartnerList.length; i++) {
                    if (currentPartnerType.partnerTypeId == $scope.metaPartnerList[i].partnerTypeId) {
                        for (j = 0; j < $scope.metaPartnerList[i].partners.length; j++) {
                            if (currentTag.partnerId == $scope.metaPartnerList[i].partners[j].partnerId) {
                                $scope.metaPartnerAll[currentRow.partnerTypeId] = !1
                            }
                        }
                    }
                }
                $scope.metaPartn[key].partnerDetails.splice(index, 1);
                return !1
            }
        })
    }
    $scope.cpClose = function(currentRow) {
        for (i = 0; i < $scope.metaPartn.length; i++) {
            if ($scope.metaPartn[i].isbn == currentRow.isbn && $scope.metaPartn[i].partnerTypeId == currentRow.partnerTypeId) {
                $scope.metaPartn.splice(i, 1)
            }
        }
    }
    $scope.toggleAllPartnersType = function(CurrentPartner) {
        if (Object.keys($scope.metafinalPartnerDetails).length == 0) {
            angular.forEach($scope.metaPartnerList, function(prtList) {
                $scope.metafinalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerType = CurrentPartner.partnerTypeId;
        var chk = $scope.metaPartnerAll[currentPartnerType];
        angular.forEach(CurrentPartner.partners, function(selectedPartner) {
            selectedPartner.selected = chk;
            if (chk) {
                var index = $scope.metafinalPartnerDetails[currentPartnerType].findIndex(function(item, index) {
                    return ((item.partnerId === selectedPartner.partnerId) && (item.isGroup === !1)) ? !0 : !1
                });
                if (index == -1) {
                    $scope.metafinalPartnerDetails[currentPartnerType].push({
                        partnerId: selectedPartner.partnerId,
                        partner: selectedPartner.partnerName,
                        isGroup: !1
                    })
                }
            } else {
                $scope.metaBrAll[CurrentPartner.partnerTypeId] = !1;
                $.each($scope.metafinalPartnerDetails[currentPartnerType], function(index1, result1) {
                    if (selectedPartner.partnerId == result1.partnerId && result1.isGroup == !1) {
                        $scope.metafinalPartnerDetails[currentPartnerType].splice(index1, 1);
                        return !1
                    }
                })
            }
        });
        angular.forEach($rootScope.metaPartn, function(value, key) {
            value.partnerDetails = angular.copy($scope.metafinalPartnerDetails[value.partnerTypeId])
        });
        $scope.getMetaDistributionStatus();
        $timeout(function() {
            $.each($rootScope.metaPartn, function(index, row) {
                if (row.partnerTypeId == currentPartnerType) {
                    $.each(row.partnerDetails, function(key, value) {
                        $scope.setBrStatus(row, value, chk)
                    })
                }
            })
        }, 300)
    }
    $scope.partnersListToggled = function(currentPartnerType, selectedPartner, chk) {
        if (Object.keys($scope.metafinalPartnerDetails).length == 0) {
            angular.forEach($scope.metaPartnerList, function(prtList) {
                $scope.metafinalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerTypeId = currentPartnerType.partnerTypeId;
        $scope.metaPartnerAll[currentPartnerTypeId] = currentPartnerType.partners.every(function(itm) {
            return itm.selected
        })
        if (chk) {
            var index = $scope.metafinalPartnerDetails[currentPartnerTypeId].findIndex(function(item, index) {
                return ((item.partnerId === selectedPartner.partnerId) && (item.isGroup === !1)) ? !0 : !1
            });
            if (index == -1) {
                $scope.metafinalPartnerDetails[currentPartnerTypeId].push({
                    partnerId: selectedPartner.partnerId,
                    partner: selectedPartner.partnerName,
                    isGroup: !1
                })
            }
        } else {
            $.each($scope.metafinalPartnerDetails[currentPartnerTypeId], function(index, row) {
                if (row.partnerId == selectedPartner.partnerId && row.isGroup == !1) {
                    $scope.metafinalPartnerDetails[currentPartnerTypeId].splice(index, 1);
                    return !1
                }
            })
        }
        $scope.metaPushPopPartners(selectedPartner, chk, !1);
        $scope.getMetaDistributionStatus();
        $timeout(function() {
            $.each($rootScope.metaPartn, function(index, row) {
                if (row.partnerTypeId == currentPartnerTypeId) {
                    $.each(row.partnerDetails, function(key, value) {
                        if (value.partnerId == selectedPartner.partnerId) {
                            $scope.setBrStatus(row, value, chk)
                        }
                    })
                }
            })
        }, 300)
    }
    $scope.metaPushPopPartners = function(parDetails, chk, isgroup) {
        if (chk) {
            angular.forEach($rootScope.metaPartn, function(value, key) {
                if (value.partnerDetails) {
                    var index = value.partnerDetails.findIndex(function(item, index) {
                        console.log(item)
                        return (item.partnerId === parDetails.partnerId) ? !0 : !1
                    });
                    if (index == -1) {
                        value.partnerDetails.push({
                            partnerId: parDetails.partnerId,
                            partner: parDetails.partnerName,
                            isGroup: isgroup
                        })
                    }
                } else {
                    value.partnerDetails = angular.copy($scope.metafinalPartnerDetails[value.partnerTypeId])
                }
            })
        } else {
            angular.forEach($rootScope.metaPartn, function(value, key) {
                var index = value.partnerDetails.findIndex(function(item, index) {
                    console.log(item)
                    return (item.partnerId === parDetails.partnerId) ? !0 : !1
                });
                if (index >= 0) {
                    value.partnerDetails.splice(index, 1)
                }
            })
        }
    }
    $scope.toggleAllPartnersGrp = function(CurrentPartner) {
        if (Object.keys($scope.metafinalPartnerDetails).length == 0) {
            angular.forEach($scope.metaPartnerList, function(prtList) {
                $scope.metafinalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerType = CurrentPartner.partnerTypeId;
        var chk = $scope.metapartGrp[currentPartnerType];
        angular.forEach(CurrentPartner.partnerGrps, function(prtgrp) {
            prtgrp.selected = chk;
            if (chk) {
                angular.forEach(prtgrp.partners, function(selectedPartner) {
                    var index = $scope.metafinalPartnerDetails[currentPartnerType].findIndex(function(item, index) {
                        return ((item.partnerId === selectedPartner.partnerId) && (item.isGroup === !0)) ? !0 : !1
                    });
                    if (index == -1) {
                        $scope.metafinalPartnerDetails[currentPartnerType].push({
                            partnerId: selectedPartner.partnerId,
                            partner: selectedPartner.partnerName,
                            isGroup: !0
                        })
                    }
                })
            } else {
                $.each(prtgrp.partners, function(index0, row) {
                    $.each($scope.metafinalPartnerDetails[currentPartnerType], function(index1, res) {
                        if (row.partnerId == res.partnerId && res.isGroup == !0) {
                            $scope.metafinalPartnerDetails[currentPartnerType].splice(index1, 1);
                            return !1
                        }
                    })
                })
            }
        })
        angular.forEach($rootScope.metaPartn, function(value, key) {
            value.partnerDetails = angular.copy($scope.metafinalPartnerDetails[value.partnerTypeId])
        });
        $scope.getMetaDistributionStatus()
    }
    $scope.partnersGrpToggled = function(currentPartner, partnersGrp, chk) {
        if (Object.keys($scope.metafinalPartnerDetails).length == 0) {
            angular.forEach($scope.metaPartnerList, function(prtList) {
                $scope.metafinalPartnerDetails[prtList.partnerTypeId] = []
            })
        }
        var currentPartnerType = currentPartner.partnerTypeId;
        $scope.metapartGrp[currentPartnerType] = currentPartner.partnerGrps.every(function(itm) {
            return itm.selected
        })
        angular.forEach(partnersGrp.partners, function(selectedPartner) {
            if (chk) {
                var index = $scope.metafinalPartnerDetails[currentPartnerType].findIndex(function(item, index) {
                    return ((item.partnerId === selectedPartner.partnerId) && (item.isGroup === !0)) ? !0 : !1
                });
                if (index == -1) {
                    $scope.metafinalPartnerDetails[currentPartnerType].push({
                        partnerId: selectedPartner.partnerId,
                        partner: selectedPartner.partnerName,
                        isGroup: !0
                    })
                }
            } else {
                $.each($scope.metafinalPartnerDetails[currentPartnerType], function(index, row) {
                    if (selectedPartner.partnerId == row.partnerId && row.isGroup == !0) {
                        $scope.metafinalPartnerDetails[currentPartnerType].splice(index, 1);
                        return !1
                    }
                })
            }
            $scope.metaPushPopPartners(selectedPartner, chk, !0)
        })
        $scope.getMetaDistributionStatus()
    }
    $scope.$watch('metafinalPartnerDetails', function(newVal, oldVal) {
        $scope.metafinalPartnerNames = {}
        if (Object.keys($scope.metafinalPartnerNames).length == 0) {
            angular.forEach($scope.partnerList, function(prtList) {
                $scope.metafinalPartnerNames[prtList.partnerTypeId] = {}
                $scope.metafinalPartnerNames[prtList.partnerTypeId] = {}
            })
        }
        angular.forEach(newVal, function(value, key) {
            var values = "";
            if (value.length > 0) {
                angular.forEach(value, function(value1, key1) {
                    values += value[key1].partner + ", "
                });
                $scope.metafinalPartnerNames[key] = values
            }
        })
    }, !0)
}])