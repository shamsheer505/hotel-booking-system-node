app.controller('UserProfileController',['$scope','$http','Upload','$rootScope',function($scope,$http,Upload,$rootScope){$scope.oneAtATime=!1;$scope.basic_open=!1;$scope.showMessage=!1;$scope.toggleprofile=function(){$scope.showProfile=!$scope.showProfile}
$scope.sbmt_changePword=function(){$rootScope.showModal=!1;$scope.showMessage=!0}
$scope.hideAlert=function(){$scope.showMessage=!1}
$scope.userAccountFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.account,function(value){if(value==item.accountId)
result=!0})}catch(e){}
return result}
$scope.userMetadataTypeFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.metadataType,function(value){if(value==item.metadataTypeId)
result=!0})}catch(e){}
return result}
$scope.userProductCategoryFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.productCategory,function(value){if(value==item.productCategoryId)
result=!0})}catch(e){}
return result}
$scope.userMetadataGroupFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.metadataGroup,function(value){if(value==item.groupNameId)
result=!0})}catch(e){}
return result}
$scope.userPartnerTypeFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.partnerType,function(value){if(value==item.partnerTypeId)
result=!0})}catch(e){}
return result}
$scope.userApplicationFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.application,function(value){if(value==item.applicationId)
result=!0})}catch(e){}
return result}
$scope.userModuleFilter=function(item){var userRole;var result=!1;try{angular.forEach($scope.roleList,function(value){if(value.roleId==$rootScope.loggedUser.permissionGroup.roleId){userRole=value;return}});angular.forEach(userRole.module,function(value){if(value.moduleId==item.moduleId)
result=!0})}catch(e){}
return result}
$scope.viewFormatFilter=function(item){var per;var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.asset,function(value){if(value.permission=="VIEW"){per=value;return}});angular.forEach(per.format,function(value){if(value==item.formatId)
result=!0})}catch(e){}
return result}
$scope.uploadFormatFilter=function(item){var per;var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.asset,function(value){if(value.permission=="UPLOAD"){per=value;return}});angular.forEach(per.format,function(value){if(value==item.formatId)
result=!0})}catch(e){}
return result}
$scope.downloadFormatFilter=function(item){var per;var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.asset,function(value){if(value.permission=="DOWNLOAD"){per=value;return}});angular.forEach(per.format,function(value){if(value==item.formatId)
result=!0})}catch(e){}
return result}
$scope.shareFormatFilter=function(item){var per;var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.asset,function(value){if(value.permission=="SHARE"){per=value;return}});angular.forEach(per.format,function(value){if(value==item.formatId)
result=!0})}catch(e){}
return result}
$scope.deleteFormatFilter=function(item){var per;var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.asset,function(value){if(value.permission=="DELETE"){per=value;return}});angular.forEach(per.format,function(value){if(value==item.formatId)
result=!0})}catch(e){}
return result}
$scope.userReportFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.report,function(value){if(value==item.reportId)
result=!0})}catch(e){}
return result}
$scope.userAccessFilter=function(item){var result=!1;try{angular.forEach($rootScope.loggedUser.permissionGroup.administrator,function(value){if(value==item.accessId)
result=!0})}catch(e){}
return result}
$scope.resetForm=function(){$scope.user=angular.copy($rootScope.loggedUser)}
$scope.isFileSizeValid=!0;$scope.isFileDimensionValid=!0;$scope.isFileTypeValid=!0;$scope.updateUserProfilePicture=function(user_profile_image){$scope.isFileTypeValid=!0;$scope.isFileSizeValid=!0;$scope.isFileDimensionValid=!0;var _validFileExtensions=["jpg","jpeg","png"];var fr=new FileReader;fr.onload=function(){var file_extension=user_profile_image.files[0].type.split("/")[1];if(_validFileExtensions.indexOf(file_extension)!=-1){$scope.isFileTypeValid=!0;if(user_profile_image.files[0].size<10485760){$scope.isFileSizeValid=!0;var img=new Image;img.onload=function(){$scope.disableProfilePicUpload=!0;if(img.height>=150&&img.width>=150){Upload.upload({url:'/updateUserProfilePicture',data:{user_profile_image:user_profile_image.files[0]}}).then(function(response){$scope.disableProfilePicUpload=!1;$rootScope.accountUser();if(response.data.code=='200'){$scope.showUserProfileSuccessMsg=!0;$scope.userProfileSuccessMsg=response.data.statusMessage;setTimeout(function(){$scope.showUserProfileSuccessMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}else{$scope.showUserProfileErrorMsg=!0;$scope.userProfileErrorMsg=response.data.statusMessage;setTimeout(function(){$scope.showUserProfileErrorMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}},function errorCallback(error){console.log('Error status: '+error.status)});$scope.isFileDimensionValid=!0}else{$scope.isFileDimensionValid=!1;$scope.imageWidth=img.width;$scope.imageHeight=img.height;$scope.$apply()}};img.src=fr.result}else{$scope.isFileSizeValid=!1;$scope.$apply()}}else{$scope.isFileTypeValid=!1;$scope.fileType=file_extension;$scope.$apply()}};fr.readAsDataURL(user_profile_image.files[0])};$scope.saveUserInfo=function(BasicInfoForm){if(BasicInfoForm.$valid){$http({method:'POST',url:'/saveprofile',data:{firstName:$scope.user.firstNameFirst+" "+$scope.user.firstNameLast,firstNameFirst:$scope.user.firstNameFirst,firstNameLast:$scope.user.firstNameLast,contactNo:$scope.user.contactNo,address:$scope.user.address,city:$scope.user.city,zipCode:$scope.user.zipCode}}).then(function(response){if(response.data.code=='200'){$scope.toggleprofile();$rootScope.accountUser();$scope.showUserProfileSuccessMsg=!0;$scope.userProfileSuccessMsg=response.data.statusMessage;setTimeout(function(){$scope.showUserProfileSuccessMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}else{$scope.showUserProfileErrorMsg=!0;$scope.userProfileErrorMsg=response.data.statusMessage;setTimeout(function(){$scope.showUserProfileErrorMsg=!1;$scope.$apply()},$rootScope.alertTimeoutInterval)}},function errorCallback(error){console.log('Error status: '+error.status)})}};$scope.resetForm()}])