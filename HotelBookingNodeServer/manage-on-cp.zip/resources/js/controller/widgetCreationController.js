'use strict'
app.controller('widgetCreationController', ['$scope', '$window', '$rootScope', 'ModalService', '$timeout', '$http', '$routeParams', '$location', '$filter', '$q', 'httpCall', function($scope, $window, $rootScope, ModalService, $timeout, $http, $routeParams, $location, $filter, $q, httpCall) {
    $rootScope.testScroll();
    if (localStorage.getItem("isWidget") == "true") {
        $scope.isnavigationShow = !1
    } else {
        $scope.isnavigationShow = !0
    }
    $scope.swpPdfPages = [];
    $scope.swpPdfSelected = {
        pageLength: 0,
        pages: []
    };
    $scope.createbuttonDisable = !1;
    $scope.editbuttonDisable = !1;
    $scope.widgetPageList = [];
    $scope.widgetPageSelected = {
        pageLength: 0,
        pages: []
    };
    $rootScope.widget = {};
    $scope.focusDate = function() {
        angular.element('.angDatePicker').focus()
    }
    $scope.widgetFormSelected = []
    $scope.AddWidgetPages = function(pageType) {
        if (pageType == "PRINT") {
            for (var i = $rootScope.widgetForm.PrintpageFrom; i <= $rootScope.widgetForm.PrintpageTo; i++) {
                $rootScope.uniqueSelectedPageRange.push(i + $rootScope.widgetForm.printLabelPages)
            }
        } else {
            for (var i = $rootScope.widgetForm.pageFrom; i <= $rootScope.widgetForm.pageTo; i++) {
                $rootScope.uniqueSelectedPageRange.push(i)
            }
        }
        $rootScope.uniqueSelectedPageRange = Array.from(new Set($rootScope.uniqueSelectedPageRange)).sort(function(a, b) {
            return a - b
        });
        $scope.displayValue = angular.copy($rootScope.uniqueSelectedPageRange);
        $rootScope.widgetForm.PrintpageFrom = "";
        $rootScope.widgetForm.PrintpageTo = "";
        $rootScope.widgetForm.pageFrom = "";
        $rootScope.widgetForm.pageTo = "";
        $scope.setPages()
    }
    $scope.ToChanged = function(pageType) {
        if (pageType == "PRINT") {
            if ($rootScope.widgetForm.PrintpageFrom > $rootScope.widgetForm.PrintpageTo) {
                alert("Please select valid to page. From page is greater than to page");
                $rootScope.widgetForm.PrintpageTo = '';
                return !1
            }
        } else {
            if ($rootScope.widgetForm.pageFrom > $rootScope.widgetForm.pageTo) {
                alert("Please select valid to page. From page is greater than to page");
                $rootScope.widgetForm.pageTo = '';
                return !1
            }
        }
    }
    $scope.AddWidgetSelectedPages = function() {
        $scope.displayValue = [];
        $scope.displayValue = angular.copy($rootScope.uniqueSelectedPageRange)
    }
    $scope.setPages = function() {
        $scope.getWidgetPages();
        setTimeout(function() {
            angular.forEach($rootScope.uniqueSelectedPageRange, function(pageno) {
                angular.forEach($scope.swpPdfPages, function(value, key) {
                    var ttt = $rootScope.uniqueSelectedPageRange.indexOf(value.id);
                    if (ttt == -1) {
                        $scope.swpPdfPages[key].selected = !1
                    }
                    if (pageno == value.id) {
                        $scope.thumbSelect(value)
                    }
                })
            });
            $scope.$apply();
            $scope.widgetUnloading = !1;
            $scope.widgetContent = !0
        }, 10000)
    }
    $scope.getCurrentDate = function() {
        return moment(new Date()).format('YYYY/MM/DD')
    }
    $scope.wvminDate = 0;
    $scope.CreateNewWidget = function() {
        $scope.widgetCreationPage = !0;
        $rootScope.widgetForm.pageSelected = [];
        $rootScope.widgetForm.pageSelected = $rootScope.uniqueSelectedPageRange;
        $scope.createbuttonDisable = !0;
        if ($rootScope.widgetForm.buyurl == "default") {
            $scope.widgetForm.buyURL = "https://www.bloomsbury.com"
        } else {
            $scope.widgetForm.buyURL = $scope.widgetForm.otherurl
        }
        $http({
            method: 'POST',
            url: '/WidgetSubmit',
            data: {
                "pageName": "widget",
                "widgetName": $rootScope.widgetForm.widgetName,
                "isbn": localStorage.getItem("viewerISBN"),
                "formatId": localStorage.getItem("viewerFormat"),
                "expiryDate": $rootScope.widgetForm.expiryDate,
                "range": $scope.range,
                "viewPages": $rootScope.widgetForm.pageSelected,
                "buyURL": $scope.widgetForm.buyURL,
                "pageType": $rootScope.widgetForm.pageType
            }
        }).then(function(response) {
            $scope.widgetBasicInfo = response.data.data;
            var port = $location.port();
            var portStr = "";
            if (port != "443" && port != "80") {
                var portStr = ":" + $location.port()
            }
            var host = $location.protocol() + "://" + $location.host() + portStr;
            $rootScope.widgetForm.urlPreview = host + "/viewer/" + $scope.widgetBasicInfo.id;
            $rootScope.widgetForm.urlWidget = host + "/widget/" + $scope.widgetBasicInfo.id;
            $rootScope.widgetForm.image = $scope.widgetBasicInfo.image;
            $rootScope.widgetForm.buyURL = $scope.widgetBasicInfo.buyURL;
            $scope.createbuttonDisable = !1;
            $scope.showWidgetCreateMsg = !0;
            setTimeout(function() {
                $scope.showWidgetCreateMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
            $scope.widgetCreation = !$scope.widgetCreation
        })
    }
    $scope.EditWidget = function() {
        $scope.editbuttonDisable = !0;
        $rootScope.widgetForm.pageSelected = [];
        $rootScope.widgetForm.pageSelected = $rootScope.uniqueSelectedPageRange;
        if ($rootScope.widgetForm.buyurl == "default") {
            $scope.widgetForm.buyURL = "https://www.bloomsbury.com"
        } else {
            $scope.widgetForm.buyURL = $scope.widgetForm.otherurl
        }
        $http({
            method: 'POST',
            url: '/WidgetEdit',
            data: {
                "pageName": "widget",
                "id": $rootScope.widgetForm.editId,
                "widgetName": $rootScope.widgetForm.widgetName,
                "isbn": $rootScope.widgetForm.isbn,
                "formatId": $rootScope.widgetForm.formatId,
                "expiryDate": $rootScope.widgetForm.expiryDate,
                "viewPages": $rootScope.widgetForm.pageSelected,
                "buyURL": $scope.widgetForm.buyURL
            }
        }).then(function(response) {
            $scope.widgetBasicInfo = response.data.data;
            var port = $location.port();
            var portStr = "";
            if (port != "443" && port != "80") {
                var portStr = ":" + $location.port()
            }
            var host = $location.protocol() + "://" + $location.host() + portStr;
            $rootScope.widgetForm.urlPreview = host + "/viewer/" + $scope.widgetBasicInfo.id;
            $rootScope.widgetForm.urlWidget = host + "/widget/" + $scope.widgetBasicInfo.id;
            $rootScope.widgetForm.buyURL = $scope.widgetBasicInfo.buyURL;
            $scope.editbuttonDisable = !1;
            $scope.showWidgetEditMsg = !0;
            setTimeout(function() {
                $scope.showWidgetEditMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
            $scope.widgetCreation = !$scope.widgetCreation
        })
    }
    $rootScope.getRoles = function() {
        $http({
            method: 'GET',
            url: '/getRoles'
        }).then(function successCallback(response) {
            if ($rootScope.loggedUser != undefined && $rootScope.loggedUser != null) {
                $scope.widgetloggedUserRole = $filter('filter')(response.data.data, function(data) {
                    return (data.roleId == $rootScope.loggedUser.permissionGroup.roleId)
                })[0]
            }
        }, function errorCallback(response) {})
    };
    $scope.checkAccessPerm = function(moduleId, accessId, tabName) {
        var returnFlg = !1;
        if ($scope.widgetloggedUserRole != undefined) {
            angular.forEach($scope.widgetloggedUserRole.module, function(module) {
                if (module.moduleId === moduleId) {
                    angular.forEach(module.submodule, function(val) {
                        if (val.accessId == accessId) {
                            var index = val.activityAccess.indexOf(tabName);
                            if (index != -1)
                                returnFlg = !0;
                            return
                        }
                    })
                }
            })
        }
        return returnFlg
    };
    $scope.widgetUnloading = !0;
    $scope.widgetContent = !1;
    $scope.setWidgetData = function(editData, entireData, pageType) {
        $scope.widgetUnloading = !0;
        $scope.widgetContent = !1;
        $rootScope.uniqueSelectedPageRange = angular.copy(editData.viewPages);
        $rootScope.widgetForm = {};
        $rootScope.widgetForm.isset = "true";
        $rootScope.widgetForm.activity = "Update";
        $rootScope.widgetForm.pageType = "PRINT";
        $rootScope.widgetForm.pageNos = [];
        $rootScope.widgetForm.pageNosPrint = [];
        if (pageType == "viewer") {
            var pageCnt = entireData.pageCount;
            var PrintpageCnt = entireData.pageModel.pagesWithPageNumbers.pageLabelsDifference;
            $rootScope.widgetForm.printLabelPages = entireData.pageModel.pagesWithPageNumbers.pageLabelsStart - 1;
            for (var i = 1; i <= pageCnt; i++) {
                $rootScope.widgetForm.pageNos.push(i)
            }
            for (var i = 1; i <= PrintpageCnt; i++) {
                $rootScope.widgetForm.pageNosPrint.push(i)
            }
            $scope.setEditvalues(editData)
        } else {
            $http({
                method: 'POST',
                url: '/widgetview',
                data: {
                    "id": editData.id,
                    "isbn": editData.ISBN,
                    "formatId": editData.formatId,
                    "widgetName": editData.widgetName,
                    "range": editData.range,
                    "pageName": 'widget'
                }
            }).then(function(response) {
                $scope.respstatus = response.data.code;
                if (response.data.code == "401") {
                    alert("widget expired")
                } else {
                    $rootScope.widget_detail = response.data.data;
                    var pageCnt = $rootScope.widget_detail.pageCount;
                    var PrintpageCnt = $rootScope.widget_detail.pageModel.pagesWithPageNumbers.pageLabelsDifference;
                    $rootScope.widgetForm.printLabelPages = $rootScope.widget_detail.pageModel.pagesWithPageNumbers.pageLabelsStart - 1;
                    for (var i = 1; i <= pageCnt; i++) {
                        $rootScope.widgetForm.pageNos.push(i)
                    }
                    for (var i = 1; i <= PrintpageCnt; i++) {
                        $rootScope.widgetForm.pageNosPrint.push(i)
                    }
                    $scope.setEditvalues(editData)
                }
            })
        }
    }
    $scope.setEditvalues = function(editData) {
        $rootScope.widgetForm.widgetName = editData.widgetName;
        $rootScope.widgetForm.editId = editData.id;
        $scope.widgetBasicInfo = editData;
        var port = $location.port();
        var portStr = "";
        if (port != "443" && port != "80") {
            var portStr = ":" + $location.port()
        }
        var host = $location.protocol() + "://" + $location.host() + portStr;
        $rootScope.widgetForm.urlPreview = host + "/viewer/" + $scope.widgetBasicInfo.id;
        $rootScope.widgetForm.urlWidget = host + "/widget/" + $scope.widgetBasicInfo.id;
        $rootScope.widgetForm.image = $scope.widgetBasicInfo.image;
        $rootScope.widgetForm.buyURL = $scope.widgetBasicInfo.buyURL;
        editData.viewPages.sort(function(a, b) {
            return a - b
        });
        if (editData.range == "true") {
            $rootScope.widgetForm.viewpageType = 'range';
            $rootScope.widgetForm.pageFrom = editData.viewPages[0];
            $rootScope.widgetForm.pageTo = editData.viewPages[editData.viewPages.length - 1]
        } else {
            $rootScope.widgetForm.viewpageType = 'pageSelect'
        }
        $rootScope.widgetForm.buyurl = 'default';
        $rootScope.widgetForm.expiryDate = (editData.expiryDate == "Unlimited") ? "" : editData.expiryDate;
        if (editData.ISBN == undefined && editData.formatId == undefined) {
            $rootScope.widgetForm.isbn = localStorage.getItem("viewerISBN");
            $rootScope.widgetForm.formatId = localStorage.getItem("viewerFormat")
        } else {
            $rootScope.widgetForm.isbn = editData.ISBN;
            $rootScope.widgetForm.formatId = editData.formatId
        }
        $timeout(function() {
            location.href = '#widget-action'
        }, 1000)
    }
    $scope.removeWidget = function(pageType) {
        $http({
            method: 'POST',
            url: '/removeWidget',
            data: {
                "id": $scope.deleteId
            }
        }).then(function(response) {
            $scope.showWidgetDelSuccessMsg = !0;
            if (pageType == 'viewer') {
                angular.forEach($rootScope.widget_detail.relatedWidgets, function(value, key) {
                    if (value.id == $scope.deleteId) {
                        $rootScope.widget_detail.relatedWidgets.splice(key, 1)
                    }
                })
            } else {
                $rootScope.viewWidgetDashboard(0, '', !1)
            }
            setTimeout(function() {
                $scope.showWidgetDelSuccessMsg = !1;
                $scope.$apply()
            }, $rootScope.alertTimeoutInterval)
        })
    }
    $scope.previewUrlLink = function(widgetId) {
        var port = $location.port();
        var portStr = "";
        if (port != "443" && port != "80") {
            var portStr = ":" + $location.port()
        }
        var host = $location.protocol() + "://" + $location.host() + portStr;
        var viewerUrl = host + "/widget/" + widgetId;
        return viewerUrl
    }
    $scope.viewerUrlLink = function(widgetId) {
        var port = $location.port();
        var portStr = "";
        if (port != "443" && port != "80") {
            var portStr = ":" + $location.port()
        }
        var host = $location.protocol() + "://" + $location.host() + portStr;
        var viewerUrl = host + "/viewer/" + widgetId;
        return viewerUrl
    }
    $scope.deleteWidgetModal = function(deleteData) {
        $scope.deleteId = deleteData.id;
        $('#deleteWidget').modal('toggle')
    }
    $scope.dateOptions = {
        disabled: !1,
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };
    $scope.open1 = function() {
        $scope.popup1.opened = !0
    };
    $scope.popup1 = {
        opened: !1
    };
    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];
    $scope.getWidgetPages = function() {
        var start_page = 1,
            end_page = $rootScope.widget_detail.pageCount;
        if (!$scope.swpPdfPages.length) {
            PDFJS.getDocument($rootScope.widget_detail.widgetURL).promise.then(function(doc) {
                var pages = [];
                if (end_page > doc.numPages || start_page > doc.numPages) {
                    return
                }
                for (var i = start_page; i <= end_page; i++) {
                    pages.push(i)
                }
                return Promise.all(pages.map(function(num) {
                    doc.getPage(num).then(function(page) {
                        $scope.$apply(function() {
                            if ($scope.swpPdfPages.length === 0) {
                                $scope.swpPdfPages.push({
                                    id: num,
                                    pdf_page: page,
                                    selected: !1,
                                    active: !0
                                })
                            } else {
                                $scope.swpPdfPages.push({
                                    id: num,
                                    pdf_page: page,
                                    selected: !1,
                                    active: !1
                                })
                            }
                        })
                    })
                }))
            }).catch(console.error)
        }
    };
    $scope.thumbSelect = function(data) {
        angular.forEach($scope.swpPdfPages, function(value, key) {
            if (value.id == data.id) {
                if ($rootScope.widgetForm.viewpageType == "pageSelect") {
                    if ($scope.swpPdfPages[key].selected == !0) {
                        $rootScope.uniqueSelectedPageRange.splice($rootScope.uniqueSelectedPageRange.indexOf(data.pdf_page.pageNumber), 1);
                        angular.forEach($scope.swpPdfSelected.pages, function(value1, key1) {
                            if (value1.id == data.id) {
                                $scope.swpPdfSelected.pages.splice(key1, 1)
                            }
                        });
                        $scope.swpPdfSelected.pageLength = $scope.swpPdfSelected.pages.length;
                        $scope.swpPdfPages[key].selected = !1
                    } else {
                        $rootScope.uniqueSelectedPageRange.push(data.pdf_page.pageNumber);
                        $scope.swpPdfPages[key].selected = !0;
                        $scope.swpPdfSelected.pages.push(data);
                        $scope.swpPdfSelected.pageLength = $scope.swpPdfSelected.pages.length
                    }
                    $rootScope.uniqueSelectedPageRange = Array.from(new Set($rootScope.uniqueSelectedPageRange)).sort(function(a, b) {
                        return a - b
                    })
                }
                if ($rootScope.widgetForm.viewpageType == "range") {
                    $scope.swpPdfPages[key].selected = !0;
                    $scope.swpPdfSelected.pages.push(data);
                    $scope.swpPdfSelected.pageLength = $scope.swpPdfSelected.pages.length
                }
            }
        });
        $scope.widgetPageList = $scope.swpPdfPages;
        $scope.widgetPageSelected = $scope.swpPdfSelected
    }
    if ($location.$$path.contains("/widget-action")) {
        if ($rootScope.widgetForm.isset == "true" && angular.element('#pageTo').length > 0) {
            $rootScope.widgetForm.isset = "false";
            $scope.widgetCreationPage = !0;
            $timeout(function() {
                $scope.setPages()
            }, 1000)
        } else {
            $scope.widgetUnloading = !1;
            $scope.widgetContent = !0;
            $scope.widgetCreationPage = !1
        }
    }
    $rootScope.widgetRow = 0;
    $rootScope.widgetSellerRow = 0;
    $rootScope.searchValue = "";
    $scope.showSuccessSearchSaveMsg = !1;
    $rootScope.Search = {};
    $rootScope.Search.HeaderSearch = {};
    $rootScope.Search.AdvancedSearch = {};
    $rootScope.Search.ImprintAssetSearch = {};
    $rootScope.Search.fieldDisplayName;
    $scope.existsError = !1;
    $rootScope.viewAll = "MENU.LABLE.VIEWALL";
    $rootScope.imprintName = "";
    $rootScope.assetStatus = "";
    $rootScope.searchResult = [];
    $rootScope.searchName;
    $rootScope.customHeadersDisplayName = [];
    $rootScope.customHeadersDisplayOrder = [];
    $rootScope.widgetaccountFilterList = [];
    $rootScope.widgetimprintFilterList = [];
    $rootScope.GlobalImprintList = [];
    $rootScope.GlobalOthersList = [];
    $rootScope.formatFilterList = [];
    $rootScope.formatCodeList = [];
    $rootScope.widgetpCategoryFilterList = [];
    $rootScope.statusFilterList = [];
    $rootScope.othersFilterList = [];
    $rootScope.columnFilterList = {};
    $rootScope.searchCount = "";
    $rootScope.selectedAccounts = [];
    $scope.widgetimgAllSelected;
    $rootScope.columnFilterSearch = {};
    $rootScope.viewWidgetDashboard = function(skipCountVal, widgetAdvanceFilterFlag, columnFilterFlg) {
        $rootScope.showLoader($('.table-tab-container'), 1, 'win8_linear');
        if (widgetAdvanceFilterFlag == 'R') {
            $rootScope.Search.AdvancedSearch.accounts = $rootScope.widgetselectedAccounts;
            $rootScope.Search.AdvancedSearch.imprints = $rootScope.widgetimprintFilterList;
            $rootScope.Search.AdvancedSearch.productCategories = $rootScope.widgetselectedProductCategoryArraySearch
        }
        $http({
            method: 'POST',
            url: '/viewWidgetDashboard',
            data: {
                skipCount: skipCountVal,
                pageName: "widgetDashboard",
                advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
            }
        }).then(function(response) {
            $rootScope.listWidgetDashboard = response.data.data;
            $rootScope.listWidgetDashboarddata = response.data;
            $rootScope.hideLoader('table-tab-container')
        })
    };
    $scope.showLoadMore = function() {
        if (($rootScope.listWidgetDashboard == null) || ($rootScope.listWidgetDashboarddata.searchCount == $rootScope.listWidgetDashboard.length)) {
            return !1
        }
        return !0
    }
    $scope.widgetLoadMore = function(startIndex) {
        $scope.widgetLoading = !0;
        $http({
            method: 'POST',
            url: '/viewWidgetDashboard',
            data: {
                skipCount: startIndex,
                pageName: "widgetDashboard",
                advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
            }
        }).then(function(response) {
            $scope.widgetLoading = !1;
            $rootScope.listWidgetDashboard = $rootScope.listWidgetDashboard.concat(response.data.data);
            $rootScope.listWidgetDashboarddata = response.data
        })
    }
    $rootScope.viewWidgetBestSeller = function(skipCountVal) {
        $http({
            method: 'POST',
            url: '/viewWidgetBestSeller',
            data: {
                skipCount: skipCountVal
            }
        }).then(function(response) {
            $rootScope.listWidgetBestSeller = response.data.data
        })
    };
    if ($location.$$url != "/widget-action") {
        $rootScope.viewWidgetDashboard($rootScope.widgetRow, '', !1);
        $rootScope.viewWidgetBestSeller($rootScope.widgetSellerRow);
        $rootScope.getRoles()
    }
    $scope.filterSuggestions = [];
    $scope.getSearchColumnSuggestion = function(type) {
        $http({
            method: 'POST',
            url: '/getSearchWidgetColumnSuggestion',
            data: {
                "pageName": "widgetDashboard",
                "advancedSearch": Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
                "fieldDisplayName": type,
                "columnFilterValues": $rootScope.columnFilterValues,
                "searchText": $scope.headersrch[type]
            }
        }).then(function(response) {
            $scope.filterSuggestions[type] = response.data.data;
            if (($rootScope.columnFilterValues[type]) != undefined && ($scope.filterSuggestions[type].length > 0)) {
                angular.forEach($rootScope.columnFilterValues[type], function(value, key) {
                    angular.forEach($scope.filterSuggestions[type], function(value1, key1) {
                        if (value == value1.code) {
                            value1.selected = !0
                        }
                    })
                })
            }
        })
    };
    $rootScope.checkallwidgetColumnFilter = function($event, type) {
        var ischeckedall = $event.target.checked
        angular.forEach($scope.filterSuggestions[type], function(value, key) {
            $rootScope.checkWidgetItems($event, type, value.code);
            if (ischeckedall) {
                value.selected = !0
            } else {
                value.selected = !1
            }
        });
        if (ischeckedall) {
            $rootScope.widcheckAll[type] = !0
        } else {
            $rootScope.widcheckAll[type] = !1
        }
    }
    $rootScope.columnFilterValues = {};
    $rootScope.widcheckAll = {};
    $scope.isObjectEmpty = function(card) {
        return Object.keys(card).length === 0
    }
    $scope.removeItems = function(type, value) {
        var delIndex = $rootScope.columnFilterValues[type].indexOf(value);
        $rootScope.columnFilterValues[type].splice(delIndex, 1);
        angular.forEach($rootScope.columnFilterValues, function(value, key) {
            if (value.length == 0)
                delete $rootScope.columnFilterValues[key]
        });
        if ($scope.filterSuggestions[type].length > 0) {
            angular.forEach($scope.filterSuggestions[type], function(value1, key1) {
                if (value == value1.code) {
                    value1.selected = !1
                }
            })
        }
        $scope.viewDashboardAftRemove(type)
    }
    $scope.removeDateItems = function(index, category) {
        if (category == "Created") {
            (index == 0) ? $scope.createdOn.From = "": $scope.createdOn.To = "";
            $scope.createdDate[index] = "";
            if (($scope.createdDate[0] == "") && ($scope.createdDate[1] == "")) {
                $scope.createdDate = [];
                delete $rootScope.columnFilterValues.createdOn;
                if ($rootScope.columnFilterValues.createdBy == "") {
                    delete $rootScope.columnFilterValues.createdBy
                }
            }
            var fieldType = "createdBy"
        } else {
            (index == 0) ? $scope.modifiedOn.From = "": $scope.modifiedOn.To = "";
            $scope.modifiedDate[index] = "";
            if (($scope.modifiedDate[0] == "") && ($scope.modifiedDate[1] == "")) {
                $scope.modifiedDate = [];
                delete $rootScope.columnFilterValues.modifiedOn;
                if ($rootScope.columnFilterValues.modifiedBy == "") {
                    delete $rootScope.columnFilterValues.modifiedBy
                }
            }
            var fieldType = "modifiedBy"
        }
        $scope.viewDashboardAftRemove(fieldType)
    }
    $scope.viewDashboardAftRemove = function(fieldType) {
        $rootScope.showLoader($('.table-tab-container'), 1, 'win8_linear');
        $http({
            method: 'POST',
            url: '/viewWidgetDashboard',
            data: {
                pageName: "widgetDashboard",
                advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
                "fieldDisplayName": fieldType,
                "columnFilterValues": $rootScope.columnFilterValues,
                "searchText": ""
            }
        }).then(function(response) {
            $rootScope.hideLoader('table-tab-container');
            $rootScope.listWidgetDashboard = response.data.data;
            $rootScope.listWidgetDashboarddata = response.data
        })
    }
    $scope.widgetSelectVal = "Descending";
    $rootScope.checkWidgetItems = function($event, type, selectedValue, selectVal) {
        var sortBy = $scope.sortBy == undefined ? null : $scope.sortBy;
        if (null == selectVal || "" == selectVal)
            $scope.widgetSelectVal = "Descending";
        else $scope.widgetSelectVal = selectVal;
        if (type != "sortBy") {
            if (type != "createdOn" && type != "modifiedOn") {
                $scope.fieldDispType = type;
                $rootScope.showLoader($('.widget-list'), 1, 'win8_linear');
                var ischecked = $event.target.checked;
                if ($rootScope.columnFilterValues[type] == undefined) {
                    $rootScope.columnFilterValues[type] = []
                }
                if (type == 'createdBy' || type == 'modifiedBy') {
                    var newType = type + "Name";
                    if ($rootScope.columnFilterValues[newType] == undefined) {
                        $rootScope.columnFilterValues[newType] = []
                    }
                    var splitedArr = selectedValue.split(":::");
                    var currentValue = splitedArr[0];
                    var currentadditionslValue = splitedArr[1];
                    if (ischecked) {
                        $rootScope.columnFilterValues[newType].push(currentadditionslValue)
                    } else {
                        for (var i = 0; i < $rootScope.columnFilterValues[newType].length; i++) {
                            var cur = $rootScope.columnFilterValues[newType][i];
                            if (cur == currentadditionslValue) {
                                $rootScope.columnFilterValues[newType].splice(i, 1);
                                break
                            }
                        }
                    }
                } else {
                    var currentValue = selectedValue
                }
                if (ischecked) {
                    $rootScope.columnFilterValues[type].push(currentValue)
                } else {
                    for (var i = 0; i < $rootScope.columnFilterValues[type].length; i++) {
                        var cur = $rootScope.columnFilterValues[type][i];
                        if (cur == currentValue) {
                            $rootScope.columnFilterValues[type].splice(i, 1);
                            break
                        }
                    }
                }
                $scope.count = 0;
                $rootScope.widcheckAll[type] = $scope.filterSuggestions[type].every(function(itm) {
                    return itm.selected
                });
                angular.forEach($rootScope.columnFilterValues, function(value, key) {
                    if (value.length == 0)
                        delete $rootScope.columnFilterValues[key]
                })
            } else {
                if (type == "createdOn") {
                    $scope.createdDate = ["", ""];
                    $scope.fieldDispType = "createdOn";
                    $scope.createdDate[0] = $scope.createdOn.From != undefined ? $scope.createdOn.From : "";
                    $scope.createdDate[1] = $scope.createdOn.To != undefined ? $scope.createdOn.To : "";
                    $rootScope.columnFilterValues[type] = $scope.createdDate
                } else {
                    $scope.modifiedDate = ["", ""];
                    $scope.fieldDispType = "modifiedOn";
                    $scope.modifiedDate[0] = $scope.modifiedOn.From != undefined ? $scope.modifiedOn.From : "";
                    $scope.modifiedDate[1] = $scope.modifiedOn.To != undefined ? $scope.modifiedOn.To : "";
                    $rootScope.columnFilterValues[type] = $scope.modifiedDate
                }
                if ($rootScope.columnFilterValues[$scope.fieldDispType] == undefined) {
                    $rootScope.columnFilterValues[$scope.fieldDispType] = [];
                    $scope.headersrch = []
                }
            }
        }
        if ($scope.fieldDispType !== undefined && ($scope.fieldDispType != "modifiedOn" && $scope.fieldDispType != "createdOn")) {
            var SearchText = $scope.headersrch[$scope.fieldDispType] == undefined ? "" : $scope.headersrch[$scope.fieldDispType]
        }
        $http({
            method: 'POST',
            url: '/viewWidgetDashboard',
            data: {
                pageName: "widgetDashboard",
                advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
                "fieldDisplayName": $scope.fieldDispType,
                "columnFilterValues": $rootScope.columnFilterValues,
                "searchText": SearchText,
                "sortBy": sortBy
            }
        }).then(function(response) {
            $rootScope.hideLoader('widget-list');
            $rootScope.listWidgetDashboard = response.data.data;
            $rootScope.listWidgetDashboarddata = response.data
        })
    };
    $rootScope.widgetaccountFilterList = [];
    $rootScope.widgetselectedAccounts = [];
    $rootScope.widgetimprintFilterList = [];
    $rootScope.widgetpCategoryFilterList = [];
    $rootScope.widgetregionAllSelect = function($event) {
        $rootScope.widgetaccountFilterList = [];
        $rootScope.widgetselectedAccounts = [];
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        var widgetfilteredAccountList = $rootScope.accountList;
        if (action === 'add') {
            angular.forEach(widgetfilteredAccountList, function(acl) {
                document.getElementById("widgetregion_" + acl.accountName).checked = !0;
                $rootScope.widgetaccountFilterList.push(acl);
                $rootScope.widgetselectedAccounts.push(acl.accountId)
            })
        } else if (action === 'remove') {
            angular.forEach(widgetfilteredAccountList, function(acl) {
                document.getElementById("widgetregion_" + acl.accountName).checked = !1
            })
        }
        $rootScope.getImprints();
        $rootScope.getProductCategoriesForSearch();
        setTimeout(function() {
            $rootScope.getWidgetSelectedSearchFilterProductCategories();
            $rootScope.viewWidgetDashboard(0, 'R', !1)
        }, 200)
    };
    $rootScope.getAccounts = function() {
        $rootScope.accountMetadataMappingFieldValueAvailableList = [];
        $http({
            method: 'GET',
            url: '/getAccounts'
        }).then(function successCallback(response) {
            $rootScope.accountList = response.data.data.accountList;
            $rootScope.accountMetadataMappedFieldName = response.data.data.metadataMappedFieldName;
            $rootScope.accountMetadataMappedFieldLabel = response.data.data.metadataMappedFieldLabel;
            $rootScope.accountMetadataMappingFieldValueList = response.data.data.metadataMappingFieldValueList;
            angular.forEach(response.data.data.metadataMappingFieldValueAvailableList, function(mappingValue) {
                if (mappingValue != null && mappingValue != 'null' && mappingValue.trim() != '')
                    $rootScope.accountMetadataMappingFieldValueAvailableList.push({
                        "name": mappingValue,
                        selected: !1
                    })
            })
        }, function errorCallback(response) {})
    };
    $rootScope.getImprints = function() {
        var accountArray = $rootScope.widgetselectedAccounts;
        $http({
            method: 'GET',
            url: '/getImprintListForAccounts/' + accountArray.toString()
        }).then(function successCallback(response) {
            $rootScope.imprintList = response.data.data;
            var temp = $.grep($rootScope.widgetimprintFilterList, function(element) {
                return $.inArray(element, $rootScope.imprintList) !== -1
            });
            $rootScope.widgetimprintFilterList = temp;
            if (document.getElementById("widgetimAllSelected") != null && document.getElementById("widgetimAllSelected") != undefined) {
                if ($rootScope.imprintList.length === $rootScope.widgetimprintFilterList.length && $rootScope.imprintList.length != 0)
                    document.getElementById("widgetimAllSelected").checked = !0;
                else document.getElementById("widgetimAllSelected").checked = !1
            }
        }, function errorCallback(response) {})
    };
    $rootScope.widgetproductCategoryList = angular.copy($rootScope.productCategoryList);
    $rootScope.widgetproductCategoryTreeList = $rootScope.getNestedChildren($rootScope.widgetproductCategoryList, null);
    $rootScope.widgetaddAccountTags = function(input, checkAcct) {
        var checkCount = 0;
        if (checkAcct) {
            $rootScope.widgetaccountFilterList.push(input);
            $rootScope.widgetselectedAccounts.push(input.accountId)
        } else {
            $rootScope.widgetaccountFilterList.splice($rootScope.widgetaccountFilterList.indexOf(input), 1);
            $rootScope.widgetselectedAccounts.splice($rootScope.widgetselectedAccounts.indexOf(input.accountId), 1)
        }
        var widgetfilteredAccountList = $rootScope.accountList;
        angular.forEach(widgetfilteredAccountList, function(acl) {
            if (document.getElementById("widgetregion_" + acl.accountName).checked) checkCount++
        });
        $timeout(function() {
            $rootScope.widgetregionAllSelected = (checkCount === widgetfilteredAccountList.length);
            document.getElementById("widgetregionAllSelected").checked = (checkCount === widgetfilteredAccountList.length)
        }, 100);
        $rootScope.getImprints();
        setTimeout(function() {
            $rootScope.viewWidgetDashboard(0, 'R', !1)
        }, 200)
    };
    $rootScope.widgetaddImprintTags = function(input, checkImprint) {
        var checkCount = 0;
        if (checkImprint) {
            $rootScope.widgetimprintFilterList.push(input)
        } else {
            $rootScope.widgetimprintFilterList.splice($scope.widgetimprintFilterList.indexOf(input), 1)
        }
        angular.forEach($rootScope.imprintList, function(item) {
            if (document.getElementById("widgetimprint_" + item).checked) checkCount++
        });
        $timeout(function() {
            $rootScope.widgetimAllSelected = (checkCount === $rootScope.imprintList.length);
            document.getElementById("widgetimAllSelected").checked = (checkCount === $rootScope.imprintList.length)
        }, 100);
        $rootScope.viewWidgetDashboard(0, 'R', !1)
    };
    $rootScope.widgetimprintAllSelect = function($event) {
        $rootScope.widgetimprintFilterList = [];
        var checkbox = $event.target;
        var action = (checkbox.checked ? 'add' : 'remove');
        if (action === 'add') {
            angular.forEach($rootScope.imprintList, function(imp) {
                document.getElementById("widgetimprint_" + imp).checked = !0;
                $rootScope.widgetimprintFilterList.push(imp)
            })
        } else if (action === 'remove') {
            angular.forEach($rootScope.imprintList, function(imp) {
                document.getElementById("widgetimprint_" + imp).checked = !1
            })
        }
        $rootScope.viewWidgetDashboard(0, 'R', !1)
    }
    $rootScope.clearAlltags = function() {
        $rootScope.columnFilterValues = {};
        $rootScope.widcheckAll = {};
        $scope.filterSuggestions = [];
        $scope.headersrch = [];
        $rootScope.widgetaccountFilterList = [];
        $rootScope.widgetimprintFilterList = [];
        $rootScope.widgetpCategoryFilterList = [];
        document.getElementById("widgetimAllSelected").checked = !1;
        document.getElementById("widgetregionAllSelected").checked = !1;
        document.getElementById("widgetpCateoryAllSelected").checked = !1;
        angular.forEach($rootScope.imprintList, function(imp) {
            document.getElementById("widgetimprint_" + imp).checked = !1
        });
        angular.forEach($rootScope.accountList, function(acl) {
            document.getElementById("widgetregion_" + acl.accountName).checked = !1
        });
        $rootScope.widgettraverseSearchTree($rootScope.widgetproductCategoryTreeList, "UNSELECT");
        $rootScope.viewWidgetDashboard($rootScope.widgetRow, '', !1)
    }
    $rootScope.widgetpCateoryAllSelect = function(chkFlg) {
        $rootScope.widget.widgetpCateoryAllSelected = chkFlg;
        if (chkFlg)
            $rootScope.widgettraverseSearchTree($rootScope.widgetproductCategoryTreeList, "SELECT");
        else $rootScope.widgettraverseSearchTree($rootScope.widgetproductCategoryTreeList, "UNSELECT");
        $rootScope.getWidgetSelectedSearchFilterProductCategories();
        setTimeout(function() {
            $rootScope.viewWidgetDashboard(0, 'R', !1)
        }, 100)
    }
    $rootScope.cpRemovewidget = function(filterCategory, val) {
        $rootScope.searchResult = [];
        if (filterCategory == "ACCOUNT") {
            if ($rootScope.widgetaccountFilterList.length > 0) {
                $rootScope.widgetselectedAccounts.splice(val.accountId, 1);
                document.getElementById("widgetregion_" + val.accountName).checked = !1;
                $rootScope.widgetaccountFilterList.splice(val, 1);
                document.getElementById("widgetregionAllSelected").checked = !1;
                $rootScope.getImprints();
                $rootScope.getProductCategoriesForSearch();
                if ($rootScope.widgetaccountFilterList.length === 0 && $rootScope.widgetimprintFilterList.length === 0 && $rootScope.widgetpCategoryFilterList.length === 0) {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                } else {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                }
            }
        } else if (filterCategory == "IMPRINT") {
            if ($rootScope.widgetimprintFilterList.length > 0) {
                document.getElementById("widgetimprint_" + val).checked = !1;
                document.getElementById("widgetimAllSelected").checked = !1;
                $rootScope.widgetimprintFilterList.splice($rootScope.widgetimprintFilterList.indexOf(val), 1);
                $scope.widgetimAllSelected = !1;
                if ($rootScope.widgetaccountFilterList.length === 0 && $rootScope.widgetimprintFilterList.length === 0 && $rootScope.widgetpCategoryFilterList.length === 0) {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                } else {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                }
            }
        } else if (filterCategory == "PRODUCTCATEGORY") {
            $rootScope.widgetpCategoryFilterList.splice($rootScope.widgetpCategoryFilterList.indexOf(val), 1);
            val.selected = !1;
            if (val.children && val.children.length > 0) {
                $rootScope.widgettraverseSearchTree(val.children, "UNSELECT")
            }
            $rootScope.widget.widgetpCateoryAllSelected = !1;
            $scope.getWidgetSelectedSearchFilterProductCategories();
            setTimeout(function() {
                if ($rootScope.widgetaccountFilterList.length === 0 && $rootScope.widgetimprintFilterList.length === 0 && $rootScope.widgetpCategoryFilterList.length === 0) {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                } else {
                    $rootScope.viewWidgetDashboard(0, 'R', !1)
                }
            }, 100)
        }
    };
    $rootScope.widget.widgetpCateoryAllSelected = !1;
    $rootScope.searchClearAllwidget = function() {
        $http({
            method: 'GET',
            url: '/getMetaDataTypes',
            data: null
        }).then(function(response) {
            $rootScope.metaDataTypes = response.data.data;
            $rootScope.mDataType = $rootScope.metaDataTypes[0].metadataTypeName;
            $rootScope.mCategory = $rootScope.metaDataTypes[0].categories[0].description;
            $rootScope.searchFieldName = $rootScope.metaDataTypes[0].categories[0].fieldDisplayName;
            $rootScope.mTypeTitle = $rootScope.metaDataTypes[0].categories[0].displayName;
            $rootScope.searchValue = ""
        });
        if ($rootScope.widgetaccountFilterList.length > 0) {
            angular.forEach($rootScope.widgetaccountFilterList, function(value, key) {
                document.getElementById("widgetregion_" + value.accountName).checked = !1
            });
            document.getElementById("widgetregionAllSelected").checked = !1
        }
        if ($rootScope.widgetimprintFilterList.length > 0) {
            angular.forEach($rootScope.widgetimprintFilterList, function(value, key) {
                document.getElementById("widgetimprint_" + value).checked = !1
            });
            document.getElementById("widgetimAllSelected").checked = !1
        }
        $rootScope.widget.widgetpCateoryAllSelected = !1;
        $rootScope.widgettraverseSearchTree($rootScope.widgetproductCategoryTreeList, "UNSELECT");
        if ($rootScope.formatList.length > 0) {
            angular.forEach($rootScope.formatList, function(value, key) {
                document.getElementById("format_" + value.formatId).checked = !1
            });
            document.getElementById("formatCheckAll").checked = !1
        }
        if ($rootScope.othersFilterList.length > 0) {
            angular.forEach($rootScope.othersFilterList, function(value, key) {
                document.getElementById("other_" + value).checked = !1
            });
            document.getElementById("otherCheckAll").checked = !1
        }
        if ($rootScope.GlobalImprintList.length > 0) {
            angular.forEach($rootScope.GlobalImprintList, function(value, key) {
                document.getElementById(value + "_Global").checked = !1
            });
            document.getElementById("imgAllSelected").checked = !1;
            $scope.imgAllSelected = !1
        }
        if ($rootScope.GlobalOthersList.length > 0) {
            angular.forEach($rootScope.GlobalOthersList, function(value, key) {
                document.getElementById(value + "_Global").checked = !1
            });
            document.getElementById("mtAllSelected").checked = !1;
            $scope.mtAllSelected = !1
        }
        $rootScope.widgetaccountFilterList = [];
        $rootScope.widgetselectedAccounts = [];
        $rootScope.widgetimprintFilterList = [];
        $rootScope.widgetpCategoryFilterList = [];
        $rootScope.getImprints();
        $rootScope.getProductCategoriesForSearch()
    };
    $rootScope.widgetgetNestedChildren = function(arr, parent) {
        var out = [];
        for (var i in arr) {
            if (arr[i].parentId == parent) {
                var children = $scope.widgetgetNestedChildren(arr, arr[i].productCategoryId)
                if (children.length) {
                    arr[i].children = children
                }
                out.push(arr[i])
            }
        }
        return out
    }
    $rootScope.widgettraverseSearchTree = function(arr, operation) {
        for (var i = 0, l = arr.length; i < l; i++) {
            var current = arr[i];
            if (operation == "GETSELECTED") {
                if (current.selected) {
                    $rootScope.widgetselectedProductCategoryArraySearch.push(current.productCategoryId)
                }
            } else if (operation == "UNSELECT") {
                current.selected = !1;
                var index = $rootScope.widgetpCategoryFilterList.indexOf(current);
                $rootScope.widgetpCategoryFilterList.splice(index, 1)
            } else if (operation == "SELECT") {
                current.selected = !0;
                $rootScope.widgetpCategoryFilterList.push(current)
            } else if (operation == "POPULATEFOREDIT") {
                if ($rootScope.widgetselectedProductCategoryArraySearch.indexOf(current.productCategoryId) > -1) {
                    current.selected = !0;
                    $rootScope.widgetpCategoryFilterList.push(current)
                }
            }
            if (current.children && current.children.length > 0) {
                $rootScope.widgettraverseSearchTree(current.children, operation)
            }
        }
    }
    $rootScope.getWidgetSelectedSearchFilterProductCategories = function() {
        $rootScope.widgetselectedProductCategoryArraySearch = [];
        $rootScope.widgettraverseSearchTree($rootScope.widgetproductCategoryTreeList, "GETSELECTED")
    };
    $rootScope.widgettoggleSearchProductCategoryChildren = function(data, pCId) {
        if (!data.selected) {
            var index = $rootScope.widgetpCategoryFilterList.indexOf(data);
            $rootScope.widgetpCategoryFilterList.splice(index, 1);
            if (data.children && data.children.length > 0) {
                $rootScope.widgettraverseSearchTree(data.children, "UNSELECT")
            }
        } else {
            $rootScope.widgetpCategoryFilterList.push(data);
            if (data.children && data.children.length > 0) {
                $rootScope.widgettraverseSearchTree(data.children, "SELECT")
            }
        }
        $rootScope.getWidgetSelectedSearchFilterProductCategories();
        $timeout(function() {
            $rootScope.widget.widgetpCateoryAllSelected = (($rootScope.widgetpCategoryFilterList.length === $rootScope.widgetproductCategoryList.length) && $rootScope.widgetproductCategoryList.length != 0);
            $rootScope.viewWidgetDashboard(0, 'R', !1)
        }, 100)
    };
    $scope.exportWidget = function(exportType) {
        $scope.showWidgetSuccessMsgExport = !0;
        $scope.widgetSuccessMsgExport = "EXPORT_REQUEST_SUCCESS";
        setTimeout(function() {
            $scope.showWidgetSuccessMsgExport = !1;
            $scope.$apply()
        }, $rootScope.alertTimeoutInterval)
        if ((!angular.equals({}, $rootScope.Search.AdvancedSearch)) || (!angular.equals({}, $rootScope.columnFilterValues))) {
            var sortBy = $scope.sortBy == undefined ? null : $scope.sortBy;
            if ($scope.fieldDispType !== undefined && ($scope.fieldDispType != "modifiedOn" && $scope.fieldDispType != "createdOn")) {
                var SearchText = $scope.headersrch[$scope.fieldDispType] == undefined ? "" : $scope.headersrch[$scope.fieldDispType]
            }
            $http({
                method: 'POST',
                url: '/exportWidget',
                data: {
                    pageName: "widgetDashboard",
                    exportFormat: exportType.type,
                    advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
                    "fieldDisplayName": $scope.fieldDispType,
                    "columnFilterValues": $rootScope.columnFilterValues,
                    "searchText": SearchText,
                    "sortBy": sortBy
                }
            }).then(function successCallback(response) {
                $rootScope.getDownloadNotification();
                angular.element("#getDownloadNotification").addClass('open');
                angular.element(".download-up").addClass("flashit")
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        } else {
            $http({
                method: 'POST',
                url: '/exportWidget',
                data: {
                    skipCount: 0,
                    pageName: "widgetDashboard",
                    exportFormat: exportType.type,
                    advancedSearch: Object.keys($rootScope.Search.AdvancedSearch).length > 0 ? $rootScope.Search.AdvancedSearch : {},
                }
            }).then(function successCallback(response) {
                $rootScope.getDownloadNotification();
                angular.element("#getDownloadNotification").addClass('open');
                angular.element(".download-up").addClass("flashit")
            }, function errorCallback(response) {
                console.log('Error status: ' + response.status)
            })
        }
    }
}])