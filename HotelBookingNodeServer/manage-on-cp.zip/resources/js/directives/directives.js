
    /* Pop up modal directives start*/
    app.directive('modal', function () {
        return {
        template: '<div class="modal fade">' + 
           '<div class="modal-dialog">' + 
             '<div class="modal-content">' + 
               '<div class="modal-header">' + 
                '<button type="button" class="modal-close" data-dismiss="modal" aria-hidden="true"> <i class="cp-close"></i> </button>' + 
                 '<h5 class="modal-title">{{ title }}</h5>' + 
               '</div>' + 
               '<div class="modal-body" ng-transclude></div>' + 
             '</div>' + 
           '</div>' + 
         '</div>',
       restrict: 'E',
       transclude: true,
       replace:true,
       scope:true,
       link: function postLink(scope, element, attrs) {
         scope.title = attrs.title;
         scope.$watch(attrs.visible, function(value){
           if(value == true)
             $(element).modal('show');
           else
             $(element).modal('hide');
         });

         $(element).on('shown.bs.modal', function(){
           scope.$apply(function(){ 
             scope.$parent[attrs.visible] = true;
           });
         });

         $(element).on('hidden.bs.modal', function(){
           scope.$apply(function(){
             scope.$parent[attrs.visible] = false;
           });
         });
       }
     };
    });   
    /* Pop up modal directives end*/
     
     /* column chart directive start*/
    app.directive('chColumnChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    scope: {
      chccOptions: '=?',
      chccData: '=',
      chccClass:'@',
      chccHeight: '@',
      chccWidth: '@',
      chccId: '@'
    },
    template: '<canvas id="{{chccId}}" height="{{chccHeight}}" height="200"></canvas>',
    link: function(scope, el) {
      
        var myChart = false;
       console.log($window);
    //    scope.$watch('chccData', function( newValue, oldValue ) {
    //     if(newValue){

    //     }
    // },true);

        $timeout(function() {
        var initChart = function(id, data) {
            //if (myChart) myChart.destroy();
            var ctx = document.getElementById(scope.chccId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'bar',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
           
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor:'rgba(255, 99, 132, 1)',
            borderColor: 'rgba(255,99,132,1)',
            borderWidth: 1
        }]
    },
    options: {
      legend: {
                display: false
            },
        scales: {
           yAxes: [{
              
                ticks: {
                    beginAtZero:true,
                    drawTicks:false
                }
            }],
            xAxes: [{
              barPercentage: 0.2
            }]
        }
    }
});
        };

        initChart(scope.chccId, scope.chccData);
        }, 0);
    }
};
}]);   
    /* column chart directive end*/
     /* stacked column chart directive start*/
    app.directive('chStackcolumnChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    replace:true,
    scope: {
      chscOptions: '=?',
      chscData: '=',
      chscClass:'@',
      chscHeight: '@',
      chscWidth: '@',
      chscId: '@'
    },
    template: '<canvas id="{{chscId}}" height="{{chscHeight}}" ng-class="chscClass"></canvas>',
    link: function(scope, el) {
    //       scope.$watchCollection('chscData', function( newValue, oldValue ) {
    //     if(newValue){
    //       console.log(newValue);
    //     }
    // });
        var myChart = false;
          scope.$watch('chscData.labels', function( newValue, oldValue ) {
        if(newValue){

        $timeout(function() {
        var initChart = function(id, data) {
           // if (myChart) myChart.destroy();
//           console.log(data);
           var ctx = document.getElementById(scope.chscId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'bar',
    data: {
        labels: data.labels,
        datasets: data.datasets
    },
    options: {
      legend: {
                display: false
            },
        scales: {
            yAxes: [{
              stacked: true,
                ticks: {
                    beginAtZero:true,
                    drawTicks:false
                }
            }],
            xAxes: [{
              stacked: true,
                // Change here
              barPercentage: 0.2
            }]
        }
    }
});
        };

        initChart(scope.chscId, scope.chscData);
        }, 0);
             }
    },true);
    }
};
}]);   
    /* stacked column chart directive end*/
    /* line chart directive start*/
    app.directive('chLineChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    replace:true,
    scope: {
      chlcOptions: '=?',
      chlcData: '=',
      chlcClass:'@',
      chlcHeight: '@',
      chlcWidth: '@',
      chlcId: '@'
    },
    template: '<canvas id="{{chlcId}}" height="{{chlcHeight}}" ng-class="chlcClass"></canvas>',
    link: function(scope, el) {
      
        var myChart = false;
//       console.log($window);
       scope.$watch('chlcData.labels', function( newValue, oldValue ) {
        if(newValue){

        $timeout(function() {
        var initChart = function(id, data) {
            //if (myChart) myChart.destroy();
            var ctx = document.getElementById(scope.chlcId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'line',
    data: data,
    options: {
      legend: {
                display: false
            },
            scales: {
            yAxes: [{
            
                ticks: {
                    beginAtZero:true
                }
            }]
        }
        
    }
});
        };

        initChart(scope.chlcId, scope.chlcData);
        }, 0);
            }
    },true);
    }
};
}]);   
    /* line chart directive end*/
        /* donut chart directive start*/
    app.directive('chDoughnutChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    replace:true,
    scope: {
      chdcOptions: '=?',
      chdcData: '=',
      chdcClass:'@',
      chdcHeight: '@',
      chdcWidth: '@',
      chdcId: '@'
    },
    template: '<div><canvas id="{{chdcId}}" height="{{chdcHeight}}" ng-class="chdcClass" ></canvas>'+
    '<div class="donut-inner">'+
    '<h5>{{chdcData.app_value}}</h5>'+
    '<span>Approval</span>'+
'</div>'+
'</div>',
    link: function(scope, el) {
      
        var myChart = false;
//       console.log($window);
       scope.$watch('chdcData.labels', function( newValue, oldValue ) {
        if(newValue){

        $timeout(function() {
        var initChart = function(id, data) {
            //if (myChart) myChart.destroy();
            var ctx = document.getElementById(scope.chdcId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'pie',
    data: data,
    options: {
      legend: {
                display: false
            },
            pieceLabel: {
    render: 'percentage',
    fontStyle: 'bold',
    fontColor: "#ffffff",
    precision: 0
  },
            cutoutPercentage:50
        
    }
});
        };

        initChart(scope.chdcId, scope.chdcData);
        }, 0);
            }
    },true);
    }
};
}]);   
    /* donut chart directive end*/
    /* donut chart directive start*/
    app.directive('chPieChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    replace:true,
    scope: {
      chpcOptions: '=?',
      chpcData: '=',
      chpcClass:'@',
      chpcHeight: '@',
      chpcWidth: '@',
      chpcId: '@'
    },
    template: '<div><canvas id="{{chpcId}}" height="{{chpcHeight}}" ng-class="chpcClass" ></canvas>',
    link: function(scope, el) {
      
        var myChart = false;
       console.log($window);
       scope.$watch('chpcData.labels', function( newValue, oldValue ) {
        if(newValue){

        $timeout(function() {
        var initChart = function(id, data) {
            //if (myChart) myChart.destroy();
            var ctx = document.getElementById(scope.chpcId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'pie',
    data: data,
    options: {
      legend: {
                display: false
            },
            pieceLabel: {
    render: 'percentage',
    fontStyle: 'bold',
    fontColor: "#ffffff",
    precision: 0
  },
            cutoutPercentage:0
        
    }
});
        };

        initChart(scope.chpcId, scope.chpcData);
        }, 0);
            }
    },true);
    }
};
}]);   
    /* donut chart directive end*/
    /* smooth line chart directive start*/
    app.directive('chSmoothlineChart', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    replace:true,
    scope: {
      chslcOptions: '=?',
      chslcData: '=',
      chslcClass:'@',
      chslcHeight: '@',
      chslcWidth: '@',
      chslcId: '@'
    },
    template: '<canvas id="{{chslcId}}" height="{{chslcHeight}}" ng-class="chslcClass"></canvas>',
    link: function(scope, el) {
      
        var myChart = false;
     
    //    scope.$watch('chccData', function( newValue, oldValue ) {
    //     if(newValue){

    //     }
    // },true);
   scope.$watch('chslcData.labels', function( newValue, oldValue ) {
        if(newValue){
        $timeout(function() {
        var initChart = function(id, data) {
//          console.log(data);
            //if (myChart) myChart.destroy();
            var ctx = document.getElementById(scope.chslcId).getContext('2d');
              myChart = new Chart(ctx, {
                responsive: true,
    type: 'line',
    data: data,
    options: {
      legend: {
                display: false
            },
            scales: {
            yAxes: [{
            
                ticks: {
                    beginAtZero:true
                   
                }
            }]
        }
        
    }
});
        };

        initChart(scope.chslcId, scope.chslcData);
        }, 0);
            }
    },true);
    }
};
}]);   
    /* smooth line chart directive end*/
/* image select directive start*/
    app.directive('imageSelect', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    require: 'ngModel',
    scope: {
      isList: '=?',
      isSelected: '=?',
      isClass:'@'
    },
    template: '<div uib-dropdown >'+
      '<a href id="simple-dropdown"  uib-dropdown-toggle>'+
        '{{isSelected.type?isSelected.type:"Select"}}'+
      '</a>'+
      '<ul class="dropdown-menu" uib-dropdown-menu aria-labelledby="simple-dropdown">'+
        '<li role="menuitem" ng-repeat="data in isList">'+
        '<a ng-click="anwSelectedChart(data)">'+
        '<img class=""  ng-src="{{data.image}}" alt="" title="{{data.type}}">'+
        '</a></li>'+
      '</ul>'+
    '</div>',
    link: function(scope, el) {
      scope.anwSelectedChart= function(data){
        scope.isSelected=data;
       
    };
      }
};
}]);   
    /* image select directive end*/
    /* image select directive start*/
    app.directive('listSelect', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    require: 'ngModel',
    scope: {
      lsList: '=?',
      lsSelected: '=?',
      lsClass:'@'
    },
    template: '<div uib-dropdown >'+
      '<a href id="simple-dropdown"  uib-dropdown-toggle>'+
        '{{lsSelected.name?lsSelected.name:"Select"}}'+
      '</a>'+
      '<ul class="dropdown-menu" uib-dropdown-menu aria-labelledby="simple-dropdown">'+
        '<li role="menuitem" ng-repeat="data in lsList">'+
        '<a ng-click="anwSelectedList(data)">{{data.name}}'+
        '</a></li>'+
      '</ul>'+
    '</div>',
    link: function(scope, el) {
      scope.anwSelectedList= function(data){
        scope.lsSelected=data;
       
    };
      }
};
}]);   
    /* image select directive end*/
      /* side menu directive start*/
    app.directive('sideMenuLeft', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
   
    templateUrl: 'templates/common/side-menu-left.html',
    link: function(scope, el) {
    
     var j_Query=$window.jQuery;
    // j_query.app.menu.init();
    var smlFxn= function($){
      $.app = $.app || {};

  var $body       = $('body');
  var $window     = $( window );
  var menuWrapper_el = $('div[data-menu="menu-wrapper"]').html();
  var menuWrapperClasses = $('div[data-menu="menu-wrapper"]').attr('class');

  // Main menu
  /*$.app.menu = {
    expanded: null,
    collapsed: null,
    hidden : null,
    container: null,
    horizontalMenu: false,

    manualScroller: {
      obj: null,

      init: function() {
        // var scroll_theme = ($('.main-menu').hasClass('menu-dark')) ? 'light' : 'dark';
        this.obj = $(".main-menu-content").perfectScrollbar({
          suppressScrollX: true,
          // theme: scroll_theme
        });
      },

      update: function() {
        if (this.obj) {
          // Scroll to currently active menu on page load if data-scroll-to-active is true
          if($('.main-menu').data('scroll-to-active') === true){
              var position;
              if( $(".main-menu-content").find('li.active').parents('li').length > 0 ){
                position = $(".main-menu-content").find('li.active').parents('li').last().position();
              }
              else{
                position = $(".main-menu-content").find('li.active').position();
              }
              setTimeout(function(){
                
                // $.app.menu.container.scrollTop(position.top);
                $.app.menu.container.stop().animate({scrollTop:position.top}, 300);
                $('.main-menu').data('scroll-to-active', 'false');
              },300);
          }
          $(".main-menu-content").perfectScrollbar('update');
        }
      },

      enable: function() {
        this.init();
      },

      disable: function() {
        if (this.obj) {
          $('.main-menu-content').perfectScrollbar('destroy');
        }
      },

      updateHeight: function(){
        if( ($body.data('menu') == 'vertical-menu' || $body.data('menu') == 'vertical-overlay-menu' ) && $('.main-menu').hasClass('menu-fixed')){
          $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight() );
          this.update();
        }
      }
    },

    init: function() {
      if($('.main-menu-content').length > 0){
        this.container = $('.main-menu-content');

        var menuObj = this;

        this.change();
      }
      else{
        // For 1 column layout menu won't be initialized so initiate drill down for mega menu

        // Drill down menu
        // ------------------------------
        this.drillDownMenu();
      }
    },

    drillDownMenu: function(screenSize){
      if($('.drilldown-menu').length){
        if(screenSize == 'sm' || screenSize == 'xs'){
          if($('#navbar-mobile').attr('aria-expanded') == 'true'){

            $('.drilldown-menu').slidingMenu({
              backLabel:true
            });
          }
        }
        else{
          $('.drilldown-menu').slidingMenu({
            backLabel:true
          });
        }
      }
    },

    change: function() {
      var currentBreakpoint = Unison.fetch.now(); // Current Breakpoint

      this.reset();

      var menuType = $body.data('menu');

      if (currentBreakpoint) {
        switch (currentBreakpoint.name) {
          case 'xl':
          case 'lg':
            if(menuType === 'vertical-overlay-menu'){
              this.hide();
            }
            else if(menuType === 'vertical-compact-menu'){
              this.open();
            }
            else{
              this.expand();
            }
            break;
          case 'md':
            if(menuType === 'vertical-overlay-menu' || menuType === 'vertical-mmenu'){
              this.hide();
            }
            else if(menuType === 'vertical-compact-menu'){
              this.open();
            }
            else{
              this.collapse();
            }
            break;
          case 'sm':
            this.hide();
            break;
          case 'xs':
            this.hide();
            break;
        }
      }

      // On the small and extra small screen make them overlay menu
      if(menuType === 'vertical-menu' || menuType === 'vertical-compact-menu' || menuType === 'vertical-content-menu'){
        this.toOverlayMenu(currentBreakpoint.name);
      }

      // Initialize drill down menu for vertical layouts, for horizontal layouts drilldown menu is intitialized in changemenu function
      if(menuType != 'horizontal-menu' && menuType != 'horizontal-top-icon-menu'){
        // Drill down menu
        // ------------------------------
        this.drillDownMenu(currentBreakpoint.name);
      }

      // Dropdown submenu on large screen on hover For Large screen only
      // ---------------------------------------------------------------
      if(currentBreakpoint.name == 'xl'){
        $('body[data-open="hover"] .dropdown').on('mouseenter', function(){
          if (!($(this).hasClass('open'))) {
            $(this).addClass('open');
          }else{
            $(this).removeClass('open');
          }
        }).on('mouseleave', function(event){
          $(this).removeClass('open');
        });

        $('body[data-open="hover"] .dropdown a').on('click', function(e){
          if(menuType == 'horizontal-menu' || menuType == 'horizontal-top-icon-menu'){
            var $this = $(this);
            if($this.hasClass('dropdown-toggle')){
              return false;
            }
          }
        });
      }

      // Added data attribute brand-center for navbar-brand-center
      // TODO:AJ: Shift this feature in JADE.
      if($('.header-navbar').hasClass('navbar-brand-center')){
        $('.header-navbar').attr('data-nav','brand-center');
      }
      if(currentBreakpoint.name == 'sm' || currentBreakpoint.name == 'xs'){
        $('.header-navbar[data-nav=brand-center]').removeClass('navbar-brand-center');
      }else{
        $('.header-navbar[data-nav=brand-center]').addClass('navbar-brand-center');
      }

      // Dropdown submenu on small screen on click
      // --------------------------------------------------
      $('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
        if($(this).siblings('ul.dropdown-menu').length > 0){
          event.preventDefault();
        }
        event.stopPropagation();
        $(this).parent().siblings().removeClass('open');
        $(this).parent().toggleClass('open');
      });
    },

    changeLogo: function(menuType){
      var logo = $('.brand-logo');
      if(menuType == 'expand'){
        logo.attr('src',logo.data('expand'));
      }
      else{
        logo.attr('src',logo.data('collapse'));
      }
    },

    transit: function(callback1, callback2) {
      var menuObj = this;
      $body.addClass('changing-menu');

      callback1.call(menuObj);

      if($body.hasClass('vertical-layout')){
        if($body.hasClass('menu-open') || $body.hasClass('menu-expanded')){
          $('.menu-toggle').addClass('is-active');

          // Show menu header search when menu is normally visible
          if( $body.data('menu') === 'vertical-menu' || $body.data('menu') === 'vertical-content-menu'){
            if($('.main-menu-header')){
              $('.main-menu-header').show();
            }
          }
        }
        else{
          $('.menu-toggle').removeClass('is-active');

          // Hide menu header search when only menu icons are visible
          if( $body.data('menu') === 'vertical-menu' || $body.data('menu') === 'vertical-content-menu'){
            if($('.main-menu-header')){
              $('.main-menu-header').hide();
            }
          }
        }
      }

      setTimeout(function() {
        callback2.call(menuObj);
        $body.removeClass('changing-menu');

        menuObj.update();
      }, 500);
    },

    open: function() {
      if($body.is('.vertical-mmenu')){
        this.mMenu.enable();
      }
      this.transit(function() {
        $body.removeClass('menu-hide menu-collapsed').addClass('menu-open');
        this.hidden = false;
        this.expanded = true;
      }, function() {
        if(!$('.main-menu').hasClass('menu-native-scroll') && !$body.is('.vertical-mmenu') && $('.main-menu').hasClass('menu-fixed') ){
          this.manualScroller.enable();
          $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight() );
          // this.manualScroller.update();
        }
      });
    },

    hide: function() {
      if($body.is('.vertical-mmenu')){
        this.mMenu.disable();
      }

      this.transit(function() {
        $body.removeClass('menu-open menu-expanded').addClass('menu-hide');
        this.hidden = true;
        this.expanded = false;
      }, function() {
        if(!$('.main-menu').hasClass('menu-native-scroll') && !$body.is('.vertical-mmenu') && $('.main-menu').hasClass('menu-fixed')){
          this.manualScroller.enable();
        }
      });
    },

    expand: function() {
      if (this.expanded === false) {
        if( $body.data('menu') == 'vertical-menu'){
          this.changeLogo('expand');
        }
        this.transit(function() {
          $body.removeClass('menu-collapsed').addClass('menu-expanded');
          this.collapsed = false;
          this.expanded = true;

        }, function() {

          if($body.is('.vertical-mmenu')){
            this.mMenu.enable();
          }
          else if( ($('.main-menu').hasClass('menu-native-scroll') || $body.data('menu') == 'vertical-mmenu' || $body.data('menu') == 'horizontal-menu' || $body.data('menu') == 'horizontal-top-icon-menu' )){
            this.manualScroller.disable();
          }
          else{
            if($('.main-menu').hasClass('menu-fixed'))
              this.manualScroller.enable();
          }

          if( $body.data('menu') == 'vertical-menu' && $('.main-menu').hasClass('menu-fixed')){
            $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height() - $('.main-menu-header').outerHeight() - $('.main-menu-footer').outerHeight() );
            // this.manualScroller.update();
          }

        });
      }
    },

    collapse: function() {
      if (this.collapsed === false) {
        if( ($body.data('menu') == 'vertical-menu' ) ){
          this.changeLogo('collapse');
        }
        this.transit(function() {
          $body.removeClass('menu-expanded').addClass('menu-collapsed');
          this.collapsed = true;
          this.expanded  = false;

        }, function() {

          if($body.data('menu') == 'vertical-content-menu'){
            this.manualScroller.disable();
          }

          if( ($body.data('menu') == 'horizontal-menu' || $body.data('menu') == 'horizontal-top-icon-menu') &&  $body.hasClass('vertical-overlay-menu')){
            if($('.main-menu').hasClass('menu-fixed'))
              this.manualScroller.enable();
          }
          if( $body.data('menu') == 'vertical-menu' && $('.main-menu').hasClass('menu-fixed') ){
            $('.main-menu-content').css('height', $(window).height() - $('.header-navbar').height());
            // this.manualScroller.update();
          }
        });
      }
    },

    toOverlayMenu: function(screen){
      var menu = $body.data('menu');
      if(screen == 'sm' || screen == 'xs'){
        if($body.hasClass(menu)){
          $body.removeClass(menu).addClass('vertical-overlay-menu');
        }
        if(menu == 'vertical-content-menu'){
          $('.main-menu').addClass('menu-fixed');
        }
      }
      else{
        if($body.hasClass('vertical-overlay-menu')){
          $body.removeClass('vertical-overlay-menu').addClass(menu);
        }
        if(menu == 'vertical-content-menu'){
          $('.main-menu').removeClass('menu-fixed');
        }
      }
    },


    toggle: function() {
      var currentBreakpoint = Unison.fetch.now(); // Current Breakpoint
      var collapsed = this.collapsed;
      var expanded = this.expanded;
      var hidden = this.hidden;
      var menu = $body.data('menu');

      switch (currentBreakpoint.name) {
        case 'xl':
        case 'lg':
        case 'md':
          if(expanded === true){
            if(menu == 'vertical-compact-menu' || menu == 'vertical-mmenu' || menu == 'vertical-overlay-menu'){
              this.hide();
            }
            else{
              this.collapse();
            }
          }
          else{
            if(menu == 'vertical-compact-menu' || menu == 'vertical-mmenu' || menu == 'vertical-overlay-menu'){
              this.open();
            }
            else{
              this.expand();
            }
          }
          break;
        case 'sm':
          if (hidden === true) {
            this.open();
          } else {
            this.hide();
          }
          break;
        case 'xs':
          if (hidden === true) {
            this.open();
          } else {
            this.hide();
          }
          break;
      }

      // Re-init sliding menu to update width
      this.drillDownMenu(currentBreakpoint.name);
    },

    update: function() {
      this.manualScroller.update();
    },

    reset: function() {
      this.expanded  = false;
      this.collapsed = false;
      this.hidden    = false;
      $body.removeClass('menu-hide menu-open menu-collapsed menu-expanded');
    },
  };*/

  // Navigation Menu
  $.app.nav = {
    container: $('.navigation-main'),
    initialized : false,
    navItem: $('.navigation-main').find('li').not('.navigation-category'),

    config: {
      speed: 300,
    },

    init: function(config) {
      this.initialized = true; // Set to true when initialized
      $.extend(this.config, config);

      if(!$body.is('.vertical-mmenu')){
        this.bind_events();
      }
    },

    bind_events: function() {
      var menuObj = this;

      $('.navigation-main').on('mouseenter.app.menu', 'li', function() {
        var $this = $(this);
        $('.hover', '.navigation-main').removeClass('hover');
        if( $body.hasClass('menu-collapsed') || ($body.data('menu') == 'vertical-compact-menu' && !$body.hasClass('vertical-overlay-menu')) ){
          $('.main-menu-content').children('span.menu-title').remove();
          $('.main-menu-content').children('a.menu-title').remove();
          $('.main-menu-content').children('ul.menu-content').remove();

          // Title
          var menuTitle = $this.find('span.menu-title').clone(),
          tempTitle,
          tempLink;
          if(!$this.hasClass('has-sub') ){
            tempTitle = $this.find('span.menu-title').text();
            tempLink = $this.children('a').attr('href');
            if(tempTitle !== ''){
              menuTitle = $("<a>");
              menuTitle.attr("href", tempLink);
              menuTitle.attr("title", tempTitle);
              menuTitle.text(tempTitle);
              menuTitle.addClass("menu-title");
            }
          }
          // menu_header_height = ($('.main-menu-header').length) ? $('.main-menu-header').height() : 0,
          // fromTop = menu_header_height + $this.position().top + parseInt($this.css( "border-top" ),10);
          var fromTop;
          if($this.css( "border-top" )){
            fromTop = $this.position().top + parseInt($this.css( "border-top" ), 10);
          }
          else{
            fromTop = $this.position().top;
          }
          if($body.data('menu') !== 'vertical-compact-menu'){
            menuTitle.appendTo('.main-menu-content').css({
              position:'fixed',
              top : fromTop,
            });
          }

          // Content
          if($this.hasClass('has-sub') && $this.hasClass('nav-item')) {
            var menuContent = $this.children('ul:first');
            menuObj.adjustSubmenu($this);
          }
        }
        $this.addClass('hover');
      }).on('mouseleave.app.menu', 'li', function() {
        // $(this).removeClass('hover');
      }).on('active.app.menu', 'li', function(e) {
        $(this).addClass('active');
        e.stopPropagation();
      }).on('deactive.app.menu', 'li.active', function(e) {
        $(this).removeClass('active');
        e.stopPropagation();
      }).on('open.app.menu', 'li', function(e) {

        var $listItem = $(this);
        $listItem.addClass('open');

        menuObj.expand($listItem);

        // If menu collapsible then do not take any action
        if ($('.main-menu').hasClass('menu-collapsible')) {
          return false;
        }
        // If menu accordion then close all except clicked once
        else{
          $listItem.siblings('.open').find('li.open').trigger('close.app.menu');
          $listItem.siblings('.open').trigger('close.app.menu');
        }

        e.stopPropagation();
      }).on('close.app.menu', 'li.open', function(e) {
        var $listItem = $(this);

        $listItem.removeClass('open');
        menuObj.collapse($listItem);

        e.stopPropagation();
      }).on('click.app.menu', 'li', function(e) {
        var $listItem = $(this);
        if($listItem.is('.disabled')){
          e.preventDefault();
        }
        else{
          if( $body.hasClass('menu-collapsed') || ($body.data('menu') == 'vertical-compact-menu' && $listItem.is('.has-sub') && !$body.hasClass('vertical-overlay-menu')) ){
            e.preventDefault();
          }
          else{
            if ($listItem.has('ul')) {
              if ($listItem.is('.open')) {
                $listItem.trigger('close.app.menu');
              } else {
                $listItem.trigger('open.app.menu');
              }
            } else {
              if (!$listItem.is('.active')) {
                $listItem.siblings('.active').trigger('deactive.app.menu');
                $listItem.trigger('active.app.menu');
              }
            }
          }
        }

        e.stopPropagation();
      });

      $('.main-menu-content').on('mouseleave', function(){
        if( $body.hasClass('menu-collapsed') || $body.data('menu') == 'vertical-compact-menu' ){
          $('.main-menu-content').children('span.menu-title').remove();
          $('.main-menu-content').children('a.menu-title').remove();
          $('.main-menu-content').children('ul.menu-content').remove();
        }
        $('.hover', '.navigation-main').removeClass('hover');
      });

      // If list item has sub menu items then prevent redirection.
      $('.navigation-main li.has-sub > a').on('click',function(e){
        e.preventDefault();
      });

      $('ul.menu-content').on('click', 'li', function(e) {
        var $listItem = $(this);
        if($listItem.is('.disabled')){
          e.preventDefault();
        }
        else{
          if ($listItem.has('ul')) {
            if ($listItem.is('.open')) {
              $listItem.removeClass('open');
              menuObj.collapse($listItem);
            } else {
              $listItem.addClass('open');

              menuObj.expand($listItem);

              // If menu collapsible then do not take any action
              if ($('.main-menu').hasClass('menu-collapsible')) {
                return false;
              }
              // If menu accordion then close all except clicked once
              else{
                $listItem.siblings('.open').find('li.open').trigger('close.app.menu');
                $listItem.siblings('.open').trigger('close.app.menu');
              }

              e.stopPropagation();
            }
          } else {
            if (!$listItem.is('.active')) {
              $listItem.siblings('.active').trigger('deactive.app.menu');
              $listItem.trigger('active.app.menu');
            }
          }
        }

        e.stopPropagation();
      });
    },


    /**
     * Ensure an admin submenu is within the visual viewport.
     * @param {jQuery} $menuItem The parent menu item containing the submenu.
     */
    adjustSubmenu: function ( $menuItem ) {
      var menuHeaderHeight, menutop, topPos, winHeight,
      bottomOffset, subMenuHeight, popOutMenuHeight, borderWidth, scroll_theme,
      $submenu = $menuItem.children('ul:first'),
      ul = $submenu.clone(true);

      menuHeaderHeight = $('.main-menu-header').height();
      menutop          = $menuItem.position().top;
      winHeight        = $window.height() - $('.header-navbar').height();
      borderWidth      = 0;
      subMenuHeight    = $submenu.height();

      if(parseInt($menuItem.css( "border-top" ),10) > 0){
        borderWidth = parseInt($menuItem.css( "border-top" ),10);
      }

      popOutMenuHeight = winHeight - menutop - $menuItem.height() - 30;
      scroll_theme     = ($('.main-menu').hasClass('menu-dark')) ? 'light' : 'dark';

      if($body.data('menu') === 'vertical-compact-menu'){
        topPos = menutop + borderWidth;
        popOutMenuHeight = winHeight - menutop - 30;
      }
      else if($body.data('menu') === 'vertical-content-menu'){
        topPos = menutop + $menuItem.height() + borderWidth;
        popOutMenuHeight = winHeight - $('.content-header').height() -$menuItem.height() - menutop - 60;
      }
      else{
        topPos = menutop + $menuItem.height() + borderWidth;
      }

      if($body.data('menu') == 'vertical-content-menu'){
        ul.addClass('menu-popout').appendTo('.main-menu-content').css({
          'top' : topPos,
          'position' : 'fixed',
        });
      }
      else{
        ul.addClass('menu-popout').appendTo('.main-menu-content').css({
          'top' : topPos,
          'position' : 'fixed',
          'max-height': popOutMenuHeight,
        });

        $('.main-menu-content > ul.menu-content').perfectScrollbar({
          theme:scroll_theme,
        });
      }
    },

    collapse: function($listItem, callback) {
      var $subList = $listItem.children('ul');

      $subList.show().slideUp($.app.nav.config.speed, function() {
        $(this).css('display', '');

        $(this).find('> li').removeClass('is-shown');

        if (callback) {
          callback();
        }

        $.app.nav.container.trigger('collapsed.app.menu');
      });
    },

    expand: function($listItem, callback) {
      var $subList  = $listItem.children('ul');
      var $children = $subList.children('li').addClass('is-hidden');

      $subList.hide().slideDown($.app.nav.config.speed, function() {
        $(this).css('display', '');

        if (callback) {
          callback();
        }

        $.app.nav.container.trigger('expanded.app.menu');
      });

      setTimeout(function() {
        $children.addClass('is-shown');
        $children.removeClass('is-hidden');
      }, 0);
    },

    refresh: function() {
      $.app.nav.container.find('.open').removeClass('open');
    },
  };

    };
     smlFxn(j_Query);
//     console.log($window);
     j_Query.app.menu.init();

        // Navigation configurations
        var config = {
            speed: 300 // set speed to expand / collpase menu
        };
        if(j_Query.app.nav.initialized === false){
            j_Query.app.nav.init(config);
        }
        j_Query(document).on('click', '.menu-toggle', function(e) {
        e.preventDefault();

        // Toggle menu
        j_Query.app.menu.toggle();

        return false;
    });

    // Add Children Class
    j_Query('.navigation').find('li').has('ul').addClass('has-sub');
    j_Query("#menu-side-border").hover(function () {
    j_Query(".left-nav").css("display", "block");
}, function () {
    j_Query(".left-nav").css("display", "none");
});

      }
};
}]);   
    /* side menu directive end*/
    /* header directive*/
    app.directive('headerMain', ['$q', '$window', '$timeout','httpCall','scheduleCreationService', function($q, $window, $timeout,httpCall,scheduleCreationService) {
return {
    restrict: 'E',
    templateUrl: 'templates/common/header.html',
    link: function(scope, el) {
      var j_Query= $window.jQuery;
          j_Query(".header-filter").click(function () {
            j_Query(this).toggleClass("active");
            j_Query(".header-filter-dropdown.header").toggleClass("active");
        });
      var j_Query= $window.jQuery;
          j_Query(".header-filter1").click(function () {
            j_Query(this).toggleClass("active");
            j_Query(".header-filter-dropdown.one").toggleClass("active");
        });
    
            j_Query(".filter-close").click(function () {
            j_Query(".header-filter, .header-filter1").removeClass("active");
            j_Query(this).closest(".header-filter-dropdown").removeClass("active");
        });
      scope.notifyInit={
        activeNotifyTab:1,
        createSchedule:false,
        scheduleEditMode:false,
        formData:scheduleCreationService.scheduleData()

      } 
     
      scope.userDetailTemplate='userDetailTemplate.html';
     
     /* scope.notifyToggled=function(){

          httpCall.getApi('/resources/json/notification.json').then(function (response) {
          scope.notifListAll=response.data;
         
      }, function (response) {

      });
        
      };*/
      scope.setScheduleStatus= function(data){
      if(data.status){
          //set true
      }else{
        //set false
      }
    };
      scope.editSchedule= function(data){
          scope.notifyInit.createSchedule=true;
          scope.notifyInit.scheduleEditMode=true;
          scope.notifyInit.formData=scheduleCreationService.scheduleEditData(data);
      };
      }
};
}]);   
    /* header directive end*/
        /* header directive*/
    app.directive('adminTab', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    templateUrl: 'templates/common/admin-tab.html',
    link: function(scope, el) {
   
      }
};
}]);   
    /* header directive end*/
     /* image select widget page*/
    app.directive('selectWidgetPage', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    scope: {
      swpPdfPages: '=?',
      swpPdfSelected: '=?'
    },
    template: '<div uib-dropdown >'+
      '<a href id="simple-dropdown" ng-click="getWidgetPages()" uib-dropdown-toggle>'+
        'Select Pages'+
      '</a>'+
      '<ul id="thumbnail_on_select_page" ng-click="$event.stopPropagation()" class="dropdown-menu" uib-dropdown-menu aria-labelledby="simple-dropdown">'+
       '<li class="cp-" ng-class="{\'selected\':data.selected}" ng-repeat="data in swpPdfPages |orderBy :\'id\'">'+
       '<a ng-click="thumbSelect(data)" data-select="{{data.selected}}" >'+
       '<pdf-thumb-nail ptn-data="data" ptn-scale=".2"></pdf-thumb-nail>'+
       '</a>'+
       '<div class="thumbnail-caption">{{data.pdf_page.pageNumber}}</div>'+
       '</li>'+
      '</ul>'+
    '</div>',
    controller: 'widgetCreationController'
};
}]);   
    /* image select widget page end*/
    /* pdf thumbnail directive start*/
    app.directive('pdfThumbNail', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    scope: {
      ptnData: '=?',
      ptnOption:'@',
      ptnScale:'@'
    },
    template: '',
    link: function(scope, el) {
      if(scope.ptnData){
        var viewport = scope.ptnData.pdf_page.getViewport(scope.ptnScale);
        var canvas = document.createElement("canvas");
          canvas.height = viewport.height;
          canvas.width = viewport.width;
       scope.ptnData.pdf_page.render({canvasContext: canvas.getContext("2d"), viewport: scope.ptnData.pdf_page.getViewport(scope.ptnScale)}).promise.then(function () {
          el.append(canvas);
        });
        }
      }
};
}]);   
    /* pdf thumbnail directive end*/
 /* pdf slider directive start*/
    app.directive('pdfSlider', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    scope: {
      psData: '=?'
    },
    templateUrl: 'templates/common/pdf-slider.html',
    link: function(scope, el) {
      scope.currentIndex=0;
     
      scope.$watch('psData.pageLength', function (newVal, oldVal) { 
       
        if(newVal!=0&&scope.currentIndex==newVal){
          scope.currentIndex=newVal-1;
        }
      });
      scope.pdfNextSlide= function(){
        var count=0;
        
        if(scope.psData.pages&&scope.currentIndex<scope.psData.pages.length-1){
          scope.currentIndex++;
          
          for (i = 0; i < scope.psData.pages.length; i++) { 
      //  console.log(scope.psData.pages[i]);
            scope.psData.pages[i].active=false;
            
                if(i==scope.currentIndex){
                  scope.psData.pages[i].active=true;
            }else{
              
            }
            }
          
        }
      };
      
     scope.pdfPrevSlide= function(){
    
        if(scope.psData.pages&&scope.currentIndex>0){
          scope.currentIndex--;
          for (i = 0; i < scope.psData.pages.length; i++) { 
            scope.psData.pages[i].active=false;
            
                if(i==scope.currentIndex){
                  scope.psData.pages[i].active=true;
            }else{
              
            }
            }
          
        }
      };
      scope.sliderThumbClick= function(index){
      scope.currentIndex=index;
     
       
      };
      }
};
}]);   
    /* pdf slider directive end*/
 /* widget viewer directive start*/
    app.directive('widgetCreation', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'E',
    scope: {
      wvData: '=?'
    },
    templateUrl: 'templates/widget-preview-dummy.html',
    controller: 'widgetCreationController',
    link: function(scope, el, rootScope) {
      //scope.widgetActivity="Create Widget";
      scope.widgetCreation=true;
	//alert(JSON.stringify(scope.wvData))
      scope.widgetForm=scope.wvData;
		if(scope.wvData.activity == 'Update'){
			scope.activityLabel = "Update";
			scope.activityTitle = "UPDATE WIDGET";
		}else{
			scope.activityLabel = "Create Widget";
			scope.activityTitle = "NEW WIDGET CREATION";
		 	scope.widgetForm.viewpageType ='range';
			
		}
        scope.detailSideMenu = true;
            scope.sideMenuBtn = function() {
                scope.detailSideMenu = scope.detailSideMenu == false ? true : false;
            }
      }
};
}]);   

    /* widget viewer directive end*/
    /* schedule creator directive start*/
    app.directive('scheduleCreator', ['httpCall','scheduleCreationService', function(httpCall,scheduleCreationService) {
return {
    restrict: 'E',
    scope: {
     scInit:'=?',
     scLayout:'@'
    },
    templateUrl: ' templates/common/schedule-creation.html',
    controller: function ($scope) {
            
              },
    link: function(scope, el) {
      
      scope.getNotifyApi= function(){
        httpCall.getApi('/resources/json/notification.json').then(function (response) {
          scope.scInit.formData.notificationList=scheduleCreationService.notifyListing(response.data.notification_list);
          if(scope.scInit.formData.notificationSelected.length==1){

          scope.scInit.formData.notificationList=scheduleCreationService.notifyListUpdate(scope.scInit.formData.notificationList,scope.scInit.formData.notificationSelected[0], true);
          console.log(scope.scInit.formData.notificationList);
        }
      }, function (response) {
        
      });
      };
      scope.getNotifyApi();
    
     scope.multiSelectDd=false;
     scope.freqSelectDd=false;
    
     scope.mSelectOpen= function(){
      if(!scope.multiSelectDd){
        scope.multiSelectDd=true;
        if(scope.scInit.formData.notificationSelected.length==1){

          scope.scInit.formData.notificationList=scheduleCreationService.notifyListUpdate(scope.scInit.formData.notificationList,scope.scInit.formData.notificationSelected[0], true);
          console.log(scope.scInit.formData.notificationList);
        }
        
        if(!scope.scInit.formData.notificationList.length){
          scope.getNotifyApi();
        }
      }else{
        scope.multiSelectDd=false;
      }
     };
     scope.freqSelectOpen= function(){
      scope.freqSelectDd=!scope.freqSelectDd;
      console.log(scope.scInit.formData.freqList);
     };
     
     scope.freqSelector= function(data){
      angular.forEach(scope.scInit.formData.freqList, function(value1, key1) {
        if(data.id==value1.id){
          scope.scInit.formData.freqList[key1].selected=true;
          scope.scInit.formData.frequencySelected=value1.type;
        }else{
          scope.scInit.formData.freqList[key1].selected=false;
        }
            });
     };
     scope.notifyListSelector= function(data){
      if(data.selected==true){
        scope.scInit.formData.notificationList=scheduleCreationService.notifyListUpdate(scope.scInit.formData.notificationList,data, false);
        scope.scInit.formData.notificationSelected= scheduleCreationService.selectedUpdate(scope.scInit.formData.notificationSelected, data, false);
      }else{
       scope.scInit.formData.notificationSelected= scheduleCreationService.selectedUpdate(scope.scInit.formData.notificationSelected, data, true);
         scope.scInit.formData.notificationList=scheduleCreationService.notifyListUpdate(scope.scInit.formData.notificationList,data, true);
      }
      // console.log(scope.scInit.formData.notificationList);
     };
     scope.removeNotifyItem= function(data){
        scope.scInit.formData.notificationList=scheduleCreationService.notifyListUpdate(scope.scInit.formData.notificationList,data, false);
        scope.scInit.formData.notificationSelected= scheduleCreationService.selectedUpdate(scope.scInit.formData.notificationSelected, data, false);
     };
     scope.scheduleSubmit= function(){
      var submit_data=scheduleCreationService.scheduleSubmitData(scope.scInit.formData);
      console.log(submit_data);
        // httpCall.postApi('').then(function (response) {
          
        // }, function (response) {
          
        // });
     };
     scope.scheduleCancel= function(){
      scope.scInit.createSchedule=false;
      scope.scInit.scheduleEditMode=false;
     };
    }
};
}]);   
    /* schedule creator directive end*/
 /* table repeat directive start*/
    app.directive('tableRepeat', ['$q', '$window', '$timeout', function($q, $window, $timeout) {
return {
    restrict: 'A',
    scope:{
      trData:'=?',
      trChildren:'=?'
    },
    template: 
	
	 '<div >'+
                  '<div class="row" style="border-bottom:1px solid #ddd;padding:5px 0">'+
                          '<div class="col-md-7"><span style="padding-left:{{trChildren*10+5}}px" class="category-level-{{trChildren}}">{{trChildren==0? \'\':\'-- \'}}{{trData.productCategoryName}}</span></div>'+
                          '<div class="col-md-3">{{trData.productCategoryCode}}</div>'+
                          '<div class="col-md-2"><span class="btn-table" ng-if="trChildren!=0" ng-show="false">'+
                           '<a href="javascript:;" data-ng-click="populateForEdit(trData);"><i class="cp cp-edit"></i></a>'+
                          '<a href="javascript:;" ng-show="!trData.children"  ng-show="false" data-toggle="modal" data-target="#category-delete" data-backdrop="static" data-keyboard="false" ng-click="passDataToCategoryDeleteModal(trData);" ><i class="cp cp-delete"></i></a>'+
                          '</span></div>'+
                      '</div>'+
                      '<div ng-if="trData.children" ng-repeat="item in trData.children">'+
                          '<div table-repeat tr-data="item" tr-children="trChildrenCount"></div>'+
                      '</div>'+
                      
                  '</div>',
	
                 /* '<div >'+
                  '<div class="row" style="border-bottom:1px solid #ddd;padding:15px 0">'+
                          '<div class="col-md-7"><span style="padding-left:{{trChildren*10+5}}px" class="category-level-{{trChildren}}">{{trChildren==0? \'\':\'-- \'}}{{trData.productCategoryName}}</span></div>'+
                          '<div class="col-md-3">{{trData.accountId}}</div>'+
                          '<div class="col-md-2"><span ng-if="trChildren!=0">'+
                           '<a href="javascript:;"><i class="cp cp-edit"></i></a>'+
                          '<a href="javascript:;"><i class="cp cp-delete"></i></a>'+
                          '</span></div>'+
                      '</div>'+
                      '<div ng-if="trData.children" ng-repeat="item in trData.children">'+
                          '<div table-repeat tr-data="item" tr-children="trChildrenCount"></div>'+
                      '</div>'+
                      
                  '</div>',*/
                 
                  
    controller: 'ProductCategoryController',
    link: function(scope, el) {
      scope.trChildrenCount=parseInt(scope.trChildren)+1;
      }
};
}]);   

    /* table repeat directive end*/
 /* text editor directive start*/
    app.directive('textEditor', ['$q', '$window', '$rootScope','$sce', function($q, $window, $rootScope, $sce) {
return {
    restrict: 'A',
    require: '?ngModel',
    scope:{
      edId:'=?'
    },
             
    controller: function ($scope) {
         


              },
    link: function(scope, el, attrs, ngModel) {
      var sel,range;
     
      console.log(el);
       var getCharPosition= function(){
        var html_content = el.html();
        sel = $window.getSelection();
        range = sel.getRangeAt(0);
        
        ngModel.$setViewValue(html_content.replace(/&nbsp;/gi,''));
        console.log(html_content.replace(/&nbsp;/gi,''));
      }
  
    el.on('blur keyup change', function() {
          getCharPosition();
        });
   
      $rootScope.$on('addTextToMessage', function(e, val) {
            var spanEl = document.createElement("span");
            spanEl.setAttribute('contenteditable', 'false');
            spanEl.style.color = "#3bb965";
            spanEl.innerHTML = val;
            
        if ($window.getSelection) {
            if (sel&&sel.getRangeAt && sel.rangeCount) {
              range.deleteContents();
              range.insertNode( spanEl );
              
              range.setStartAfter(spanEl);
              
              sel.removeAllRanges();
              sel.addRange(range);
 
              el.focus();
              console.log(val);
            }
            
        } else if (document.selection && document.selection.createRange) {
            document.selection.createRange().text = text;
        } 

      });
      
      }
};
}]);   

    /* text editor directive end*/
