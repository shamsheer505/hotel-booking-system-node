/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
window.routes = {
    '/task/:id': {
         title: 'Task',
        templateUrl: '/templates/scheduling-source.html',
        controller: 'taskDetails',
        route_key: 'TASKDETAILS',
        requireLogin: true,
        breadcrumb:{'Dashboard':'/'}
    },
    '/error': {
        title: 'Error',
        templateUrl: '/templates/error.html',
        route_key: 'ERROR',
         breadcrumb:{'Dashboard':'/','Error':''}
//        controller: 'ErrorCtrl'
    },
    '/dashboard/': {
        title: 'Dashboard',
        templateUrl: '/templates/jch-dashboard.html',
        route_key: 'DASHBOARD',
        controller: 'dashboardCtrl',
        breadcrumb:{'Dashboard':'/'}
    },
    '/': {
        title: 'Dashboard',
        templateUrl: '/templates/jch-dashboard.html',
        route_key: 'DASHBOARD',
        controller: 'dashboardCtrl',
        breadcrumb:{'Dashboard':'/'}
    },
    '/query-details/:id': {
        title: 'Query details',
        templateUrl: '/templates/query-details.html',
        route_key: 'QUERIES',
        controller: 'queryDetailsCtrl',
        breadcrumb:{'Dashboard':'/','Query details':''}
    },
    '/query-list/': {
        title: 'Other Query list',
        templateUrl: '/templates/query-list.html',
        route_key: 'QUERIES',
        controller: 'querylistCtrl',
        breadcrumb:{'Dashboard':'/','Queries':'','Other Query list':''}
    },
//    '/queries/:id': {
//        title: 'Query list',
//        templateUrl: '/templates/queries.html',
//        route_key: 'QUERIES',
//        controller: 'querylistCtrl',
//        breadcrumb:{'Dashboard':'/','Query list':''}
//    },
    '/query-report/': {
        title: 'Query Report',
        templateUrl: '/templates/query-report.html',
        route_key: 'QUERYREPORT',
        controller: 'queryReportCtrl',
        breadcrumb:{'Dashboard':'/','Reports':'','Query Report':''}
    },
    '/resolution-report/': {
        title: 'Resolution Report',
        templateUrl: '/templates/resolution-report.html',
        route_key: 'QUERYREPORT',
        controller: 'resolutionReportCtrl',
        breadcrumb:{'Dashboard':'/','Reports':'','Resolution Report':''}
    },
    '/company-notification/': {
        title: 'Company Notification',
        templateUrl: '/templates/company-notification.html',
        route_key: 'EMAILNOTIFICATION',
        controller: 'companyNotificationCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','Company Notification':''}
    },
    '/add-email-template/': {
        title: 'Add Email Template',
        templateUrl: '/templates/add-email-template.html',
        route_key: 'EMAILTEMPLATEMASTER',
        controller: 'addEmailTempCtrl',
        breadcrumb:{'Dashboard':'/','Email Template':'','Add Email Template':''}
    },
    '/update-email-template/': {
        title: 'Update Email Template',
        templateUrl: '/templates/update-email-template.html',
        route_key: 'EMAILTEMPLATEMASTER',
        controller: 'addEmailTempCtrl',
        breadcrumb:{'Dashboard':'/','Email Template':'','Update Email Template':''}
    },
    '/list-email-template/': {
        title: 'EmailTemplate List',
        templateUrl: '/templates/list-email-template.html',
        route_key: 'EMAILTEMPLATEMASTER',
        controller: 'listEmailTempCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','EmailTemplate List':''}
    },
    '/user-notification/': {
        title: 'Email Template List',
        templateUrl: '/templates/user-notification.html',
        route_key: 'DASHBOARD',
        controller: 'userNotificationCtrl',
         breadcrumb:{'Dashboard':'/','User':'','Email Template List':''}
    },
    '/sla-master/': {
        title: 'SLA List',
        templateUrl: '/templates/sla-master.html',
        route_key: 'SLAMASTER',
        controller: 'listSlaCtrl',
         breadcrumb:{'Dashboard':'/','Setting':'','SLA List':''}
    },
    '/add-sla-master/': {
        title: 'Add SLA Master',
        templateUrl: '/templates/add-sla-master.html',
        route_key: 'SLAMASTER',
        controller: 'addSlaCtrl',
        breadcrumb:{'Dashboard':'/','SLA List':'','Add SLA Master':''}
    },
    '/update-sla-master/': {
        title: 'Update SLA Master',
        templateUrl: '/templates/update-sla-master.html',
        route_key: 'SLAMASTER',
        controller: 'addSlaCtrl',
        breadcrumb:{'Dashboard':'/','SLA List':'','Update SLA Master':''}
    },
    '/add-project/:mapId': {
        title: 'Add Project',
        templateUrl: '/templates/add-project.html',
//        route_key: 'ADDPROJECT',
        route_key: 'DASHBOARD',
        controller: 'addProjectCtrl',
        breadcrumb:{'Dashboard':'/','Add Project':''}
    },
    '/my-account/': {
        title: 'My Account',
        templateUrl: '/templates/my-account.html',
        route_key: 'MYACCOUNT',
        controller: 'myAccountCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','My Account':''}
    },
    '/company-account/': {
        title: 'Company Account',
        templateUrl: '/templates/company-account.html',
        route_key: 'COMPANYACCOUNT',
        controller: 'companyAccountCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','Company Account':''}
    },
    '/service-master/': {
        title: 'Service Master',
        templateUrl: '/templates/service-master.html',
        route_key: 'SERVICEMASTER',
        controller: 'serviceMasterCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','Service Master':''}
    },
    '/vendor-master/': {
        title: 'Vendor Master',
        templateUrl: '/templates/vendor-master.html',
        route_key: 'VENDORMASTER',
        controller: 'vendorMasterCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','Vendor Master':''}
    },
    '/user-master/': {
        title: 'User Master',
        templateUrl: '/templates/user-master.html',
        route_key: 'USERMASTER',
        controller: 'userMasterCtrl',
        breadcrumb:{'Dashboard':'/','Setting':'','User Master':''}
    },
    '/on-board-team/': {
        title: 'Configure-Collaborate',
        templateUrl: '/templates/on-board-team.html',
        route_key: 'USERMASTER',
        controller: 'onBoardMyTeamCtrl',
        breadcrumb:{'Dashboard':'/','On Board My Team':''}
    },
    '/configureDashboard/': {
        title: 'Initial Dashboard',
        templateUrl: '/templates/initial-dashboard.html',
        route_key: 'USERMASTER',
        breadcrumb:{'Dashboard':'/','Initial Dashboard':''}
    },
    '/my-projects/': {
        title: 'My Journals',
        templateUrl: '/templates/my-project.html',
        route_key: 'DASHBOARD',
        breadcrumb:{'Dashboard':'/','My Journals':''}
    },
    '/my-queries/': {
        title: 'My Queries',
        templateUrl: '/templates/my-queries.html',
        route_key: 'DASHBOARD',
        controller: 'myQueriesCtrl',
        breadcrumb:{'Dashboard':'/'}
    },
    '/global-search/': {
        title: 'Search Queries',
        templateUrl: '/templates/global_query_search.html',
        route_key: 'DASHBOARD',
        controller: 'globalSearchCtrl',
        breadcrumb:{'Dashboard':'/','Search Results':''}
    },
    '/project-info/:id': {
        title: 'Journal Info',
        templateUrl: '/templates/project_info.html',
        route_key: 'QUERIES',
        controller: 'projectInfoCtrl',
        breadcrumb:{'Dashboard':'/','Journal Info':''}
    },
    '/queries/:id': {
        title: 'Query list',
        templateUrl: '/templates/queries.html',
        route_key: 'QUERIES',
        controller: 'querylistCtrl',
        breadcrumb:{'Dashboard':'/','Journal Query List':''}
    },
    '/my-team/:id': {
        title: 'Journal Team',
        templateUrl: '/templates/my_team.html',
        route_key: 'QUERIES',
        controller: 'myTeamCtrl',
        breadcrumb:{'Dashboard':'/','Journal Team':''}
    }
};

