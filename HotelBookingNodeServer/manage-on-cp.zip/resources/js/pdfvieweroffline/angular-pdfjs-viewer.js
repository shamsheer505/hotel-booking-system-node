/**
 * angular-pdfjs
 * https://github.com/legalthings/angular-pdfjs
 * Copyright (c) 2015 ; Licensed MIT
 */

+ function() {
    'use strict';

    var module = angular.module('pdfjsViewer', []);

    module.provider('pdfjsViewerConfig', function() {
        var config = {
            workerSrc: null,
            cmapDir: null,
            imageResourcesPath: null,
            disableWorker: false,
            verbosity: null
        };

        this.setWorkerSrc = function(src) {
            config.workerSrc = src;
        };

        this.setCmapDir = function(dir) {
            config.cmapDir = dir;
        };

        this.setImageDir = function(dir) {
            config.imageDir = dir;
        };

        this.disableWorker = function(value) {
            if (typeof value === 'undefined') value = true;
            config.disableWorker = value;
        };

        this.setVerbosity = function(level) {
            config.verbosity = level;
        };

        this.$get = function() {
            return config;
        }
    });

    module.run(['pdfjsViewerConfig', function(pdfjsViewerConfig) {
        if (pdfjsViewerConfig.workerSrc) {
            PDFJS.workerSrc = pdfjsViewerConfig.workerSrc;
        }

        if (pdfjsViewerConfig.cmapDir) {
            PDFJS.cMapUrl = pdfjsViewerConfig.cmapDir;
        }

        if (pdfjsViewerConfig.imageDir) {
            PDFJS.imageResourcesPath = pdfjsViewerConfig.imageDir;
        }

        if (pdfjsViewerConfig.disableWorker) {
            PDFJS.disableWorker = true;
        }

        if (pdfjsViewerConfig.verbosity !== null) {
            var level = pdfjsViewerConfig.verbosity;
            if (typeof level === 'string') level = PDFJS.VERBOSITY_LEVELS[level];
            PDFJS.verbosity = pdfjsViewerConfig.verbosity;
        }
    }]);

    module.directive('pdfjsViewer', ['$interval', '$window', function($interval, $window) {
        return {
            templateUrl: '../vendor/pdf.js-viewer/pdf-viewer.html',
            restrict: 'E',
            scope: {
                onInit: '&',
                onPageLoad: '&',
                scale: '=?',
                src: '@?',
                widgetid: '@?',
                data: '=?'
            },
    		//controller: 'widgetCtrl', 
            controller: ['$scope', '$http', '$location', function($scope, $http, $location) { 
				
				if($location.$$absUrl.indexOf("/help") != '-1'){ 
					//alert('help')
				}else{
					//alert($scope.widgetid);
					$http({
						method: 'POST',
						url: '/widgetviewoffline',
						data: {
							"id": $scope.widgetid
						}
					}).then(function(response) {
						//console.log(response.data)
						if(response.data.code==401){
							
							alert(response.data.statusMessage);
							return false;
						}
						//console.log(response.data.data)
						$scope.src =  response.data.data.widgetURL.toString();
						//alert($scope.src)
					}); 
				} 
				
				 

            }],
            link: function($scope, $element, $attrs) {
                $scope.widget_new_click = function() {

                };

                PDFJS.searchSentenceFxn = function(data, id, divContent, divOffsetTop) {
                    var htmlString = '';
                    //console.log(divContent);
                    if (divContent.length >= 3) {
                        var first = divContent[0].class_name ? 'search_highlight' : '',
                            second = divContent[1].class_name ? 'search_highlight' : '',
                            third = divContent[2].class_name ? 'search_highlight' : ''
                        htmlString = '<span class="' + first + '">' + divContent[0].text + '</span>' + '<span class="' + second + '">' + divContent[1].text + '</span>' + '<span class="' + third + '">' + divContent[2].text + '</span>';

                        PDFJS.searchSentence.push({ offsetTop: divOffsetTop, htmlContent: htmlString });
                        $scope.searchedData = PDFJS.searchSentence;

                    }

                    if (PDFJS.searchSentenceId.indexOf(id) == -1) {
                        PDFJS.searchSentenceId.push(id);
                    }

                };
                PDFJS.searchSentenceClear = function() {
                    PDFJS.searchSentenceId = [];
                    PDFJS.searchSentence = [];
                    $scope.searchedData = PDFJS.searchSentence;
                };
                $scope.searchedPage = function(number) {

                    var scrollDuration = 1000;
                    var myDiv = document.getElementById('viewerContainer');
                    myDiv.scrollTop = number;
                };
                $scope.togglePdfBook = true;
                $element.children().wrap('<div class="pdfjs" style="width: 100%; height: 100%;"></div>');

                var initialised = false;
                var loaded = {};
                var numLoaded = 0;

                if (!window.PDFJS) {
                    return console.warn("PDFJS is not set! Make sure that pdf.js is loaded before angular-pdfjs-viewer.js is loaded.");
                }

                // initialize the pdf viewer with (with empty source)
                window.PDFJS.webViewerLoad("");

                function onPdfInit() {
                    initialised = true;

                    if ($attrs.removeMouseListeners === "true") {
                        window.removeEventListener('DOMMouseScroll', handleMouseWheel);
                        window.removeEventListener('mousewheel', handleMouseWheel);

                        var pages = document.querySelectorAll('.page');
                        angular.forEach(pages, function(page) {
                            angular.element(page).children().css('pointer-events', 'none');
                        });
                    }
                    if ($scope.onInit) $scope.onInit();
                }

                var poller = $interval(function() {
                    if (!window.PDFViewerApplication) {
                        return;
                    }

                    var pdfViewer = window.PDFViewerApplication.pdfViewer;

                    if (pdfViewer) {
                        if ($scope.scale !== pdfViewer.currentScale) {
                            loaded = {};
                            numLoaded = 0;
                            $scope.scale = pdfViewer.currentScale;
                        }
                    } else {
                        console.warn("PDFViewerApplication.pdfViewer is not set");
                    }

                    var pages = document.querySelectorAll('.page');
                    angular.forEach(pages, function(page) {
                        var element = angular.element(page);
                        var pageNum = element.attr('data-page-number');

                        if (!element.attr('data-loaded')) {
                            delete loaded[pageNum];
                            return;
                        }

                        if (pageNum in loaded) return;

                        if (!initialised) onPdfInit();

                        if ($scope.onPageLoad) {
                            if ($scope.onPageLoad({ page: pageNum }) === false) return;
                        }

                        loaded[pageNum] = true;
                        numLoaded++;
                    });
                }, 200);

                $element.on('$destroy', function() {
                    $interval.cancel(poller);
                });

                // watch pdf source
                $scope.$watchGroup([
                    function() { return $scope.src; },
                    function() { return $scope.data; }
                ], function(values) {
                    var src = values[0];
                    var data = values[1];

                    if (!src && !data) {
                        return;
                    }

                    window.PDFViewerApplication.open(src || data);
                });

                // watch other attributes
                $scope.$watch(function() {
                    return $attrs;
                }, function() {
                    if ($attrs.open === 'false') {
                        document.getElementById('openFile').setAttribute('hidden', 'true');
                        document.getElementById('secondaryOpenFile').setAttribute('hidden', 'true');
                    }

                    if ($attrs.download === 'false') {
                        document.getElementById('download').setAttribute('hidden', 'true');
                        document.getElementById('secondaryDownload').setAttribute('hidden', 'true');
                    }

                    if ($attrs.print === 'false') {
                        document.getElementById('print').setAttribute('hidden', 'true');
                        document.getElementById('secondaryPrint').setAttribute('hidden', 'true');
                    }

                    if ($attrs.width) {
                        document.getElementById('outerContainer').style.width = $attrs.width;
                    }

                    if ($attrs.height) {
                        document.getElementById('outerContainer').style.height = $attrs.height;
                    }
                });
				 
               /* var book = new EPUBJS.Book();
                $scope.openPdfOrBook = function() {
                    var $el = document.getElementById("epubBookArea");

//                    book = ePub("https://s3.amazonaws.com/moby-dick/", { restore: true, storage: false });
                    book = ePub(localStorage.getItem("EpubSrc"), { restore: true, storage: false });

                    if ($scope.togglePdfBook == false) {
                        book = null;
                        $el.removeChild($el.firstChild);
                        $scope.togglePdfBook = true;

                    } else {


                        $scope.togglePdfBook = false;

                        //book = ePub("https://s3.amazonaws.com/moby-dick/", { restore: true,storage: false });
                        book.renderTo($el);
                    }
                    console.log(book);


                };
                $scope.BookPrevPage = function() {
                    book.prevPage();
                };
                $scope.BookNextPage = function() {
                    book.nextPage();
                };
                $scope.deleteWidgetModal = function() {
                    console.log('hi');
                    $('#deleteWidget').modal('toggle');
                }*/
            }
        };
    }]);
	module.directive('epubjsViewer', ['$interval', '$window', function($interval, $window) {
        return {
            templateUrl: 'vendor/pdf.js-viewer/epub-viewer.html',
            restrict: 'E',
            scope: {
                onInit: '&',
                onPageLoad: '&',
                scale: '=?',
                src: '@?',
                data: '=?'
            },
            controller: ['$scope', '$http', function($scope, $http) {

              /*  $scope.rate = 5;
                $scope.max = 10;
                $scope.isReadonly = false;

                $scope.hoveringOver = function(value) {
                    $scope.overStar = value;
                    $scope.percent = 100 * (value / $scope.max);
                };
  				
				
                $scope.ratingStates = [
                    { stateOn: 'glyphicon-ok-sign', stateOff: 'glyphicon-ok-circle' },
                    { stateOn: 'glyphicon-star', stateOff: 'glyphicon-star-empty' },
                    { stateOn: 'glyphicon-heart', stateOff: 'glyphicon-ban-circle' },
                    { stateOn: 'glyphicon-heart' },
                    { stateOff: 'glyphicon-off' }
                ];*/

            }],
            link: function($scope, $element, $attrs) { 
				
                $scope.widget_new_click = function() {

                };
                $scope.togglePdfBook = false;
                $element.children().wrap('<div class="pdfjs" style="width: 100%; height: 100%;"></div>');
				
				var book = new EPUBJS.Book();
				var $el = document.getElementById("epubBookArea");

//                    book = ePub("https://s3.amazonaws.com/moby-dick/", { restore: true, storage: false });
				book = ePub(localStorage.getItem("EpubSrc"), { restore: true, storage: false }); book.renderTo($el);
				
				$scope.BookPrevPage = function() {
                    book.prevPage();
                };
                $scope.BookNextPage = function() {
                    book.nextPage();
                };
                
   
                // initialize the pdf viewer with (with empty source)
                window.PDFJS.webViewerLoad(""); 
				
                // watch pdf source
                $scope.$watchGroup([
                    function() { return $scope.src; },
                    function() { return $scope.data; }
                ], function(values) {
                    var src = values[0];
                    var data = values[1];

                    if (!src && !data) {
                        return;
                    }

					//alert(values)	
					
                    //window.PDFViewerApplication.open(src || data);
                }); 
               
            }
        };
    }]);
}();
