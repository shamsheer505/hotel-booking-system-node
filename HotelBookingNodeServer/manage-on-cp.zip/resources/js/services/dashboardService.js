'use strict'
var app = angular.module('ManageonCP.dashboard.serivce', [])
    .service('dashboardService', function () {
       
        this.addNewWidgetFormInput = function() {
            return {
                widget:"",
                error:false,
                errorMsg:"",
                loading:false,
                widget_list:[
                    {
                        id:1,
                        name:"Activity summary"
                    },
                    {
                        id:2,
                        name:"Delivary summary"
                    },
                    {
                        id:3,
                        name:"Title summary"
                    },
                    {
                        id:4,
                        name:"Approval"
                    },
                    {
                        id:5,
                        name:"E-pub checker validation"
                    }
                ],
                chart:"",
                chart_list:[
                    {
                        id:1,
                        type:"line",
                        image:"resources/images/line.png"
                    },
                    {
                        id:2,
                        type:"column",
                        image:"resources/images/column.png"
                    },
                    {
                        id:3,
                        type:"pie",
                        image:"resources/images/pie.png"
                    },
                    {
                        id:4,
                        type:"donut",
                        image:"resources/images/donut.png"
                    },
                    {
                        id:5,
                        type:"bubble",
                        image:"resources/images/bubble.png"
                    },
                    {
                        id:6,
                        type:"stacked column",
                        image:"resources/images/stacked-column.png"
                    },
                    {
                        id:7,
                        type:"smooth line",
                        image:"resources/images/smooth-line.png"
                    },
                    {
                        id:8,
                        type:"mixed",
                        image:"resources/images/mixed.png"
                    }
                ],
                range:"",
                range_list:[
                    {
                        name:"weekly"
                    },
                    {
                        name:"monthly"
                    },
                    {
                        name:"quarterly"
                    },
                    {
                        name:"half yearly"
                    },
                    {
                        name:"yearly"
                    },
                    {
                        name:"custom"
                    }
                ],
                column:"",
                column_list:[
                    {
                        id:1,
                        type:"col-sm3",
                        image:"resources/images/col-1.png"
                    },
                    {
                        id:2,
                        type:"col-sm-6",
                        image:"resources/images/col-2.png"
                    },
                    {
                        id:3,
                        type:"col-sm-12",
                        image:"resources/images/col-3.png"
                    }
                ]
            }
        };
    this.addNewWidgetData = function(data) {
        return {
            widget:'',
            chart:'',
            range:'',
            column:''
        };
    };
    })