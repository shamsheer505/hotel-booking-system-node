app.service('httpCall', function ($http, $q) {
      // var cUrl = 'https://api.codemantra.com';


      var cUrl = 'https://localhost:8080/';

        var cancel = $q.defer(),
            cancelHttp = { timeout: cancel.promise, cancel: cancel };
        return {
            apiUrl: function() {
                return cUrl;
            },
            getApi: function(url) {

                return $http.get(cUrl + url, cancelHttp);
            },
            getApiData: function(url, data) {
                return $http.get(cUrl + url, data, cancelHttp);
            },
            postApi: function(url, data) {
                return $http.post(cUrl + url, data, cancelHttp);
            },
            putApi: function(url, data) {
                return $http.put(cUrl + url, data, cancelHttp);
            },
            ppApi: function(url, data, method) {
                if (method === 'put') {
                    return $http.put(cUrl + url, data, cancelHttp);
                } else {
                    return $http.post(cUrl + url, data, cancelHttp);
                }
            },
            deleteApi: function(url) {
                return $http.delete(cUrl + url, cancelHttp);
            }

        };
  
});
app.service('notificationService', function ($filter) {
   this.modifyNotifyList = function(data) {
            var newData=[], currentData="";
            angular.forEach(data, function(value1, key1) {
                if ($filter('date')(value1.notificationDateString, 'MM/dd/yyyy') !== currentData) {
                  
                   value1.uniqueDateTime=value1.notificationDateString;
                }
                currentData=$filter('date')(value1.notificationDateString, 'MM/dd/yyyy');
                
                newData.push(value1);
            });
            return newData;
        };

    this.statusFilterListing = function() {
            return [
                { name: 'All', current: true },
                { name: 'Read', current: false },
                { name: 'Unread', current: false },
                { name: 'Flag', current: false }
            ];
        };
    this.statusUpdate = function(statusList, data) {
            angular.forEach(statusList, function(value1, key1) {
                if (data.name === value1.name) {
                    statusList[key1].current = true;
                } else {
                    statusList[key1].current = false;
                }
            });
            return statusList;
        };
    
  
});
app.service('scheduleCreationService', function ($http, $q) {
   
    this.notifyListing = function(data) {
            angular.forEach(data, function(value1, key1) {
                data[key1].selected=false;
            });
            return data;
        };
   
    this.notifyListUpdate = function(data, item, mode) {
            angular.forEach(data, function(value1, key1) {
                if(item.id==value1.id){
                    if(mode){
                        data[key1].selected=true;
                    }else{
                         data[key1].selected=false;
                    }
                }
                
            });
            return data;
        };
    this.selectedUpdate = function(data, item, mode) {
        if(mode){
            data.push(item);
        }else{
            angular.forEach(data, function(value1, key1) {
                if(item.id==value1.id){
                   data.splice(key1, 1);
                }
                
            });
        }
            
            return data;
        };
    this.scheduleData= function(){
        return {
            createMode:true,
            notificationList:[],
            notificationSelected:[],
            frequencySelected:'Select Frequency',
            freqList:[
                {   
                    id:1,
                    type:'Weekly',
                    days_selected:'',
                    days:['Monday', 'Tuesday','Wednesday','Thursday', 'Friday','Saturday','Sunday'],
                    selected:false
                },
                {
                    id:2,
                    type:'Monthly',
                    selected:false
                },
                {
                    id:3,
                    type:'Custom days',
                    selected:false,
                    day_no:''
                }
            ]
        }
    };
    this.scheduleEditData= function(data){

        return {
            createMode:true,
            notificationList:[],
            notificationSelected:[{name:data.name,id:data.id}],
            frequencySelected:data.frequency,
            freqList:[
                {   
                    id:1,
                    type:'Weekly',
                    days_selected:data.freq_data.days_selected?data.freq_data.days_selected:'',
                    days:['Monday', 'Tuesday','Wednesday','Thursday', 'Friday','Saturday','Sunday'],
                    selected:data.id==1?true:false
                },
                {
                    id:2,
                    type:'Monthly',
                    selected:data.id==2?true:false
                },
                {
                    id:3,
                    type:'Custom days',
                    selected:data.id==3?true:false,
                    day_no:data.freq_data.day_no?data.freq_data.day_no:'',
                }
            ]
        };
    };
    this.scheduleSubmitData= function(data){
        return data;
    };
   
});