
(function(window, document, $) {
    'use strict';
    var $html = $('html');
    var $body = $('body');


    $(window).on('load',function(){
        $.app.menu.init();

        // Navigation configurations
        var config = {
            speed: 300 // set speed to expand / collpase menu
        };
        if($.app.nav.initialized === false){
            $.app.nav.init(config);
        }


    });


    $(document).on('click', '.menu-toggle', function(e) {
        e.preventDefault();

        // Toggle menu
        $.app.menu.toggle();

        return false;
    });

    // Add Children Class
    $('.navigation').find('li').has('ul').addClass('has-sub');

})(window, document, jQuery);