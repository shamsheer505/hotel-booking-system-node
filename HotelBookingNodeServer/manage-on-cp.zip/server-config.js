/**
 * 
 */
var server = http.createServer(app);
//app.listen(config.manage_port, function () {});