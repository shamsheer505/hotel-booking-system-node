/**********************************************************************************************************************
`Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
19-05-2017			  1.0       	Saravanan K	  		Initial Version.
16-06-2017			  1.1       	Senthil J	  		Updated Version.
10-08-2017			  1.2       	Shahid ul Islam	  	Added code for User Profile.
11-08-2017			  1.3       	Saravanan K	  		Integration for Search microservices.
21-08-2017			  1.4       	Shahid ul Islam	  	Added code for User Master - I
03-11-2017			  1.5       	Saravanan K	  		Integration for Metadata microservices.
***********************************************************************************************************************/

/* require */
config = require('./config.json');
express = require('express');
bodyParser = require('body-parser');
session = require('express-session');
urlencode = require('urlencode');
http = require('http');
https = require('https');
redis = require('redis');
winston = require('winston');
path = require('path');
fs = require('fs');
multer = require('multer');
methodOverride = require('method-override');
fileUpload = require('express-fileupload');
url = require('url');
  qs = require('querystring');

var request = require('request');
const XLSX = require('xlsx');
const Excel = require('exceljs');
//Added by shamsheer for zlib compression
var compression = require('compression');
//var MongoClient = require('mongodb').MongoClient;
//Added by shamsheer to enable HTTP/2 
const spdy = require('spdy');


var fs = require("fs");
fsextra = require("fs-extra");
uuid = require('uuid');
sharp = require('sharp');
dateFormat = require('dateformat');

function read(f) {
    return fs.readFileSync(f).toString();
}
function include(f) {
    eval.apply(global, [read(f)]);
}

/* include additional node js scripts by specifing 
include('service_dev_1.js');
*/

/* server and other cofig path details */
service_ip = config.service_ip;

/* Search - v1.3 - starts here */
search_service_ip =config.service_ip;
manageqa_ip =config.manageqa_ip;
/* Search - v1.3 - ends here */
//8088 - onix
//
onix_port = '8088',user_port = '8082', login_port = '8082',email_port='8083'
	,search_port="8084",admin_port='8085',fileupload_port='8086'
		,business_port='8087',report_port='8089',metadata_port='8090',dashboard_port='8091', drm_port='8092', widget_port='8093',downloadNotifiy_port='8094',notification_port='8096',support_port='8107';
profile_pic_Db_path = "/image/profilepic/userid_";
profile_pic_path = "D:/2016 jully CW-Spring version/collaborate web/collab/image/profilepic/userid_";
logo_pic_Db_path = "/image/profilepic/companyid_";
logo_pic_path = "D:/2016 jully CW-Spring version/collaborate web/collab/image/profilepic/companyid_";
project_instruction_file_path = "/uploads/instructions/";
company_profile_picture_file_path = "/uploads/company/";
user_profile_picture_file_path = "/uploads/user/";
email_inline_attachements = "/uploads/email/";
metadatauploadPath="/metadata/upload/";
metadataonixuploadPath="/metadata/onixupload/";
gdsExcelUploadPath="/templates/";
newgdsExcelUploadPath="/templates/temp/";
watermarkpath ="/watermark/extract/"

//customTemplatePath="/home/codemantra/Desktop/Custom/"

app = express();
//user_identity='';
session_expiration_time=config.session_expiry_time; //seconds


/* logger details */
logger = new (winston.Logger)({
    transports: [
        new (winston.transports.File)({
            name: 'info_file',
            filename: 'log_info.log',
            level: 'info'
        }),
        new (winston.transports.File)({
            name: 'error-file',
            filename: 'log_error.log',
            level: 'error'
        })
    ]
});

app = express();
//Added by shamsheer for zlib compression
//app.use(compression());

app.use(function (req, res, next) { //allow cross origin requests
	
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   /* //console.log(req);
    client.hgetall(req.headers.sessionID, function (error, session) {
		   //console.log(session);
		   if(session!=null && session.token!=null)
			   res.header("Authorization",'Bearer '+ session.token);
		   //httpRes.json({"token":session.token});
	   });
      */
    next();
});

app.all(['*server.js*', '*server-config.js*', '*config.json*', '*key.pem*', '*package.json*', '*bower.json*',
'*cMSSL.crt*', '*c2.crt*', '*c3.crt*', '*ssl.key*', '*Gruntfile.js*',
'*Dockerfile*', '*package-lock.json*', '*Public/**'], function (req, res, next){
 res.status(404).send({
    message: 'Not Found'
 });
});

app.all(['/var/*','/etc/*','/bin/*','/boot/*','/dev/*','/home/*','/lib/*','/lib64/*','/lost+found/*',
 '/media/*','/mnt/*','/opt/*','/proc/*','/root/*','/run/*','/sbin/*','/snap/*','/srv/*','/sys/*',
 '/tmp/*','/usr/*',], function (req,res, next) {

 res.status(403).send({
    message: 'Access Forbidden'
 });

});



//app.base ="/views";
app.use(express.static(__dirname));
app.use(express.static(__dirname + '/uploads/company'));
app.use(express.static(__dirname + '/uploads/instructions'));
app.use(express.static(__dirname + '/uploads/user'));
app.use(express.static(__dirname + '/uploads/metadata'));
app.use(express.static(__dirname + '/acsm'));
app.use(express.static(__dirname + '/custom'));
app.engine('html', require('ejs').renderFile);




app.all('/api/*', function( req, res, next ){
    corsIndex = $.inArray( req.headers.origin, config.CORS_WHITELIST );
    if( corsIndex > -1 ){
        res.header( 'Access-Control-Allow-Origin', config.CORS_WHITELIST[ corsIndex ]);
        res.header( 'Access-Control-Allow-Headers', 'Authorization');
    }

    // check for session id in authorize header. if true, set headers.cookie with signed session id
    var sid = req.headers.authorization;
    if(sid){
        var cookie = require('cookie'),
        signature = require('cookie-signature');
        var signed = 's:' + signature.sign(sid, config.SESS_SECRET);
        var data = cookie.serialize(config.SESS_COOKIE_NAME, signed);
        req.headers.cookie = data;
    }
    next();
});

app.use(session({secret: 'codemantra', cookie: {}}));
//app.use(session({secret: 'codemantra', cookie: {httpOnly:true,secure:true}}));

/* Session code */
client = redis.createClient({port: config.redis_port,host: config.redis_ip,expire : 60});
client.auth(config.redis_password);

 
app.use(express.static('/'));
app.use(bodyParser.json({limit : '50mb'}));

/** Added for SyntaxError Handling in NodeJs - Shahid  :: START **/
app.use (function (error, req, res, next){
    //Catch bodyParser error
    if (error instanceof SyntaxError) {
        var errorResponse = {
            "status": "BAD_REQUEST",
            "timestamp": dateFormat(new Date(), "dd-mm-yyyy hh:mm:ss"),
            "message": "Malformed JSON Request",
            "debugMessage": error.stack
        }
        res.send(errorResponse);
    }else{
        next();
    }
});

/** Added for SyntaxError Handling in NodeJs - Shahid  :: END **/



app.use(bodyParser.urlencoded({extended: true, limit : '50mb'}));
app.use(fileUpload());

var vendor_storage = multer.diskStorage({//multers disk storage settings
    destination: function (req, file, cb) {
        cb(null, 'uploads/vendor/');
    },
    filename: function (req, file, cb) {
        var sessionId = req.sessionID;
        client.hgetall(sessionId, function (error, session) {
            if (session) {
                var company_id = session.company_id;
                cb(null, 'company' + '-' + company_id + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1]);
            }
        });
    },
    onFileUploadStart: function (file) {
    }
});

app.use(updateSession);

/* Define authentication middleware BEFORE your routes */


authenticate = function (req, res, next) {
	var sessionId = req.sessionID;
	client.hgetall(sessionId, function (error, session) {
		var isAuthenticated = true;
        if (error || session == null||req.query.expired) {
        	////console.log('Session exired' );
        	res.redirect("/login/#/");
        	//res.redirect("under-construction.html");
        }
        else if(session){ 
        	var datetime = new Date();
        	//console.log(datetime);
        	//console.log("Will logout in another "+session_expiration_time + " from now("+datetime+")");
        	client.expire(sessionId, session_expiration_time);  
        	next();
        }
    });
}

logActivity = function (req, res, next) {
    var sessionId = req.sessionID;
    client.hgetall(sessionId, function (error, session) {
        if (error || session == null || req.query.expired) {
            ////console.log('Session exired' );
            res.redirect("/login/#/");
            //res.redirect("under-construction.html");
        }
        else if (session) {
            var datetime = new Date();
            //console.log(datetime);
            try {
                var date = new Date();
                //  var dir = config.daily_log_file_path;
                if (!fs.existsSync(config.daily_log_file_path)) {
                    fs.mkdirSync(config.daily_log_file_path);
                }
                if (req.path == '/viewSearch') {
                    if (req.body.exportCheck != null && req.body.exportCheck == true) {
                        fs.appendFile(config.daily_log_file_path + "UI-" + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + ".log"

                            , (new Date()) + " " + session.userId + " " + session.userName + " requested "

                            + req.path + " : " + req.body.pageName + " page export." + JSON.stringify(req.body) + "\n"

                            , function (err) {

                                if (err) console.log("Error : Unable to save daily activity log file");


                            });
                    }
                    else {
                        fs.appendFile(config.daily_log_file_path + "UI-" + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + ".log"

                            , (new Date()) + " " + session.userId + " " + session.userName + " requested "

                            + req.path + " : " + req.body.pageName + " page. Request Body : " + JSON.stringify(req.body) + "\n"

                            , function (err) {

                                if (err) console.log("Error : Unable to save daily activity log file");


                            });
                    }
                }
                else {
                    if (req.path == '/loadAllReportChart' || req.path == '/loadAllReportGrid' || req.path == '/downloadCSVFile') {
                        fs.appendFile(config.daily_log_file_path + "UI-" + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + ".log"

                            , (new Date()) + " " + session.userId + " " + session.userName + " requested "

                            + req.path + " : " + req.body.pageName + " page." + "\n"

                            , function (err) {

                                if (err) console.log("Error : Unable to save daily activity log file");


                            });
                    }
                    else {
                        fs.appendFile(config.daily_log_file_path + "UI-" + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + ".log"

                            , (new Date()) + " " + session.userId + " " + session.userName + " requested "

                            + req.path + "\n"

                            , function (err) {

                                if (err) console.log("Error : Unable to save daily activity log file");
                            });
                    }
                }
            } catch (error) {
                console.log("Error : Unable to save daily activity log file");
            }
            next();
        }
    });
}

function updateSession(httpReq, httpRes, nextRoute) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function (error, session) {
        if (session != null) {
            session['loginTime'] = new Date().getTime();
            client.hmset(sessionId, session);
        }
        nextRoute();
    });
}


app.get('/keepalive',function(httpReq,httpRes){
    httpRes.json({"success":"true"});
});

/* Get service integration starts here*/

/* landing page*/

app.get('/',function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;
	 
	////console.log(sessionId +" : " +  session_expiration_time);
	
	//client.expire(sessionId, session_expiration_time);
	
	client.hgetall(sessionId, function (error, session) {
		var isAuthenticated = true;
        if (error || session == null) {
           httpRes.redirect('login/#');
           //
             //console.log('Loading under-construction!!');
        	//httpRes.redirect("under-construction.html");
        }else 
        	httpRes.render('base.html');
	});
});


app.get('/setLanguage', function (httpReq, httpRes) {
	////console.log('Set language');
	var sessionID = httpReq.sessionID;
	////console.log(' sessionID '+ sessionID + " : "+ httpReq.param('lang') );
	   
	client.set(sessionID+"-Lang",  httpReq.param('lang'), function(err, reply) {
		  ////console.log(reply);
		  httpRes.json({"language":reply});
		});
});
  app.get('/getLanguage', function (httpReq, httpRes) {
	////console.log('get language ');
	var sessionID = httpReq.sessionID;
	client.get(sessionID+"-Lang", function(err, reply) {
		////console.log(reply);
		httpRes.json({"language":reply});
	});
  });


app.get('/getToken',authenticate, function (httpReq, httpRes) {
	////console.log('get token');
	var sessionID = httpReq.sessionID;
	////console.log(' sessionID '+ sessionID);
	   
	 // var data = '';
	  client.hgetall(sessionID, function (error, session) {
		   ////console.log(session);
		   //data = session.token;
		  // //console.log(' sessionID '+ data);
		   httpRes.json({"token":session.token});
	   });
	  
	  
	});
/* login page. */
app.get('/login', function (httpReq, httpRes) {
	////console.log('get /login');
   var loginIP = httpReq.ip;
   var sessionID = httpReq.sessionID;
   var count = 0;
  // var validation = {error_deactivated: false, error_invalid: false, loginAttempt: 0, captcha_validation: false};
   client.get(sessionID, function (err, session) {
	   ////console.log('get session '+ sessionID + " : " );
       if (session == null) {
           client.hgetall(loginIP, function (err, value) {
               if (value == null)
                   client.hmset(loginIP, ['loginAttempt', 0]);
               httpRes.render('login.html');
           });
       } else {
           httpRes.render('base.html');
       }
   });
});

app.get('/dashboard',authenticate, function (httpReq, httpRes) {
	////console.log('get /dashboard');
   var loginIP = httpReq.ip;
   var sessionID = httpReq.sessionID;
   var count = 0;
   client.get(sessionID, function (err, session) {
	   ////console.log('get session '+ sessionID + " : " );
	   ////console.log(session);
	   ////console.log(err);
       if (session == null || session == undefined) {
                   httpRes.redirect('/login');
       } else {
           httpRes.redirect('/views/base.html#/');
       }
   });
});

/* User Roles 
app.get('/getRoles',authenticate, function (httpReq, httpRes) {
    var company_id = user_identity.company_id;
    var loginOptions = {
        host: service_ip,
        port: user_port,
        path: '/user/role/All/' + company_id,
        method: 'GET'
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
            //  httpRes.json(reply);
            data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0 && res.statusCode == 200) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});*/
app.get('/setpassword1/:accesskey/:lang', function (httpReq, httpRes) {
     //	console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        ////console.log(language+"lang");
        if(language===undefined || language==='undefined' || language==='')
        	language ='en';
        var invitationOption = {
            host: service_ip,
            port: user_port,
            path: '/manage-login-service/verifyaccesswithoutemail/' + accesskey,
            method: 'GET'
        };
        var req = http.request(invitationOption, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
                //console.log(user.status);
                if(user.status == 'VERIFYACCESS.SUCCESS.ACCESSKEY_VALID') {
                	httpRes.send("200");
                }
                else if (user.status == 'VERIFYACCESS.ERROR.ACCESSKEY_EXPIRED') {
                	httpRes.send("400");
                	//httpRes.data = "Invalid"
                } else if(user.status == 'VERIFYACCESS.ERROR.ACCESSKEY_NOT_VALID'){
                	httpRes.send("400");
                	//httpRes.render = "Invalid"
                	//httpRes.end('<h2>Invalid access key, Please contact to our Admin !!!</h2>');
                	// httpRes.render('errorMessage.html', {userName: user.user_name});//
                }
            });
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});

app.get('/forgetinvitation', function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    try {
        	var link = httpReq.param('link');
        	var invitationOption = {
        			host: service_ip,
        			port: user_port,
        			path: '/user/forgetinvitation?link=' + link,
        			method: 'GET'
        	};
        	var req = http.request(invitationOption, function (res) {
        		var data = "";
        		res.on('data', function (reply) {
        			data += reply;
        		});
        		res.on('end', function () {
        			var user = JSON.parse(data);
        			if (user.status == 'success') {
        				client.set(sessionId, user.user_id);
        				httpRes.render('password-reset.html', {userName: user.user_name});
        			} else {
        				httpRes.render('invalid-link.html', {userName: user.user_name});
        			}
        		});
        	});
        	req.on('error', function (error) {
        	});
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation');
    }
});

app.get('/drm/:drmId', function (httpReq, httpRes) {
	     httpRes.render('drm.html',{drm:httpReq.param("drmId")});
});

app.get('/setpassword/:accessKey/:lang', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;
    client.del(sessionId);
    client.del(sessionId+"-Lang");
	httpRes.render('resetpassword.html',{accessKey:httpReq.param("accessKey"),lang:httpReq.param("lang")});
});

app.get('/setpassword/:accessKey', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;
    client.del(sessionId);
    client.del(sessionId+"-Lang");
    httpRes.render('resetpassword.html',{accessKey:httpReq.param("accessKey"),lang:"en"});
});
app.get('/widget/:widgetId', function (httpReq, httpRes) {
	     httpRes.render('widget.html',{widgetparam:httpReq.param("widgetId")});
});

app.get('/viewer/:widgetId', function (httpReq, httpRes) {
	     httpRes.render('viewerBase.html',{widgetparam:httpReq.param("widgetId")});
});
app.get('/help', function (httpReq, httpRes) {
	     httpRes.render('help.html');
});

app.post('/widgetviewoffline', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
/*        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {*/
                var viewSearch = {
				   host: service_ip,
				   port: widget_port,
				   path: '/manage-widget-service/view',
				   method: 'POST',
				   headers: {
					   'Content-Type': 'application/json'
				   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        //console.log(decoded_buffer);
                         //console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
           // }
      //  });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});

app.get('/drmData/:drmId', function (httpReq, httpRes) {
	////console.log('Server');
	   try {
		   
		   	//var link = httpReq.param('link');
		    var request_options = {
	                host: service_ip,
	                port: drm_port,
	                path: '/manage-drm-service/drm/'+httpReq.param("drmId"),
	                method: 'GET',
	                headers: {
	                    'Content-Type': 'application/json',
	                } 
	            };
	       	var drmReq = http.request(request_options, function (drmRes) {
	       		var data = "";
	       		drmRes.on('data', function (reply) {
	       			data += reply;
	       		});
	       		drmRes.on('end', function () {
	       			var response = JSON.parse(data);
	       			////console.log(response)
	       			//if(response.data!=null && response.data.length!=0)
       				{
	       				httpRes.send(response.data);
       				}
	       			//else	       				httpRes.send('NO-DATA');
	       		});
	       	});
	       	drmReq.on('error', function (error) {
	       	});
	       	drmReq.end();
} catch (error) {
    logger.log('error', 'error caught while verifying user invitation');
}
    
});

app.get('/drm/:drmId/download', function (httpReq, httpRes) {
	httpRes.download('/acsm/'+httpReq.param("drmId"));
});

app.get('/mdataTemplate/:fileId', function (httpReq, httpRes) {
	httpRes.download('/metadata/custom/'+httpReq.param("fileId"));
});

/* SHAHID - Watermark Changes : Start */
app.get('/watermark/:watermarkId', function(httpReq, httpRes) {
    httpRes.render('watermark.html', { watermarkId: httpReq.param("watermarkId") });
});

app.get('/watermarkData/:watermarkId', function(httpReq, httpRes) {
    try {
        var request_options = {
            host: service_ip,
            port: drm_port,
            path: '/manage-drm-service/watermark/' + httpReq.param("watermarkId"),
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        };
        var req = http.request(request_options, function(res) {
            var data = "";
            res.on('data', function(reply) {
                data += reply;
            });
            res.on('end', function() {
                httpRes.json(JSON.parse(data));
            });
        });
        req.on('error', function(error) {
            ////console.log(error);
            httpRes.json(JSON.parse('[]'));
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while getting watermarkDetails');
    }
});
/* SHAHID - Watermark Changes : End */

/* Displaying users list in dashboard.*/
app.get('/user',authenticate, function (httpReq, httpRes) {
	var vendorId;
    var companyid = user_identity.company_id;
    var loginOptions = {
               host: service_ip,
               port: user_port,
               path: '/user/All/' + companyid,
               method: 'GET'
    };
    var req = http.request(loginOptions, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  //  httpRes.json(reply);
                   data += reply;
               });
               res.on('end', function () {
                   httpRes.json(JSON.parse(data));
               })
    });
    req.on('error', function (error) {
               ////console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

/* user profile accountUser */
/*app.get('/accountUser',authenticate, function (httpReq, httpRes) {
     var loginOptions = {
            host: service_ip,
            port: user_port,
            path: '/user/' + user_identity.user_id,
            method: 'GET'
     };
     var req = http.request(loginOptions, function (res) {
            res.setEncoding('utf8');
            var data = "";
            res.on('data', function (reply) {
                  data += reply;
            });
            res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                         httpRes.json(JSON.parse(data));
                  } else {
                          httpRes.json(JSON.parse('[]'));
                  }
             })
       });
       req.on('error', function (error) {
              //console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.end();
});*/

/* Logout: once the logout is completed then it will redirect to login page.*/

setInterval(logoutInactiveSessions, config.session_expiry_verify_interval); // 300000 = 5 minutes

function logoutInactiveSessions() {
        logger.log('info', 'checkSessionExpiry :: checking session expiry');
        var logUserOut = false;
        var sessionList = [];
        var count = 0;
        client.keys('*', function (err, keys) {
            logger.log("Client count : " + keys.length);
            if (err)
                return console.log(err);
            for (var i = 0, len = keys.length; i < len; i++) {
                var sessionId = keys[i];
                client.hgetall(sessionId, function (error, session) {
                        count = count + 1;
                        if (session != null && session.sid != undefined && session.sid != null) {
                          sessionList.push(session);
                        }
                        while(true){
                            if(count == keys.length){
                                processSessionIds(sessionList);
                                break;
                            }
                            break;
                        }
                });
                
            }
            
        });
    }

function processSessionIds(sessionList){
    var tempList = sessionList;
    var filterCompleted = null;
    for(var i=0; i<sessionList.length; i++){
        if(new Date().getTime() - sessionList[i].loginTime >= config.session_expiry_time){
            var multipleSessionObject = [];
            multipleSessionObject = tempList.filter(function(doc) {
              return (doc.userId == sessionList[i].userId && 
                new Date().getTime() - doc.loginTime <= config.session_expiry_time && 
                doc.sid != sessionList[i].sid);
            });
            filterCompleted = true;
            if(multipleSessionObject.length == 0){
                //console.log("Multiple sessions doesnt exists for : " + sessionList[i].userId);
                logoutUserUpdated(sessionList[i],sessionList[i].sid, true, null);
            }
            else{
                //console.log("Multiple sessions exists for : " + sessionList[i].userId);
                logoutUserUpdated(sessionList[i],sessionList[i].sid, false, null);
            }
        }
    }
}

function logoutUserUpdated(session, sessionId , updateOnlineStatus, httpRes){
    try{
            //console.log("Inside LOGOUTUSERUPDATED ----- > " + sessionId); 
            var logoutOption = {
                host: service_ip,
                port: user_port,
                path: '/manage-login-service/logout/' + session.userId+'/'+session.token+'/'+session.clientIP+'/'+updateOnlineStatus,
                method: 'GET'
            };
            var req = http.request(logoutOption, function (res) {
                var data = "";
                res.on('data', function (reply) {
                    data += reply;
                });
                res.on('end', function () {
                    client.del(sessionId);
                    client.del(sessionId+"-Lang");
                    //httpRes.json({sessionExpired : true});
                    if(httpRes != null){    
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    }
                });
            });
            req.on('error', function (error) {
            logger.log('error', 'logging out user :: ' + error);
            client.del(sessionId);
            });
            req.end();
        }catch (error) {
            client.del(sessionId);
        }
    }

app.get('/logout', function (httpReq, httpRes) {
    /*try {
        var sessionId = httpReq.sessionID;
        client.del(sessionId);
        client.del(sessionId+"-Lang");
        httpRes.redirect('/login');
    }catch (error) {
        logger.log('error', 'error caught:: ' + error);
    }*/
    var updateOnlineStatus = true;
    var count = 0;
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function (error, session) {
        if (error || session == null) {
           httpRes.redirect('login/#');
        }else {
            try {

                var logged_user_id = session.userId;
                var ipAddress = session.clientIP;
                var sessId = session.sid;
                client.keys('*', function (err, keys) {
                    if (err)
                        return console.log(err);
                    for (var i = 0, len = keys.length; i < len; i++) {
                        var subsessionId = keys[i];
                        //console.log((new Date().getTime() - session.loginTime) + " :::: " + session.userId);
                        client.hgetall(subsessionId, function (subError, subSession) {
                            count = count + 1;
                            if(subSession != undefined && subSession != null){
                                if(logged_user_id == subSession.userId && sessId != subSession.sid){
                                    if(new Date().getTime() - subSession.loginTime <= config.session_expiry_time){
                                        updateOnlineStatus = false;
                                    }
                                    
                                }
                            }
                            while(true){
                            if(count == keys.length){
                                    logoutUserUpdated(session,sessionId,updateOnlineStatus, httpRes);
                                    break;
                            }
                            break;
                        }
                        });
                    }
                });   
            } catch (error) {
                logger.log('error', 'error caught while verifying user invitation :: ' + error);
            }
        }
            
    });
    
});

/*
app.get('/logout', function (httpReq, httpRes) {
	   
	var sessionId = httpReq.sessionID;
	client.hgetall(sessionId, function (error, session) {
        if (error || session == null) {
           httpRes.redirect('login/#');
        }else {
        	try {
            	var logged_user_id = session.userId;
            	var ipAddress = session.clientIP;
            	
                var invitationOption = {
                    host: service_ip,
                    port: user_port,
                    path: '/manage-login-service/logout/' + logged_user_id+'/'+session.token+'/'+ipAddress,
                    method: 'GET'
                };
                var req = http.request(invitationOption, function (res) {
                    var data = "";
                    res.on('data', function (reply) {
                        data += reply;
                    });
                    res.on('end', function () {
                        var user = JSON.parse(data);
                    	var sessionId = httpReq.sessionID;
                        client.del(sessionId);
                        client.del(sessionId+"-Lang");
                       // httpRes.redirect('/login');
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    });
                });
                req.on('error', function (error) {
                });
                req.end();
            } catch (error) {
                logger.log('error', 'error caught while verifying user invitation :: ' + error);
            }
        }
        	
	});
    
});

*/
app.get('/google', function(httpReq, httpRes) {
    try {
        var token = httpReq.param('token');
   https.get("https://www.google.com/recaptcha/api/siteverify?secret=" + config.domain_secret_key + "&response=" + token, function(res) {
                var data = "";
                res.on('data', function (chunk) {
                        data += chunk.toString();
                });
                res.on('end', function() {
                        try {
                                var parsedData = JSON.parse(data);
                                // console.log(parsedData);
                                // console.log(parsedData.success);
                                httpRes.json(JSON.parse(data));
                        } catch (e) {
                                //callback(false);
                        }
                });
        });

    } catch (error) {

        logger.log('error', 'error caught while getting watermarkDetails');

    }
});

app.get('/forgotpassword', function (httpReq, httpRes) {
    httpRes.render('forgotpassword.html');
});

app.get('/returnIndex', function (httpReq, httpRes) {
    httpRes.render('/login');
});

app.get('/getCurrentUser',authenticate, function (httpReq, httpRes) {
   var session=user_identity;
   //console.log('111111');
   //console.log(session);
   session.session_expired_in=session_expiration_time;
   httpRes.json(session);
});

// Get all user for a company
app.get('/getUserList',authenticate, function (httpReq, httpRes) {
        var company_id = user_identity.company_id;
        var options = {
                hostname: service_ip,
                port: user_port,
                path: '/user/All/' + company_id,
                method: 'GET'
         };
         var req = http.request(options, function (res) {
         var data = '';
         res.on('data', function (reply) {
                data += reply;
         });
         res.on('end', function () {
               var decoded_buffer = data.toString()
               if (decoded_buffer.length > 0) {
                	httpRes.json(JSON.parse(data));
               } else {
                    httpRes.json(JSON.parse('[]'));
               }
         })
      });
      req.on('error', function (error) {
      });
      req.end();
            
});
/*
 Get all user 
app.get('/getUserList',authenticate, function (httpReq, httpRes) {
                var company_id = user_identity.company_id;
                var options = {
                    host: service_ip,
                    port: user_port,
                    path: '/user/All/' + company_id,
                    method: 'GET'
                };
                var req = http.request(options, function (res) {
                    var data = '';
                    res.on('data', function (reply) {
                        data += reply;
                    });
                    res.on('end', function () {
                        var decoded_buffer = data.toString()
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                });
                req.on('error', function (error) {
                });
                req.end();
});
*/

/* Search - v1.3 - starts here */
app.get('/getMetaDataTypes',authenticate, function (httpReq, httpRes) {
	var metaDataTypes = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getMetaDataTypes/',
               method: 'GET'
    };
    var req = http.request(metaDataTypes, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
           
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

app.get('/getAdvancedFilters',authenticate, function (httpReq, httpRes) {
   var advancedFilters = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getAdvancedFilters/',
               method: 'GET'
    };
    var req = http.request(advancedFilters, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
           
    });
    req.on('error', function (error) {
             ////console.logog(error); 
               httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

/*app.post('/getGridHeaders',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var gridHeaders = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getGridHeaders/' + userId + '/',
               method: 'POST'
    };
    var req = http.request(gridHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});*/

app.get('/getGridHeaders/:pageName/:savedSearchName', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var pageName = httpReq.params.pageName;
            var saveSearchName = encodeURIComponent(httpReq.params.savedSearchName);
            //console.log("**************"+ saveSearchName);
            //var saveSearchName = httpReq.params.savedSearchName;
            

            if(pageName == undefined)
              pageName = 'Default';
            
            var queryParams = 'pageName=' + pageName+'&saveSearchName=' + saveSearchName+'&loggedUser=' + logged_user_id;

            var request_options = {
                host: search_service_ip,
                port: search_port,
                path: '/manage-search-service/getGridHeaders?' + queryParams,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                   // console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.get('/getCustomHeaders/:pageName', function(httpReq, httpRes) {
    //console.log("In")
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var pageName = httpReq.params.pageName;

            if(pageName == undefined)
              pageName = 'Default';
            
            var queryParams = 'pageName=' + pageName+'&loggedUser=' + logged_user_id;

            var request_options = {
                host: search_service_ip,
                port: search_port,
                path: '/manage-search-service/getCustomHeaders?' + queryParams,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});


/*app.get('/getCustomHeaders/:pageName',authenticate, function (httpReq, httpRes) {
	//var userId = httpReq.param('userId');
	var customHeaders = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getCustomHeaders/',
               method: 'GET'
    };
    var req = http.request(customHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});*/


app.post('/viewSearch', authenticate,logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        var reqId = httpReq.body.reqId;
        httpReq.setTimeout(0);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                                   host: search_service_ip,
                                   //host: '172.16.3.126',
                                   port: search_port,
                                   path: '/manage-search-service/viewSearch?loggedUser=' + session.userId,
                                   method: 'POST',
                                   headers: {
                                       'Content-Type': 'application/json'
                                   }
                        };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            data = JSON.parse(data)
                            data.reqId = reqId;
                            httpRes.json(data);
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});

/*app.post('/viewSearch',authenticate, function (httpReq, httpRes) {
	//var userId = httpReq.params('userId');
	var cope = JSON.stringify(httpReq.body);
		
	var viewSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/viewSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(viewSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                 // console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

app.post('/renameSearch',logActivity, function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var renameSearch = {
                    host: search_service_ip,
                    //host: '172.16.3.126',
                    port: search_port,
                    path: '/manage-search-service/renameSearch?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(renameSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in renameSearch');
    }

})

/*app.post('/renameSearch', function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	
	var renameSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/renameSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

/*app.post('/duplicateSearch', function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	
	var dupSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/duplicateSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(dupSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

app.post('/duplicateSearch',logActivity, function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                //console.log("logged_user_id ["+logged_user_id+"]");
                var dupSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/duplicateSearch?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(dupSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in duplicateSearch');
    }

})

app.post('/getSavedSearch', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                //console.log("logged_user_id ["+logged_user_id+"]");
                var dupSearch = {
                    host: search_service_ip,
                    //host: "172.16.3.126",
                    port: search_port,
                    path: '/manage-search-service/getSavedSearch?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(dupSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in duplicateSearch');
    }

})



/*app.post('/getSavedSearch',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var savedSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getSavedSearch/' + userId + '/',
               method: 'POST'
    };
    var req = http.request(savedSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

/*app.post('/deleteSearch',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);
	
	var deletedSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/deleteSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(deletedSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

app.post('/deleteSearch',logActivity, function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var deletedSearch = {
                    host: search_service_ip,
                    //host: '172.16.3.126',
                    port: search_port,
                    path: '/manage-search-service/deleteSearch?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(deletedSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in deleteSearch');
    }

})

app.post('/pintodashboard', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var request_options = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/pintodashboard?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in pintodashboard');
    }

})

/*app.post('/saveSearch',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);

	var saveSearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/saveSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/


app.post('/saveSearch',logActivity, function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/saveSearch?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})


app.post('/saveCustomHeaders',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);

	var saveHeaders = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/saveCustomHeaders/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});
app.post('/saveCustomHeadersBaseOnOrder', function(httpReq, httpRes) {
    try {
        //console.log("Inside saveCustomHeadersNew");
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/saveCustomHeadersBaseOnOrder?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})
app.post('/saveCustomHeadersNew', function(httpReq, httpRes) {
    try {
        //console.log("Inside saveCustomHeadersNew");
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/saveCustomHeadersNew?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})



app.get('/getImprints',authenticate, function (httpReq, httpRes) {
	var imprints = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getImprints/',
               method: 'GET'
    };
    var req = http.request(imprints, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               //console.log(error); 
               httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

app.post('/getRecentSearch',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);
    var recentsearch = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getRecentSearch/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(recentsearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
           
    });
    req.on('error', function (error) {
               //console.log(error);
               httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

/*app.post('/getSearchSuggestions',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);
	
    var searchsuggest = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getSearchSuggestions/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(searchsuggest, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
           
    });
    req.on('error', function (error) {
               console.log(error);
                httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

app.post('/getSearchSuggestions', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/getSearchSuggestions?loggedUser=' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught in getColumnFilterSuggestions');
    }

});

/*app.post('/getColumnFilterSuggestions',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);
	
    var searchsuggest = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/getColumnFilterSuggestions/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(searchsuggest, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
           
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/

app.post('/getColumnFilterSuggestions', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                    host: service_ip,
                    port: search_port,
                    path: '/manage-search-service/getColumnFilterSuggestions?loggedUser=' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught in getColumnFilterSuggestions');
    }

});



/* Search - v1.3 - ends here */

/* Metadata - v1.5 - starts here */
app.post('/getSavedMetadata',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var savedMdata = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/getSavedMetadata/' + userId + '/',
               method: 'POST'
    };
    var req = http.request(savedMdata, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
              // console.log(error);
               httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

app.post('/getMdataGridHeaders',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var mGridHeaders = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/getMdataGridHeaders/' + userId + '/',
               method: 'POST'
    };
    var req = http.request(mGridHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
              // console.log(error);
               httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

app.get('/getCodeLookUpValues', function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    try {
        var codeLookUp = {
        		host: search_service_ip,
                port: metadata_port,
            path: '/manage-metadata-service/getCodeLookUpValues/',
            method: 'GET'
        };
        var req = http.request(codeLookUp, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});


app.get('/getMdataCustomHeaders',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var mCustomHeaders = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/getMdataCustomHeaders/',
               method: 'GET'
    };
    var req = http.request(mCustomHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
              // console.log(error); 
               httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

app.post('/saveCustomMdataHeaders',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);

	var saveMHeaders = {
               host: search_service_ip,
               port: search_port,
               path: '/manage-search-service/saveCustomHeaders/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveMHeaders, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/viewMetaData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
			
	var viewMetaData = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/viewMetaData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(viewMetaData, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/customTemplateMData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
			
	var customMetaData = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/customTemplateMData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(customMetaData, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  console.log(decoded_buffer);
                  console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/uploadMetaData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	
	 var metadataXl = httpReq.files.metadataUpload;
             if (!fsextra.existsSync(metadatauploadPath)) {
                 console.log("Directory doesnt exist ",metadatauploadPath);
                 fsextra.ensureDirSync(metadatauploadPath);
             }
             metadataXl.mv(metadatauploadPath +"123" +metadataXl.name, function(err) {
                 if (err) {
                     httpRes.status(500).send(err);
                 } else {
                	 console.log("success");
                	 var cope = JSON.stringify({path:"123" +metadataXl.name});
                	 
                	 var uploadMetaData = {
                         host: search_service_ip,
                         port: metadata_port,
                         path: '/manage-metadata-service/uploadMetaData/',
                         method: 'POST',
                         headers: {
                             'Content-Type': 'application/json',
                         }
                	 };
                	   var req = http.request(uploadMetaData, function (res) {
                           res.setEncoding('utf8');
                           var data = "";
                           res.on('data', function (reply) {
                               data += reply;
                           });
                           res.on('end', function () {
                               var decoded_buffer = data.toString();
                               //console.log(decoded_buffer);
                               //console.log(decoded_buffer.length);
                               if (decoded_buffer.length > 0) {
                                   httpRes.json(JSON.parse(data));
                               } else {
                                   httpRes.json(JSON.parse('[]'));
                               }
                           })
                 });
                 req.on('error', function (error) {
                        console.log(error); httpRes.json(JSON.parse('[]'));
                 }); 
                 req.write(cope);
                 req.end();
                 }
             });
}); 

app.get('/getMetadataConfigDetails', function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    try {
        var metaDataConfig = {
            host: search_service_ip,
            port: metadata_port,
            path: '/manage-metadata-service/getMetadataConfigDetails/',
            method: 'GET'
        };
        var req = http.request(metaDataConfig, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});

app.post('/getMdataColumnFilterSuggestions',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	//console.log("Search :::::"+cope);
		
	var mDataSuggestions = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/getMdataColumnFilterSuggestions/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(mDataSuggestions, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/saveMetaData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	//console.log(cope);
	var saveMeta = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/saveMetaData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveMeta, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/editMetaData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	//console.log(cope);
	var saveMeta = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/editMetaData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveMeta, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/updateMetaData',authenticate, function (httpReq, httpRes) {
	var userId = httpReq.param('userId');
	var cope = JSON.stringify(httpReq.body);
	//console.log(cope);
	var saveMeta = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/updateMetaData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(saveMeta, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/deleteMetaData',authenticate, function (httpReq, httpRes) {
	var cope = JSON.stringify(httpReq.body);
	//console.log(cope);
	var deleteMeta = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/deleteMetaData/',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               }
    };
    var req = http.request(deleteMeta, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                  data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  //console.log(decoded_buffer);
                  //console.log(decoded_buffer.length);
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/existIsbnCheck',authenticate, function (httpReq, httpRes) {
	var isbnValue = httpReq.param('isbnValue');
	var existisbnValue = {
               host: search_service_ip,
               port: metadata_port,
               path: '/manage-metadata-service/existIsbnCheck/' + isbnValue + '/',
               method: 'POST'
    };
    var req = http.request(existisbnValue, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});


/* Metadata - v1.5 - ends here */

app.post('/userIp', function (httpReq, httpRes) {

    var ip = httpReq.headers['x-forwarded-for'] ? httpReq.headers['x-forwarded-for'].split(',')[0] : httpReq.connection.remoteAddress;;
    var userip = ip.split(':').pop();;
    
httpRes.json({'ip':userip });
})

/* GET service integration ends here*/

/* POST service integration starts here*/

/* Login service is used to get the login details from the login page and post it to login boot service for login.
dashboard will be redirect for valid user. */
app.post('/login', function (httpReq, httpRes) {

 var sessionId = httpReq.sessionID;
 var loginIP = httpReq.ip;
 httpReq.body.ip_address = loginIP;
 
 console.log(loginIP+" - > "+ service_ip + ":" +login_port+ " on " + sessionId );
 
 var email = httpReq.body.email_id;
 var clientIP=  httpReq.body.clientIp;
 var loginOptions = {
     host: service_ip,
     port: login_port,
     path: '/manage-login-service/login',
     method: 'POST',
     headers: {
         'Content-Type': 'application/json'
     }
 };
/* if (httpReq.body["g-recaptcha-response"]) {
     verifyRecaptcha(httpReq.body["g-recaptcha-response"], function (success) {*/
    	 
    	 if (true) {
    	     verifyRecaptcha(httpReq.body["g-recaptcha-response"], function (success) {
         if (true) {
             var req = http.request(loginOptions, function (res) {
                 res.setEncoding('utf8');
                 var data = "";
                 res.on('data', function (reply) {
                     data += reply;
                 });
                 res.on('end', function () {
                	 userData = data;
                     
                      //console.log(userData);
                     data = JSON.parse(userData);
                     if (data.status == 'LOGIN.SUCCESS') {
                    	 console.log('Login success');
//                    	 user_identity = data;
                    	 //user_identity=session;
                 //   	 client.hmset(sessionId,'userEmail',data.data.emailId, 'userName', data.data.userName == null ? "" : data.data.firstName,'userId',data.data.userId, 'profilePicName',data.data.profilePicName == null ? "" : data.data.profilePicName, 'loginTime', new Date().getTime(),'Token',data.data.access_token);
                    	 client.hmset(sessionId,'sid', sessionId,'userEmail',data.data.emailId, 'userName',
                          data.data.userName == null ? "" : data.data.userName,'userId',
                          data.data.userId, 'profilePicName',
                          data.data.profilePicName == null ? "" : data.data.profilePicName,
                           'loginTime', new Date().getTime(),'token',data.data.oautAaccessToken,
                           'clientIP',clientIP,'expired','false');
                    	 //user_identity=JSON.parse();
                    	
                    	 client.hgetall(sessionId, function (error, session) {user_identity=session;console.log(user_identity);});
                    	 
                    	 
                    	 client.expire(sessionId, session_expiration_time);
                         //httpRes.json({status: 'success'});
                         httpRes.json(data);
                     } else {
                    	 console.log('Login Failure');
                    	 httpRes.json(data);
                     }
                 });
             });
             req.on('error', function (error) {
                 console.log(error); httpRes.json(JSON.parse('[]'));
             });
           
             req.write(JSON.stringify(httpReq.body));
             req.end();
         }
         else {
        	 httpRes.json(json_validation);
         }
     }); 
 }
 else {
      var req = http.request(loginOptions, function (res) {
         res.setEncoding('utf8');
         var data = "";
         res.on('data', function (reply) {
             data += reply;
         });
         res.on('end', function () {
        	 userData = data;
             
/*             console.log('sessionId');
             console.log(sessionId);
             console.log(data);
             console.log('*********');
*/             data = JSON.parse(userData);
			//console.log(userData);
            // if (data.status == 'success') {
             if (data.status == 'LOGIN.SUCCESS') {
            	 console.log('Login success ..');
            	 //client.hmset(sessionId,'userEmail',data.data.emailId, 'userName', data.data.userName,'userId',data.data.userId, 'loginTime', new Date().getTime());
            //	 client.hmset(sessionId,'userEmail',data.data.emailId, 'userName', data.data.userName == null ? "" : data.data.userName,'userId',data.data.userId, 'profilePicName',data.data.profilePicName == null ? "" : data.data.profilePicName, 'loginTime', new Date().getTime());
            	 client.hmset(sessionId,'userEmail',data.data.emailId, 'userName', data.data.userName == null ? "" : data.data.userName,'userId',data.data.userId, 'profilePicName',data.data.profilePicName == null ? "" : data.data.profilePicName, 'loginTime', new Date().getTime(),'token',data.data.oautAaccessToken);
            	 client.hgetall(sessionId, function (error, session) {user_identity=session;
            	 console.log(user_identity);
            	 });
             	client.expire(sessionId, session_expiration_time);
                 httpRes.json({status: 'success'});
             } else {
            	     httpRes.json({data});
             }
         });
     });
     req.on('error', function (error) {
    	 console.log('***error***');
         console.log(error); httpRes.json(JSON.parse('[]'));
     });
    // req.write(JSON.stringify(httpReq.body));
     req.end();
 	}
});

app.get('/getCurrentUserDetails',authenticate, function (httpReq, httpRes) {

	var queryString = httpReq.param('q');
	client.hgetall(httpReq.sessionID, function(err, obj) {
	    
		//console.log(httpReq.sessionID);
		//console.log(obj);
		if(obj!=null){
			if(obj[queryString]!=undefined)
				httpRes.json({queryString: obj[queryString]});
			else
				httpRes.json({queryString: "not found"});
		}
		else
			httpRes.json({queryString: "session not found"});
	});
	
})
/*forgot password*/
app.post('/forgotpassword', function (httpReq, httpRes) {
	
        //   httpReq.body.created_by = user_identity.user_id;
           var cope = JSON.stringify(httpReq.body);
            var loginOptions = {
               host: service_ip,
               port: user_port,
               path: '/manage-login-service/forgotpassword',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               },
               data: cope
           };
           var req = http.request(loginOptions, function (res) {
               res.setEncoding('utf8');
               var data = "";
               res.on('data', function (reply) {
                    data += reply;
               });
               res.on('end', function () {
                   var decoded_buffer = data.toString();
                   if (decoded_buffer.length > 0) {
                       httpRes.json(JSON.parse(data));
                   } else {
                       httpRes.json(JSON.parse('[]'));
                   }
               })
           });
           req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
           });
           req.write(cope);
           req.end();
});
/* update Audit log */
app.post('/updateAuditLogs', function (httpReq, httpRes) {
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: user_port,
           path: '/manage-login-service/updateAuditLogs',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

/*set password*/
app.post('/setPasswordFirstTimeLogin', function (httpReq, httpRes) {
	
        //   httpReq.body.created_by = user_identity.user_id;
           var cope = JSON.stringify(httpReq.body);
            var loginOptions = {
               host: service_ip,
               port: user_port,
               path: '/manage-login-service/setpassword',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               },
               data: cope
           };
           var req = http.request(loginOptions, function (res) {
               res.setEncoding('utf8');
               var data = "";
               res.on('data', function (reply) {
                    data += reply;
               });
               res.on('end', function () {
                   var decoded_buffer = data.toString();
                   if (decoded_buffer.length > 0) {
                       httpRes.json(JSON.parse(data));
                   } else {
                       httpRes.json(JSON.parse('[]'));
                   }
               })
           });
           req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
           });
           req.write(cope);
           req.end();
});

/* File upload download starts */

app.post('/generateFileUploadLink',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/awsapi',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

/*app.use('/fileUploadSignature', function (req, res) {
	// TODO: Do something to authenticate this request
	console.log("to_sign::"+req.query.to_sign);
	var signature = crypto
		.createHmac('sha256', "obiOOcL+HIM4j6m23ZdBOZHoswM7DRdXr/VabLuE")
		.update(req.query.to_sign)
		.digest('base64')
	console.log('Created signature "' + signature + '" from ' + req.query.to_sign);
	res.send(signature);
});*/

app.get('/fileUploadSignature',authenticate, function (httpReq, httpRes) {
//	console.log("to-sing::::");
	httpReq.body.url=httpReq.param('to_sign');
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/manualupload',
           method: 'GET',
           headers: {
               'Content-Type': 'application/json; charset=utf-8',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        
        var req = http.request(loginOptions, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
                //console.log(user);
                httpRes.send(user.data);
            });
        });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});


app.post('/download', authenticate, logActivity,function (httpReq, httpRes) {
	
	console.log("format::"+httpReq.body.formatId);
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/downloadfile',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        //console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/saveDownloadData', authenticate,function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: downloadNotifiy_port,
           path: '/manage-download-service/saveDownloadData',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        //console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/saveShelfTransaction', authenticate,function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/saveShelfTransaction',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/saveBulkShelfTransaction', authenticate,function (httpReq, httpRes) {
	
    var cope = JSON.stringify(httpReq.body);
     var loginOptions = {
     		host: service_ip,
             port: fileupload_port,
        path: '/manage-file-upload-download-service/saveBulkShelfTransaction',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
    // console.log("loginOptions::"+loginOptions);
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/getPermissionGroup', authenticate,function (httpReq, httpRes) {
	
	//console.log("format::"+httpReq.body.formatId);
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/getPermissionGroup',
 method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
     //  console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getUserPermissionGroup', authenticate,function (httpReq, httpRes) {
	
	//console.log("format::"+httpReq.body.formatId);
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/getUserPermissionGroup',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
     //   console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/verifyUser', authenticate,function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/verifyUser',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/sendExistingUserFailedShareMail', authenticate,function (httpReq, httpRes) {
	
    var cope = JSON.stringify(httpReq.body);
     var loginOptions = {
      		host: service_ip,
             port: fileupload_port,
        path: '/manage-file-upload-download-service/sendExistingUserFailedShareMail',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
     console.log("loginOptions::"+loginOptions);
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/getUserPermissionFormats', authenticate,function (httpReq, httpRes) {
	
	//console.log("format::"+httpReq.body.formatId);
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/getUserPermissionFormats',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
   //     console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/addfileobjects', authenticate,logActivity,function (httpReq, httpRes) {
	//console.log("addfileobjects::"+httpReq.body.productIDValue);
    var cope = JSON.stringify(httpReq.body);
     var loginOptions = {
//    		 host: service_ip,
    		 host: service_ip,
             port: fileupload_port,
        path: '/manage-file-upload-download-service/addfileobjects',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/uploadMail', authenticate,logActivity,function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
     var loginOptions = {
    		 host: service_ip,
             port: fileupload_port,
        path: '/manage-file-upload-download-service/uploadMail',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/sharedownload',authenticate, function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        	host: service_ip,
            port: fileupload_port,
           path: '/manage-file-upload-download-service/downloadfileshare',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

/*app.post('/sharedownloadtool',authenticate, function (httpReq, httpRes) {
	
    var cope = JSON.stringify(httpReq.body);
     var loginOptions = {
     	host: service_ip,
         port: fileupload_port,
        path: '/manage-file-upload-download-service/downloadfilesharetool',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
     console.log("loginOptions::"+loginOptions);
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});*/


app.post('/sharedownloadtool', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
            	host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/downloadfilesharetool?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/formatlist',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        	host: service_ip,
            port: fileupload_port,
           path: '/manage-file-upload-download-service/listformat',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getProductForm',authenticate, function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        	host: service_ip,
            port: fileupload_port,
           path: '/manage-file-upload-download-service/getProductForm',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/bucketUploadDetails',authenticate,logActivity, function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);


    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

     var loginOptions = {
         host: service_ip,
         port: fileupload_port,
        path: '/manage-file-upload-download-service/bucketUploadDetails?loggedUser=' + logged_user_id,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
     console.log("loginOptions::"+loginOptions);
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
}
});
});
app.get('/getNotificationEmailIds',authenticate, function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
     var loginOptions = {
         host: service_ip,
         port: fileupload_port,
        path: '/manage-file-upload-download-service/getNotificationEmailIds?loggedUser=' + logged_user_id,
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
}
});  

});
app.post('/checkIsbn',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        	host: service_ip,
            port: fileupload_port,
           path: '/manage-file-upload-download-service/checkIsbn',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getFilenameByFormatId',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        	host: service_ip,
            port: fileupload_port,
           path: '/manage-file-upload-download-service/getFilenameByFormatId',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/isbnformatlist',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/isbnformatlist',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getFormat',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/getFormat',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});


app.post('/folderlist',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/listfolders',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getFolderlist',authenticate, function (httpReq, httpRes) {
	
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/getFolderlist',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/getAssetStatus',authenticate, function (httpReq, httpRes) {
    //   httpReq.body.created_by = user_identity.user_id;
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/getStatusCode',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});
app.post('/updateAssetStatus',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/updateAssetStatus',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/checkFileFormat',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/checkFileFormat',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});


app.post('/getReportGridHeaders', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			//host:"172.16.3.107",   
			port: report_port,
               path: '/manage-report-service/getGridHeaders/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});
app.post('/getReportsList', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			  // host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/getSavedSearch/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});


app.post('/loadAllReportGrid',logActivity, function(httpReq, httpRes) {
    try {
    	var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        logger.log('info', 'account user');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                		 host: service_ip,
                		 //host: "172.16.3.107",
                         port: report_port,
                         path: '/manage-report-service/viewSearch/?loggedUser=' + session.userId,
                   
                    method: 'POST',
                    headers: {
                    	'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting user profile');
    }
});

app.post('/loadAllReportChart',logActivity, function(httpReq, httpRes) {
    try {
    	var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        logger.log('info', 'account user');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                		 host: service_ip,
                		 //host: "172.16.3.107",
                         port: report_port,
                         path: '/manage-report-service/chart/?loggedUser=' + session.userId,
                   
                    method: 'POST',
                    headers: {
                    	'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting user profile');
    }
});
app.post('/getFrequencies', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                    //host:"172.16.3.107",
                    port: report_port,
                    path: '/manage-report-service/getFrequencies/?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }
})

app.post('/getCustomReportCondition', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                    //host:"172.16.3.107",
                    port: report_port,
                    path: '/manage-report-service/getSavedSearchById/?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }
})


app.post('/saveReportSearch', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                    //host:"172.16.3.107",
                    port: report_port,
                    path: '/manage-report-service/saveSearch?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})

app.post('/getSavedSearchName', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var reportColoumnSearch = {
                   host: service_ip,
                	//host:"172.16.3.107",	
                    port: report_port,
                    path: '/manage-report-service/getSavedSearch?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(reportColoumnSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in reportColoumnSearch');
    }

})


app.post('/getReportColumnFilterSuggestions', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                	//host:"172.16.3.107",   
                    port: report_port,
                    path: '/manage-report-service/getColumnFilterSuggestions/?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})

app.post('/duplicateSavedReport', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			  host: service_ip, 
			  // host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/duplicateSearch/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});

app.post('/deleteSavedReport', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/deleteSearch/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});

app.post('/reportHeaderSearchSuggestions', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/getSearchSuggestions/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});


app.get('/getAssetDelete/:id', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var requestID = httpReq.params.id;
            //var cope = JSON.stringify(httpReq.body);
            console.log("requestID"+requestID);
            var request_options = {
                host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/getAssetDeleteRequestDetails?requestId=' + requestID,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
               

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

             
            req.end();
        }
    });
});

app.post('/assetDeleteApprovel', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.105",
			   port: fileupload_port,
               path: '/manage-file-upload-download-service/assetDeleteApprove',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});
app.post('/drmReorder', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: drm_port,
               path: '/manage-drm-service/drm/reorder?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
            	   'Authorization':'Bearer '+ session.token,
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});

app.post('/wmReorder', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: drm_port,
               path: '/manage-drm-service/watermark/reorder?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
            	   'Authorization':'Bearer '+ session.token,
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});

app.post('/downloadCSVFile',logActivity, function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/exportcsv/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});
app.post('/reportPinToDashBoard', function (httpReq, httpRes) {
	var sessionId = httpReq.sessionID;;
	var cope = JSON.stringify(httpReq.body);
	client.hgetall(sessionId, function(error, session){
		 if (error)
             return error;
         if (session != null) {
	var renameSearch = {
			   host: service_ip, 
			   //host:"172.16.3.107",
			   port: report_port,
               path: '/manage-report-service/pintodashboard/?loggedUser=' + session.userId,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               }
    };
    var req = http.request(renameSearch, function (res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function (reply) {
                   data += reply;
              });
              res.on('end', function () {
                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })
    });
    req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
         }
	})
});

app.post('/updateDeleteCompleteStatus',authenticate, function (httpReq, httpRes) {
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/saveShelfTransaction',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});
/*report end*/
app.post('/addTransactionDetails',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/addTransactionDetails',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/addBulkTransactionDetails',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/addBulkTransactionDetails',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

/* File upload download ends */

/* Bulk upload starts */

app.post('/bulkUploadValidation',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/bulkUploadValidation',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});
app.get('/exportNamingConversion',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
            	var loggedUser = session.userId;
                var request_options = {
                    host:service_ip,
                    port: fileupload_port,
                    path: '/manage-file-upload-download-service/exportNamingConversion/'+loggedUser,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.end();
            }});
    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});


app.get('/getApprovalFormats', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
            	var loggedUser = session.userId;
                var request_options = {
                    host:service_ip,
                    port: fileupload_port,
                    path: '/manage-file-upload-download-service/getApprovalFormats',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.end();
            }});
    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});

app.get('/getAllFormats',authenticate, function (httpReq, httpRes) {
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/getAllFormats',
                method: 'GET',
                headers: {
                	'Content-Type': 'application/json',
                	'Content-Length': Buffer.byteLength(cope)
                },
                data: cope
       };
        
        var req = http.request(loginOptions, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
                httpRes.send(user.data);
            });
        });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});


app.post('/bulkshare',authenticate, function (httpReq, httpRes) {
	
	var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
           host: service_ip,
           port: fileupload_port,
           path: '/manage-file-upload-download-service/bulkshare',
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        console.log("loginOptions::"+loginOptions);
       var req = http.request(loginOptions, function (res) {
           res.setEncoding('utf8');
           var data = "";
           res.on('data', function (reply) {
                data += reply;
           });
           res.on('end', function () {
               var decoded_buffer = data.toString();
               if (decoded_buffer.length > 0) {
                   httpRes.json(JSON.parse(data));
               } else {
                   httpRes.json(JSON.parse('[]'));
               }
           })
       });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

/* Bulk upload ends */

/* add user */
app.post('/addUser',authenticate, function (httpReq, httpRes) {
           httpReq.body.created_by = user_identity.user_id;
           var cope = JSON.stringify(httpReq.body);
            var loginOptions = {
               host: service_ip,
               port: user_port,
               path: '/user/add',
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(cope)
               },
               data: cope
           };
           var req = http.request(loginOptions, function (res) {
               res.setEncoding('utf8');
               var data = "";
               res.on('data', function (reply) {
                    data += reply;
               });
               res.on('end', function () {
                   var decoded_buffer = data.toString();
                   if (decoded_buffer.length > 0) {
                       httpRes.json(JSON.parse(data));
                   } else {
                       httpRes.json(JSON.parse('[]'));
                   }
               })
           });
           req.on('error', function (error) {
               console.log(error); httpRes.json(JSON.parse('[]'));
           });
           req.write(cope);
           req.end();
});

/* update user */
app.post('/updateUser',authenticate, function (httpReq, httpRes) {

    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: user_port,
        path: '/user/update',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        },
        data: cope
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

/* update user password using link */
app.post('/userPassword',authenticate, function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    try {
        client.get(sessionId, function (error, userId) {
            if (error)
                return error;
            if (userId != null)
            {
                httpReq.body.user_id = userId;
                var cope = JSON.stringify(httpReq.body);
                var loginOptions = {
                    host: service_ip,
                    port: user_port,
                    path: '/user/updatepassword',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(loginOptions, function (res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function (reply) {
                        data += reply;
                    });
                    res.on('end', function () {
                        client.del(sessionId);
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    });
                });
                req.on('error', function (error) {
                    console.log(error); httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            } else {
            }
        });
    } catch (error) {
    }
});

/* get single user */
app.post('/editUser', authenticate,function (httpReq, httpRes) {
    var taskId = httpReq.body.user_id;
    var loginOptions = {
        host: service_ip,
        port: user_port,
        path: '/user/' + taskId,
        method: 'GET'
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
              data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

/* deactivateUser */
app.post('/deactivateUser',authenticate, function (httpReq, httpRes) {
    var user_id = httpReq.body.user_id;
    var loginOptions = {
        host: service_ip,
        port: user_port,
        path: '/user/delete/' + user_id,
        method: 'GET'
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.end();
});

/* Forgot password */
app.post('/addforgotpassword', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: user_port,
        path: '/user/forgotpassword/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

/* Get Project Rights */
app.post('/GetProjectRights',authenticate, function (httpReq, httpRes) {
                httpReq.body.user_id = user_identity.user_id;
                var cope = JSON.stringify(httpReq.body);
                var options = {
                    host: service_ip,
                    port: user_port,
                    path: '/user/projectlevelpermissions/',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    },
                };
                var req = http.request(options, function (res) {
                    var data = '';
                    res.on('data', function (reply) {
                        data += reply;
                    });
                    res.on('end', function () {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                });
                req.on('error', function (error) {
                });
                req.write(cope);
                req.end();
           
});

/*Business Rules*/
app.get('/getBrs', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
        		/*host: service_ip,*/
        		host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getBrs/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});

app.get('/getMetadataGroupFields', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getMetadataGroupFields/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.get('/retrieveMetadataConditions', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/retrieveMetadataConditions/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.get('/getMetadataDataFields', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getMetadataDataFields/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.get('/getBrMetaDataTypes', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getMetaDataTypes/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.get('/getBrRuleTypes', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getBrRuleTypes/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.get('/getOperationalConditions', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
        		/*host: service_ip,*/
        		host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getOperationalConditions/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});

app.get('/getMetaDataDateTypes', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
            host: service_ip,
            port: business_port,
            path: '/manage-bsr-service/getMetaDataDateTypes/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.post('/updateApproveFlag', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/updateApproveFlag/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});



app.post('/removeBusinessRules', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/removeBusinessRule/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/getAllUserByAccountId', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/getAllUserByAccountId/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/getPatnersByAccountId', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/getPatnersByAccountId/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});
app.post('/exportBr', function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
 var cope = JSON.stringify(httpReq.body);
 var loginOptions = {
     /*host: service_ip,*/
         host: service_ip,
     port: business_port,
     path: '/manage-bsr-service/exportBr/',
     method: 'POST',
     headers: {
         'Content-Type': 'application/json',
         'Content-Length': Buffer.byteLength(cope)
     }
 };
 var req = http.request(loginOptions, function (res) {
     res.setEncoding('utf8');
     var data = "";
     res.on('data', function (reply) {
          data += reply;
     });
     res.on('end', function () {
         var decoded_buffer = data.toString();
         if (decoded_buffer.length > 0) {
             httpRes.json(JSON.parse(data));
         } else {
             httpRes.json(JSON.parse('[]'));
         }
     })
 });
 req.on('error', function (error) {
     console.log(error); httpRes.json(JSON.parse('[]'));
 });
 req.write(cope);
 req.end();
});
app.post('/saveBr', function (httpReq, httpRes) {
	 var user_id = session.userId;
	 //httpReq.body.createdBy = user_id;
	 //httpReq.body.modifiedBy = user_id;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/saveBr/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/updateBr', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: business_port,
        path: '/manage-bsr-service/updateBr/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});


app.get('/getAllLookUpValues', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
        		host: service_ip,
                port: business_port,
            path: '/manage-bsr-service/getAllLookUpValues/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});

app.post('/checkRule', function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-bsr-service/checkRule/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/getGrid', function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-bsr-service/getGrid/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.get('/getDataTypeOperators', function (httpReq, httpRes) {
	//console.log("setpass");
    var sessionId = httpReq.sessionID;
    try {
        /*var accesskey = httpReq.param('accesskey');
        var language = httpReq.param('lang');
        console.log(language+"lang");*/
        var retrieveBusinessRules = {
        		host: service_ip,
                port: business_port,
            path: '/manage-bsr-service/getDataTypeOperators/',
            method: 'GET'
        };
        var req = http.request(retrieveBusinessRules, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(JSON.parse(data));
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
            })
        });
        req.on('error', function (error) {
        });
        req.end();
    } catch (error) {
        logger.log('error', 'error caught while verifying user invitation :: ' + error);
    }
});
app.post('/getVendorData', function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
       host: service_ip,
     /* host: service_ip,*/
      port: business_port,
      path: '/manage-bsr-service/getVendorData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.post('/getColumnSearchData',logActivity, function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
	   host: service_ip,
      /*host: service_ip,*/
      port: business_port,
      path: '/manage-bsr-service/getColumnSearchData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.post('/getColumnSearchFilterData', function (httpReq, httpRes) {
    var user_id = session.userId;
    //httpReq.body.createdBy = user_id;
    //httpReq.body.modifiedBy = user_id;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
	   host: service_ip,
      /*host: service_ip,*/
      port: business_port,
      path: '/manage-bsr-service/getColumnSearchFilterData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
/*EOF Business Rules*/

/*Manual Distribution*/
app.post('/getEligibleFormats', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
      /*host: service_ip,*/
		  host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/formatType/'+httpReq.param('userId'),
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.post('/getEligiblePartners', function (httpReq, httpRes) {
   var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
	  host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/partnerGrp/'+httpReq.param('userId'),
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/saveManualTakeDownDistData', function (httpReq, httpRes) {
    var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/saveManualTakeDownDistData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
 });

app.post('/getDistributionStatus', function (httpReq, httpRes) {
    var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
		  host: service_ip,
		  port: business_port,
      path: '/manage-manualDist-service/getDistStatus/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});


app.post('/saveManualDistData', function (httpReq, httpRes) {
    var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
		  host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/saveManualDistData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.post('/getFormatGridData', function (httpReq, httpRes) {
    var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
		  host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/getFormatGridData/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});

app.post('/getEligibleMetadataPartners', function (httpReq, httpRes) {
    var user_id = session.userId;
  var cope = JSON.stringify(httpReq.body);
  var loginOptions = {
	 host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/partnerMeta/'+httpReq.param('userId'),
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/getPartnerDataByIsbnFormatId', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/fetchPartnersByIsbnFormat/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/stopDistribution', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/stopDistribution/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/removeFromSaleDistribution', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/removeFromSaleDistribution/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/reDistribute', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/reDistribute/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/updatePriority', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/updatePriority/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/showDistHistory', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
     host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/fetchDistributedDataHistory/',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.post('/fetchIsbnHistory', function (httpReq, httpRes) {
    var user_id = session.userId;
    var cope = JSON.stringify(httpReq.body);
    //console.log("isbn value: "+httpReq.body.isbn)
    var loginOptions = {
      host: service_ip,
      port: business_port,
      path: '/manage-manualDist-service/fetchIsbnHistory/'+httpReq.body.isbn,
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(cope)
      }
  };
  var req = http.request(loginOptions, function (res) {
      res.setEncoding('utf8');
      var data = "";
      res.on('data', function (reply) {
           data += reply;
      });
      res.on('end', function () {
          var decoded_buffer = data.toString();
          if (decoded_buffer.length > 0) {
              httpRes.json(JSON.parse(data));
          } else {
              httpRes.json(JSON.parse('[]'));
          }
      })
  });
  req.on('error', function (error) {
      console.log(error); httpRes.json(JSON.parse('[]'));
  });
  req.write(cope);
  req.end();
});
app.get('/assetBinding/:isbn', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var isbn = httpReq.params.isbn;
            var request_options = {
                host: search_service_ip,
                port: search_port,
                path: '/manage-search-service/binding/'+isbn+'?loggedUser=' + logged_user_id,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })
                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
            });
            req.end();
        }
    });
});


app.post('/partneronixexport', function(httpReq, httpRes) {
    try {
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: search_service_ip,
                    port: search_port,
                    path: '/manage-search-service/partneronixexport?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

})

/*Eof Manual Distribution*/

/*Notification Start*/
app.post('/getNotifications', function (httpReq, httpRes) {
	   var user_id = session.userId;
	  var cope = JSON.stringify(httpReq.body);
	  var loginOptions = {
		  host: service_ip,
	      port: notification_port,
	      path: '/manage-notification-service/getNotifications/'+httpReq.param('userId'),
	      method: 'POST',
	      headers: {
	          'Content-Type': 'application/json',
	          'Content-Length': Buffer.byteLength(cope)
	      }
	  };
	  var req = http.request(loginOptions, function (res) {
	      res.setEncoding('utf8');
	      var data = "";
	      res.on('data', function (reply) {
	           data += reply;
	      });
	      res.on('end', function () {
	          var decoded_buffer = data.toString();
	          if (decoded_buffer.length > 0) {
	              httpRes.json(JSON.parse(data));
	          } else {
	              httpRes.json(JSON.parse('[]'));
	          }
	      })
	  });
	  req.on('error', function (error) {
	      console.log(error); httpRes.json(JSON.parse('[]'));
	  });
	  req.write(cope);
	  req.end();
	});


app.post('/updateNotifcationFlag', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: notification_port,
        path: '/manage-notification-service/updateNotificationFlag/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/deleteNotifcation', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: notification_port,
        path: '/manage-notification-service/removeNotification/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/clearAllNotifications', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: notification_port,
        path: '/manage-notification-service/clearAllNotifications/'+httpReq.param('userId'),
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/markAllReadNotifications', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
        /*host: service_ip,*/
    		host: service_ip,
        port: notification_port,
        path: '/manage-notification-service/markAllReadNotifications/'+httpReq.param('userId'),
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});

app.post('/deleteDownloadData', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
       host: service_ip,
        port: downloadNotifiy_port,
        path: '/manage-download-service/removeDownloadData/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});
app.post('/getNotificationsFilter', function (httpReq, httpRes) {
    var cope = JSON.stringify(httpReq.body);
    var loginOptions = {
       host: service_ip,
        port: notification_port,
        path: '/manage-notification-service/getNotificationsFilter/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(cope)
        }
    };
    var req = http.request(loginOptions, function (res) {
        res.setEncoding('utf8');
        var data = "";
        res.on('data', function (reply) {
             data += reply;
        });
        res.on('end', function () {
            var decoded_buffer = data.toString();
            if (decoded_buffer.length > 0) {
                httpRes.json(JSON.parse(data));
            } else {
                httpRes.json(JSON.parse('[]'));
            }
        })
    });
    req.on('error', function (error) {
        console.log(error); httpRes.json(JSON.parse('[]'));
    });
    req.write(cope);
    req.end();
});
/*Eof Notification*/



/* Changes Start - Shahid */

app.get('/accountUser', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'account user');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/user/' + session.userId + '?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting user profile');
    }
});

app.get('/getLoggedUserId', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'account user');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
               	data = session.userId;
               	var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(data);
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
                //req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting user profile');
    }
});

app.get('/getFrontCoverFormat', function(httpReq, httpRes) {
    try {
        logger.log('info', 'front cover');
               	data = config.Front_Cover_Format;
               	var decoded_buffer = data.toString();
                if (decoded_buffer.length > 0) {
                    httpRes.json(data);
                } else {
                    httpRes.json(JSON.parse('[]'));
                }
                //req.end();
      

    } catch (error) {
        logger.log('error', 'exception caught while getting fornt cover format');
    }
});

app.post('/updateUserProfilePicture', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    try {
        var user_profile_image = httpReq.files.user_profile_image;
        client.hgetall(sessionId, function(error, session) {
            if (session) {
                var user_id = session.userId;
                var oldProfilePicName = session.profilePicName;
                var file_extension = user_profile_image.name.split(".")[user_profile_image.name.split('.').length - 1];
                var file_name = 'user-profile-' + uuid.v1() + '.' + file_extension;

                if (!fsextra.existsSync(user_profile_picture_file_path)) {
                    console.log("Directory doesnt exist ");
                    fsextra.ensureDirSync(user_profile_picture_file_path);
                }

                user_profile_image.mv(user_profile_picture_file_path + "o-" + file_name, function(err) {
                    if (err) {
                        httpRes.status(500).send(err);
                    } else {
                        sharp(user_profile_picture_file_path + "o-" + file_name)
                            .resize(150, 150)
                            .toFile(user_profile_picture_file_path + file_name, function(err) {
                                if (err) {
                                    console.log("error " + err);
                                    httpRes.status(500).send(err);
                                } else {
                                    try {
                                        fs.unlinkSync(user_profile_picture_file_path + "o-" + file_name);
                                    } catch (e) { console.log("error " + e); }
                                    httpReq.body.profilePicName = user_profile_picture_file_path + file_name;
                                    var cope = JSON.stringify(httpReq.body);
                                    var request_options = {
                                        host: service_ip,
                                        port: admin_port,
                                        path: '/manage-admin-service/user/' + user_id + '/updateprofilepic?loggedUser=' + user_id,
                                        method: 'PUT',
                                        headers: {
                                            'Content-Type': 'application/json',
                                            'Content-Length': Buffer.byteLength(cope)
                                        }
                                    };
                                    var req = http.request(request_options, function(res) {
                                        var data = '';
                                        res.on('data', function(reply) {
                                            data += reply;
                                        });
                                        res.on('end', function() {
                                            var decoded_buffer = data.toString();
                                            if (decoded_buffer.length > 0) {
                                                var data_json = JSON.parse(data);
                                                console.log("oldProfilePicName [" + oldProfilePicName + "]");
                                                console.log("newProfilePicName [" + data_json.data.profilePicName + "]");
                                                if (oldProfilePicName != "" && oldProfilePicName != "null" && oldProfilePicName != null) {
                                                    fs.stat(oldProfilePicName, function(err, stat) {
                                                        if (err == null) {
                                                            fs.unlinkSync(oldProfilePicName);
                                                        } else if (err.code == 'ENOENT') {
                                                            console.log("User Old Profile Pic Doesn't Exist")
                                                        }
                                                    });
                                                }

                                                client.hmset(sessionId, 'userEmail', session.userEmail, 'userName', session.userName, 'userId', session.userId, 'profilePicName', data_json.data.profilePicName, 'loginTime', session.loginTime);
                                                httpRes.json(JSON.parse(data));
                                            } else {
                                                httpRes.json(JSON.parse('[]'));
                                            }
                                        })
                                        res.on('error', function(error) {
                                            console.log(error);
                                            httpRes.json(JSON.parse('[]'));
                                        });
                                    });
                                    req.on('error', function(error) {
                                        console.log(error);
                                        httpRes.json(JSON.parse('[]'));
                                    });
                                    req.write(cope);
                                    req.end();

                                }
                            });
                    }
                });
            }
        });

    } catch (error) {
        logger.log('error', 'error caught while updating user Profile Pic :: ' + error);
    }
});



app.post('/saveprofile', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/saveprofile/' + user_id + '?loggedUser=' + user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.get('/permissionGroup', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'permission Group');
        var permissionGroupId = httpReq.query.id;
        //console.log("Permission Group Id " + permissionGroupId);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/permissiongroup/' + permissionGroupId + '?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting Permission Group');
    }
});


app.get('/getRoles',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'roles');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/role?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});
app.get('/getWidget', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'roles');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                	//host:service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/defaultwidget?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});
app.get('/getAccounts',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'accounts');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/account?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting accounts');
    }
});

app.get('/getMetadataTypesFromConfig', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'metadatatypes');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/metadatatype?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting metadatatypes');
    }
});



app.get('/getProductCategories/:accountList?',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'productCategories');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {

            var logged_user_id = session.userId;
            var accountList = httpReq.params.accountList;

            var queryParams = '';

            if(accountList == undefined)
              queryParams = 'loggedUser=' + logged_user_id;
            else
              queryParams = 'accounts=' + accountList+'&loggedUser=' + logged_user_id;

                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/productcategory?' + queryParams,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting productCategories');
    }
});



app.get('/getMetadataGroups', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'metadataGroups');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/metadatagroup?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting metadataGroups');
    }
});

app.get('/getcMetadataGroups', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'cmetadataGroups');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/cmetadatagroup?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting metadataGroups');
    }
});



app.get('/getPartnerTypes',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'partnerTypes');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/partnertype?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});



app.get('/getApplications', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'applications');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/application?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting applications');
    }
});



app.get('/getModules', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'modules');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/module?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting modules');
    }
});

app.get('/getFormats', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'formats');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/format?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting formats');
    }
});

app.get('/getReports', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'reports');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/report?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting reports');
    }
});

app.get('/getAccessList', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'accessList');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/access?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting modules');
    }
});

app.get('/getUsers/:skip',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'users');
        var skip = httpReq.params.skip;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/users/' + skip + '?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting users');
    }
});



app.get('/getPermissionGroups', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'permissionGroups');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/permissiongroup?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting permissonGroups');
    }
});

app.post('/deleteUser/:userId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var user_id = httpReq.params.userId;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/' + user_id + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.post('/unlockUser/:userId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var user_id = httpReq.params.userId;
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/unlock/' + user_id + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/activate/:actVal/:userId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var user_id = httpReq.params.userId;
            var act_val = httpReq.params.actVal;/*
            console.log("User to be ACT/DEact [" + user_id + "]");
            console.log("new IsActive Val [" + act_val + "]");*/
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/' + user_id + '/activate/' + act_val + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/resendmail/:userId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var user_id = httpReq.params.userId;
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/' + user_id + '/resendmail?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.write(cope);
            req.end();
        }
    });
});


app.get('/getImprintListForAccounts/:accountList?', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var accountList = httpReq.params.accountList;

            var queryParams = '';

            if(accountList == undefined)
              queryParams = 'loggedUser=' + logged_user_id;
            else
              queryParams = 'accounts=' + accountList+'&loggedUser=' + logged_user_id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/imprint?' + queryParams,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});


app.post('/createPermissionGroup',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/permissiongroup?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/createUser',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});



app.post('/editPermissionGroup/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var permissionGroupId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/permissiongroup/' + permissionGroupId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/editUser/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var userId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/user/' + userId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/changepassword', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: login_port,
                path: '/manage-login-service/changepassword',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/saveAccount',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/account?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editAccount/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var accountId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/account/' + accountId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/deleteAccount/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var accountId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/account/' + accountId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});


app.post('/deleteAccountMapping/:id/:mappingValue',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var accountId = httpReq.params.id;
                var mappingValue = encodeURIComponent(httpReq.params.mappingValue);

                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/account/' + accountId + '/mapping/' + mappingValue + '?loggedUser=' + logged_user_id,
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    }

                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.end();
            }
        });
    } catch (e) { httpRes.json(JSON.parse('[]')); }

});

app.post('/editAccount/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var accountId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/account/' + accountId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/saveMapping/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var accountId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/account/' + accountId + '/mapping?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.get('/getMetadataFields', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'metadatafields');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/metadatafield?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting metadataGroups');
    }
});

app.post('/saveProductCatMapping/:metadataFieldName',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var metadataFieldName = httpReq.params.metadataFieldName;

            //console.log("Field Name [" + metadataFieldName + "]");

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/productcategory/mapping/' + metadataFieldName + '?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {}

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/saveProductCategory',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/productcategory?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editProductCategory/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var productCategoryId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/productcategory/' + productCategoryId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/deleteProductCategory/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var productCategoryId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/productcategory/' + productCategoryId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.get('/getFormatTypes', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'formatTypes');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/formattype?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});


// app.get('/getPartners', function(httpReq, httpRes) {
//     try {
//         var sessionId = httpReq.sessionID;
//         logger.log('info', 'partners');
//         client.hgetall(sessionId, function(error, session) {
//             if (error)
//                 return error;
//             if (session != null) {
//                 var request_options = {
//                     host: service_ip,
//                     port: admin_port,
//                     path: '/manage-admin-service/partner?loggedUser=' + session.userId,
//                     method: 'GET',
//                     headers: {
//                         'Content-Type': 'application/json'
//                     }
//                 };

//                 var req = http.request(request_options, function(res) {
//                     res.setEncoding('utf8');
//                     var data = "";
//                     res.on('data', function(reply) {
//                         data += reply;
//                     });
//                     res.on('end', function() {

//                         var decoded_buffer = data.toString();
//                         if (decoded_buffer.length > 0) {
//                             httpRes.json(JSON.parse(data));
//                         } else {
//                             httpRes.json(JSON.parse('[]'));
//                         }
//                     })

//                     res.on('error', function(error) {
//                         console.log(error);
//                         httpRes.json(JSON.parse('[]'));
//                     });

//                 });

//                 req.on('error', function(error) {
//                     console.log(error);
//                     httpRes.json(JSON.parse('[]'));
//                 });

//                 req.end();
//             }
//         });

//     } catch (error) {
//         logger.log('error', 'exception caught while getting partnerTypes');
//     }
// });

app.get('/getPartners/:export/:exportFormat',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'partners');
        //console.log("Inside getPatneers"+httpReq.params.export);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/partner?export='+httpReq.params.export+'&exportFormat='+httpReq.params.exportFormat+'&loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});


app.get('/getPartnerGroups',logActivity, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'partnergroups');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/partnergroup?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});

app.post('/savePartnerType',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnertype?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/savePartnerGroup',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnergroup?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/savePartner',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partner?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/deletePartnerType/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerTypeId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnertype/' + partnerTypeId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.post('/deletePartner/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partner/' + partnerId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.post('/deletePartnerGroup/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerGroupId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnergroup/' + partnerGroupId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

app.post('/activateDeactivatePartner/:actVal/:partnerId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerId = httpReq.params.partnerId;
            var act_val = httpReq.params.actVal;
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partner/' + partnerId + '/activate/' + act_val + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editPartner/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partner/' + partnerId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/changePartnerFtppassword/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partner/' + partnerId + '/changeftppassword?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editPartnerType/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerTypeId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnertype/' + partnerTypeId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editPartnerGroup/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerGroupId = httpReq.params.id;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/partnergroup/' + partnerGroupId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/saveDRM', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
    	//console.log('Save DRM request with Auth : '+session.token )
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: drm_port,
                path: '/manage-drm-service/drminternal?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                	'Authorization':'Bearer '+ session.token,
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


//***// Api call
app.post('/manage-drm-service/drm',function(httpReq, httpRes) {

	try{
	//console.log("DRM save from :"+httpReq.connection.remoteAddress );
	
	if(httpReq.headers.authorization==="" || httpReq.headers.authorization===undefined )
		{
			httpRes.status(403);
			httpRes.json({'status':403,error_description:'Authentication Required'});
			return;
		}
	
	var loggedUser = httpReq.query.loggedUser;
	
	var data1;
	data1 = JSON.stringify(httpReq.body);

	 
	var options = {
               host: service_ip,
               port: drm_port,
               path: "/manage-drm-service/drm?loggedUser="+loggedUser,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(data1),
                   'Authorization':httpReq.headers.authorization
               }
    };
	
	
    var req = http.request(options, function (res) {
              var datas = "";
              res.on('data', function (reply) {
            	  //console.log("Data !!!");
                   datas += reply;
               });
               res.on('end', function () {
            	   //console.log("Response End !!!");
            	   //console.log(datas);
            	   //.httpRes.status(datas.code);
                   httpRes.json(JSON.parse(datas));
               })
    });
    req.on('error', function (error) {
    	console.log("Call Error !!!");
               console.log(error); 
               httpRes.json(JSON.parse('[]'));
    });
    req.write(data1);
    req.end();
	}
	catch(e){
		httpRes.status(403);
		httpRes.json(JSON.parse({'status':500,error_description:'Invalid Request !!'}));
		return;
	}
});


app.post('/manage-drm-service/watermark',function(httpReq, httpRes) {

	try{
	//console.log("watermark save from :"+httpReq.connection.remoteAddress );
	
	if(httpReq.headers.authorization==="" || httpReq.headers.authorization===undefined )
		{
			httpRes.status(403);
			httpRes.json({'status':403,error_description:'Authentication Required'});
			return;
		}
	
	var loggedUser = httpReq.query.loggedUser;
	
	var data1;
	data1 = JSON.stringify(httpReq.body);

	 
	var options = {
               host: service_ip,
               port: drm_port,
               path: "/manage-drm-service/watermark?loggedUser="+loggedUser,
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Content-Length': Buffer.byteLength(data1),
                   'Authorization':httpReq.headers.authorization
               }
    };
	
	
    var req = http.request(options, function (res) {
              var datas = "";
              res.on('data', function (reply) {
            	  //console.log("Data !!!");
                   datas += reply;
               });
               res.on('end', function () {
            	   //console.log("Response End !!!");
            	   //console.log(datas);
            	   //.httpRes.status(datas.code);
                   httpRes.json(JSON.parse(datas));
               })
    });
    req.on('error', function (error) {
    	console.log("Call Error !!!");
               console.log(error); 
               httpRes.json(JSON.parse('[]'));
    });
    req.write(data1);
    req.end();
	}
	catch(e){
		httpRes.status(403);
		httpRes.json(JSON.parse({'status':500,error_description:'Invalid Request !!'}));
		return;
	}
});


// end of API Call

app.get('/cover/:isbn', function(httpReq, httpRes) {
    try {
    	 var isbn = httpReq.params.isbn;
    	  var request_options = {
                  host: service_ip,
                  port: drm_port,
                  path: '/manage-drm-service/cover/'+isbn,
                  method: 'GET',
                  headers: {
                      'Content-Type': 'application/json'
                  }
              };

              var req = http.request(request_options, function(res) {
                  res.setEncoding('utf8');
                  var data = "";
                  res.on('data', function(reply) {
                      data += reply;
                  });
                  res.on('end', function() {

                      var decoded_buffer = data.toString();
                      if (decoded_buffer.length > 0) {
                          httpRes.json(JSON.parse(data));
                      } else {
                          httpRes.json(JSON.parse('[]'));
                      }
                  })

                  res.on('error', function(error) {
                      console.log(error);
                      httpRes.json(JSON.parse('[]'));
                  });

              });

              req.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

              req.end();
    	
    }
    catch(e){console.log(e)}
});


app.get('/getDrmEligibleFormats', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'getDrmEligibleFormats');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: drm_port,
                    path: '/manage-drm-service/eligibleFormats?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting eligible DRM Formats');
    }
});

app.post('/checkForDuplicateUser', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

                var cope = JSON.stringify(httpReq.body);

                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/user/checkforduplicateuser?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    },
                    data: cope
                };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/checkForDuplicatePgName', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

                var cope = JSON.stringify(httpReq.body);

                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/user/checkForDuplicatePgName?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    },
                    data: cope
                };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/getUserColumnFilterSuggestions', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/getUserColumnFilterSuggestions?loggedUser=' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught in getColumnFilterSuggestions');
    }

});

app.post('/getFilteredUsers', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        var reqId = httpReq.body.reqId;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/filteredusers?loggedUser=' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            data = JSON.parse(data)
                            data.reqId = reqId;
                            httpRes.json(data);
                            //httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught in getColumnFilterSuggestions');
    }

});

/* Changes End - Shahid */

/* jp changes Strat */
//Start Water-Mark

app.post('/saveWaterMark', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);

            var request_options = {
                host: service_ip,
                port: drm_port,
                path: '/manage-drm-service/watermark?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                	'Authorization':'Bearer '+ session.token,
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});
app.post('/createRole',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);
           // console.log("role"+cope);
            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/role?loggedUser=' + logged_user_id,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editRole/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var roleID = httpReq.params.id;
            var cope = JSON.stringify(httpReq.body);
           // console.log("role"+cope);
            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/role/'+ roleID +'?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/deleteRole/:id',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            
            var roleID = httpReq.params.id;
            var request_options = {
                host: service_ip,
            	//host: "172.16.3.117",
            	port: admin_port,
                path: '/manage-admin-service/role/' + roleID + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});


app.post('/roleActivate/:actVal/:roleId',logActivity, function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var role_id = httpReq.params.roleId;
            var act_val = httpReq.params.actVal;
            //console.log("Role to be ACT/DEact [" + role_id + "]");
            //console.log("new IsActive Val [" + act_val + "]");
            var cope = JSON.stringify(httpReq.body);

            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/role/' + role_id + '/activate/' + act_val + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/checkForDuplicateRole', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
                var cope = JSON.stringify(httpReq.body);
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/role/checkforduplicaterole?loggedUser=' + logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    },
                    data: cope
                };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                //console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});
//Shelf start

app.post('/deleteShelfItem', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);
            //console.log("shelf"+cope);
            var request_options = {
                host:service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/deleteShelfItem',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});
app.post('/clearAssetShelf/:shelftype', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var loggedUserId = session.userId;
            
            var cope = JSON.stringify(httpReq.body);
            var shelf_type = httpReq.params.shelftype;
            var request_options = {
                host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/clearShelf/'+shelf_type+'/' + loggedUserId,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: null

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                //console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.post('/deleteShelf', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            
            var cope = JSON.stringify(httpReq.body);
            var request_options = {
                host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/deleteShelfDetails',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});
app.post('/editShelf', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            
            var cope = JSON.stringify(httpReq.body);
           // console.log("role"+cope);
            var request_options = {
                host: service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/editShelfDetails',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.get('/getShelfDetails', function(httpReq, httpRes) {
    try {
        
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
            	var loggedUserId = session.userId;
                httpReq.body.loggedUser = loggedUserId;
              var cope = JSON.stringify(httpReq.body);
                var request_options = {
                    host:service_ip,
                    port: fileupload_port,
                    path: '/manage-file-upload-download-service/getShelfDetails?loggeduser=' + loggedUserId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(cope)
                    },
                    data: cope
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
          
            }});

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});
//dashboard start


//standard dashBoard

app.get('/getStandardDashBoard', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/standarddashboard/details?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});

app.post('/createSD', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);
           // console.log("role"+cope);
            var request_options = {
            	host: service_ip,
            	port: admin_port,
                path: '/manage-admin-service/standarddashboard/details?loggedUser=' + session.userId,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});

app.post('/editSD/:id', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var sdID = httpReq.params.id;
            var cope = JSON.stringify(httpReq.body);
           // console.log("role"+cope);
            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/standarddashboard/details/'+ sdID +'?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});


app.get('/getUserSearchList/:search', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
    	try{
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var search = httpReq.params.search;
            //var cope = JSON.stringify(httpReq.body);
           //console.log("role"+cope);
            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/standarddashboard/userSuggestions?searchText='+ search +'&loggedUser=' + logged_user_id,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    //'Content-Length': Buffer.byteLength(cope)
                },
               // data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            //req.write(cope);
            req.end();
        }
    	}catch(e){};
    });
});

app.get('/YearCall/:date', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var date = httpReq.params.date;
            //var cope = JSON.stringify(httpReq.body);
           //console.log("role"+cope);
            var request_options = {
            	host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/standarddashboard/details?year='+ date +'&loggedUser=' + logged_user_id,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    //'Content-Length': Buffer.byteLength(cope)
                },
               // data: cope

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.on('error', function(error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            //req.write(cope);
            req.end();
        }
    });
});



//dashboard

app.post('/deleteUnPinDashboard/:param', function(httpReq, httpRes) {
	  var sessionId = httpReq.sessionID;
	  client.hgetall(sessionId, function(error, session) {
	      if (error)
	          return error;
	      if (session != null) {
	          var logged_user_id = session.userId;
	          var val= httpReq.params.param;
	         // console.log(val+"checkDashBoard")
	          var request_options = {
	        	  host:service_ip,
	              port: dashboard_port,
	              path: '/manage-dashboard-service/unpin/' + val + '?loggedUser=' + logged_user_id,
	              method: 'DELETE',
	              headers: {
	                  'Content-Type': 'application/json'
	                 // 'Content-Length': Buffer.byteLength(cope)
	              },
	            

	          };

	          var req = http.request(request_options, function(res) {
	              res.setEncoding('utf8');
	              var data = "";
	              res.on('data', function(reply) {
	                  data += reply;
	              });
	              res.on('end', function() {

	                  var decoded_buffer = data.toString();
	                  if (decoded_buffer.length > 0) {
	                      httpRes.json(JSON.parse(data));
	                  } else {
	                      httpRes.json(JSON.parse('[]'));
	                  }
	              })

	              res.on('error', function(error) {
	                  //console.log(error);
	                  httpRes.json(JSON.parse('[]'));
	              });

	          });

	          //req.write(cope);
	          req.end();
	      }
	  });
	});

app.get('/getDashBoard', function(httpReq, httpRes) {
  try {
      var sessionId = httpReq.sessionID;
      logger.log('info', 'dashboard');
      client.hgetall(sessionId, function(error, session) {
          if (error)
              return error;
          if (session != null) {
              var request_options = {
              	host:service_ip,
              	port: dashboard_port,
                  path: '/manage-dashboard-service/dashboard?loggedUser=' + session.userId,
                  method: 'GET',
                  headers: {
                      'Content-Type': 'application/json'
                  }
              };

              var req = http.request(request_options, function(res) {
                  res.setEncoding('utf8');
                  var data = "";
                  res.on('data', function(reply) {
                      data += reply;
                  });
                  res.on('end', function() {

                      var decoded_buffer = data.toString();
                      if (decoded_buffer.length > 0) {
                          httpRes.json(JSON.parse(data));
                      } else {
                          httpRes.json(JSON.parse('[]'));
                      }
                  })

                  res.on('error', function(error) {
                      console.log(error);
                      httpRes.json(JSON.parse('[]'));
                  });

              });

              req.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

              req.end();
          }
      });

  } catch (error) {
      logger.log('error', 'exception caught while getting roles');
  }
});

app.post('/saveRename/:dabId/:rename', function(httpReq, httpRes) {
  var sessionId = httpReq.sessionID;
  client.hgetall(sessionId, function(error, session) {
      if (error)
          return error;
      if (session != null) {
          var logged_user_id = session.userId;
          var dabId= httpReq.params.dabId;
          var rename = httpReq.params.rename;
          
          var cope = JSON.stringify(httpReq.body);
          var request_options = {
        	 host:service_ip,
              port: dashboard_port,
              path: '/manage-dashboard-service/dashboard/' + dabId + '/rename?loggedUser=' + logged_user_id,
              method: 'PUT',
              headers: {
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(cope)
              },
              data: cope

          };

          var req = http.request(request_options, function(res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function(reply) {
                  data += reply;
              });
              res.on('end', function() {

                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })

              res.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

          });

          req.write(cope);
          req.end();
      }
  });
});


app.post('/saveDuplicate/:dabId/:duplicate', function(httpReq, httpRes) {
  var sessionId = httpReq.sessionID;
  client.hgetall(sessionId, function(error, session) {
      if (error)
          return error;
      if (session != null) {
          var logged_user_id = session.userId;
          var dabId= httpReq.params.dabId;
          var rename = httpReq.params.rename;
          
          var cope = JSON.stringify(httpReq.body);
          var request_options = {
        		  host:service_ip,
              port: dashboard_port,
              path: '/manage-dashboard-service/dashboard/' + dabId + '/duplicate?loggedUser=' + logged_user_id,
              method: 'PUT',
              headers: {
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(cope)
              },
              data: cope

          };

          var req = http.request(request_options, function(res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function(reply) {
                  data += reply;
              });
              res.on('end', function() {

                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })

              res.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

          });

          req.write(cope);
          req.end();
      }
  });
});

app.post('/deleteDashbordName/:dabId', function(httpReq, httpRes) {
  var sessionId = httpReq.sessionID;
  client.hgetall(sessionId, function(error, session) {
      if (error)
          return error;
      if (session != null) {
          var logged_user_id = session.userId;
          var dabId= httpReq.params.dabId;
          var rename = httpReq.params.rename;
          
          var cope = JSON.stringify(httpReq.body);
          var request_options = {
        		  host:service_ip,
              port: dashboard_port,
              path: '/manage-dashboard-service/dashboard/' + dabId + '?loggedUser=' + logged_user_id,
              method: 'DELETE',
              headers: {
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(cope)
              },
              data: cope

          };

          var req = http.request(request_options, function(res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function(reply) {
                  data += reply;
              });
              res.on('end', function() {

                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })

              res.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

          });

          req.write(cope);
          req.end();
      }
  });
});

app.post('/saveDashbord', function(httpReq, httpRes) {
  var sessionId = httpReq.sessionID;
  client.hgetall(sessionId, function(error, session) {
      if (error)
          return error;
      if (session != null) {
          var logged_user_id = session.userId;
          var dabId= httpReq.params.dabId;
          var rename = httpReq.params.rename;
          
          var cope = JSON.stringify(httpReq.body);
          var request_options = {
        		  host:service_ip,
              port: dashboard_port,
              path: '/manage-dashboard-service/dashboard/' + dabId + 'customwidget?loggedUser=' + logged_user_id,
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'Content-Length': Buffer.byteLength(cope)
              },
              data: cope

          };

          var req = http.request(request_options, function(res) {
              res.setEncoding('utf8');
              var data = "";
              res.on('data', function(reply) {
                  data += reply;
              });
              res.on('end', function() {

                  var decoded_buffer = data.toString();
                  if (decoded_buffer.length > 0) {
                      httpRes.json(JSON.parse(data));
                  } else {
                      httpRes.json(JSON.parse('[]'));
                  }
              })

              res.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

          });

          req.write(cope);
          req.end();
      }
  });
});


app.get('/defaultwidget',logActivity, function(httpReq, httpRes) {
  try {
      var sessionId = httpReq.sessionID;
      logger.log('info', 'dashboard');
      client.hgetall(sessionId, function(error, session) {
          if (error)
              return error;
          if (session != null) {
              var request_options = {
                  host:service_ip,
                  port: dashboard_port,
                  path: '/manage-dashboard-service/dashboard/defaultwidget?loggedUser=' + session.userId,
                  method: 'GET',
                  headers: {
                      'Content-Type': 'application/json'
                  }
              };

              var req = http.request(request_options, function(res) {
                  res.setEncoding('utf8');
                  var data = "";
                  res.on('data', function(reply) {
                      data += reply;
                  });
                  res.on('end', function() {

                      var decoded_buffer = data.toString();
                      if (decoded_buffer.length > 0) {
                          httpRes.json(JSON.parse(data));
                      } else {
                          httpRes.json(JSON.parse('[]'));
                      }
                  })

                  res.on('error', function(error) {
                      console.log(error);
                      httpRes.json(JSON.parse('[]'));
                  });

              });

              req.on('error', function(error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
              });

              req.end();
          }
      });

  } catch (error) {
      logger.log('error', 'exception caught while getting roles');
  }
});

app.get('/searchNameAsset', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'dashboard');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host:service_ip,
                    port: dashboard_port,
                    path: '/manage-dashboard-service/dashboard/importantassets?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});

app.post('/getDownloadNotification', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
       
        client.hgetall(sessionId, function(error, session) {
        	//console.log(session.userId+"=--------------------------userId");
            if (error)
                return error;
            if (session != null) {
            	//console.log(session.userId+"=--------------------------userId");
                var request_options = {
                	host:service_ip,
                    port: downloadNotifiy_port,
                    path: '/manage-download-service/retrieveDownloadData/' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting roles');
    }
});
//end dashboard
app.get('/nameList',authenticate, function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host:service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/nameList',
           method: 'GET',
           headers: {
               'Content-Type': 'application/json; charset=utf-8',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        
        var req = http.request(loginOptions, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
                //console.log(user);
                httpRes.send(user.data);
            });
        });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.get('/activityList/:val',authenticate, function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
       var req_type = httpReq.params.val;
      // console.log(val);
        var loginOptions = {
        		host:service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/activityList/'+req_type,
           method: 'GET',
           headers: {
               'Content-Type': 'application/json; charset=utf-8',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        
        var req = http.request(loginOptions, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
            //    console.log(user);
                httpRes.send(user.data);
            });
        });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.get('/remainderList',authenticate, function (httpReq, httpRes) {
	
       var cope = JSON.stringify(httpReq.body);
        var loginOptions = {
        		host:service_ip,
                port: fileupload_port,
           path: '/manage-file-upload-download-service/remainderList',
           method: 'GET',
           headers: {
               'Content-Type': 'application/json; charset=utf-8',
               'Content-Length': Buffer.byteLength(cope)
           },
           data: cope
       };
        
        var req = http.request(loginOptions, function (res) {
            var data = "";
            res.on('data', function (reply) {
                data += reply;
            });
            res.on('end', function () {
                var user = JSON.parse(data);
               // console.log(user);
                httpRes.send(user.data);
            });
        });
       req.on('error', function (error) {
           console.log(error); httpRes.json(JSON.parse('[]'));
       });
       req.write(cope);
       req.end();
});

app.post('/saveShelfDetails', function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function (error, session) {
        if (error)
            return error;
        if (session != null) {
          var logged_user_id = session.userId;

            var cope = JSON.stringify(httpReq.body);
            
            var request_options = {
                host:service_ip,
                port: fileupload_port,
                path: '/manage-file-upload-download-service/saveShelfDetails',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope

            };

            var req = http.request(request_options, function (res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function (reply) {
                    data += reply;
                });
                res.on('end', function () {

                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function (error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
                });

            });
            
            req.on('error', function (error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });

            req.write(cope);
            req.end();
        }
    });
});
/* Changes End - Selvam */
app.get('/getWMEligibleFormats', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'getDrmEligibleFormats');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/watermark/eligibleFormats?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting eligible DRM Formats');
    }
});
/* Widget start */
app.post('/widgetview', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
				   host: service_ip,
				   port: widget_port,
				   path: '/manage-widget-service/view?loggedUser=' + session.userId,
				   method: 'POST',
				   headers: {
					   'Content-Type': 'application/json'
				   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});
app.post('/WidgetSubmit', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
				   host: service_ip,
				   port: widget_port,
				   path: '/manage-widget-service/create?loggedUser=' + session.userId,
				   method: 'POST',
				   headers: {
					   'Content-Type': 'application/json'
				   }
				};

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});

app.post('/WidgetEdit', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
				   host: service_ip,
				   port: widget_port,
				   path: '/manage-widget-service/edit?loggedUser=' + session.userId,
				   method: 'POST',
				   headers: {
					   'Content-Type': 'application/json'
				   }
				};

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});
app.post('/removeWidget', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
				   host: service_ip,
				   port: widget_port,
				   path: '/manage-widget-service/remove?loggedUser=' + session.userId,
				   method: 'POST',
				   headers: {
					   'Content-Type': 'application/json'
				   }
				};

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});
app.get('/viewerFormats', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
				   host: service_ip,
				   port: admin_port,
				   path: '/manage-admin-service/viewerformats?loggedUser=' + session.userId,
				   method: 'GET',
				   headers: {
					   'Content-Type': 'application/json'
				   }
				};

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});
/* Widget end */
/*widget dashboard : Starts 
Author :venkatesh*/
/*view widget dashboard*/
app.post('/viewWidgetDashboard', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: widget_port,
                   path: '/manage-widget-service/viewall?loggedUser=' + session.userId,
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };
                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });
    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }
});
/*view widget best seller*/
app.post('/viewWidgetBestSeller', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                		host: service_ip,
                   port: widget_port,
                   path: '/manage-widget-service/bestbuys?loggedUser=' + session.userId,
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };
                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        //console.log(decoded_buffer);
                        // console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });
    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }
});
//getSearchWidgetColumnSuggestion
app.post('/getSearchWidgetColumnSuggestion', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: widget_port,
                   path: '/manage-widget-service/getColumnFilterSuggestions?loggedUser=' + session.userId,
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };
                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        //console.log(decoded_buffer);
                         //console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });
    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }
});
/* Widget Dashboard end */

//getHeaderFieldsWidget
app.post('/getHeaderFieldsWidget', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: widget_port,
                   path: '/manage-widget-service/getGridHeaders?loggedUser=' + session.userId,
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        console.log(decoded_buffer);
                         console.log(decoded_buffer.length);
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});
app.post('/insertAssetDeleteRequest', function (httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function (error, session) {
        if (error)
            return error;
        if (session != null) {
          var logged_user_id = session.userId;
            var cope = httpReq.body;
            cope.loggedUser=logged_user_id;
            cope = JSON.stringify(cope);
            console.log("Delete Request");
            console.log(cope);
            
            var request_options = {
                host:service_ip,
            	//host:"172.16.3.105",
                port: fileupload_port,
                path: '/manage-file-upload-download-service/insertAssetDeleteRequest',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(cope)
                },
                data: cope
            };
            var req = http.request(request_options, function (res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function (reply) {
                    data += reply;
                });
                res.on('end', function () {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })
                res.on('error', function (error) {
                  console.log(error);
                  httpRes.json(JSON.parse('[]'));
                });
            });
            req.on('error', function (error) {
                console.log(error);
                httpRes.json(JSON.parse('[]'));
            });
            req.write(cope);
            req.end();
        }
    });
});
/* POST service integration ends here*/

/* Asset Version start*/

app.post('/fetchAssetVersion', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: fileupload_port,
                   path: '/manage-asset-version-service/getAllVersion',
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});

app.post('/newFileVersion', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: fileupload_port,
                   path: '/manage-asset-version-service/newFileVersion',
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});

app.post('/assetversionColumnSearchFilter', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: fileupload_port,
                   path: '/manage-asset-version-service/getColumnSearchFilterData',
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});


app.post('/assetversionColumnSearchData', authenticate, function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        //console.log("cope ", cope);
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var viewSearch = {
                   host: service_ip,
                   port: fileupload_port,
                   path: '/manage-asset-version-service/getColumnSearchData',
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json'
                   }
                };

                var req = http.request(viewSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in viewSearch');
    }

});


app.post('/saveTransaction', function (httpReq, httpRes) {
	   var cope = JSON.stringify(httpReq.body);
	   var loginOptions = {
	       /*host: service_ip,*/
	           host: service_ip,
	       port: notification_port,
	       path: '/manage-notification-service/saveTransaction/',
	       method: 'POST',
	       headers: {
	           'Content-Type': 'application/json',
	           'Content-Length': Buffer.byteLength(cope)
	       }
	   };
	   var req = http.request(loginOptions, function (res) {
	       res.setEncoding('utf8');
	       var data = "";
	       res.on('data', function (reply) {
	            data += reply;
	       });
	       res.on('end', function () {
	           var decoded_buffer = data.toString();
	           if (decoded_buffer.length > 0) {
	               httpRes.json(JSON.parse(data));
	           } else {
	               httpRes.json(JSON.parse('[]'));
	           }
	       })
	   });
	   req.on('error', function (error) {
	       console.log(error); httpRes.json(JSON.parse('[]'));
	   });
	   req.write(cope);
	   req.end();
	});
/* Asset Version End*/



/* If the user is idle for more than 20 minutes then session will expire. */
function verifyRecaptcha(key, callback) {
	callback( true);
    /*https.get(config.google_recaptcha_verification_url + config.site_secret_key + "&response=" + key, function (res) {
        var data = "";
        res.on('data', function (chunk) {
            data += chunk.toString();
        });
        res.on('end', function () {
            try {
                var parsedData = JSON.parse(data);
                callback(parsedData.success);
            } catch (e) {
                callback(false);
            }
        });
    });*/
}

/*

function checkSessionExpiry() {
    logger.log('info', 'checkSessionExpiry :: redis client connected.....');
    var myTimer = setInterval(function () {
        logger.log('info', 'checkSessionExpiry :: checking session expiry');
        client.keys('*', function (err, keys) {
            if (err)
                return console.log(err);
            for (var i = 0, len = keys.length; i < len; i++) {
                var sessionId = keys[i];
                logger.log('info', 'checkSessionExpiry :: key :: %s', sessionId);
                client.hgetall(sessionId, function (error, session) {
                    if (session != null) {
                        if (session.userName != null && session.loginTime != null) {
                            var totalIdleTime = (new Date().getTime() - session.loginTime);
                            if (totalIdleTime >= config.session_expiry_time) {
                                logger.log('info', 'checkSessionExpiry :: Session ID :: %s', sessionId);
                                client.del(sessionId);
                                logger.log('info', 'session expired for user %s', session.userName);
                            }
                        }
                    }
                });
            }
        });
    }, config.session_expiry_verify_interval);
}
*/

/* watermark extraction start*/

app.post('/extractWatermark',authenticate, function (httpReq, httpRes) {
	 var sessionId = httpReq.sessionID;
	
	client.hgetall(sessionId, function (error, session) {
		if (error)
			return error;
		if (session != null) {
			//var userId = httpReq.param('userId');
			var watermarkFile = httpReq.files.file;

			//var metadataXl = httpReq.files.metadataUpload;

			if (!fsextra.existsSync(watermarkpath)) {
				console.log("Directory doesnt exist ", watermarkpath);
				fsextra.ensureDirSync(watermarkpath);
			}
			watermarkFile.mv(watermarkpath + watermarkFile.name, function (err) {
			
			
				if (err) {
					httpRes.status(500).send(err);
				} else {
					console.log("success");

					var cope = JSON.stringify({
						inputFileName: watermarkpath + watermarkFile.name
						//inputFileName: "/watermark/pdf/input/9781780962207_WebPDF.pdf"
						
					});

					var uploadMetaData = {
						host: service_ip,
						port: drm_port,
						path: '/manage-drm-service/extractwatermark?loggedUser=' + session.userId,
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						}
					};
					var req = http.request(uploadMetaData, function (res) {
						res.setEncoding('utf8');
						var data = "";
						res.on('data', function (reply) {
							data += reply;
						});
						res.on('end', function () {
							var decoded_buffer = data.toString();
							//console.log(decoded_buffer);
							//console.log(decoded_buffer.length);
							if (decoded_buffer.length > 0) {
								httpRes.json(JSON.parse(data));
							} else {
								httpRes.json(JSON.parse('[]'));
							}
						})
					});
					req.on('error', function (error) {
						console.log(error);
						httpRes.json(JSON.parse('[]'));
					});
					req.write(cope);
					req.end();
				}
			});
		}
	});
}); 

/* watermark extraction end*/
app.get('/Widgets/:isbn/:file', function (httpReq, httpRes) {
  
	widgetPages = require('/help/WidgetData.json');
 	var pathData = httpReq.param("file").replace(".html","").replace(".HTML","").replace(".Html","");
 
	var newId = widgetPages.filter(function(item) {
		  return item.path == httpReq.param("isbn")+"/"+pathData;
		});
  
    //httpRes.render('widget.html',{widgetparam:newId[0]._id});
  httpRes.redirect('/widget/'+newId[0]._id);
});

// ADDED FOR SUPPORT MODULE START

app.post('/searchPartnersforSupport',authenticate, function (httpReq, httpRes) {
    
    //   httpReq.body.created_by = user_identity.user_id;
        try {
        console.log("Inside searchPartnersforSupport");
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                console.log(logged_user_id);
                var saveSearch = {
                    host: service_ip,
                    port: support_port,
                    path: '/manage-support-service/searchPartnersforSupport?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

});

app.post('/updateAndSendEmail',authenticate, function (httpReq, httpRes) {
       try {
        //console.log("Inside saveCustomHeadersNew");
        var cope = JSON.stringify(httpReq.body);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                    port: support_port,
                    path: '/manage-support-service/updateAndSendEmail?loggedUser='+logged_user_id,
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

});

//ADDED FOR ON-DEMAND ONIX INGESTION

app.post('/uploadonixMetaData',authenticate, function (httpReq, httpRes) {
    var userId = httpReq.param('userId');
    
     var metadataXl = httpReq.files.metadataUpload;
             if (!fsextra.existsSync(metadataonixuploadPath)) {
                 console.log("Directory doesnt exist ",metadataonixuploadPath);
                 fsextra.ensureDirSync(metadataonixuploadPath);
             }
             console.log(metadataXl.name);
             metadataXl.mv(metadataonixuploadPath +metadataXl.name, function(err) {
                 if (err) {
                     httpRes.status(500).send(err);
                 } else {
                     console.log("success");
                     console.log("Path : "+metadataonixuploadPath+metadataXl.name);
                     var cope = JSON.stringify({path:metadataonixuploadPath+metadataXl.name,userId:userId});
                     
                     var uploadMetaData = {
                         host: service_ip,
                         port: onix_port,
                         path: '/manage-onix-service/readOnixProduct/',
                         method: 'POST',
                         headers: {
                             'Content-Type': 'application/json',
                         }
                     };
                       var req = http.request(uploadMetaData, function (res) {
                           res.setEncoding('utf8');
                           var data = "";
                           res.on('data', function (reply) {
                               data += reply;
                           });
                           res.on('end', function () {
                               var decoded_buffer = data.toString();
                               //console.log(decoded_buffer);
                               //console.log(decoded_buffer.length);
                               if (decoded_buffer.length > 0) {
                                   httpRes.json(JSON.parse(data));
                               } else {
                                   httpRes.json(JSON.parse('[]'));
                               }
                           })
                 });
                 req.on('error', function (error) {
                        console.log(error); httpRes.json(JSON.parse('[]'));
                 }); 
                 req.write(cope);
                 req.end();
                 }
             });
}); 

app.post('/exportWidget', function(httpReq, httpRes) {
    console.log("WIDGET EXPORT");
    try {
        var sessionId = httpReq.sessionID;
        var cope = JSON.stringify(httpReq.body);
        logger.log('info', 'partners');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: widget_port,
                    path: '/manage-widget-service/viewallExport?loggedUser=' + session.userId,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});

//ADDED FOR GDS CONFIGURATION
/*
app.post('/uploadExcelTemplateForGds',authenticate, function (httpReq, httpRes) {
    //var userId = httpReq.param('userId');
     var metadataXl = httpReq.files.metadataUpload;
             if (!fsextra.existsSync(gdsExcelUploadPath)) {
                 console.log("Directory doesnt exist ",gdsExcelUploadPath);
                 fsextra.ensureDirSync(gdsExcelUploadPath);
             }
             console.log(metadataXl.name);
             metadataXl.mv(gdsExcelUploadPath +metadataXl.name, function(err) {
                 if (err) {
                    httpRes.json({"Path":"Error"});
                     httpRes.status(500).send(err);
                 } else {
                     console.log("success");
                     console.log("Path : "+gdsExcelUploadPath+metadataXl.name);

                     
                    const workbook = XLSX.readFile(gdsExcelUploadPath+metadataXl.name);
                    const sheet_name_list = workbook.SheetNames;
                    console.log('#######################');
                    console.log(sheet_name_list);
                    httpRes.json({"Path":gdsExcelUploadPath+metadataXl.name,
                                  "sheetNames":sheet_name_list});
                }
             });
});
*/

app.post('/uploadExcelTemplateForGds',authenticate, function (httpReq, httpRes) {
    //var userId = httpReq.param('userId');
     var metadataXl = httpReq.files.metadataUpload;
             if (!fsextra.existsSync(gdsExcelUploadPath)) {
                 console.log("Directory doesnt exist ",gdsExcelUploadPath);
                 fsextra.ensureDirSync(gdsExcelUploadPath);
             }
             console.log(metadataXl.name);
             
            if (fs.existsSync(gdsExcelUploadPath+metadataXl.name.replace(/\s/gi, "_"))) {
                // Do something
                fs.rename(gdsExcelUploadPath+metadataXl.name.replace(/\s/gi, "_"), newgdsExcelUploadPath+(new Date().getTime()).toString()+'_'+metadataXl.name.replace(/\s/gi, "_"), function (err) {
                if (err) {console.log(err); return; }

                console.log('The file has been re-named to: ' + newgdsExcelUploadPath+(new Date().getTime()).toString()+'_'+metadataXl.name.replace(/\s/gi, "_"));
                });
           
            } 
            
           	metadataXl.mv(gdsExcelUploadPath +metadataXl.name.replace(/\s/gi, "_"), function(err) {
                 if (err) {
                    httpRes.json({"Path":"Error"});
                     httpRes.status(500).send(err);
                 } else {
                     console.log("success");
                     console.log("Path : "+gdsExcelUploadPath+metadataXl.name.replace(/\s/gi, "_"));

                     
                    const workbook = XLSX.readFile(gdsExcelUploadPath+metadataXl.name.replace(/\s/gi, "_"));
                    const sheet_name_list = workbook.SheetNames;
                    console.log(sheet_name_list);
                    httpRes.json({"Path":gdsExcelUploadPath+metadataXl.name.replace(/\s/gi, "_"),
                                  "sheetNames":sheet_name_list});
                }
             });
});

app.get('/getAllGdsLookupNames', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var logged_user_id = session.userId;
        logger.log('info', 'partnergroups');
        console.log('INSIDE getAllPartnerConfig');
        
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                console.log('USER ID ------>'+logged_user_id);
                var request_options = {
                   host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/getAllGdsLookupNames?loggedUser='+logged_user_id,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});

app.get('/getAllPartnerConfig', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        var logged_user_id = session.userId;
        logger.log('info', 'partnergroups');
        console.log('INSIDE getAllPartnerConfig');
        
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                console.log('USER ID ------>'+logged_user_id);
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/getAllpartnerConfig?loggedUser='+logged_user_id,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});


app.get('/exportGds', function(httpReq, httpRes) {
    try {
        var sessionId = httpReq.sessionID;
        logger.log('info', 'partners');
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var request_options = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/exportGds?loggedUser=' + session.userId,
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };

                var req = http.request(request_options, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {

                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })

                    res.on('error', function(error) {
                        console.log(error);
                        httpRes.json(JSON.parse('[]'));
                    });

                });

                req.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while getting partnerTypes');
    }
});

app.post('/savePartnerConfiguration',authenticate, function (httpReq, httpRes) {
       try {
        var logged_user_id = session.userId;    
        //console.log("Inside saveCustomHeadersNew");
        var cope = JSON.stringify(httpReq.body);
        console.log(cope);
        var sessionId = httpReq.sessionID;
        client.hgetall(sessionId, function(error, session) {
            if (error)
                return error;
            if (session != null) {
                var logged_user_id = session.userId;
                var saveSearch = {
                    host: service_ip,
                    port: admin_port,
                    path: '/manage-admin-service/partnerconfig?loggedUser='+logged_user_id,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                };
                var req = http.request(saveSearch, function(res) {
                    res.setEncoding('utf8');
                    var data = "";
                    res.on('data', function(reply) {
                        data += reply;
                    });
                    res.on('end', function() {
                        var decoded_buffer = data.toString();
                        if (decoded_buffer.length > 0) {
                            httpRes.json(JSON.parse(data));
                        } else {
                            httpRes.json(JSON.parse('[]'));
                        }
                    })
                });
                req.on('error', function(error) {
                    //console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });
                req.write(cope);
                req.end();
            }
        });

    } catch (error) {
        logger.log('error', 'exception caught while in saveSearch');
    }

});

app.post('/updatePartnerConfiguration/:id', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    var cope = JSON.stringify(httpReq.body);
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerConfigId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/editPartnerConfig/' + partnerConfigId + '?loggedUser=' + logged_user_id,
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });
            req.write(cope);
            req.end();
        }
    });
});

app.post('/deletePartnerConfig/:id', function(httpReq, httpRes) {
    var sessionId = httpReq.sessionID;
    client.hgetall(sessionId, function(error, session) {
        if (error)
            return error;
        if (session != null) {
            var logged_user_id = session.userId;
            var partnerConfigId = httpReq.params.id;

            var request_options = {
                host: service_ip,
                port: admin_port,
                path: '/manage-admin-service/deletePartnerConfig/' + partnerConfigId + '?loggedUser=' + logged_user_id,
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }

            };

            var req = http.request(request_options, function(res) {
                res.setEncoding('utf8');
                var data = "";
                res.on('data', function(reply) {
                    data += reply;
                });
                res.on('end', function() {
                    var decoded_buffer = data.toString();
                    if (decoded_buffer.length > 0) {
                        httpRes.json(JSON.parse(data));
                    } else {
                        httpRes.json(JSON.parse('[]'));
                    }
                })

                res.on('error', function(error) {
                    console.log(error);
                    httpRes.json(JSON.parse('[]'));
                });

            });

            req.end();
        }
    });
});

//ADDED FOR GDS CONFIGURATION END

/*app.use(function (req, res, next) {
    res.redirect('/#/error')
});
*/
/*
var DB = require('./javascripts/db');

function count (MongoDBURI, collectionName) {

	var database = new DB;

	database.connect(MongoDBURI)
	.then(
	
		function() {
			// Successfully connected to the database
			// Make the database call and pass the returned promise to the next stage
			return database.countDocuments(collectionName);
		},
		function(err) {
			// DB connection failed, add context to the error and throw it (it will be
			// converted to a rejected promise
			throw("Failed to connect to the database: " + err);
		})
	// The following `.then` clause uses the promise returned by the previous one.
	.then(
		function(count) {
			// Successfully counted the documents
			console.log(count + " documents");
			database.close();
		},
		function(err) {
			// Could have got here by either `database.connect` or `database.countDocuments`
			// failing
			console.log("Failed to count the documents: " + err);
			database.close();
		})
}*/

//count("mongodb://172.16.3.24:27017/manage_dev", "simples");
eval(fs.readFileSync('server-config.js')+'');

//app.listen(config.manage_port, function () {});
app.use(bodyParser.urlencoded({ extended: true, limit : '50mb' }));
app.use(bodyParser.json({limit : '50mb'}));
var MongoClient = require('mongodb').MongoClient;
//var url = "mongodb://devtest:testdev@172.16.1.24:27017/manage_dev";


var socket = require('socket.io');

var appNoti = express(); 
//var io = require('socket.io')(server);
//Added by shamsheer
var io = require('socket.io').listen(server);
server.listen(config.manage_port);
var mubsub = require('mubsub');

var clientNoti = mubsub(config.dburl);
var channel = clientNoti.channel('tNf');

var subscription = channel.subscribe('document' ,function (doc){//console.log('Inserted : '+doc.userId);
io.sockets.emit(doc.userId, doc);});

app.get('/Drm_setting.aspx', function (httpReq, httpRes) {
	     httpRes.render('drm.html',{drm:httpReq.query.File_id});
});


app.get('/watermarkservice/Drm_setting.aspx', function(httpReq, httpRes) {
    httpRes.render('watermark.html', { watermarkId: httpReq.query.File_id });
});


process.on('uncaughtException', function (err) {
	  console.log('Caught exception: ', err);
	});