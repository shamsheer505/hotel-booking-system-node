/**
 * 
 */
var options = {
 key: fs.readFileSync('ca.key'),
 //cert: fs.readFileSync('cMSSL.crt'),
 ca: fs.readFileSync('ca.crt'),
 //rsa: fs.readFileSync('ca.crt'),
  passphrase: "c$@cl55@248"
};
//var server = https.createServer(options, app);
//app.listen(config.manage_port, function () {});

//Added by shamsheer
var server = spdy
  .createServer(options, app);
 // server.listen(config.manage_port);