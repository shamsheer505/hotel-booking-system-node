package com.codemantra.manage.metadata.model;

public class FileObj {
	String path;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	

}
