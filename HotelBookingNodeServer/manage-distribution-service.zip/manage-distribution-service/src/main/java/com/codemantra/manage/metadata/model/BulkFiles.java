package com.codemantra.manage.metadata.model;

import java.io.File;

public class BulkFiles {

	private String filePath;
	private long fileSize;
	private boolean fileStatus;
	private String fileStatusMessage;
	private String convertedFileSize;
	private File file;
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public boolean isFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(boolean fileStatus) {
		this.fileStatus = fileStatus;
	}
	public String getFileStatusMessage() {
		return fileStatusMessage;
	}
	public void setFileStatusMessage(String fileStatusMessage) {
		this.fileStatusMessage = fileStatusMessage;
	}
	public String getConvertedFileSize() {
		return convertedFileSize;
	}
	public void setConvertedFileSize(String convertedFileSize) {
		this.convertedFileSize = convertedFileSize;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	
}
