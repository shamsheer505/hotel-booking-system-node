/**
 * 
 */
package com.codemantra.manage.bsr.model;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.model
 *         Updated On: 19-Jan-2018
 */
public class StatusMailVO {

	private String isbn;

	private String title;

	private String author;

	private String partner;

	private String format;

	private String priority;

	private String status;

	private String distributionPreflightStatus;

	private String businessRuleStatus;

	private String remarks;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getDistributionPreflightStatus() {
		return distributionPreflightStatus;
	}

	public void setDistributionPreflightStatus(String distributionPreflightStatus) {
		this.distributionPreflightStatus = distributionPreflightStatus;
	}

	public String getBusinessRuleStatus() {
		return businessRuleStatus;
	}

	public void setBusinessRuleStatus(String businessRuleStatus) {
		this.businessRuleStatus = businessRuleStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
