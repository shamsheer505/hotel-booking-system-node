/**
 * 
 */
package com.codemantra.manage.bsr.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.query.Criteria;

import com.codemantra.manage.bsr.entity.AccountEntity;
import com.codemantra.manage.bsr.entity.BlockTitlesEntity;
import com.codemantra.manage.bsr.entity.BrEntity;
import com.codemantra.manage.bsr.entity.TransactionEntity;
import com.codemantra.manage.bsr.entity.DefaultMailGroup;
import com.codemantra.manage.bsr.entity.ManageConfigEntity;
import com.codemantra.manage.bsr.entity.MetaDataFieldsEntity;
import com.codemantra.manage.bsr.entity.MstatusEntity;
import com.codemantra.manage.bsr.entity.PartnerEntity;
import com.codemantra.manage.bsr.entity.ProductMapEntity;
import com.codemantra.manage.bsr.entity.TDistribution;
import com.codemantra.manage.bsr.entity.TScheduleRunTime;
import com.codemantra.manage.bsr.entity.TrnFromatEntity;

/**
 * @author Y V Bharath Prasanna
 *
 */
public interface BusinessRuleDao {

	public List<BrEntity> getPreflightData();

	public List<BrEntity> getDistributionBrData();

	public boolean updateDistributionData(List<Criteria> criterias, Map<String, Object> operations,
			List<PartnerEntity> partners, boolean eligible, Date lastRun);

	public MetaDataFieldsEntity getReferencePathByDisplayName(String displayName);

	public List<TrnFromatEntity> getAllFormats();

	public List<PartnerEntity> getAllPartners();

	public ManageConfigEntity getConfigDataById(String id);

	public AccountEntity getAccountById(String id);

	public List<PartnerEntity> verifyPartnerById(List<String> partnerIds);

	public DefaultMailGroup getMailData(String mailName);

	public MetaDataFieldsEntity getReferencePathById(String id);

	public MetaDataFieldsEntity getReferencePathByFieldName(String fieldName);

	public List<MetaDataFieldsEntity> getAllMetadataFields();

	public List<BrEntity> getBrEntityDataByType(String ruleType);

	public boolean saveTransactionData(List<TransactionEntity> transactionEntities);

	public boolean checkTransaction(String isbn, String formatId, String partnerId);

	public List<TransactionEntity> getTransactionByIFP(String isbn, List<String> formatIds, String partnerId);

	public boolean checkFormatTransaction(String isbn, String formatId, String partnerId, Date modifiedOn);

	public List<MstatusEntity> getMStatusByType(String type);

	public boolean deleteEliglibleData();

	public boolean processPreflight(List<Criteria> criterias, BrEntity entity);

	public boolean saveTransactionDist(List<TDistribution> distEntity);
	
	public boolean removeEligibleTitleData(List<String> isbns, String partnerId);
	
	public TScheduleRunTime getLastRun(String mailName);
	
	public boolean updateLastRuntime(TScheduleRunTime runTime);
	
	public List<ProductMapEntity> getAllPrdMa();
	
	public void updateAsset();
	
	public List<BlockTitlesEntity> getBlockTitlesEntities(List<String> isbns, String partnerId);
	
	public boolean updateBusinessRuleById(String id);
}
