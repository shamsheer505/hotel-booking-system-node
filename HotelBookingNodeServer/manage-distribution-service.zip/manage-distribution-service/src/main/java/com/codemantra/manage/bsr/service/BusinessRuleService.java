package com.codemantra.manage.bsr.service;

import com.codemantra.manage.bsr.model.APIResponse;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.service
 *         Updated On: 02-Nov-2017
 */
public interface BusinessRuleService {

	public APIResponse<Object> placeDiststributionRequest(boolean isScheduled);

}
