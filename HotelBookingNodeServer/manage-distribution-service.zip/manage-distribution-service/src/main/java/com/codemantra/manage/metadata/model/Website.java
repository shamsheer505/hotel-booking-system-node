/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/


package com.codemantra.manage.metadata.model;

import java.util.List;

public class Website
{
	public List<String> WebsiteDescription;

	public String WebsiteLink;

	public String WebsiteRole;

	public List<String> getWebsiteDescription() {
		return WebsiteDescription;
	}

	public void setWebsiteDescription(List<String> websiteDescription) {
		WebsiteDescription = websiteDescription;
	}

	public String getWebsiteLink() {
		return WebsiteLink;
	}

	public void setWebsiteLink(String websiteLink) {
		WebsiteLink = websiteLink;
	}

	public String getWebsiteRole() {
		return WebsiteRole;
	}

	public void setWebsiteRole(String websiteRole) {
		WebsiteRole = websiteRole;
	}

		
}
