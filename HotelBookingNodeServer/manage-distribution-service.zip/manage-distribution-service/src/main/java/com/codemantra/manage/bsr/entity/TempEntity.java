/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author Bharath Prasanna Y V
 * Package Name: com.codemantra.manage.bsr.entity
 * Updated On:  14-Jun-2018
 */
@Document(collection = "ASSET_Format_DIFF_1")
public class TempEntity {

	@Id
	private String id;
	@Field("ISBN")
	private String isbn;
	@Field("assetId")
	private String assetId;
	@Field("fileId")
	private Integer fileId;
	@Field("formatId")
	private String formatId;
	@Field("objectkey")
	private String objectkey;
	@Field("folder")
	private String folder;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public String getObjectkey() {
		return objectkey;
	}
	public void setObjectkey(String objectkey) {
		this.objectkey = objectkey;
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = folder;
	}
	
	
}
