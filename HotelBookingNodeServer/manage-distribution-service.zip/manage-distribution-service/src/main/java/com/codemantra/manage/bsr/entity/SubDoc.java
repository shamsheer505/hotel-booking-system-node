/**
 * 
 */
package com.codemantra.manage.bsr.entity;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 21-Feb-2018
 */
public class SubDoc {

	private String field;
	private String condition;
	private Object value;

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
