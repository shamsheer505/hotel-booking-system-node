/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 15-May-2018
 */
@Document(collection = "tDistribution")
public class TDistribution {

	@Id
	private String id;

	@Field("isbn")
	private String isbn;

	@Field("title")
	private String title;

	@Field("userId")
	private String userId;

	@Field("transactionType")
	private String transactionType;

	@Field("transactionDate")
	private Date transactionDate;

	@Field("transactionStatus")
	private String transactionStatus;

	@Field("partnerId")
	private String partnerId;

	@Field("partnerName")
	private String partnerName;

	@Field("redistribution")
	private Boolean redistribution;

	@Field("priority")
	private String priority;

	@Field("format")
	private TrnFromatEntity format;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public Boolean getRedistribution() {
		return redistribution;
	}

	public void setRedistribution(Boolean redistribution) {
		this.redistribution = redistribution;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public TrnFromatEntity getFormat() {
		return format;
	}

	public void setFormat(TrnFromatEntity format) {
		this.format = format;
	}

}
