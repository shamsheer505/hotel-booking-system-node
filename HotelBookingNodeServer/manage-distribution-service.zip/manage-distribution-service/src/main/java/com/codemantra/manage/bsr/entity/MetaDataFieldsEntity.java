/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
25-07-2017			v1.0       	   	Bharath Prasanna Y V	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.bsr.entity;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "metaDataFieldConfig")
public class MetaDataFieldsEntity {

	@Field("metaDataFieldId")
	public int metaDataFieldId;

	@Field("metaDataFieldName")
	public String metaDataFieldName;

	@Field("displayOrderNo")
	public String displayOrderNo;

	@Field("groupId")
	public String groupId;

	@Field("fieldDisplayName")
	public String fieldDisplayName;

	@Field("fieldType")
	public String fieldType;

	@Field("valueType")
	public String valueType;

	@Field("jsonPath")
	public String jsonPath;

	@Field("jsonDbPath")
	public List<SubDoc> jsonDbPath;

	@Field("jsonType")
	public String jsonType;

	@Field("lookUp")
	public String lookUp;

	@Field("jsonPathIndex")
	public String jsonPathIndex;

	@Field("referenceTable")
	public String referenceTable;

	@Field("referencePath")
	public String referencePath;

	@Field("referenceValue")
	public String referenceValue;

	@Field("referenceValuePath")
	public String referenceValuePath;

	@Field("minlength")
	public String minlength;

	@Field("maxlength")
	public String maxlength;

	@Field("isDisplay")
	public Boolean isDisplay;

	@Field("isMandatory")
	public Boolean isMandatory;

	@Field("isActive")
	public Boolean isActive;

	@Field("isDeleted")
	public Boolean isDeleted;

	@Field("isEdit")
	public Boolean isEdit;

	@Field("jsonDbPathElement")
	public String jsonDbPathElement;

	@Field("jsonDbPathList")
	public String jsonDbPathList;

	@Field("jsonDbPathCondition")
	private List<SubDoc> jsonDbPathCondition;

	public int getMetaDataFieldId() {
		return metaDataFieldId;
	}

	public void setMetaDataFieldId(int metaDataFieldId) {
		this.metaDataFieldId = metaDataFieldId;
	}

	public String getMetaDataFieldName() {
		return metaDataFieldName;
	}

	public void setMetaDataFieldName(String metaDataFieldName) {
		this.metaDataFieldName = metaDataFieldName;
	}

	public String getDisplayOrderNo() {
		return displayOrderNo;
	}

	public void setDisplayOrderNo(String displayOrderNo) {
		this.displayOrderNo = displayOrderNo;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getFieldDisplayName() {
		return fieldDisplayName;
	}

	public void setFieldDisplayName(String fieldDisplayName) {
		this.fieldDisplayName = fieldDisplayName;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public String getJsonPath() {
		return jsonPath;
	}

	public void setJsonPath(String jsonPath) {
		this.jsonPath = jsonPath;
	}

	public List<SubDoc> getJsonDbPath() {
		return jsonDbPath;
	}

	public void setJsonDbPath(List<SubDoc> jsonDbPath) {
		this.jsonDbPath = jsonDbPath;
	}

	public String getJsonType() {
		return jsonType;
	}

	public void setJsonType(String jsonType) {
		this.jsonType = jsonType;
	}

	public String getLookUp() {
		return lookUp;
	}

	public void setLookUp(String lookUp) {
		this.lookUp = lookUp;
	}

	public String getJsonPathIndex() {
		return jsonPathIndex;
	}

	public void setJsonPathIndex(String jsonPathIndex) {
		this.jsonPathIndex = jsonPathIndex;
	}

	public String getReferenceTable() {
		return referenceTable;
	}

	public void setReferenceTable(String referenceTable) {
		this.referenceTable = referenceTable;
	}

	public String getReferencePath() {
		return referencePath;
	}

	public void setReferencePath(String referencePath) {
		this.referencePath = referencePath;
	}

	public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public String getReferenceValuePath() {
		return referenceValuePath;
	}

	public void setReferenceValuePath(String referenceValuePath) {
		this.referenceValuePath = referenceValuePath;
	}

	public String getMinlength() {
		return minlength;
	}

	public void setMinlength(String minlength) {
		this.minlength = minlength;
	}

	public String getMaxlength() {
		return maxlength;
	}

	public void setMaxlength(String maxlength) {
		this.maxlength = maxlength;
	}

	public Boolean getIsDisplay() {
		return isDisplay;
	}

	public void setIsDisplay(Boolean isDisplay) {
		this.isDisplay = isDisplay;
	}

	public Boolean getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(Boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean getIsEdit() {
		return isEdit;
	}

	public void setIsEdit(Boolean isEdit) {
		this.isEdit = isEdit;
	}

	public String getJsonDbPathElement() {
		return jsonDbPathElement;
	}

	public void setJsonDbPathElement(String jsonDbPathElement) {
		this.jsonDbPathElement = jsonDbPathElement;
	}

	public String getJsonDbPathList() {
		return jsonDbPathList;
	}

	public void setJsonDbPathList(String jsonDbPathList) {
		this.jsonDbPathList = jsonDbPathList;
	}

	public List<SubDoc> getJsonDbPathCondition() {
		return jsonDbPathCondition;
	}

	public void setJsonDbPathCondition(List<SubDoc> jsonDbPathCondition) {
		this.jsonDbPathCondition = jsonDbPathCondition;
	}

	@Override
	public String toString() {
		return "MetaDataFieldsEntity [metaDataFieldId=" + metaDataFieldId + ", metaDataFieldName=" + metaDataFieldName
				+ ", displayOrderNo=" + displayOrderNo + ", groupId=" + groupId + ", fieldDisplayName="
				+ fieldDisplayName + ", fieldType=" + fieldType + ", valueType=" + valueType + ", jsonPath=" + jsonPath
				+ ", jsonDbPath=" + jsonDbPath + ", jsonType=" + jsonType + ", lookUp=" + lookUp + ", jsonPathIndex="
				+ jsonPathIndex + ", referenceTable=" + referenceTable + ", referencePath=" + referencePath
				+ ", referenceValue=" + referenceValue + ", referenceValuePath=" + referenceValuePath + ", minlength="
				+ minlength + ", maxlength=" + maxlength + ", isDisplay=" + isDisplay + ", isMandatory=" + isMandatory
				+ ", isActive=" + isActive + ", isDeleted=" + isDeleted + ", isEdit=" + isEdit + ", jsonDbPathElement="
				+ jsonDbPathElement + ", jsonDbPathList=" + jsonDbPathList + ", jsonDbPathCondition="
				+ jsonDbPathCondition + "]";
	}

	
}
