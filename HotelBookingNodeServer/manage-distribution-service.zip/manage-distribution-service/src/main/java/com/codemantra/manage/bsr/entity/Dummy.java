/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 16-Jun-2018
 */
@Document(collection = "Dummy")
public class Dummy {

	private List<String> isbn;

	public List<String> getIsbn() {
		return isbn;
	}

	public void setIsbn(List<String> isbn) {
		this.isbn = isbn;
	}

	

}
