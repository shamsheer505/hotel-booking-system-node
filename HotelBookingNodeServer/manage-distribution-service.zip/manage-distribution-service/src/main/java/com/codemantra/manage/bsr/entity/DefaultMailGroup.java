/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 13-Dec-2017
 */
@Document(collection = "cDefaultMailGroup")
public class DefaultMailGroup {

	@Field("name")
	private String name;

	@Field("emailIds")
	private List<String> emailIds;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getEmailIds() {
		return emailIds;
	}

	public void setEmailIds(List<String> emailIds) {
		this.emailIds = emailIds;
	}

}
