package com.codemantra.manage.bsr.entity;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document(collection = "businessRule")
public class BusinessRuleEntity {
	@Id
	@JsonProperty
	private String id;

	@Field("ruleName")
	private String ruleName;

	@Field("description")
	private String description;

	@Field("customer")
	private String customer;

	@Field("account")
	private String account;

	@Field("metadataConditions")
	private List<Map<String, List<BrMetadata>>> metadataConditions;

	@Field("operations")
	private Map<String, BrMetadata> operations;

	@Field("createdBy")
	private String createdBy;

	@Field("createdOn")
	private Date createdOn;

	@Field("modifiedBy")
	private String modifiedBy;

	@Field("modifiedOn")
	private Date modifiedOn;

	@Field("isActive")
	private Boolean activeFlag;

	@Field("isDeleted")
	public Boolean isDelete;

	@Field("metadataPreflight")
	private Map<String, List<String>> metadataPreflight;

	@Field("trigger")
	private Integer trigger;
	
	@Field("dateToTrigger")
	private String dateToTrigger;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getTrigger() {
		return trigger;
	}

	public void setTrigger(Integer trigger) {
		this.trigger = trigger;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public List<Map<String, List<BrMetadata>>> getMetadataConditions() {
		return metadataConditions;
	}

	public void setMetadataConditions(List<Map<String, List<BrMetadata>>> metadataConditions) {
		this.metadataConditions = metadataConditions;
	}



	public Map<String, BrMetadata> getOperations() {
		return operations;
	}

	public void setOperations(Map<String, BrMetadata> operations) {
		this.operations = operations;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public Boolean getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Boolean isDelete) {
		this.isDelete = isDelete;
	}

	public Map<String, List<String>> getMetadataPreflight() {
		return metadataPreflight;
	}

	public void setMetadataPreflight(Map<String, List<String>> metadataPreflight) {
		this.metadataPreflight = metadataPreflight;
	}

	public String getDateToTrigger() {
		return dateToTrigger;
	}

	public void setDateToTrigger(String dateToTrigger) {
		this.dateToTrigger = dateToTrigger;
	}

}
