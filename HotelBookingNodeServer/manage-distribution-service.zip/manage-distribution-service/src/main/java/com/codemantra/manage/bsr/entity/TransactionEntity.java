package com.codemantra.manage.bsr.entity;

import java.util.Date;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "transactionEntity")
public class TransactionEntity {

	@Field("isbn")
	private String isbn;

	@Field("title")
	private String title;

	@Field("userId")
	private String userId;

	@Field("transactionType")
	private String transactionType;

	@Field("transactionDate")
	private Date transactionDate;

	@Field("transactionStatus")
	private String transactionStatus;

	@Field("partnerId")
	private String partnerId;

	@Field("priority")
	private String priority;

	@Field("isBusinessRule")
	private Boolean isBusinessRule;

	@Field("redistribution")
	private Boolean redistribution;

	@Field("format")
	private TrnFromatEntity format;

	@Field("completedOn")
	private Date completedOn;

	@Field("createdBy")
	private String createdBy;

	@Field("createdOn")
	private Date createdOn;

	@Field("modifiedBy")
	private String modifiedBy;

	@Field("modifiedOn")
	private Date modifiedOn;

	@Field("templateData")
	private Map<String, Object> templateData;

	@Field("PublicationDate")
	private String publicationDate;

	@Field("CountryOfPublication")
	private String countryOfPublication;

	@Field("ImprintName")
	private String imprintName;

	@Field("ProductCategory")
	private String productCategory;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Boolean getIsBusinessRule() {
		return isBusinessRule;
	}

	public void setIsBusinessRule(Boolean isBusinessRule) {
		this.isBusinessRule = isBusinessRule;
	}

	public TrnFromatEntity getFormat() {
		return format;
	}

	public void setFormat(TrnFromatEntity format) {
		this.format = format;
	}

	public Date getCompletedOn() {
		return completedOn;
	}

	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Map<String, Object> getTemplateData() {
		return templateData;
	}

	public void setTemplateData(Map<String, Object> templateData) {
		this.templateData = templateData;
	}

	public String getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getCountryOfPublication() {
		return countryOfPublication;
	}

	public void setCountryOfPublication(String countryOfPublication) {
		this.countryOfPublication = countryOfPublication;
	}

	public String getImprintName() {
		return imprintName;
	}

	public void setImprintName(String imprintName) {
		this.imprintName = imprintName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Boolean getRedistribution() {
		return redistribution;
	}

	public void setRedistribution(Boolean redistribution) {
		this.redistribution = redistribution;
	}

}
