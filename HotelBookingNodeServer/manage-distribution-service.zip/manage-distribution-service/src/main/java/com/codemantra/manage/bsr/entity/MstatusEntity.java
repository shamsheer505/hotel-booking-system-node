/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 03-Apr-2018
 */
@Document(collection = "mStatus")
public class MstatusEntity {

	private String code;
	private String description;
	private String type;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
