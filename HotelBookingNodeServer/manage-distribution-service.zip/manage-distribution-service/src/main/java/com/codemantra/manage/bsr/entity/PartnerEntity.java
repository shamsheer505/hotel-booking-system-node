package com.codemantra.manage.bsr.entity;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "mPartner")
public class PartnerEntity {

	@Field("partnerId")
	private String partnerId;

	@Field("accountId")
	private String accountId;

	@Field("partnerTypeId")
	private String partnerTypeId;

	@Field("partnerName")
	private String partnerName;

	@Field("channelName")
	private String channelName;

	@Field("formatId")
	private List<String> formatIds;

	@Field("emailId")
	private String emailId;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getPartnerTypeId() {
		return partnerTypeId;
	}

	public void setPartnerTypeId(String partnerTypeId) {
		this.partnerTypeId = partnerTypeId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public List<String> getFormatIds() {
		return formatIds;
	}

	public void setFormatIds(List<String> formatIds) {
		this.formatIds = formatIds;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
