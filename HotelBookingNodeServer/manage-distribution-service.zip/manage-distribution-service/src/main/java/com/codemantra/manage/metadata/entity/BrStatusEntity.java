/**
 * 
 */
package com.codemantra.manage.metadata.entity;

import java.util.Date;
import java.util.List;

/**
 * @author Bharath Prasanna Y V Package Name:
 *         com.codemantra.manage.metadata.entity Updated On: 06-Mar-2018
 */
public class BrStatusEntity {

	private String code;
	private boolean status;
	private Date modifiedOn;
	private String partnerId;
	private String parentId;
	private List<String> remarks;
	private Boolean isParent;
	private List<String> associateIds;
	private String partnerTypeId;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public List<String> getRemarks() {
		return remarks;
	}

	public void setRemarks(List<String> remarks) {
		this.remarks = remarks;
	}

	public Boolean getIsParent() {
		return isParent;
	}

	public void setIsParent(Boolean isParent) {
		this.isParent = isParent;
	}

	public List<String> getAssociateIds() {
		return associateIds;
	}

	public void setAssociateIds(List<String> associateIds) {
		this.associateIds = associateIds;
	}

	public String getPartnerTypeId() {
		return partnerTypeId;
	}

	public void setPartnerTypeId(String partnerTypeId) {
		this.partnerTypeId = partnerTypeId;
	}

}
