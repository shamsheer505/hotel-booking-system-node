/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.metadata.model;

import java.util.Date;
import java.util.List;

public class CDCMetaData {
	
	public String Id;
	
	public List<CDCMetaDataDetails> cdcMetaDataDetails;
	
	public List<String> modifiedFields;
	
	public Date modifiedOn;
	
	public String modifiedBy;
	
	public String updatedSource;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public List<CDCMetaDataDetails> getCdcMetaDataDetails() {
		return cdcMetaDataDetails;
	}

	public void setCdcMetaDataDetails(List<CDCMetaDataDetails> cdcMetaDataDetails) {
		this.cdcMetaDataDetails = cdcMetaDataDetails;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getUpdatedSource() {
		return updatedSource;
	}

	public void setUpdatedSource(String updatedSource) {
		this.updatedSource = updatedSource;
	}

	public List<String> getModifiedFields() {
		return modifiedFields;
	}

	public void setModifiedFields(List<String> modifiedFields) {
		this.modifiedFields = modifiedFields;
	}
}
