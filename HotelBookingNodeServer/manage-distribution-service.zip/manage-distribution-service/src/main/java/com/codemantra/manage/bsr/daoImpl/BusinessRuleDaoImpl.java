package com.codemantra.manage.bsr.daoImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.codemantra.exportEngine.ExportEngine;
import com.codemantra.manage.bsr.dao.BusinessRuleDao;
import com.codemantra.manage.bsr.entity.AccountEntity;
import com.codemantra.manage.bsr.entity.BlockTitlesEntity;
import com.codemantra.manage.bsr.entity.BrEntity;
import com.codemantra.manage.bsr.entity.BusinessRuleLog;
import com.codemantra.manage.bsr.entity.DefaultMailGroup;
import com.codemantra.manage.bsr.entity.Dummy;
import com.codemantra.manage.bsr.entity.EligibleTitleEntity;
import com.codemantra.manage.bsr.entity.ManageConfigEntity;
import com.codemantra.manage.bsr.entity.MetaDataFieldsEntity;
import com.codemantra.manage.bsr.entity.MstatusEntity;
import com.codemantra.manage.bsr.entity.PartnerEntity;
import com.codemantra.manage.bsr.entity.ProductMapEntity;
import com.codemantra.manage.bsr.entity.SubDoc;
import com.codemantra.manage.bsr.entity.TDistribution;
import com.codemantra.manage.bsr.entity.TScheduleRunTime;
import com.codemantra.manage.bsr.entity.TempEntity;
import com.codemantra.manage.bsr.entity.TransactionEntity;
import com.codemantra.manage.bsr.entity.TrnFromatEntity;
import com.codemantra.manage.bsr.entity.UserTemp;
import com.codemantra.manage.bsr.model.APIResponse;
import com.codemantra.manage.bsr.model.MailDetails;
import com.codemantra.manage.bsr.model.StatusMailVO;
import com.codemantra.manage.metadata.entity.AssetEntity;
import com.codemantra.manage.metadata.entity.BrStatusEntity;
import com.codemantra.manage.metadata.entity.ContributorEntity;
import com.codemantra.manage.metadata.entity.FileDetailEntity;
import com.codemantra.manage.metadata.entity.ImprintEntity;
import com.codemantra.manage.metadata.entity.ProductEntity;
import com.codemantra.manage.metadata.entity.ProductIdentifierEntity;
import com.codemantra.manage.metadata.entity.SubjectEntity;
import com.codemantra.manage.metadata.entity.TitleEntity;
import com.google.gson.Gson;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.mongodb.WriteResult;

@Repository
@Qualifier("businessRuleDao")
public class BusinessRuleDaoImpl implements BusinessRuleDao {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Value("${DISTRIBUTION_EMAIL_FROM}")
	public String DISTRIBUTION_EMAIL_FROM;

	@Value("${DISTRIBUTION_EMAIL_SUBJECT}")
	public String DISTRIBUTION_EMAIL_SUBJECT;

	@Value("${PREFLIGHT_EMAIL_SUBJECT}")
	public String PREFLIGHT_EMAIL_SUBJECT;

	@Value("${MANAGE_EMAIL_SERVICE_URL}")
	public String MANAGE_EMAIL_SERVICE_URL;

	@Value("${DISTRIBUTION_VIRTUAL_PATH}")
	public String DISTRIBUTION_VIRTUAL_PATH;

	@Value("${PRODUCTS_COLLECTION}")
	public String PRODUCTS_COLLECTION;

	@Value("${BLOOMSBURY_PARTNER}")
	public String BLOOMSBURY_PARTNER;

	@Value("${BUSINESS_RULE_USER}")
	public String BUSINESS_RULE_USER;

	@Value("${BRITISH_LIBRARY_PARTNERS}")
	public String BRITISH_LIBRARY_PARTNERS;

	private static final Logger logger = LoggerFactory.getLogger(BusinessRuleDaoImpl.class);

	@Override
	public List<BrEntity> getPreflightData() {
		List<BrEntity> entities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(Boolean.TRUE).and("isDeleted").is(Boolean.FALSE)
					.and("metadataPreflight").ne(null));
			entities = mongoTemplate.find(query, BrEntity.class);
		} catch (Exception e) {
			logger.error("Error occurred while retrieving preflight data" + e);
			throw e;
		}
		return entities;
	}

	@Override
	public List<BrEntity> getDistributionBrData() {
		List<BrEntity> entities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(Boolean.TRUE).and("isDeleted").is(Boolean.FALSE)
					.and("metadataConditions").exists(true).and("ruleType").is("Distribution"));
			entities = mongoTemplate.find(query, BrEntity.class);
			/*Query query = new Query();
			String part[] = {"P00180"};
			List<String> parts = Arrays.asList(part);
			query.addCriteria(Criteria.where("isActive").is(Boolean.TRUE).and("isDeleted").is(Boolean.FALSE)
					.and("metadataConditions").exists(true).and("ruleType").is("Distribution").and("partnerIds").in(parts));*/
			//entities = mongoTemplate.find(query, BrEntity.class);
		} catch (Exception e) {
			logger.error("Error occurred while retrieving distributions data" + e);
			throw e;
		}
		return entities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#updateDistributionData(java
	 * .util.List, java.util.Map, java.util.List)
	 */
	@Override
	public boolean updateDistributionData(List<Criteria> criterias, Map<String, Object> operations,
			List<PartnerEntity> partners, boolean eligible, Date lastRun) {
		boolean result = false;
		try {

			Query query = new Query();
			Criteria c = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			/*List<Criteria> crs = new ArrayList<>();
			Date d = new Date("09/27/2018");
			//2018-09-27
			crs.add(Criteria.where("Product.ProductForm").is("DG"));
			//crs.add(Criteria.where("Product.LastModifiedOn").lt(d));
			String [] fmts ={"F00082" , "F00081"}; 
			Criteria[] formatCriteria = new Criteria[] {
					Criteria.where("formatId").in( Arrays.asList(fmts)),
					Criteria.where("isDeleted").is(Boolean.FALSE),
					Criteria.where("formatStatus").is("11"),
					 };
			
			//Criteria.where("modifiedOn").lt(d)
			crs.add(Criteria.where("asset")
					.elemMatch(new Criteria().andOperator(formatCriteria)));
			Criteria c = new Criteria().andOperator(crs.toArray(new Criteria[crs.size()]));*/
			//query.addCriteria(Criteria.where("_id").is("9781472959843"));
			query.addCriteria(c);
			System.out.println("Initial Query: " + query);
			query.fields().include("_id");
			List<ProductEntity> entities = mongoTemplate.find(query, ProductEntity.class, PRODUCTS_COLLECTION);
			List<String> ids = new ArrayList<>();
			for (ProductEntity entity : entities) {
				ids.add(entity.getId());
			}

			String preflight = "";
			String approvalStatus = "";
			if (null != ids && ids.size() > 0) {
				for (Entry<String, Object> operations1 : operations.entrySet()) {
					if (operations1.getKey().contains("Pre-flight")) {
						List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1.getValue();
						for (Map<String, String> map : operationDa) {
							switch (map.get("value")) {
							case "Pass":
								preflight = "Pass";
								break;
							case "Fail":
								preflight = "Fail";
								break;
							default:
								preflight = "";
								break;
							}
						}

					} else if (operations1.getKey().equalsIgnoreCase("Approval Status")) {
						List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1.getValue();
						for (Map<String, String> map : operationDa) {
							approvalStatus = map.get("approvalId");
						}
					} /*
						 * else if
						 * (operations1.getKey().equalsIgnoreCase("Format")) {
						 * List<Map<String, Object>> operationDa =
						 * (List<Map<String, Object>>) operations1.getValue();
						 * for (Map<String, Object> map : operationDa) {
						 * formatIds = (List<String>) map.get("value"); } }
						 */
				}
				/*
				 * for (String formatId : formatIds) {
				 * System.out.println("Main " + formatId); if
				 * (formatIds.indexOf(formatId) == 0) {
				 * System.out.println("Hi : " + formatId); } else { int ind =
				 * formatIds.indexOf(formatId); boolean check = false; for
				 * (String formatIdCheck : formatIds) { if (ind ==
				 * formatIds.indexOf(formatIdCheck)) { break; } else {
				 * System.out.println("else: " + formatIdCheck); if (check) {
				 * break; } else { // make a call to verify format is available
				 * or // not if ("epu1b".equals(formatIdCheck)) { check = true;
				 * } else { check = false; } } } } if (!check) {
				 * System.out.println("In :" + formatId); } }
				 * 
				 * }
				 */

				if ("Pass".equals(preflight)) {
					for (PartnerEntity partner : partners) {
						result = processOperationData(operations, partner, ids, preflight, approvalStatus, eligible,
								lastRun);
					}
				} else if ("Fail".equals(preflight)) {
					for (PartnerEntity partner : partners) {
						result = processOperationData(operations, partner, ids, preflight, approvalStatus, eligible,
								lastRun);
					}
				} else {
					for (PartnerEntity partner : partners) {
						result = processOperationData(operations, partner, ids, preflight, approvalStatus, eligible,
								lastRun);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occurred while updating data in transaction table." + e.getMessage());
			throw e;
		}
		return result;
	}

	private boolean processOperationData(Map<String, Object> oppData, PartnerEntity partner, List<String> ids,
			String preflight, String approvalStatus, boolean eligible, Date lastRun) {
		boolean result = false;
		List<Criteria> operationCriterias = new ArrayList<>();
		List<String> formatNames = null;
		List<TrnFromatEntity> formatEntities = new ArrayList<>();
		List<ProductEntity> l1 = null;
		try {
			if (oppData.size() > 0 && null != oppData) {
				for (Entry<String, Object> operations1 : oppData.entrySet()) {
					if (operations1.getKey().equals("Uploaded On")) {

						List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1.getValue();
						for (Map<String, String> map : operationDa) {
							Calendar c1 = Calendar.getInstance();
							String s = map.get("value");
							String[] s1 = s.split("/");
							int month = new Integer(s1[1]);
							int year = new Integer(s1[2]);
							int day = new Integer(s1[0]);
							c1.set(year, month - 1, day);
							c1.set(year, month - 1, day, 00, 00, 00);
							Criteria[] uploadedByCriteria = null;
							switch (map.get("operator")) {
							case "=":
								Calendar c2 = Calendar.getInstance();
								c2.set(new Integer(s1[2]), month - 1, new Integer(s1[1]), 23, 59, 59);
								// operationCriterias.add();
								uploadedByCriteria = new Criteria[] {
										Criteria.where(null).is(null).andOperator(
												Criteria.where("uploadedOn").lt(c2.getTime()),
												Criteria.where("uploadedOn").gte(c1.getTime())),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "<>":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedOn").ne(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case ">":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedOn").lt(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "<":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedOn").lt(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "<=":
								uploadedByCriteria = new Criteria[] {
										Criteria.where("uploadedOn").lte(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case ">=":
								uploadedByCriteria = new Criteria[] {
										Criteria.where("uploadedOn").gte(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "Between":
								Calendar c21 = Calendar.getInstance();
								String s2 = map.get("value1");
								String[] s12 = s2.split("/");
								int month1 = new Integer(s12[1]);
								c21.set(new Integer(s12[2]), month1 - 1, new Integer(s12[0]), 23, 59, 59);
								uploadedByCriteria = new Criteria[] {
										Criteria.where(null).is(null).andOperator(
												Criteria.where("uploadedOn").lt(c21.getTime()),
												Criteria.where("uploadedOn").gte(c1.getTime())),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							default:
								Calendar c22 = Calendar.getInstance();
								c22.set(new Integer(s1[2]), month - 1, new Integer(s1[1]), 23, 59, 59);
								uploadedByCriteria = new Criteria[] {
										Criteria.where(null).is(null).andOperator(
												Criteria.where("uploadedOn").lt(c22.getTime()),
												Criteria.where("uploadedOn").gte(c1.getTime())),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							}
						}

					} else if (operations1.getKey().equals("Uploaded By")) {

						List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1.getValue();
						for (Map<String, String> map : operationDa) {
							Criteria[] uploadedByCriteria = null;
							switch (map.get("operator")) {
							case "=":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedBy").is(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "<>":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedBy").ne(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "In":
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedBy").in(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							case "Not in":
								uploadedByCriteria = new Criteria[] {
										Criteria.where("uploadedBy").nin(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							default:
								uploadedByCriteria = new Criteria[] { Criteria.where("uploadedBy").is(map.get("value")),
										Criteria.where("isDeleted").is(Boolean.FALSE) };
								operationCriterias.add(Criteria.where("asset")
										.elemMatch(new Criteria().andOperator(uploadedByCriteria)));
								break;
							}
						}
					} else if (operations1.getKey().equals("Format")) {
						List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1.getValue();
						List<TrnFromatEntity> formats1 = getAllFormats();
						List<String> formatIds = new ArrayList<>();
						for (Map<String, String> map : operationDa) {
							Object s = (Object) map.get("value");
							formatNames = (List<String>) s;
							System.out.println(formatNames);
							for (String string : formatNames) {
								for (TrnFromatEntity formatEntity : formats1) {
									if (string.trim().equals(formatEntity.getFormatId())) {
										formatIds.add(formatEntity.getFormatId().trim());
										formatEntities.add(formatEntity);
										break;
									}
								}
							}
							switch (map.get("operator")) {

							case "In":
								if ("".equals(approvalStatus)) {
									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").in(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE) };
									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));
								} else {
									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").in(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE),
											Criteria.where("formatStatus").is(approvalStatus) };
									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));

								}
								break;
							case "Not in":
								if ("".equals(approvalStatus)) {

									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").nin(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE) };

									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));
								} else {

									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").nin(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE),
											Criteria.where("formatStatus").is(approvalStatus) };
									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));
								}
								break;

							default:
								if ("".equals(approvalStatus)) {
									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").in(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE) };
									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));
								} else {
									Criteria[] formatCriteria = new Criteria[] {
											Criteria.where("formatId").in(formatNames),
											Criteria.where("isDeleted").is(Boolean.FALSE),
											Criteria.where("formatStatus").is(approvalStatus) };
									operationCriterias.add(Criteria.where("asset")
											.elemMatch(new Criteria().andOperator(formatCriteria)));

								}
								break;

							}
						}
					} else if (operations1.getKey().equals("Pre-flight")) {

						if ("Pass".equals(preflight)) {

							Criteria[] formatCriteria = new Criteria[] {
									Criteria.where("partnerId").is(partner.getPartnerId()),
									Criteria.where("status").is(Boolean.TRUE) };
							operationCriterias.add(Criteria.where("CustomFields.Preflight")
									.elemMatch(new Criteria().andOperator(formatCriteria)));
						} else if ("Fail".equals(preflight)) {
							Criteria[] formatCriteria = new Criteria[] {
									Criteria.where("partnerId").is(partner.getPartnerId()),
									Criteria.where("status").is(Boolean.FALSE) };
							operationCriterias.add(Criteria.where("CustomFields.Preflight")
									.elemMatch(new Criteria().andOperator(formatCriteria)));

						}

					}
				}
				operationCriterias.add(Criteria.where("_id").in(ids));
				Query queryOperations = new Query();
				Criteria oc = new Criteria()
						.andOperator(operationCriterias.toArray(new Criteria[operationCriterias.size()]));
				queryOperations.addCriteria(oc);
				System.out.println();
				System.out.println("Operational: " + queryOperations);
				l1 = mongoTemplate.find(queryOperations, ProductEntity.class, PRODUCTS_COLLECTION);
				if (l1.size() > 0) {
					if (eligible) {
						result = saveEligibleReportData(l1, formatEntities, partner);
					} else {
						result = addTransactionData(l1, formatEntities, partner, lastRun, approvalStatus);
					}
				}
			} else {
				Query query = new Query();
				query.addCriteria(Criteria.where("_id").in(ids).and("Product.isDeleted").is(Boolean.FALSE));
				l1 = mongoTemplate.find(query, ProductEntity.class, PRODUCTS_COLLECTION);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private boolean addTransactionData(List<ProductEntity> productEntities, List<TrnFromatEntity> formats,
			PartnerEntity partner, Date lastRun, String formatStatus) {
		boolean result = false;
		List<StatusMailVO> statusList = new ArrayList<>();
		System.out.println("Distribution Isbn size: " + productEntities.size());
		try {
			List<String> isbns = productEntities.stream().filter(pe->null!= pe.getId()).map(pe->pe.getId()).collect(Collectors.toList());
			List<BlockTitlesEntity> blockTitles = getBlockTitlesEntities(isbns, partner.getPartnerId());
			List<String> blockedIsns = blockTitles.stream().map(bt->bt.getIsbn()).collect(Collectors.toList());
			List<BusinessRuleLog> brLogs = new ArrayList<>();
			StatusMailVO mailVo = null;
			List<String> productIds = new ArrayList<>();
			TransactionEntity brTrnEntity = null;
			List<TransactionEntity> trEntities = new ArrayList<>();
			List<TDistribution> trnDistEntities = new ArrayList<>();
			for (ProductEntity productEntity : productEntities) {
				if(null!=blockedIsns && blockedIsns.size()>0 && blockedIsns.contains(productEntity.getId())){
					continue;
				}
				BusinessRuleLog brLog = new BusinessRuleLog();
				brLog.setRuleType("Distribution");
				Date today = Calendar.getInstance().getTime();
				productIds.add(productEntity.getId());
				brTrnEntity = new TransactionEntity();
				mailVo = new StatusMailVO();
				List<TitleEntity> tiles = productEntity.getProduct().getTitle();
				for (TitleEntity titleEntity : tiles) {
					if ("01".equals(titleEntity.getTitleType())) {
						brTrnEntity.setTitle(titleEntity.getTitleText());
						mailVo.setTitle(titleEntity.getTitleText());
						break;
					}
				}
				String isbn = "";
				List<ProductIdentifierEntity> prodIdent = productEntity.getProduct().getProductIdentifier();
				for (ProductIdentifierEntity productIdentifierEntity : prodIdent) {
					if ("15".equals(productIdentifierEntity.getProductIDType())) {
						isbn = productIdentifierEntity.getIdValue();

						break;
					}
				}
				brLog.setIsbn(isbn);
				String author = "";
				for (ContributorEntity contributor : productEntity.getProduct().getContributor()) {
					if ("".equals(author)) {
						author = contributor.getPersonName();
					} else {
						author += ", " + contributor.getPersonName();
					}

				}
				brTrnEntity.setIsbn(isbn);
				mailVo.setIsbn(isbn);
				brTrnEntity.setRedistribution(false);
				if (null != productEntity.getProduct().getCountryOfPublication())
					brTrnEntity.setCountryOfPublication(productEntity.getProduct().getCountryOfPublication());
				if (null != productEntity.getProduct().getPublicationDate())
					brTrnEntity.setPublicationDate(productEntity.getProduct().getPublicationDate());
				if (null != productEntity.getProduct().getSubject()
						&& productEntity.getProduct().getSubject().size() > 0) {
					for (SubjectEntity subject : productEntity.getProduct().getSubject()) {
						if ("24".equals(subject.getSubjectSchemeIdentifier())
								&& "Product Category".equals(subject.getSubjectSchemeName())) {
							brTrnEntity.setProductCategory(subject.getSubjectCode());
							break;
						}
					}
				}
				if (null != productEntity.getProduct().getImprint()
						&& productEntity.getProduct().getImprint().size() > 0) {
					for (ImprintEntity imprint : productEntity.getProduct().getImprint()) {
						brTrnEntity.setImprintName(imprint.getImprintName());
						break;
					}
				}
				brLog.setPartnerName(partner.getPartnerName());
				brTrnEntity.setTransactionStatus("02");
				brTrnEntity.setTransactionDate(today);
				brTrnEntity.setCreatedBy(BUSINESS_RULE_USER);
				brTrnEntity.setCreatedOn(today);
				brTrnEntity.setModifiedBy(BUSINESS_RULE_USER);
				brTrnEntity.setModifiedOn(today);
				brTrnEntity.setUserId(BUSINESS_RULE_USER);
				brTrnEntity.setPartnerId(partner.getPartnerId());
				brTrnEntity.setIsBusinessRule(Boolean.TRUE);
				brTrnEntity.setPriority("Regular");
				mailVo.setPartner(partner.getPartnerName());
				List<AssetEntity> assets = productEntity.getAsset();
				String formatName = "";
				Date modifiedOn = null;
				String formatId = "";
				List<String> formatIds = new ArrayList<>();
				if (formats.size() > 0) {
					brTrnEntity.setTransactionType("DISTRIBUTION");
					for (TrnFromatEntity forma : formats) {
						formatIds.add(forma.getFormatId());
						boolean flag = false;
						for (AssetEntity assetEntity : assets) {
							if (assetEntity.getFormatId().equals(forma.getFormatId()) && !assetEntity.isDeleted()
									&& formatStatus.equals(assetEntity.getFormatStatus())) {
								// if (null != assetEntity.getModifiedOn() &&
								// assetEntity.getModifiedOn().after(lastRun)) {
								modifiedOn = assetEntity.getModifiedOn();
								formatName = forma.getFormatName();
								formatId = forma.getFormatId();
								brLog.setFormatId(formatId);
								brLog.setFormatName(formatName);
								brTrnEntity.setFormat(forma);
								flag = true;
								break;
								// }
							}

						}
						if (flag)
							break;
					}
					mailVo.setFormat(formatName);
				} else {
					brTrnEntity.setTransactionType("METADATA_DISTRIBUTION");
				}
				if (formats.size() > 0 && "".equals(formatId)) {
					continue;
				}

				Map<String, Object> trnTemplateData = new HashMap<>();
				trnTemplateData.put("[isbn]", isbn);
				trnTemplateData.put("[requested-on]", today);
				trnTemplateData.put("[format-name]", formatName);
				trnTemplateData.put("[partner-name]", partner.getPartnerName());
				trnTemplateData.put("[requested-by]", "Business Rule");
				brTrnEntity.setTemplateData(trnTemplateData);
				mailVo.setAuthor(author);
				mailVo.setPartner(partner.getPartnerName());
				mailVo.setStatus("Success");
				mailVo.setPriority("Regular");
				mailVo.setBusinessRuleStatus("Pass");
				mailVo.setDistributionPreflightStatus("Pass");
				String fId = formatId;
				List<TransactionEntity> transcData = getTransactionByIFP(isbn, formatIds, partner.getPartnerId());
				if (null != transcData && transcData.size() > 0) {
					List<TransactionEntity> td = transcData.stream()
							.filter(tr -> fId.equals(tr.getFormat().getFormatId())).collect(Collectors.toList());
					if (null != td && td.size() > 0) {
						TransactionEntity tt = td.get(0);
						if (null != modifiedOn) {

							if (modifiedOn.after(tt.getTransactionDate())) {
								System.out.println("RE: " + productEntity.getId());
								brTrnEntity.setRedistribution(true);
								brLog.setRedistributable(true);
							} else
								continue;
						}
					} else
						continue;
				}

				List<String> britishPartners = Arrays.asList(BRITISH_LIBRARY_PARTNERS.split(","));

				if (brTrnEntity.getRedistribution() && !britishPartners.contains(partner.getPartnerId())) {
					trEntities.add(brTrnEntity);
				} else if (!brTrnEntity.getRedistribution()) {
					trEntities.add(brTrnEntity);
				}
				statusList.add(mailVo);
				// System.out.println("New : "+productEntity.getId());
				TDistribution td = new TDistribution();
				BeanUtils.copyProperties(brTrnEntity, td);

				if ("DISTRIBUTION".equals(brTrnEntity.getTransactionType())) {
					td.setId(brTrnEntity.getIsbn() + "_" + formatId);
					brLog.setPartnerId(partner.getPartnerId());
					brLog.setPartnerTypeId(partner.getPartnerTypeId());
					brLog.setCode("Success");
					brLogs.add(brLog);
					List<BrStatusEntity> st = new ArrayList<>();
					/*if (null != productEntity.getCustomFields()) {
						if (null != productEntity.getCustomFields().get("Distribution")) {
							Object statusList1 = productEntity.getCustomFields().get("Distribution");
							List<LinkedHashMap<String, Object>> dataMap = (List<LinkedHashMap<String, Object>>) statusList1;
							
							for (LinkedHashMap<String, Object> linkedHashMap : dataMap) {
								BrStatusEntity brs = new BrStatusEntity();
								if (null != linkedHashMap.get("code"))
									brs.setCode(linkedHashMap.get("code").toString());
								if (null != linkedHashMap.get("partnerId"))
									brs.setPartnerId(linkedHashMap.get("partnerId").toString());
								if (null != linkedHashMap.get("modifiedOn"))
									brs.setModifiedOn((Date) linkedHashMap.get("modifiedOn"));
								if (null != linkedHashMap.get("status"))
									brs.setStatus((boolean) linkedHashMap.get("status"));
								if (null != linkedHashMap.get("partnerTypeId"))
									brs.setPartnerTypeId(linkedHashMap.get("partnerTypeId").toString());
								if (null != linkedHashMap.get("remarks"))
									brs.setRemarks((List<String>) linkedHashMap.get("remarks"));
								if (!partner.getPartnerId().equals(brs.getPartnerId()))
									st.add(brs);
							}
						}
					}*/
					BrStatusEntity brsNew = new BrStatusEntity();
					brsNew.setPartnerId(partner.getPartnerId());
					brsNew.setModifiedOn(new Date());
					brsNew.setPartnerTypeId(partner.getPartnerTypeId());
					brsNew.setStatus(true);
					brsNew.setCode("Yes");
					st.add(brsNew);					
					Update update = new Update();
					Query query = new Query();
					query.addCriteria(Criteria.where("_id").is(productEntity.getId()));
					update.set("CustomFields.Distribution", st);
					mongoTemplate.updateFirst(query, update, PRODUCTS_COLLECTION);
					
				} else {
					td.setId(brTrnEntity.getIsbn());

				}

				trnDistEntities.add(td);

			}

			if (null != trEntities && trEntities.size() > 0)
				mongoTemplate.insertAll(trEntities);

			if (null != trnDistEntities && trnDistEntities.size() > 0)
				saveTransactionDist(trnDistEntities);

			if (null != brLogs && brLogs.size() > 0)
				mongoTemplate.insertAll(brLogs);

			if (null != statusList && statusList.size() > 0 && !CollectionUtils.isEmpty(statusList)) {
				List<StatusMailVO> withFormat = statusList.stream().filter(s -> null != s.getFormat())
						.collect(Collectors.toList());
				sendMail(true, withFormat, partner.getPartnerName());

				List<StatusMailVO> withOutFormat = statusList.stream()
						.filter(s -> null == s.getFormat() || "".equals(s.getFormat())).collect(Collectors.toList());
				sendMail(false, withOutFormat, partner.getPartnerName());
			}
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable to update product data (or) insert trasaction data." + e.getMessage());
			throw e;
		}
		return result;
	}

	private boolean sendMail(boolean withFormat, List<StatusMailVO> mailData, String partnerName) {
		boolean result = false;
		try {
			List<String> keys = new ArrayList<>();
			keys.add("isbn");
			keys.add("title");
			keys.add("author");
			keys.add("partner");
			if (withFormat)
				keys.add("format");
			keys.add("priority");
			keys.add("status");
			keys.add("distributionPreflightStatus");
			keys.add("businessRuleStatus");

			MailDetails mailDetails = new MailDetails();
			mailDetails = new MailDetails();
			Map<String, Object> templateData = new HashMap<String, Object>();
			mailDetails.setEmail_from("donotreply@codemantra.com");
			DefaultMailGroup mailGrp = getMailData("Distribution");
			mailDetails.setToEmailIds(mailGrp.getEmailIds());
			mailDetails.setSubject(DISTRIBUTION_EMAIL_SUBJECT + " : " + partnerName);
			mailDetails.setCreatedBy(BUSINESS_RULE_USER);
			templateData.put("to", "");
			mailDetails.setTemplateData(templateData);
			String outPutFileName = BUSINESS_RULE_USER + new Date().getTime() + ".xlsx";
			String outPutFilePath = DISTRIBUTION_VIRTUAL_PATH + outPutFileName;
			List<String> attachFiles = new ArrayList<>();
			attachFiles.add(outPutFilePath);
			mailDetails.setAttachFiles(attachFiles);
			mailDetails.setTemplateName("distribution.ftl");
			System.out.println("outputpath: " + outPutFilePath);
			if (!CollectionUtils.isEmpty(mailData)) {
				try {
				ExportEngine.writeToFile(mailData, "xlsx", keys, outPutFilePath);
				RestTemplate restTemplate = new RestTemplate();
				APIResponse response1 = restTemplate.postForObject(MANAGE_EMAIL_SERVICE_URL, mailDetails,
						APIResponse.class);
				System.out.println(response1);
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
			result = true;
		} catch (Exception e) {
			logger.error("Error in send mail.");
			e.printStackTrace();
		}
		return result;

	}

	@Override
	public MetaDataFieldsEntity getReferencePathByDisplayName(String displayName) {
		MetaDataFieldsEntity fields = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("fieldDisplayName").is(displayName));
			fields = mongoTemplate.findOne(query, MetaDataFieldsEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive metadata field data by name." + e.getMessage());
			throw e;
		}
		return fields;
	}

	@Override
	public List<TrnFromatEntity> getAllFormats() {
		List<TrnFromatEntity> entities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(true).and("isDeleted").is(false));
			entities = mongoTemplate.find(query, TrnFromatEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive formats." + e.getMessage());
			throw e;
		}
		return entities;
	}

	@Override
	public List<PartnerEntity> getAllPartners() {
		List<PartnerEntity> entities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(true).and("isDeleted").is(false));
			entities = mongoTemplate.find(query, PartnerEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive partners." + e.getMessage());
			throw e;
		}
		return entities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getConfigDataById(java.lang
	 * .String)
	 */
	@Override
	public ManageConfigEntity getConfigDataById(String id) {
		ManageConfigEntity configEntity = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("_id").is(id));
			configEntity = mongoTemplate.findOne(query, ManageConfigEntity.class);
		} catch (Exception e) {
			logger.error("Unable to retrieve config data by id." + e.getMessage());
			throw e;
		}
		return configEntity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getAccountById(java.lang.
	 * String)
	 */
	@Override
	public AccountEntity getAccountById(String id) {
		AccountEntity accountEntity = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("accountId").is(id).and("isActive").is(Boolean.TRUE).and("isDeleted")
					.is(Boolean.FALSE));
			accountEntity = mongoTemplate.findOne(query, AccountEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive account data by Id." + e.getMessage());
			throw e;
		}
		return accountEntity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#verifyPartnerById(java.lang
	 * .String)
	 */
	@Override
	public List<PartnerEntity> verifyPartnerById(List<String> partnerIds) {
		List<PartnerEntity> partnerEntities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("partnerId").in(partnerIds).and("isActive").is(Boolean.TRUE)
					.and("isDeleted").is(Boolean.FALSE));
			partnerEntities = mongoTemplate.find(query, PartnerEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive partner data by partner Ids." + e.getMessage());
			throw e;
		}
		return partnerEntities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#getMailData(java.lang.
	 * String)
	 */
	@Override
	public DefaultMailGroup getMailData(String mailName) {
		DefaultMailGroup mailGrp = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(mailName));
			mailGrp = mongoTemplate.findOne(query, DefaultMailGroup.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive Default mailing group by name." + e.getMessage());
			throw e;
		}

		return mailGrp;
	}

	@Override
	public TScheduleRunTime getLastRun(String mailName) {
		TScheduleRunTime mailGrp = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(mailName));
			mailGrp = mongoTemplate.findOne(query, TScheduleRunTime.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive last run time by name." + e.getMessage());
			throw e;
		}

		return mailGrp;
	}

	@Override
	public MetaDataFieldsEntity getReferencePathById(String id) {
		MetaDataFieldsEntity fields = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("metaDataFieldId").is(id).and("isDeleted").is(Boolean.FALSE));
			fields = mongoTemplate.findOne(query, MetaDataFieldsEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive metadata field data by Id." + e.getMessage());
			throw e;
		}
		return fields;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getReferencePathByFieldName
	 * (java.lang.String)
	 */
	@Override
	public MetaDataFieldsEntity getReferencePathByFieldName(String fieldName) {
		MetaDataFieldsEntity fields = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("metaDataFieldName").is(fieldName).and("isDeleted").is(Boolean.FALSE));
			fields = mongoTemplate.findOne(query, MetaDataFieldsEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to retrive metadata field data by field name." + e.getMessage());
			throw e;
		}
		return fields;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#getAllMetadataFields()
	 */
	@Override
	public List<MetaDataFieldsEntity> getAllMetadataFields() {
		List<MetaDataFieldsEntity> metadataFields = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(Boolean.TRUE).and("isDeleted").is(Boolean.FALSE));
			metadataFields = mongoTemplate.find(query, MetaDataFieldsEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Error occurred while retrieving metadata fields data." + e);
		}
		return metadataFields;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getBrEntityDataByType(java.
	 * lang.String)
	 */
	@Override
	public List<BrEntity> getBrEntityDataByType(String ruleType) {
		logger.info("In Get Br Entity Br type  method");
		List<BrEntity> entities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isActive").is(Boolean.TRUE).and("isDeleted").is(Boolean.FALSE)
					.and("ruleType").is(ruleType));
			entities = mongoTemplate.find(query, BrEntity.class);
		} catch (Exception e) {
			logger.error("Error occurred while retrieving business rule data by Type: " + ruleType + "." + e);
			throw e;
		}
		return entities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#saveTransactionData(java.
	 * util.List)
	 */
	@Override
	public boolean saveTransactionData(List<TransactionEntity> transactionEntities) {
		boolean result = false;
		try {
			mongoTemplate.insert(transactionEntities);
			result = true;
		} catch (Exception e) {
			// TODO: handle exception
		}

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#checkTransaction(java.lang.
	 * String, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean checkTransaction(String isbn, String formatId, String partnerId) {
		boolean result = false;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isbn").is(isbn).and("format.formatId").is(formatId).and("partnerId")
					.is(partnerId).and("transactionType").is("DISTRIBUTION"));
			long count = mongoTemplate.count(query, "transactionEntity");
			if (count > 0) {
				result = true;
			}

		} catch (Exception e) {
			logger.error("In Dao: Unable to get transaction Count based on isbn, partnerid and formatid");
		}
		return result;
	}

	public boolean saveEligibleReportData(List<ProductEntity> productEntities, List<TrnFromatEntity> formats,
			PartnerEntity partner) {
		boolean result = false;
		List<EligibleTitleEntity> eligibileEntities = new ArrayList<>();
		try {
			List<MstatusEntity> st = getMStatusByType("FORMAT");
			for (ProductEntity productEntity : productEntities) {
				EligibleTitleEntity eligibielEntity = new EligibleTitleEntity();
				List<TitleEntity> tiles = productEntity.getProduct().getTitle();
				for (TitleEntity titleEntity : tiles) {
					if ("01".equals(titleEntity.getTitleType())) {
						eligibielEntity.setTitle(titleEntity.getTitleText());
						break;
					}
				}
				String isbn = "";
				List<ProductIdentifierEntity> prodIdent = productEntity.getProduct().getProductIdentifier();
				for (ProductIdentifierEntity productIdentifierEntity : prodIdent) {
					if ("15".equals(productIdentifierEntity.getProductIDType())) {
						isbn = productIdentifierEntity.getIdValue();
						break;
					}
				}

				String author = "";
				for (ContributorEntity contributor : productEntity.getProduct().getContributor()) {
					if ("".equals(author)) {
						author = contributor.getPersonName();
					} else {
						author = ", " + contributor.getPersonName();
					}

				}
				List<LinkedHashMap<String, Object>> dataMap = null;
				if (null != productEntity.getCustomFields()) {
					if (null != productEntity.getCustomFields().get("Division"))
						eligibielEntity.setDivision(productEntity.getCustomFields().get("Division").toString());
					if (null != productEntity.getCustomFields().get("Discount"))
						eligibielEntity.setDiscount(productEntity.getCustomFields().get("Discount").toString());
					if (null != productEntity.getCustomFields().get("Preflight")) {
						Object distStatusList = productEntity.getCustomFields().get("Preflight");
						dataMap = (List<LinkedHashMap<String, Object>>) distStatusList;
						for (LinkedHashMap<String, Object> linkedHashMap : dataMap) {
							if (null != linkedHashMap.get("partnerId")) {
								String partnerIdV = linkedHashMap.get("partnerId").toString();
								boolean status = false;
								if (partnerIdV == BLOOMSBURY_PARTNER) {
									if (null != linkedHashMap.get("status"))
										status = (boolean) linkedHashMap.get("status");
									if (status)
										eligibielEntity.setPreflightStatus("Pass");
									else
										eligibielEntity.setPreflightStatus("Fail");
								}
							}
						}

					}

				}
				if (null != productEntity.getProduct().getSubject()
						&& productEntity.getProduct().getSubject().size() > 0) {
					for (SubjectEntity subject : productEntity.getProduct().getSubject()) {
						if ("24".equals(subject.getSubjectSchemeIdentifier())
								&& "CP Custom Vendor".equals(subject.getSubjectSchemeName())) {
							eligibielEntity.setSelectedEbookVendors(subject.getSubjectHeadingText());
							break;
						}
					}
				}
				if (null != productEntity.getProduct().getSubject()
						&& productEntity.getProduct().getSubject().size() > 0) {
					for (SubjectEntity subject : productEntity.getProduct().getSubject()) {
						if ("24".equals(subject.getSubjectSchemeIdentifier())
								&& "Ebook Distribution Type".equals(subject.getSubjectSchemeName())) {
							eligibielEntity.setEdt(subject.getSubjectHeadingText());
							break;
						}
					}
				}
				eligibielEntity.setPartnerName(partner.getPartnerName());
				eligibielEntity.setFormatDetails(productEntity.getProduct().getProductForm());
				eligibielEntity.setEpubType(productEntity.getProduct().getePubType());
				eligibielEntity.setAuthor(author);
				eligibielEntity.setIsbn(isbn);
				if (null != productEntity.getProduct().getCountryOfPublication())
					eligibielEntity.setCountryOfPublication(productEntity.getProduct().getCountryOfPublication());
				if (null != productEntity.getProduct().getPublicationDate())
					eligibielEntity.setPublicationDate(productEntity.getProduct().getPublicationDate());
				if (null != productEntity.getProduct().getSubject()
						&& productEntity.getProduct().getSubject().size() > 0) {
					for (SubjectEntity subject : productEntity.getProduct().getSubject()) {
						if ("24".equals(subject.getSubjectSchemeIdentifier())
								&& "Product Category".equals(subject.getSubjectSchemeName())) {
							eligibielEntity.setProductCategory(subject.getSubjectCode());
							break;
						}
					}
				}
				if (null != productEntity.getProduct().getImprint()
						&& productEntity.getProduct().getImprint().size() > 0) {
					for (ImprintEntity imprint : productEntity.getProduct().getImprint()) {
						eligibielEntity.setImprintName(imprint.getImprintName());
						break;
					}
				}

				List<AssetEntity> assets = productEntity.getAsset();
				String formatId = "";
				if (formats.size() > 0) {
					for (TrnFromatEntity formatEntity : formats) {
						for (AssetEntity assetEntity : assets) {
							if (assetEntity.getFormatId().equals(formatEntity.getFormatId())) {
								eligibielEntity.setFormat(formatEntity.getFormatName());
								formatId = formatEntity.getFormatId();
								MstatusEntity metadataField = st.stream().filter(activ -> null != activ.getCode())
										.filter(activ -> activ.getCode().equals(assetEntity.getFormatStatus()))
										.collect(Collectors.toList()).get(0);
								if (null != metadataField)
									eligibielEntity.setApproval(metadataField.getDescription());
								break;
							}
						}
					}

				}
				if (null != eligibielEntity.getFormat()) {
					boolean check = checkTransaction(isbn, formatId, partner.getPartnerId());
					eligibielEntity.setRedistribute(check);
					eligibielEntity.setTransactionDate(new Date());
					eligibileEntities.add(eligibielEntity);
				}
			}
			// mongoTemplate.insert(eligibileEntities);
			mongoTemplate.insertAll(eligibileEntities);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();

		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getMStatusByType(java.lang.
	 * String)
	 */
	@Override
	public List<MstatusEntity> getMStatusByType(String type) {
		List<MstatusEntity> status = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("type").is(type).and("isActive").is(Boolean.TRUE).and("isDeleted")
					.is(Boolean.FALSE));
			status = mongoTemplate.find(query, MstatusEntity.class);
		} catch (Exception e) {
			logger.error("In Dao: Unable to get status by type" + e.getMessage());
			throw e;
		}
		return status;
	}

	private List<Criteria> processSubCriteria(List<SubDoc> subDocs) {
		List<Criteria> subCriterias = new ArrayList<>();
		for (SubDoc subDoc : subDocs) {
			switch (subDoc.getCondition()) {

			case "==":
				subCriterias.add(Criteria.where(subDoc.getField()).is(subDoc.getValue()));
				break;
			case "!=":
				subCriterias.add(Criteria.where(subDoc.getField()).ne(subDoc.getValue()));
				break;
			case "in":
				subCriterias.add(Criteria.where(subDoc.getField()).in((List) subDoc.getValue()));
				break;
			case "notIn":
				subCriterias.add(Criteria.where(subDoc.getField()).nin((List) subDoc.getValue()));
				break;
			}
		}

		return subCriterias;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#deleteEliglibleData()
	 */
	@Override
	public boolean deleteEliglibleData() {
		boolean result = false;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("_id").exists(true));
			WriteResult wResult = mongoTemplate.remove(query, EligibleTitleEntity.class);
			if (wResult.getN() > 0) {
				result = Boolean.TRUE;
			}
		} catch (Exception e) {
			logger.error("In Dao: Unable to remove eligible title transaction Data." + e.getMessage());
			throw e;
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#processPreflight(java.util.
	 * List, com.codemantra.manage.bsr.entity.BrEntity)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean processPreflight(List<Criteria> criterias, BrEntity entity) {
		System.out.println("In dao");
		boolean result = false;
		try {

			List<BusinessRuleLog> brLogs = new ArrayList<>();
			List<MetaDataFieldsEntity> metadataFields = null;
			Query query = new Query();
			Criteria c = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			query.addCriteria(c);
			System.out.println(query);
			long count = mongoTemplate.count(query, PRODUCTS_COLLECTION);
			int limit = 500;
			int runc = (int) (count / 500) + 1;
			for (int i = 0; i <= runc; i++) {

				query.skip((i * 500));
				query.limit(limit);

				System.out.println("Preflight: " + query.skip(i * 500).limit(limit));
				List<ProductMapEntity> products = mongoTemplate.find(query, ProductMapEntity.class,
						PRODUCTS_COLLECTION);
				List<PartnerEntity> allPartners = null;
				List<PartnerEntity> brPartners = null;
				if (null != products && products.size() > 0) {
					metadataFields = getAllMetadataFields();
					allPartners = getAllPartners();
					brPartners = allPartners.stream().filter(partner -> null != partner.getPartnerId())
							.filter(partner -> entity.getPartnerIds().contains(partner.getPartnerId()))
							.collect(Collectors.toList());
				}
				for (ProductMapEntity productMapEntity : products) {
					BusinessRuleLog brLog = new BusinessRuleLog();
					brLog.setIsbn(productMapEntity.getId());
					brLog.setRuleType("Pre-flight");
					String jsonString = new Gson().toJson(productMapEntity);
					DocumentContext docCtx = JsonPath.parse(jsonString);

					List<String> missingFields = new ArrayList<>();
					for (Entry<String, Object> prefData : entity.getMetadataPreflight().entrySet()) {
						List<Map<String, String>> n = (List<Map<String, String>>) prefData.getValue();
						for (Map<String, String> map2 : n) {
							if (null != map2.get("fieldName")) {
								List<MetaDataFieldsEntity> metadataFields1 = metadataFields.stream()
										.filter(activ -> null != activ.getMetaDataFieldName())
										.filter(activ -> activ.getMetaDataFieldName().equals(map2.get("fieldName")))
										.collect(Collectors.toList());
								MetaDataFieldsEntity metadataField = null;
								String val = "";
								if (null != metadataFields1 && metadataFields1.size() > 0) {
									metadataField = metadataFields1.get(0);
									JsonPath jsonPath = JsonPath.compile(metadataField.getJsonPath());
									Object obj = null;

									if (null != jsonPath.getPath()) {
										try {
											obj = docCtx.read(jsonPath);
											val = obj.toString().replace("[", "").replace("]", "").replace("\"", "");
										} catch (PathNotFoundException e) {
											// e.printStackTrace();
										}
									}
								}
								if ("".equals(val) || null == val) {
									if (null != metadataField)
										missingFields.add(metadataField.getFieldDisplayName());
								}
							}
						}

					}
					List<BrStatusEntity> prefStatus = new ArrayList<>();
					List<LinkedHashMap<String, Object>> dataMap = null;
					if (null != productMapEntity.getCustomFields()) {
						if (null != productMapEntity.getCustomFields().get("Preflight")) {
							Object prefStatusList = productMapEntity.getCustomFields().get("Preflight");
							dataMap = (List<LinkedHashMap<String, Object>>) prefStatusList;
							for (LinkedHashMap<String, Object> linkedHashMap : dataMap) {
								BrStatusEntity brs = new BrStatusEntity();
								if (null != linkedHashMap.get("code"))
									brs.setCode(linkedHashMap.get("code").toString());
								if (null != linkedHashMap.get("partnerId"))
									brs.setPartnerId(linkedHashMap.get("partnerId").toString());
								if (null != linkedHashMap.get("modifiedOn"))
									brs.setModifiedOn((Date) linkedHashMap.get("modifiedOn"));
								if (null != linkedHashMap.get("status"))
									brs.setStatus((boolean) linkedHashMap.get("status"));
								if (null != linkedHashMap.get("partnerTypeId"))
									brs.setPartnerTypeId(linkedHashMap.get("partnerTypeId").toString());
								if (null != linkedHashMap.get("remarks"))
									brs.setRemarks((List<String>) linkedHashMap.get("remarks"));
								if (entity.getPartnerIds().indexOf(brs.getPartnerId()) == -1)
									prefStatus.add(brs);
							}
						}
					}
					List<BrStatusEntity> finalStatus = new ArrayList<>();
					Date toDay = Calendar.getInstance().getTime();
					finalStatus.addAll(prefStatus);
					for (PartnerEntity part : brPartners) {
						BrStatusEntity br = new BrStatusEntity();
						br.setPartnerId(part.getPartnerId());
						br.setModifiedOn(toDay);
						brLog.setPartnerId(part.getPartnerId());
						brLog.setModifiedOn(toDay);
						br.setPartnerId(part.getPartnerId());
						if (missingFields.size() > 0) {
							br.setCode("No");
							br.setStatus(false);
							br.setRemarks(missingFields);
							brLog.setStatus(false);
							brLog.setCode("No");
							brLog.setRemarks(missingFields);
							System.out.println("id: " + productMapEntity.getId() + " missing: " + br.getRemarks());
						} else {
							br.setCode("Yes");
							br.setStatus(true);
							brLog.setStatus(true);
							brLog.setCode("Yes");
							System.out.println("id: " + productMapEntity.getId() + "status: " + br.isStatus());
						}
						finalStatus.add(br);
					}
					if (null != finalStatus)
						System.out.println("final size: " + finalStatus.size());

					Query q1 = new Query();
					q1.addCriteria(Criteria.where("_id").is(productMapEntity.getId()));
					Update update = new Update();
					update.set("CustomFields.Preflight", finalStatus);
					WriteResult wResult = mongoTemplate.updateMulti(q1, update, PRODUCTS_COLLECTION);
					brLogs.add(brLog);
				}
				if (null != brLogs && brLogs.size() > 0)
					mongoTemplate.insertAll(brLogs);

			}
			result = true;
			logger.info("Finished Preflight process.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#checkFormatTransaction(java
	 * .lang.String, java.lang.String, java.lang.String, java.util.Date)
	 */
	@Override
	public boolean checkFormatTransaction(String isbn, String formatId, String partnerId, Date modifiedOn) {
		boolean result = false;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isbn").is(isbn).and("format.formatId").is(formatId).and("partnerId")
					.is(partnerId).and("transactionType").is("DISTRIBUTION").and("transactionDate").gt(modifiedOn));
			long count = mongoTemplate.count(query, "transactionEntity");
			if (count > 0) {
				result = true;
			}

		} catch (Exception e) {
			logger.error("In Dao: Unable to get transaction Count based on isbn, partnerid and formatid");
		}
		return result;
	}

	@Override
	public boolean saveTransactionDist(List<TDistribution> distEntity) {
		boolean result = Boolean.FALSE;
		try {
			for (TDistribution tDistribution : distEntity) {
				mongoTemplate.save(tDistribution);
			}
			result = Boolean.TRUE;
		} catch (Exception e) {
			logger.error("In Dao: unable to save distribution Data." + e.getMessage());
			throw e;
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getTransactionByIFP(java.
	 * lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<TransactionEntity> getTransactionByIFP(String isbn, List<String> formatIds, String partnerId) {
		List<TransactionEntity> transactionEntities = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isbn").is(isbn).and("format.formatId").in(formatIds).and("partnerId")
					.is(partnerId).and("transactionType").is("DISTRIBUTION"));

			transactionEntities = mongoTemplate.find(query, TransactionEntity.class);

		} catch (Exception e) {
			logger.error("In Dao: Unable to get transaction Count based on isbn, partnerid and formatid");
		}
		return transactionEntities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#removeEligibleTitleData(
	 * java.util.List)
	 */
	@Override
	public boolean removeEligibleTitleData(List<String> isbns, String partnerId) {
		boolean result = Boolean.FALSE;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("isbn").in(isbns).and("partnerId").is(partnerId));
			WriteResult wResult = mongoTemplate.remove(query, EligibleTitleEntity.class);
			if (wResult.getN() > 0) {
				result = Boolean.TRUE;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable to remove eligible title data by isbn.");
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#updateLastRuntime(com.
	 * codemantra.manage.bsr.entity.TScheduleRunTime)
	 */
	@Override
	public boolean updateLastRuntime(TScheduleRunTime runTime) {
		boolean result = Boolean.FALSE;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is(runTime.getName()));
			Update update = new Update();
			update.set("lastRun", runTime.getLastRun());
			WriteResult wResult = mongoTemplate.updateFirst(query, update, TScheduleRunTime.class);
			if (wResult.getN() > 0) {
				result = Boolean.TRUE;
			} else {
				mongoTemplate.save(runTime);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable to update lastRun by name: " + runTime.getName() + "." + e.getMessage());
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#getAllPrdMa()
	 */
	/*
	 * @Override public List<ProductMapEntity> getAllPrdMa() { try { Query query
	 * = new Query();
	 * query.addCriteria(Criteria.where("asset").exists(true).and(
	 * "Product.isActive").is(true)); long count = mongoTemplate.count(query,
	 * PRODUCTS_COLLECTION); int limit = 1000; List<UserTemp> usrs =
	 * mongoTemplate.findAll(UserTemp.class); Map<String, String> userList = new
	 * HashMap<>(); for (UserTemp userTemp : usrs) {
	 * userList.put(userTemp.getMcpUserId(), userTemp.getUserId()); }
	 * List<String> isbns = new ArrayList<>(); int runc = (int) (count / 1000);
	 * for (int i = 0; i <= runc; i++) { query = new Query(); query.skip((i *
	 * 1000)); query.limit(limit);
	 * query.addCriteria(Criteria.where("asset").exists(true).and(
	 * "Product.isActive").is(true));
	 * 
	 * System.out.println(query); List<ProductMapEntity> mapD =
	 * mongoTemplate.find(query, ProductMapEntity.class, PRODUCTS_COLLECTION);
	 * for (ProductMapEntity productMapEntity : mapD) {
	 * System.out.println(productMapEntity.getId());
	 * isbns.add(productMapEntity.getId()); List<AssetEntity> getAssets =
	 * productMapEntity.getAsset(); List<AssetEntity> finalAsset = new
	 * ArrayList<>(); for (AssetEntity assetEntity : getAssets) {
	 * 
	 * List<FileDetailEntity> fild = new ArrayList<>();
	 * assetEntity.getFiledetails() .sort((FileDetailEntity f1, FileDetailEntity
	 * f2) -> f1.getFileId() - f2.getFileId()); // studentlist.sort((Student s1,
	 * Student // s2)->s1.getAge()-s2.getAge()); int fileCount = 1; for
	 * (FileDetailEntity fl : assetEntity.getFiledetails()) { if
	 * (fl.getLatestVersion()) { if (null != userList && userList.size() > 0) {
	 * System.out.println("old: " + fl.getCreatedBy()); String usrId =
	 * userList.get(fl.getCreatedBy()); System.out.println("new: " + usrId); if
	 * (null != usrId) { fl.setCreatedBy(usrId); fl.setUploadedBy(usrId); } }
	 * assetEntity.setUploadedBy(fl.getCreatedBy());
	 * assetEntity.setUploadedOn(fl.getCreatedOn());
	 * assetEntity.setModifiedBy(fl.getCreatedBy());
	 * assetEntity.setModifiedOn(fl.getCreatedOn());
	 * assetEntity.setSize(fl.getFileSize());
	 * fl.setVersion(assetEntity.getFiledetails().size()); } else {
	 * 
	 * List<String> l = Arrays.asList(fl.getObjectKey().split("/")); String s1 =
	 * Arrays.asList(l.get(1).split("_V")).get(1);
	 * 
	 * fl.setVersion(fileCount); fileCount++; }
	 * 
	 * fild.add(fl); } assetEntity.setFiledetails(fild);
	 * finalAsset.add(assetEntity); } productMapEntity.setAsset(finalAsset);
	 * mongoTemplate.save(productMapEntity, PRODUCTS_COLLECTION); } Dummy d =
	 * new Dummy(); d.setIsbn(isbns); mongoTemplate.insert(d, "Dummy"); }
	 * System.out.println("process Finished"); } catch (Exception e) {
	 * e.printStackTrace(); } return null; }
	 */

	@Override
	public List<ProductMapEntity> getAllPrdMa() {
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("Product.isActive").is(Boolean.TRUE));
			long count = mongoTemplate.count(query, PRODUCTS_COLLECTION);
			int limit = 1000;

			List<TempEntity> getTemp = mongoTemplate.findAll(TempEntity.class);
			int runc = (int) (count / 1000);
			for (int i = 0; i <= runc; i++) {
				query = new Query();
				query.addCriteria(Criteria.where("asset").exists(true).and("Product.isActive").is(true));
				query.skip((i * 1000));
				query.limit(limit);
				System.out.println(query);
				List<ProductMapEntity> mapD = mongoTemplate.find(query, ProductMapEntity.class, PRODUCTS_COLLECTION);
				for (ProductMapEntity productMapEntity : mapD) {
					System.out.println(productMapEntity.getId());
					List<TempEntity> inte = getTemp.stream().filter(as -> null != as.getIsbn())
							.filter(as -> as.getIsbn().equals(productMapEntity.getId())).collect(Collectors.toList());
					List<AssetEntity> getAssets = productMapEntity.getAsset();
					for (AssetEntity assetEntity : getAssets) {
						int randomAssetId = (int) (Math.random() * 9000) + 100000;

						assetEntity.setAssetId(String.valueOf(randomAssetId));
						List<FileDetailEntity> fild = new ArrayList<>();

						for (FileDetailEntity fl : assetEntity.getFiledetails()) {
							List<TempEntity> dd = inte.stream().filter(as -> as.getFileId().equals(fl.getFileId()))
									.collect(Collectors.toList());
							for (TempEntity assetEntity2 : dd) {
								int newValue = assetEntity2.getFileId();
								int OldValue = fl.getFileId();
								if (newValue == OldValue) {
									System.out.println("Old ObjKey: " + fl.getObjectKey());
									System.out.println("new ObjKey: " + assetEntity2.getObjectkey());
									fl.setObjectKey(assetEntity2.getObjectkey());
								}
							}
							fild.add(fl);
						}
						assetEntity.setFiledetails(fild);
					}
					productMapEntity.setAsset(getAssets);
					mongoTemplate.save(productMapEntity, PRODUCTS_COLLECTION);
				}

			}
			System.out.println("process Finished");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#updateAsset()
	 */
	@Override
	public void updateAsset() {

		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("asset").exists(true).and("Product.isActive").is(true));
			long count = mongoTemplate.count(query, PRODUCTS_COLLECTION);
			int limit = 1000;
			List<UserTemp> usrs = mongoTemplate.findAll(UserTemp.class);
			Map<String, String> userList = new HashMap<>();
			for (UserTemp userTemp : usrs) {
				userList.put(userTemp.getMcpUserId(), userTemp.getUserId());
			}
			List<String> isbns = new ArrayList<>();
			int runc = (int) (count / 1000);
			for (int i = 0; i <= runc; i++) {
				query = new Query();
				query.skip((i * 1000));
				query.limit(limit);
				query.addCriteria(Criteria.where("asset").exists(true).and("Product.isActive").is(true));
				System.out.println(query);
				List<ProductMapEntity> mapD = mongoTemplate.find(query, ProductMapEntity.class, PRODUCTS_COLLECTION);
				for (ProductMapEntity productMapEntity : mapD) {
					System.out.println(productMapEntity.getId());
					isbns.add(productMapEntity.getId());
					List<AssetEntity> getAssets = productMapEntity.getAsset();
					List<AssetEntity> finalAsset = new ArrayList<>();
					for (AssetEntity assetEntity : getAssets) {
						List<FileDetailEntity> fild = new ArrayList<>();
						for (FileDetailEntity fl : assetEntity.getFiledetails()) {
							if (fl.getLatestVersion()) {
								assetEntity.setUploadedBy(fl.getUploadedBy());
								assetEntity.setUploadedOn(fl.getUploadedOn());
								assetEntity.setModifiedBy(fl.getUploadedBy());
								assetEntity.setModifiedOn(fl.getUploadedOn());
								// assetEntity.setSize(fl.getFileSize());

							}

							fild.add(fl);
						}
						assetEntity.setFiledetails(fild);
						finalAsset.add(assetEntity);
					}
					productMapEntity.setAsset(finalAsset);
					mongoTemplate.save(productMapEntity, PRODUCTS_COLLECTION);
				}
				Dummy d = new Dummy();
				d.setIsbn(isbns);
				mongoTemplate.insert(d, "Dummy");

			}
			System.out.println("process Finished");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.codemantra.manage.bsr.dao.BusinessRuleDao#getBlockTitlesEntities(java
	 * .util.List, java.lang.String)
	 */
	@Override
	public List<BlockTitlesEntity> getBlockTitlesEntities(List<String> isbns, String partnerId) {
		List<BlockTitlesEntity> blockTitles = null;
		try {
			Query query = new Query();
			Date currentDate = new Date();
			List<Criteria> criterias = new ArrayList<>();
			criterias.add(Criteria.where("isbn").in(isbns));
			criterias.add(Criteria.where("partnerId").is(partnerId));
			criterias.add(Criteria.where("isActive").is(true));
			criterias.add(Criteria.where("isDeleted").is(false));
			criterias.add(Criteria.where("startDate").lte(currentDate));

			List<Criteria> endDateCriteria = new ArrayList<>();
			endDateCriteria.add(Criteria.where("endDate").exists(false));
			endDateCriteria.add(Criteria.where("endDate").gte(currentDate));

			criterias.add(new Criteria().orOperator(endDateCriteria.toArray(new Criteria[endDateCriteria.size()])));
			Criteria c = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));
			query.addCriteria(c);

			blockTitles = mongoTemplate.find(query, BlockTitlesEntity.class);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable to get block title data." + e.getMessage());
		}
		return blockTitles;
	}

	/* (non-Javadoc)
	 * @see com.codemantra.manage.bsr.dao.BusinessRuleDao#updateBusinessRuleById(java.lang.String)
	 */
	@Override
	public boolean updateBusinessRuleById(String id) {
		boolean result =Boolean.FALSE;
		try{
			Query query = new Query();
			query.addCriteria(Criteria.where("_id").is(id));
			Update update = new Update();
			update.set("isNew", Boolean.FALSE);
			WriteResult writeResult = mongoTemplate.updateMulti(query, update, BrEntity.class);
			if(writeResult.getN()>0){
				result = Boolean.TRUE;
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("In Dao: Unable update business rule by id."+e.getMessage());
		}
		return result;
	}

}
