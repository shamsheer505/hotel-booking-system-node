/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 30-Mar-2018
 */
@Document(collection = "tTodayEligibleTitles")
public class EligibleTitleEntity {

	private String isbn;
	private String title;
	private String author;
	private String publicationDate;
	private String countryOfPublication;
	private String productCategory;
	private String division;
	private String discount;
	private String imprintName;
	private String edt;
	private String preflightStatus;
	private String formatDetails;
	private String epubType;
	private String selectedEbookVendors;
	private String format;
	private String approval;
	private String partnerName;
	private Date transactionDate;
	private Boolean redistribute;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(String publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getCountryOfPublication() {
		return countryOfPublication;
	}

	public void setCountryOfPublication(String countryOfPublication) {
		this.countryOfPublication = countryOfPublication;
	}

	public String getEpubType() {
		return epubType;
	}

	public void setEpubType(String epubType) {
		this.epubType = epubType;
	}

	public String getImprintName() {
		return imprintName;
	}

	public void setImprintName(String imprintName) {
		this.imprintName = imprintName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getEdt() {
		return edt;
	}

	public void setEdt(String edt) {
		this.edt = edt;
	}

	public String getPreflightStatus() {
		return preflightStatus;
	}

	public void setPreflightStatus(String preflightStatus) {
		this.preflightStatus = preflightStatus;
	}

	public String getFormatDetails() {
		return formatDetails;
	}

	public void setFormatDetails(String formatDetails) {
		this.formatDetails = formatDetails;
	}

	public String getSelectedEbookVendors() {
		return selectedEbookVendors;
	}

	public void setSelectedEbookVendors(String selectedEbookVendors) {
		this.selectedEbookVendors = selectedEbookVendors;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Boolean getRedistribute() {
		return redistribute;
	}

	public void setRedistribute(Boolean redistribute) {
		this.redistribute = redistribute;
	}

}
