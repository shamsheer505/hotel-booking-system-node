/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.codemantra.manage.metadata.model.CDCMetaDataDetails;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 07-May-2018
 */
@Document(collection = "tCDCMetaData")
public class CDCEntity {

	@Field("referenceId")
	public String referenceId;

	@Field("lastModifiedOn")
	public Date lastModifiedOn;

	public List<CDCMetaDataDetails> cdcMetaDataDetails;

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public Date getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(Date lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public List<CDCMetaDataDetails> getCdcMetaDataDetails() {
		return cdcMetaDataDetails;
	}

	public void setCdcMetaDataDetails(List<CDCMetaDataDetails> cdcMetaDataDetails) {
		this.cdcMetaDataDetails = cdcMetaDataDetails;
	}

}
