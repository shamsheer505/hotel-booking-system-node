/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Field;

import com.codemantra.manage.metadata.entity.AssetEntity;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 11-Apr-2018
 */
public class ProductMapEntity {

	@Field("_id")
	private String Id;

	@Field("Product")
	private Map<String, Object> Product;

	@Field("asset")
	private List<AssetEntity> asset;

	@Field("CustomFields")
	private Map<Object, Object> CustomFields;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public Map<String, Object> getProduct() {
		return Product;
	}

	public void setProduct(Map<String, Object> product) {
		Product = product;
	}

	public List<AssetEntity> getAsset() {
		return asset;
	}

	public void setAsset(List<AssetEntity> asset) {
		this.asset = asset;
	}

	public Map<Object, Object> getCustomFields() {
		return CustomFields;
	}

	public void setCustomFields(Map<Object, Object> customFields) {
		CustomFields = customFields;
	}

}
