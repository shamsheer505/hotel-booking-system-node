/**********************************************************************************
Date          	Version       Modified By      			Description  
***********		********     *************				*************	
19-06-2017		v1.0       	 Bharath Prasanna Y V	  	Initial Version.
***********************************************************************************/
package com.codemantra.manage.bsr.model;

import java.util.List;
import java.util.Map;

public class MailDetails {

	private String id;
	private String to_email;
	private List<String> toEmailIds;
	private List<String> ccEmailIds;
	private String cc_email;
	private String toEmail;
	private String ccEmail;
	private String contents;
	private String subject;
	private String email_from;
	private String header;
	private String header_value;
	private String company_email;
	private Map<String, Object> templateData;
	private String templateName;
	private int updateFlag;
	private String createdBy;
	private List<String> attachFiles;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTo_email() {
		return to_email;
	}

	public void setTo_email(String to_email) {
		this.to_email = to_email;
	}

	public List<String> getToEmailIds() {
		return toEmailIds;
	}

	public void setToEmailIds(List<String> toEmailIds) {
		this.toEmailIds = toEmailIds;
	}

	public List<String> getCcEmailIds() {
		return ccEmailIds;
	}

	public void setCcEmailIds(List<String> ccEmailIds) {
		this.ccEmailIds = ccEmailIds;
	}

	public String getCc_email() {
		return cc_email;
	}

	public void setCc_email(String cc_email) {
		this.cc_email = cc_email;
	}

	public String getToEmail() {
		return toEmail;
	}

	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public String getCcEmail() {
		return ccEmail;
	}

	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEmail_from() {
		return email_from;
	}

	public void setEmail_from(String email_from) {
		this.email_from = email_from;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getHeader_value() {
		return header_value;
	}

	public void setHeader_value(String header_value) {
		this.header_value = header_value;
	}

	public String getCompany_email() {
		return company_email;
	}

	public void setCompany_email(String company_email) {
		this.company_email = company_email;
	}

	public Map<String, Object> getTemplateData() {
		return templateData;
	}

	public void setTemplateData(Map<String, Object> templateData) {
		this.templateData = templateData;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public int getUpdateFlag() {
		return updateFlag;
	}

	public void setUpdateFlag(int updateFlag) {
		this.updateFlag = updateFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<String> getAttachFiles() {
		return attachFiles;
	}

	public void setAttachFiles(List<String> attachFiles) {
		this.attachFiles = attachFiles;
	}

}
