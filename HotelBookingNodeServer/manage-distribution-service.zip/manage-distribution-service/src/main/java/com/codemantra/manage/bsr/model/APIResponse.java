/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
19-05-2017			v1.0       	   	 Senthil J	  		        Initial Version.
03-07-2017			v1.1       	   	 Shahid ul Islam	  		Added statusMessage field, for Multilingual Support
***********************************************************************************************************************/

package com.codemantra.manage.bsr.model;

public class APIResponse<T> {

	public enum ResponseCode {
		SUCCESS {
		    public String toString() {
		        return "200";
		    }
		},
 
		CREATED {
		    public String toString() {
		        return "201";
		    }
		},
		NOT_MODIFIED {
		    public String toString() {
		        return "304";
		    }
		},
		ERROR {
		    public String toString() {
		        return "500";
		    }
		},
		UNAUTHORIZED {
		    public String toString() {
		        return "401";
		    }
		},
		PRECONDITION_FAILED {
		    public String toString() {
		        return "412";
		    }
		}
		}
	
	private String code;
	private String status;
	private String statusMessage;
	private T data;
	public APIResponse(){}
	
	public APIResponse(String code, String status, String statusMessage, T data) {
		super();
		this.code = code;
		this.status = status;
		this.statusMessage = statusMessage;
		this.data = data;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
	
	

}
