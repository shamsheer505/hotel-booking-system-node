/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
13-06-2017			v1.0       	     Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.metadata.model;

public class MetaDataCDC {
		
	private String userId;
	
	private String isbn;
	
	
	private String fieldname;
	
	
}
