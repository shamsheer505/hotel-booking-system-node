/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.metadata.model;

import java.util.List;

public class AudienceRange
{
	public List<String> AudienceRangePrecisions;

	public String AudienceRangeQualifier;

	public List<String> AudienceRangeValues;

	public List<String> getAudienceRangePrecisions() {
		return AudienceRangePrecisions;
	}

	public void setAudienceRangePrecisions(List<String> audienceRangePrecisions) {
		AudienceRangePrecisions = audienceRangePrecisions;
	}

	public String getAudienceRangeQualifier() {
		return AudienceRangeQualifier;
	}

	public void setAudienceRangeQualifier(String audienceRangeQualifier) {
		AudienceRangeQualifier = audienceRangeQualifier;
	}

	public List<String> getAudienceRangeValues() {
		return AudienceRangeValues;
	}

	public void setAudienceRangeValues(List<String> audienceRangeValues) {
		AudienceRangeValues = audienceRangeValues;
	}

	
}
