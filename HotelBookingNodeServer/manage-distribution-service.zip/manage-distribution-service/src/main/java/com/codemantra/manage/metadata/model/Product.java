/**********************************************************************************************************************
RDate          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.metadata.model;

import java.util.List;

public class Product {
	
	private String id;
	
	private MetaData Product;

	private List<Assets> asset;

	public MetaData getProduct() {
		return Product;
	}

	public void setProduct(MetaData product) {
		Product = product;
	}

	public List<Assets> getAsset() {
		return asset;
	}

	public void setAsset(List<Assets> asset) {
		this.asset = asset;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
