package com.codemantra.manage.bsr.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mFormat")
public class TrnFromatEntity {

	private String formatName;

	private String formatId;

	private String fileName;

	public String getFormatName() {
		return formatName;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

	public String getFormatId() {
		return formatId;
	}

	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
