package com.codemantra.manage.bsr.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.codemantra.manage.bsr.dao.BusinessRuleDao;
import com.codemantra.manage.bsr.entity.AccountEntity;
import com.codemantra.manage.bsr.entity.AccountMappedField;
import com.codemantra.manage.bsr.entity.BrEntity;
import com.codemantra.manage.bsr.entity.ManageConfigEntity;
import com.codemantra.manage.bsr.entity.MetaDataFieldsEntity;
import com.codemantra.manage.bsr.entity.PartnerEntity;
import com.codemantra.manage.bsr.entity.SubDoc;
import com.codemantra.manage.bsr.entity.TScheduleRunTime;
import com.codemantra.manage.bsr.model.APIResponse;
import com.codemantra.manage.bsr.model.APIResponse.ResponseCode;
import com.codemantra.manage.bsr.service.BusinessRuleService;

/**
 * @author Bharath Prasanna Y V Package Name:
 *         com.codemantra.manage.bsr.serviceImpl Updated On: 02-Nov-2017
 */
@Service("businessRuleService")
public class BusinessRuleServiceImpl implements BusinessRuleService {

	@Autowired
	BusinessRuleDao businessRuleDao;

	@Value("${cornValue}")
	private String cornValue;

	@Value("${INITIAL_RUN}")
	private String INITIAL_RUN;

	public static boolean run = true;

	private static final Logger logger = LoggerFactory.getLogger(BusinessRuleServiceImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public APIResponse<Object> placeDiststributionRequest(boolean isScheduled) {
		logger.info("In Place Distribution method.");
		APIResponse<Object> response = new APIResponse<>();
		try {
			TScheduleRunTime runTime = businessRuleDao.getLastRun("Distribution");
			Date lastRun = null;
			if (null != runTime) {
				lastRun = runTime.getLastRun();
			} else {
				lastRun = new Date();
			}

			if (null == runTime) {
				runTime = new TScheduleRunTime();
				runTime.setName("Distribution");
			}
			// Date lastRun = new Date(INITIAL_RUN);
			List<BrEntity> DistributionData = businessRuleDao.getDistributionBrData();
			Date last = new Date();
			List<MetaDataFieldsEntity> metadataFields = null;
			if (null != DistributionData && DistributionData.size() > 0) {
				metadataFields = businessRuleDao.getAllMetadataFields();
			}
			for (BrEntity brEntity : DistributionData) {
				System.out.println(brEntity.getRuleType() + " : " + brEntity.getRuleName());
				AccountEntity accountEntity = businessRuleDao.getAccountById(brEntity.getAccountId());
				if (null != accountEntity.getAccountName()) {
					List<String> fieldIds = new ArrayList<>();
					for (AccountMappedField fields : accountEntity.getMetadataMappedField()) {
						if (fields.getIsActive() && !fields.getIsDeleted()) {
							fieldIds.add(fields.getValue());
						}
					}
					if (null != fieldIds && fieldIds.size() > 0) {
						ManageConfigEntity config = businessRuleDao.getConfigDataById("account");
						String refPath = config.getConfig().get("metadataMappingFieldName").toString();

						List<Criteria> criterias = new ArrayList<Criteria>();
						criterias.add(Criteria.where(refPath).in(fieldIds));
						Map<String, Object> distributionData = brEntity.getMetadataConditions();
						criterias = getDistCriterias(distributionData, metadataFields);
						criterias.add(Criteria.where("Product.isActive").is(Boolean.TRUE));
						List<Criteria> dtcriterias = new ArrayList<Criteria>();
						if (brEntity.getIsNew()) {
							dtcriterias.add(Criteria.where("Product.LastModifiedOn").lte(new Date()));
						} else {
							dtcriterias.add(Criteria.where("Product.LastModifiedOn").gt(lastRun));
						}
						List<String> formatIds = null;
						for (Entry<String, Object> operations1 : brEntity.getOperations().entrySet()) {
							if (operations1.getKey().equals("Format")) {
								List<Map<String, String>> operationDa = (List<Map<String, String>>) operations1
										.getValue();
								for (Map<String, String> map : operationDa) {
									Object s = (Object) map.get("value");
									formatIds = (List<String>) s;
								}
							}
						}
						if (null != formatIds && formatIds.size() > 0) {
							Criteria dateCheck = null;
							if (brEntity.getIsNew()) {
								dateCheck = Criteria.where("modifiedOn").lte(new Date());
							}else{
								dateCheck = Criteria.where("modifiedOn").gt(lastRun);
							}
							Criteria uploadedByCriteria[] = new Criteria[] { dateCheck,
									Criteria.where("isDeleted").is(Boolean.FALSE),
									Criteria.where("formatId").in(formatIds) };
							dtcriterias.add(
									Criteria.where("asset").elemMatch(new Criteria().andOperator(uploadedByCriteria)));
						}
						Criteria c = new Criteria().orOperator(dtcriterias.toArray(new Criteria[dtcriterias.size()]));
						criterias.add(c);
						criterias.add(Criteria.where("Product.isDeleted").is(Boolean.FALSE));
						List<PartnerEntity> partners = businessRuleDao.verifyPartnerById(brEntity.getPartnerIds());
						businessRuleDao.updateDistributionData(criterias, brEntity.getOperations(), partners, false,
								lastRun);
					}
				}
				businessRuleDao.updateBusinessRuleById(brEntity.getId());
			}
			runTime.setLastRun(last);
			businessRuleDao.updateLastRuntime(runTime);
			logger.info("Completed Distriution request placing" + new Date());
			response.setCode(ResponseCode.SUCCESS.toString());
			response.setStatusMessage("Distribution processed Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	private String getDateFormat(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		String formatedDate = "";
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		formatedDate = df.format(cal.getTime());
		return formatedDate;

	}

	public boolean sendMail() {
		boolean result = false;
		return result;
	}

	private List<Criteria> processSubCriteria(List<SubDoc> subDocs) {
		List<Criteria> subCriterias = new ArrayList<>();
		for (SubDoc subDoc : subDocs) {
			switch (subDoc.getCondition().toLowerCase()) {

			case "==":
				subCriterias.add(Criteria.where(subDoc.getField()).is(subDoc.getValue()));
				break;
			case "!=":
				subCriterias.add(Criteria.where(subDoc.getField()).ne(subDoc.getValue()));
				break;
			case "in":
				subCriterias.add(Criteria.where(subDoc.getField()).in((List) subDoc.getValue()));
				break;
			case "notin":
				subCriterias.add(Criteria.where(subDoc.getField()).nin(subDoc.getValue()));
				break;
			}
		}

		return subCriterias;

	}

	private List<String> splitAndTrim(String value) {
		List<String> opt = new ArrayList<>();
		Pattern regex = Pattern.compile("\'[^']*'|\"[^\"]*\"|(;)");
		Matcher m = regex.matcher(value);
		StringBuffer b = new StringBuffer();
		while (m.find()) {
			if (null != m.group(1))
				m.appendReplacement(b, "SplitHere");
			else
				m.appendReplacement(b, m.group(0));
		}
		m.appendTail(b);
		String replaced = b.toString();
		String[] splits = replaced.split("SplitHere");
		for (String string : splits) {
			if (string.startsWith("\"") && string.endsWith("\"")) {
				string = string.substring(1, string.length() - 1);
				opt.add(string.trim());
			} else {
				opt.add(string.trim());
			}

		}
		return opt;
	}

	private List<Criteria> getDistCriterias(Map<String, Object> distributionData,
			List<MetaDataFieldsEntity> metadataFields) {
		List<Criteria> criterias = new ArrayList<>();
		for (Entry<String, Object> set : distributionData.entrySet()) {
			List<Map<String, String>> n = (List<Map<String, String>>) set.getValue();
			for (Map<String, String> map2 : n) {
				try {
					MetaDataFieldsEntity metadataField = null;
					List<MetaDataFieldsEntity> metadataFields1 = metadataFields.stream()
							.filter(activ -> activ.getMetaDataFieldName() != null)
							.filter(activ -> activ.getMetaDataFieldName().equals(map2.get("fieldName")))
							.collect(Collectors.toList());
					if (null != metadataFields1 && metadataFields1.size() > 0) {
						metadataField = metadataFields1.get(0);
						List<Criteria> subCriterias = new ArrayList<>();
						if (null != map2.get("fieldName")) {
							switch (map2.get("operator")) {
							case "=":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).is(s));
									} else {
										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											subCriterias
													.add(Criteria.where(metadataField.getJsonDbPathElement()).in(data));
										} else {
											subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
													.is(map2.get("value")));
										}
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));

								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).is(s));
									} else {
										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											criterias.add(Criteria.where(metadataField.getReferencePath()).in(data));
										} else {
											criterias.add(Criteria.where(metadataField.getReferencePath())
													.is(map2.get("value")));
										}
									}
								}
								break;
							case ">":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).gt(s));
									} else {
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
												.gt(map2.get("value")));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));

								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).gt(s));
									} else {
										criterias.add(
												Criteria.where(metadataField.getReferencePath()).gt(map2.get("value")));
									}
								}
								break;
							case ">=":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).gte(s));
									} else {
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
												.gte(map2.get("value")));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).gte(s));
									} else {
										criterias.add(Criteria.where(metadataField.getReferencePath())
												.gte(map2.get("value")));
									}
								}
								break;
							case "<":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).lt(s));
									} else {
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
												.lt(map2.get("value")));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).lt(s));
									} else {
										criterias.add(
												Criteria.where(metadataField.getReferencePath()).lt(map2.get("value")));
									}
								}
								break;
							case "<=":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).lte(s));
									} else {
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
												.lte(map2.get("value")));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).lte(s));
									} else {
										criterias.add(Criteria.where(metadataField.getReferencePath())
												.lte(map2.get("value")));
									}
								}
								break;
							case "<>":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).ne(s));
									} else {
										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											subCriterias.add(
													Criteria.where(metadataField.getJsonDbPathElement()).nin(data));
										} else {
											subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
													.ne(map2.get("value")));
										}
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).ne(s));
									} else {

										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											criterias.add(Criteria.where(metadataField.getReferencePath()).nin(data));
										} else {
											criterias.add(Criteria.where(metadataField.getReferencePath())
													.ne(map2.get("value")));
										}

									}
								}
								break;
							case "Not in":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).nin(s));
									} else {
										Object s = map2.get("value");
										List<String> s1 = (List<String>) s;
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).nin(s1));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).nin(s));
									} else {
										Object s = map2.get("value");
										List<String> s1 = (List<String>) s;
										criterias.add(Criteria.where(metadataField.getReferencePath()).nin(s1));
									}
								}
								break;
							case "In":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).in(s));
									} else {
										Object s = map2.get("value");
										List<String> s1 = (List<String>) s;
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).in(s1));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).in(s));
									} else {
										Object s = map2.get("value");
										List<String> s1 = (List<String>) s;
										criterias.add(Criteria.where(metadataField.getReferencePath()).in(s1));
									}
								}
								break;
							case "Between":
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										String s1 = getDateFormat(new Date(map2.get("value1")));
										subCriterias.add(Criteria.where(null).is(null)
												.andOperator(Criteria.where(metadataField.getJsonDbPathElement()).gte(s)
														.and(metadataField.getJsonDbPathElement()).lte(s1)));
									} else {
										subCriterias.add(Criteria.where(null).is(null).andOperator(Criteria
												.where(metadataField.getJsonDbPathElement()).gte(map2.get("value"))
												.and(metadataField.getJsonDbPathElement()).lte(map2.get("value1"))));
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										String s1 = getDateFormat(new Date(map2.get("value1")));
										criterias.add(Criteria.where(null).is(null)
												.andOperator(Criteria.where(metadataField.getReferencePath()).gte(s)
														.and(metadataField.getReferencePath()).lte(s1)));
									} else {
										criterias.add(Criteria.where(null).is(null)
												.andOperator(Criteria.where(metadataField.getReferencePath())
														.gte(map2.get("value")).and(metadataField.getReferencePath())
														.lte(map2.get("value1"))));
									}
								}
								break;
							default:
								if (null != metadataField.getJsonDbPathCondition()
										&& metadataField.getJsonDbPathCondition().size() > 0) {
									subCriterias.addAll(processSubCriteria(metadataField.getJsonDbPathCondition()));
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement()).is(s));
									} else {
										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											subCriterias
													.add(Criteria.where(metadataField.getJsonDbPathElement()).in(data));
										} else {
											subCriterias.add(Criteria.where(metadataField.getJsonDbPathElement())
													.is(map2.get("value")));
										}
									}
									criterias.add(Criteria.where(metadataField.getJsonDbPathList())
											.elemMatch(new Criteria().andOperator(
													subCriterias.toArray(new Criteria[subCriterias.size()]))));
								} else {
									if (map2.get("key").contains("Date")) {
										String s = getDateFormat(new Date(map2.get("value")));
										criterias.add(Criteria.where(metadataField.getReferencePath()).is(s));
									} else {

										String val = map2.get("value");
										if (val.contains(";")) {
											List<String> data = splitAndTrim(val);
											criterias.add(Criteria.where(metadataField.getReferencePath()).in(data));
										} else {
											criterias.add(Criteria.where(metadataField.getReferencePath())
													.is(map2.get("value")));
										}

									}
								}
								break;
							}
						}
					}
				} catch (Exception e) {
					logger.error("In Service: unable to from criteria.");
				}
			}
		}
		return criterias;
	}

	// @Scheduled(fixedRate = 900000) // 15 min
	// @Scheduled(fixedRate = 3600000) //one hr
	// @Scheduled(fixedRate = 86400000) //one day
	// @Scheduled(fixedRate = 1800000)//30 min
	@Scheduled(cron = "${cornValue}")
	public void processBrEngine() {
		placeDiststributionRequest(true);

	}

}
