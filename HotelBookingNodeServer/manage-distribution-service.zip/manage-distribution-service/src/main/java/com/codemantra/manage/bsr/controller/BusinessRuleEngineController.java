/**
 * 
 */
package com.codemantra.manage.bsr.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.codemantra.manage.bsr.model.APIResponse;
import com.codemantra.manage.bsr.service.BusinessRuleService;

/**
 * @author Bharath Prasanna Y V Package Name:
 *         com.codemantra.manage.bsr.controller Updated On: 02-Apr-2018
 */

@CrossOrigin
@RestController
@RequestMapping("/manage-bsr-engine-service/")
public class BusinessRuleEngineController {

	private static final Logger logger = LoggerFactory.getLogger(BusinessRuleEngineController.class);

	@Autowired
	BusinessRuleService businessRuleService;

	@RequestMapping(value = "runDistribution", method = RequestMethod.PUT)
	@ResponseBody
	public APIResponse<Object> runDistribution() {
		APIResponse<Object> response = null;
		try {
			response = businessRuleService.placeDiststributionRequest(true);
		} catch (Exception e) {
			logger.error("In Controller: Unable to process distribution" + e.getMessage());
		}
		return response;
	}

}
