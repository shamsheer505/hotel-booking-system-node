/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.metadata.entity;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

public class ProductEntity {

	@Id
	private String id;

	@Field("Product")
	private MetaDataEntity product;

	@Field("asset")
	private List<AssetEntity> asset;

	@Field("CustomFields")
	private Map<String, Object> customFields;

	public MetaDataEntity getProduct() {
		return product;
	}

	public void setProduct(MetaDataEntity product) {
		this.product = product;
	}

	public List<AssetEntity> getAsset() {
		return asset;
	}

	public void setAsset(List<AssetEntity> asset) {
		this.asset = asset;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Map<String, Object> getCustomFields() {
		return customFields;
	}

	public void setCustomFields(Map<String, Object> customFields) {
		this.customFields = customFields;
	}

}
