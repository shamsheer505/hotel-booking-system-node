/**
 * 
 */
package com.codemantra.manage.metadata.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author Bharath Prasanna Y V Package Name:
 *         com.codemantra.manage.metadata.entity Updated On: 27-Feb-2018
 */
public class DistStatusEntity {

	@Field("status")
	private Boolean brStatus;

	@Field("modifiedOn")
	private Date modifiedOn;

	@Field("partnerId")
	private String partnerId;

	@Field("remarks")
	private List<String> remarks;

	@Field("isParent")
	private Boolean isParent;

	@Field("associateIds")
	private List<String> associateIds;

	/**
	 * 
	 */
	public DistStatusEntity() {
		// TODO Auto-generated constructor stub
	}

	public Boolean getBrStatus() {
		return brStatus;
	}

	public void setBrStatus(Boolean brStatus) {
		this.brStatus = brStatus;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public List<String> getRemarks() {
		return remarks;
	}

	public void setRemarks(List<String> remarks) {
		this.remarks = remarks;
	}

	public Boolean getIsParent() {
		return isParent;
	}

	public void setIsParent(Boolean isParent) {
		this.isParent = isParent;
	}

	public List<String> getAssociateIds() {
		return associateIds;
	}

	public void setAssociateIds(List<String> associateIds) {
		this.associateIds = associateIds;
	}

}
