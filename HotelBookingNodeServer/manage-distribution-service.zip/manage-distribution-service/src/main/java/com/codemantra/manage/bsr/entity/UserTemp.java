/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author Bharath Prasanna Y V
 * Package Name: com.codemantra.manage.bsr.entity
 * Updated On:  16-Jun-2018
 */
@Document(collection = "USER_UPDATE")
public class UserTemp {

	@Field("USER_ID")
	private String userId;

	@Field("McP_User_ID")
	private String mcpUserId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMcpUserId() {
		return mcpUserId;
	}

	public void setMcpUserId(String mcpUserId) {
		this.mcpUserId = mcpUserId;
	}
}
