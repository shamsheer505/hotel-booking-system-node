/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
20-07-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/


package com.codemantra.manage.metadata.model;

public class SeriesIdentifier
{
	public String SeriesIDType;

	public String IdTypeName;

	public String IdValue;

	public String getSeriesIDType() {
		return SeriesIDType;
	}

	public void setSeriesIDType(String seriesIDType) {
		SeriesIDType = seriesIDType;
	}

	public String getIdTypeName() {
		return IdTypeName;
	}

	public void setIdTypeName(String idTypeName) {
		IdTypeName = idTypeName;
	}

	public String getIdValue() {
		return IdValue;
	}

	public void setIdValue(String idValue) {
		IdValue = idValue;
	}
}
