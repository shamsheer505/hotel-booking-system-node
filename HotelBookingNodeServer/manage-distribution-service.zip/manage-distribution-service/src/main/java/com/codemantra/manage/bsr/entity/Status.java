/**
 * 
 */
package com.codemantra.manage.bsr.entity;

import java.util.Date;
import java.util.List;

/**
 * @author Bharath Prasanna Y V Package Name: com.codemantra.manage.bsr.entity
 *         Updated On: 08-Nov-2017
 */
public class Status {

	private boolean status;

	private Date modifiedOn;

	private String partnerId;

	private String parentId;

	private List<String> remarks;

	private Boolean isParent;

	private List<String> associateIds;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public List<String> getRemarks() {
		return remarks;
	}

	public void setRemarks(List<String> remarks) {
		this.remarks = remarks;
	}

	public Boolean getIsParent() {
		return isParent;
	}

	public void setIsParent(Boolean isParent) {
		this.isParent = isParent;
	}

	public List<String> getAssociateIds() {
		return associateIds;
	}

	public void setAssociateIds(List<String> associateIds) {
		this.associateIds = associateIds;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

}
