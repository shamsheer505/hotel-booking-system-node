/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
12-09-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.admin.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.codemantra.manage.admin.dao.MasterDao;
import com.codemantra.manage.admin.dto.Status;
import com.codemantra.manage.admin.entity.FormatEntity;
import com.codemantra.manage.admin.entity.FormatTypeEntity;
import com.codemantra.manage.admin.entity.UserWithPermissionGroupEntity;
import com.codemantra.manage.admin.service.FormatService;

@Service("formatService")
public class FormatServiceImpl implements FormatService {

	private static final Logger logger = LoggerFactory.getLogger(FormatServiceImpl.class);

	@Autowired
	MasterDao masterDao;

	@Value("${REQUEST_FORBIDDEN}")
	String REQUEST_FORBIDDEN;

	@Value("${SUCCESS_RETRIEVE_FT_LIST}")
	String SUCCESS_RETRIEVE_FT_LIST;

	@Value("${FAILURE_RETRIEVE_FT_LIST}")
	String FAILURE_RETRIEVE_FT_LIST;

	@Value("${SUCCESS_RETRIEVE_FORMAT_LIST}")
	String SUCCESS_RETRIEVE_FORMAT_LIST;

	@Value("${FAILURE_RETRIEVE_FORMAT_LIST}")
	String FAILURE_RETRIEVE_FORMAT_LIST;

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> retrieveAllFormatTypes(String loggedUser) {
		List<FormatTypeEntity> formatTypes = new LinkedList<FormatTypeEntity>();

		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		boolean permissionFlg = false;
		try {

			UserWithPermissionGroupEntity userEntityObj = masterDao.getUserEntity(loggedUser);
			permissionFlg = masterDao.checkPermission("MOD00006", "FORMAT", "VIEW", userEntityObj);
			if (permissionFlg) {				
				Map<String, Object> criteriaMap = new HashMap<>();
				criteriaMap.put("isDeleted", Boolean.FALSE);
				criteriaMap.put("isActive", Boolean.TRUE);

				formatTypes = (List<FormatTypeEntity>) masterDao.getAllEntityObjects(new FormatTypeEntity(), criteriaMap);

				status.setCode("SUCCESS_RETRIEVE_FT_LIST");
				status.setMessage(SUCCESS_RETRIEVE_FT_LIST);
				status.setStatus(true);
			} else {
				status.setCode("REQUEST_FORBIDDEN");
				status.setMessage(REQUEST_FORBIDDEN);
				status.setStatus(false);
			}
		} catch (Exception e) {
			logger.error("Exception in retrieveAllFormatTypes :: ", e);
			status.setCode("FAILURE_RETRIEVE_FT_LIST");
			status.setMessage(FAILURE_RETRIEVE_FT_LIST);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", formatTypes);
		}
		return finalData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> retrieveAllFormats(String loggedUser) {
		List<FormatEntity> formats = new LinkedList<FormatEntity>();

		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		boolean permissionFlg = false;

		try {
			UserWithPermissionGroupEntity userEntityObj = masterDao.getUserEntity(loggedUser);
			permissionFlg = masterDao.checkPermission("MOD00006", "FORMAT", "VIEW", userEntityObj);

			if (permissionFlg) {

				List<Object> tempList = CollectionUtils.emptyIfNull(userEntityObj.getPermissionGroup().getAsset())
						.stream().filter(k -> k.getPermission().equals("VIEW")).map(kv -> kv.getFormat())
						.collect(Collectors.toList());
				List<String> loggedUserFormatList = new ArrayList<>();
				if (tempList.size() == 1) {
					loggedUserFormatList = (List<String>) tempList.get(0);
				}

				Map<String, Object> criteriaMap = new HashMap<>();
				criteriaMap.put("formatId", loggedUserFormatList);
				criteriaMap.put("isDeleted", Boolean.FALSE);
				criteriaMap.put("isActive", Boolean.TRUE);

				formats = (List<FormatEntity>) masterDao.getAllEntityObjects(new FormatEntity(), criteriaMap);

				status.setCode("SUCCESS_RETRIEVE_FORMAT_LIST");
				status.setMessage(SUCCESS_RETRIEVE_FORMAT_LIST);
				status.setStatus(true);

			} else {
				status.setCode("REQUEST_FORBIDDEN");
				status.setMessage(REQUEST_FORBIDDEN);
				status.setStatus(false);
			}

		} catch (Exception e) {
			logger.error("Exception in retrieveAllFormats :: ", e);
			status.setCode("FAILURE_RETRIEVE_FORMAT_LIST");
			status.setMessage(FAILURE_RETRIEVE_FORMAT_LIST);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", formats);
		}

		return finalData;
	}

}
