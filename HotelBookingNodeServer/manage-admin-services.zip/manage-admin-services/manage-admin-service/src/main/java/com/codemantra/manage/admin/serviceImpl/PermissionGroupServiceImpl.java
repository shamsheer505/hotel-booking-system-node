/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
17-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.admin.serviceImpl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.codemantra.manage.admin.dao.MasterDao;
import com.codemantra.manage.admin.dto.Status;
import com.codemantra.manage.admin.entity.PermissionGroupEntity;
import com.codemantra.manage.admin.model.PermissionGroup;
import com.codemantra.manage.admin.service.PermissionGroupService;

@Service("permissionGroupService")
public class PermissionGroupServiceImpl implements PermissionGroupService {

	private static final Logger logger = LoggerFactory.getLogger(PermissionGroupServiceImpl.class);

	@Autowired
	MasterDao masterDao;

	@Value("${FAILURE_ADD_PG_ID_ERROR}")
	String FAILURE_ADD_PG_ID_ERROR;

	@Value("${SUCCESS_ADD_PG}")
	String SUCCESS_ADD_PG;

	@Value("${FAILURE_ADD_PG}")
	String FAILURE_ADD_PG;

	@Value("${PG_ALREADY_EXISTS}")
	String PG_ALREADY_EXISTS;

	@Value("${FAILURE_EDIT_PG_NOT_EXISTS}")
	String FAILURE_EDIT_PG_NOT_EXISTS;

	@Value("${SUCCESS_EDIT_PG}")
	String SUCCESS_EDIT_PG;

	@Value("${FAILURE_EDIT_PG}")
	String FAILURE_EDIT_PG;

	@Value("${FAILURE_DELETE_PG_NOT_EXISTS}")
	String FAILURE_DELETE_PG_NOT_EXISTS;

	@Value("${SUCCESS_DELETE_PG}")
	String SUCCESS_DELETE_PG;

	@Value("${FAILURE_DELETE_PG}")
	String FAILURE_DELETE_PG;

	@Value("${SUCCESS_RETRIEVE_PG_LIST}")
	String SUCCESS_RETRIEVE_PG_LIST;

	@Value("${FAILURE_RETRIEVE_PG_LIST}")
	String FAILURE_RETRIEVE_PG_LIST;

	@Value("${FAILURE_RETRIEVE_PG_NOT_EXISTS}")
	String FAILURE_RETRIEVE_PG_NOT_EXISTS;

	@Value("${SUCCESS_RETRIEVE_PG}")
	String SUCCESS_RETRIEVE_PG;

	@Value("${FAILURE_RETRIEVE_PG}")
	String FAILURE_RETRIEVE_PG;

	@Value("${FAILURE_EDIT_PG_EXISTS}")
	String FAILURE_EDIT_PG_EXISTS;

	@Override
	public Map<String, Object> save(PermissionGroup pg, String loggedUser) {

		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		try {
			/**
			 * Permission Group Name can't be duplicated
			 */
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("permissionGroupName", pg.getPermissionGroupName());
			criteriaMap.put("isDeleted", Boolean.FALSE);
			if (null == masterDao.getEntityObject(new PermissionGroupEntity(), criteriaMap)) {
				String pgId = masterDao.getNextSequenceId("permissionGroupIdSeq");
				logger.info("Permission Group Id generated is [PG" + pgId + "]");

				if (pgId.equals("-1")) {
					status.setCode("FAILURE_ADD_PG_ID_ERROR");
					status.setMessage(FAILURE_ADD_PG_ID_ERROR);
					status.setStatus(false);
				} else {
					PermissionGroupEntity entityObj = new PermissionGroupEntity();
					Timestamp currentTs = new Timestamp(new Date().getTime());

					pg.setPermissionGroupId("PG".concat(pgId));
					if (pg.getPermissionGroupName() == null || pg.getPermissionGroupName() == "")
						pg.setPermissionGroupName(pg.getPermissionGroupId());
					pg.setIsActive(Boolean.TRUE);
					pg.setIsDeleted(Boolean.FALSE);
					pg.setCreatedOn(currentTs);
					pg.setCreatedBy(loggedUser);
					pg.setModifiedOn(currentTs);
					pg.setModifiedBy(loggedUser);

					BeanUtils.copyProperties(pg, entityObj);
					result = masterDao.saveEntityObject(entityObj);

					if (result) {
						status.setCode("SUCCESS_ADD_PG");
						status.setMessage(SUCCESS_ADD_PG);
						status.setStatus(true);
					} else {
						status.setCode("FAILURE_ADD_PG");
						status.setMessage(FAILURE_ADD_PG);
						status.setStatus(false);
					}
				}
			} else {
				status.setCode("PG_ALREADY_EXISTS");
				status.setMessage(PG_ALREADY_EXISTS);
				status.setStatus(false);
			}
		} catch (Exception e) {
			logger.error("Exception in save :: ", e);
			status.setCode("FAILURE_ADD_PG");
			status.setMessage(FAILURE_ADD_PG);
			status.setStatus(false);
		} finally {
			finalData = retrieve(pg.getPermissionGroupId());
			finalData.put("status", status);
		}
		return finalData;

	}

	@Override
	public Map<String, Object> edit(PermissionGroup pg, String pgId, String loggedUser) {
		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		try {

			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("permissionGroupId", pgId);
			criteriaMap.put("isDeleted", Boolean.FALSE);

			PermissionGroupEntity entityObj = masterDao.getEntityObject(new PermissionGroupEntity(), criteriaMap);
			if (null == entityObj) {
				status.setCode("FAILURE_EDIT_PG_NOT_EXISTS");
				status.setMessage(FAILURE_EDIT_PG_NOT_EXISTS);
				status.setStatus(false);
			} else {

				PermissionGroupEntity entityObjExists = null;
				if (!entityObj.getPermissionGroupName().equals(pg.getPermissionGroupName())) {
					criteriaMap.clear();
					criteriaMap.put("permissionGroupName", pg.getPermissionGroupName());
					criteriaMap.put("isDeleted", Boolean.FALSE);

					entityObjExists = masterDao.getEntityObject(new PermissionGroupEntity(), criteriaMap);
				}

				if (null == entityObjExists) {
					entityObj.setModifiedBy(loggedUser);
					entityObj.setModifiedOn(new Timestamp(new Date().getTime()));

					result = masterDao.updateEntityObject(setEntityFieldsForModify(pg, entityObj));

					if (result) {
						status.setCode("SUCCESS_EDIT_PG");
						status.setMessage(SUCCESS_EDIT_PG);
						status.setStatus(true);
					} else {
						status.setCode("FAILURE_EDIT_PG");
						status.setMessage(FAILURE_EDIT_PG);
						status.setStatus(false);
					}
				} else {
					status.setCode("FAILURE_EDIT_PG_EXISTS");
					status.setMessage(FAILURE_EDIT_PG_EXISTS);
					status.setStatus(false);
				}
			}
		} catch (Exception e) {
			logger.error("Exception in edit :: ", e);
			status.setCode("FAILURE_EDIT_PG");
			status.setMessage(FAILURE_EDIT_PG);
			status.setStatus(false);
		} finally {
			finalData = retrieve(pgId);
			finalData.put("status", status);
		}
		return finalData;
	}

	@Override
	public Map<String, Object> delete(String pgId, String loggedUser) {
		boolean result = false;
		Map<String, Object> finalData = new HashMap<>();
		Status status = new Status();
		try {
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("permissionGroupId", pgId);
			criteriaMap.put("isDeleted", Boolean.FALSE);

			PermissionGroupEntity entityObj = masterDao.getEntityObject(new PermissionGroupEntity(), criteriaMap);

			if (null == entityObj) {
				status.setCode("FAILURE_DELETE_PG_NOT_EXISTS");
				status.setMessage(FAILURE_DELETE_PG_NOT_EXISTS);
				status.setStatus(false);
			} else {
				entityObj.setIsDeleted(Boolean.TRUE);
				entityObj.setIsActive(Boolean.FALSE);
				entityObj.setModifiedBy(loggedUser);
				entityObj.setModifiedOn(new Timestamp(new Date().getTime()));

				result = masterDao.updateEntityObject(entityObj);

				if (result) {
					status.setCode("SUCCESS_DELETE_PG");
					status.setMessage(SUCCESS_DELETE_PG);
					status.setStatus(true);
				} else {
					status.setCode("FAILURE_DELETE_PG");
					status.setMessage(FAILURE_DELETE_PG);
					status.setStatus(false);
				}
			}
		} catch (Exception e) {
			logger.error("Exception in delete :: ", e);
			status.setCode("FAILURE_DELETE_PG");
			status.setMessage(FAILURE_DELETE_PG);
			status.setStatus(false);
		} finally {
			finalData = retrieve(pgId);
			finalData.put("status", status);
		}
		return finalData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> retrieveAll() {
		List<PermissionGroupEntity> permissionGroups = new LinkedList<PermissionGroupEntity>();

		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		try {
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("isDeleted", Boolean.FALSE);
			criteriaMap.put("isActive", Boolean.TRUE);
			permissionGroups = (List<PermissionGroupEntity>) masterDao.getAllEntityObjects(new PermissionGroupEntity(), criteriaMap);

			status.setCode("SUCCESS_RETRIEVE_PG_LIST");
			status.setMessage(SUCCESS_RETRIEVE_PG_LIST);
			status.setStatus(true);
		} catch (Exception e) {
			logger.error("Exception in retrieveAll :: ", e);
			status.setCode("FAILURE_RETRIEVE_PG_LIST");
			status.setMessage(FAILURE_RETRIEVE_PG_LIST);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", permissionGroups);
		}
		return finalData;
	}

	@Override
	public Map<String, Object> retrieve(String pgId) {
		PermissionGroup pg = null;
		Status status = new Status();
		Map<String, Object> finalData = new HashMap<>();
		try {
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("permissionGroupId", pgId);
			criteriaMap.put("isDeleted", Boolean.FALSE);
			criteriaMap.put("isActive", Boolean.TRUE);

			PermissionGroupEntity entityObj = masterDao.getEntityObject(new PermissionGroupEntity(), criteriaMap);

			if (null == entityObj) {
				status.setCode("FAILURE_RETRIEVE_PG_NOT_EXISTS");
				status.setMessage(FAILURE_RETRIEVE_PG_NOT_EXISTS);
				status.setStatus(false);
			} else {
				pg = new PermissionGroup();
				BeanUtils.copyProperties(entityObj, pg);
				status.setCode("SUCCESS_RETRIEVE_PG");
				status.setMessage(SUCCESS_RETRIEVE_PG);
				status.setStatus(true);
			}

		} catch (Exception e) {
			logger.error("Exception in retrieve :: ", e);
			status.setCode("FAILURE_RETRIEVE_PG");
			status.setMessage(FAILURE_RETRIEVE_PG);
			status.setStatus(false);
		} finally {
			finalData.put("status", status);
			finalData.put("data", pg);
		}
		return finalData;
	}

	private PermissionGroupEntity setEntityFieldsForModify(PermissionGroup modelObj, PermissionGroupEntity entityObj) {

		entityObj.setPermissionGroupName(modelObj.getPermissionGroupName());
		entityObj.setRoleId(modelObj.getRoleId());
		entityObj.setAccount(modelObj.getAccount());
		entityObj.setMetadataType(modelObj.getMetadataType());
		entityObj.setImprint(modelObj.getImprint());
		entityObj.setProductCategory(modelObj.getProductCategory());
		entityObj.setMetadataGroup(modelObj.getMetadataGroup());
		entityObj.setPartnerType(modelObj.getPartnerType());
		entityObj.setApplication(modelObj.getApplication());
		entityObj.setAsset(modelObj.getAsset());
		entityObj.setReport(modelObj.getReport());
		entityObj.setAdministrator(modelObj.getAdministrator());

		return entityObj;
	}

}
