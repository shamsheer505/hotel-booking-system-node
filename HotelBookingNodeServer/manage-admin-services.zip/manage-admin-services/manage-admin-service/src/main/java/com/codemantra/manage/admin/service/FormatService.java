/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
12-09-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.admin.service;

import java.util.Map;

public interface FormatService {
	
	public Map<String, Object> retrieveAllFormatTypes(String loggedUser);
	
	public Map<String, Object> retrieveAllFormats(String loggedUser);
	
}
