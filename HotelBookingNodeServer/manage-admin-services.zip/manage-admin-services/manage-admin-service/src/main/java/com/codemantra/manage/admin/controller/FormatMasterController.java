
/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
25-09-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.admin.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.codemantra.manage.admin.dto.APIResponse;
import com.codemantra.manage.admin.dto.APIResponse.ResponseCode;
import com.codemantra.manage.admin.dto.Status;
import com.codemantra.manage.admin.service.FormatService;

@CrossOrigin
@RestController
@RequestMapping("/manage-admin-service/")
public class FormatMasterController {
	private static final Logger logger = LoggerFactory.getLogger(FormatMasterController.class);

	@Autowired
	FormatService service;
	
	@RequestMapping(value = "formattype", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> retrieveAllFormatTypes(@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.retrieveAllFormatTypes(loggedUser);
			status = (Status) finalData.get("status");

			if(status.getCode().equals("REQUEST_FORBIDDEN"))
				response.setCode(ResponseCode.FORBIDDEN.toString());
			else {
				if (status.isStatus())
					response.setCode(ResponseCode.SUCCESS.toString());
				else
					response.setCode(ResponseCode.ERROR.toString());
			}
			
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());		
			response.setData(finalData.get("data"));

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@RequestMapping(value = "format", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> retrieveAllFormats(@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.retrieveAllFormats(loggedUser);
			status = (Status) finalData.get("status");

			if(status.getCode().equals("REQUEST_FORBIDDEN"))
				response.setCode(ResponseCode.FORBIDDEN.toString());
			else {
				if (status.isStatus())
					response.setCode(ResponseCode.SUCCESS.toString());
				else
					response.setCode(ResponseCode.ERROR.toString());
			}
			
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());		
			response.setData(finalData.get("data"));

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
}

