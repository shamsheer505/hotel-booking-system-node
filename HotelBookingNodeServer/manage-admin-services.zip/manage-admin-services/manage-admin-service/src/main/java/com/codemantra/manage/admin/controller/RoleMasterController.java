
/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
04-08-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.admin.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.codemantra.manage.admin.dto.APIResponse;
import com.codemantra.manage.admin.dto.APIResponse.ResponseCode;
import com.codemantra.manage.admin.dto.Status;
import com.codemantra.manage.admin.model.Role;
import com.codemantra.manage.admin.model.User;
import com.codemantra.manage.admin.service.RoleService;

@CrossOrigin
@RestController
@RequestMapping("/manage-admin-service/")
public class RoleMasterController {
	private static final Logger logger = LoggerFactory.getLogger(RoleMasterController.class);

	@Autowired	
	RoleService service;

	@RequestMapping(value = "role", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> save(@RequestBody Role modelObj,
			@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.save(modelObj, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@RequestMapping(value = "role/{id}", method = RequestMethod.PUT, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> edit(@RequestBody Role modelObj, @PathVariable String id,
			@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("URI Parameters :: Permission Group Id [" + id + "]");
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.edit(modelObj, id, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
	@RequestMapping(value = "role/{id}", method = RequestMethod.DELETE, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> delete(@PathVariable String id,
			@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("URI Parameters :: Permission Group Id [" + id + "]");
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.delete(id, loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.DELETED.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());

			response.setData(finalData.get("data"));
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	

	
	@RequestMapping(value = "role", method = RequestMethod.GET, consumes = "application/json")
	@ResponseBody

	public APIResponse<Object> retrieveAll(@RequestParam(required = true, value = "loggedUser") String loggedUser) {
		logger.info("Request Parameters :: loggeduser [" + loggedUser + "]");
		APIResponse<Object> response = new APIResponse<Object>();
		Map<String, Object> finalData = null;
		Status status = null;
		try {
			finalData = service.retrieveAll(loggedUser);
			status = (Status) finalData.get("status");

			if (status.isStatus())
				response.setCode(ResponseCode.SUCCESS.toString());
			else
				response.setCode(ResponseCode.ERROR.toString());
			
			response.setStatus(status.getCode());
			response.setStatusMessage(status.getMessage());		
			response.setData(finalData.get("data"));

		} catch (Exception e) {
			logger.error("Exception :: ", e);
		}
		return response;
	}
	
    @RequestMapping(value = "role/{id}", method = RequestMethod.GET, consumes = "application/json")
    @ResponseBody
   
    public APIResponse<Object> retrieve(@PathVariable String id,
    		@RequestParam(required = true, value = "loggedUser") String loggedUser) {
    	logger.info("URI Parameters :: ID ["+id+"]");
    	logger.info("Request Parameters :: loggeduser ["+loggedUser+"]");
    	APIResponse<Object> response = new APIResponse<Object>();	
    	Map<String, Object> finalData = null;
    	Status status = null;
    	
    	try {    		
    			finalData = service.retrieve(id, loggedUser);  
    			status = (Status) finalData.get("status");
    			if(status.isStatus())
    				response.setCode(ResponseCode.SUCCESS.toString());
    			else
    				response.setCode(ResponseCode.ERROR.toString());
    			
    			response.setData(finalData.get("data"));
				response.setStatus(status.getCode());
				response.setStatusMessage(status.getMessage());
    	} catch(Exception e) {
    		logger.error("Exception :: ", e);
    	}      
        return response;    
    }
    
    @RequestMapping(value = "role/{id}/activate/{activeStatus}", method = RequestMethod.PUT, consumes = "application/json")
    @ResponseBody
    public APIResponse<Object> activateDeactivateRole(@RequestBody Role modelObj, @PathVariable String id, @PathVariable Integer activeStatus,
    		@RequestParam(required = true, value = "loggedUser") String loggedUser) {
    	logger.info("URI Parameters :: ID ["+id+"] - activeStatus ["+activeStatus+"]");
    	logger.info("Request Parameters :: loggeduser ["+loggedUser+"]");
    	APIResponse<Object> response = new APIResponse<Object>();	
    	Map<String, Object> finalData = null;
    	Status status = null;
    	
    	try {   
    			finalData = service.activateDeactivateRole(modelObj, id, activeStatus, loggedUser);  
    			status = (Status) finalData.get("status");
    			if(status.isStatus())
    				response.setCode(ResponseCode.SUCCESS.toString());
    			else
    				response.setCode(ResponseCode.ERROR.toString());
    			
    			response.setData(finalData.get("data"));				
				response.setStatus(status.getCode());
				response.setStatusMessage(status.getMessage());
    	} catch(Exception e) {
    		logger.error("Exception :: ", e);
    	}      
        return response;    
    }
	
    @RequestMapping(value = "role/checkforduplicaterole", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
   
    public APIResponse<User> checkForDuplicateUser(@RequestBody Role modelObj,
    		@RequestParam(required = true, value = "loggedUser") String loggedUser) {
    	logger.info("Request Parameters :: loggeduser ["+loggedUser+"]");
    	APIResponse<User> response = new APIResponse<User>();	
    	Map<String, Object> finalData = null;
    	Status status = null;
    	
    	try {    		
    			finalData = service.roleExists(modelObj, loggedUser);  
    			status = (Status) finalData.get("status");
    			if(status.isStatus())
    				response.setCode(ResponseCode.SUCCESS.toString());
    			else
    				response.setCode(ResponseCode.NOT_FOUND.toString());
    			
				response.setStatus(status.getCode());
				response.setStatusMessage(status.getMessage());
    	} catch(Exception e) {
    		logger.error("Exception :: ", e);
    	}      
        return response;    
    }
    
    

}

