/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
23-06-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

public class ScreenAccess extends Access {
	
	private String screenCode;
	private String screenName;
	
	public String getScreenCode() {
		return screenCode;
	}
	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

}
