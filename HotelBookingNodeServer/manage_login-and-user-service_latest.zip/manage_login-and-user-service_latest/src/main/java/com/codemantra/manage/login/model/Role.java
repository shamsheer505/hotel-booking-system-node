/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
28-07-2017			v1.0       	   	Shahid ul Islam	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.login.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mRole")
public class Role {

	private String roleId;
	private String roleName;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
}
