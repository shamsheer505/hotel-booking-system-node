/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
28-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mMetaDataType")
public class MetaDataType {

	
	private String metadataTypeId;
	private String metadataTypeName;
	
	public String getMetadataTypeId() {
		return metadataTypeId;
	}
	public void setMetadataTypeId(String metadataTypeId) {
		this.metadataTypeId = metadataTypeId;
	}
	public String getMetadataTypeName() {
		return metadataTypeName;
	}
	public void setMetadataTypeName(String metadataTypeName) {
		this.metadataTypeName = metadataTypeName;
	}

}
