/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
23-06-2017		    v1.1       	   Shahid ul Islam	        Added User Master Service Code
06-09-2017			v1.2       	   Shahid ul Islam	  		Added Methods for Change Password
***********************************************************************************************************************/

package com.codemantra.manage.login.service;

import java.util.Map;
import org.springframework.web.client.ResourceAccessException;

import com.codemantra.manage.login.entity.AuditLogEntity;
import com.codemantra.manage.login.model.MailDetails;
import com.codemantra.manage.login.model.Status;
import com.codemantra.manage.login.model.User;

public interface UserService {

	//Login
	public User validateUser(User user,String ipAddress);

	//public Status forgotPwd(String emailId) throws ResourceAccessException,Exception;
	public Status forgotPwd(String emailId,String lang)throws Exception;

	public User changePwd(String emailId, String oldPwd, String newPwd);
	
	public Status updatePassword(String emailId, String password,String accessKey,String lang);
	
	public Status verifyAccessKey(String accessKey,String emailId) throws Exception;
	
	public Status logout(String userId,String token,String ipAddress);
	
	public Status updateFailedEmail(MailDetails mailDetails);
	
	public String getEmailIdByAccessKey(String accessKey);
	
	public Status checkExistingPassword(String emailId, String oldPwd);
	
	public Status changePassword(String emailId, String password);
	
	public boolean updateAuditLogs(String emailId, String ipAddress,String status);
	
	public String getLoggedUserId(String email);

}
