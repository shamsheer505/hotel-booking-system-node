/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
23-06-2017			v1.1       	   Shahid ul Islam	  		Added User Master Service Code
06-09-2017			v1.2       	   Shahid ul Islam	  		Added Methods for Change Password
***********************************************************************************************************************/

package com.codemantra.manage.login.serviceImpl;

import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.Hours;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.codemantra.manage.login.dao.UserDao;
import com.codemantra.manage.login.dto.APIResponse;
import com.codemantra.manage.login.dto.APIResponse.ResponseCode;
import com.codemantra.manage.login.entity.AuditLogEntity;
import com.codemantra.manage.login.entity.MailDetailsEntity;
import com.codemantra.manage.login.entity.PasswordEntity;
import com.codemantra.manage.login.entity.UserEntity;
import com.codemantra.manage.login.model.MailDetails;
import com.codemantra.manage.login.model.Oauth;
import com.codemantra.manage.login.model.Status;
import com.codemantra.manage.login.model.User;
import com.codemantra.manage.login.service.UserService;
import com.codemantra.manage.login.util.AccessTokenGenerator;
import com.codemantra.manage.login.util.PasswordDecrypt;
import com.google.gson.Gson;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	/** retrieving values from properties file for single instance update. **/

	@Value("${MANAGE_OAUTH_SERVICE_URL}")
	String MANAGE_OAUTH_SERVICE_URL;
	
	@Value("${MANAGE_OAUTH_LOGOUT_URL}")
	String MANAGE_OAUTH_LOGOUT_URL;
	
	@Value("${APP_CLIENT_ID}")
	String APP_CLIENT_ID;
	
	@Value("${APP_CLIENT_SECRET}")
	String APP_CLIENT_SECRET;
	
	@Value("${USER_NOT_EXISTS}")
	String USER_NOT_EXISTS;
	
	@Value("${MANAGE_EMAIL_SERVICE_URL}")
	String MANAGE_EMAIL_SERVICE_URL;
	
	@Value("${MANAGE_VERIFY_ACCESS_SERVICE_URL}")
	String MANAGE_VERIFY_ACCESS_SERVICE_URL;

	@Value("${EXISTING_PASSWORD_ERROR}")
	String EXISTING_PASSWORD_ERROR;

	@Value("${LOGIN.ERROR.PASSWORD_EXPIRED_SUCCESS_EMAIL}")
	String LOGIN_ERROR_PASSWORD_EXPIRED_SUCCESS_EMAIL;
	
	@Value("${LOGIN.ERROR.PASSWORD_EXPIRED_FAILED_EMAIL}")
	String LOGIN_ERROR_PASSWORD_EXPIRED_FAILED_EMAIL;

	@Value("${LOGIN.ERROR.OAUTH_AUTHENTICATE_FAIL}")
	String LOGIN_ERROR_OAUTH_AUTHENTICATE_FAIL;
	
	@Value("${LOGIN.ERROR.OAUTH_SERVICE_FAIL}")
	String LOGIN_ERROR_OAUTH_SERVICE_FAIL;
	
	@Value("${LOGIN.ERROR.DEACTIVATED_USER}")
	String LOGIN_ERROR_DEACTIVATED_USER;

	@Value("${LOGIN.ERROR.INVALID_PASSWORD}")
	String LOGIN_ERROR_INVALID_PASSWORD;
	
	@Value("${LOGIN_ERROR_NOT_REGISTER}")
	String LOGIN_ERROR_NOT_REGISTER;
	
	@Value("${LOGIN_ERROR_INVALID_USERNAME}")
	String LOGIN_ERROR_INVALID_USERNAME;
	
	@Value("${LOGIN_ERROR_MESSAGE_LOCKED_USER}")
	String LOGIN_ERROR_MESSAGE_LOCKED_USER;
	
	@Value("${MANAGE_FORGOTPASSWORD_MAIL_SUBJECT}")
	String updatePassword;
	
	@Value("${MANAGE_RESETPASSWORD_MAIL_SUBJECT}")
	String resetPassword;
	
	
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	

	@CachePut(value = "user", key = "#loginUser.getEmail_id()")
	@Override
	public User validateUser(User user,String ipAddress) {
		User userData = null;
		Status status = null;
		MailDetails mailDetails = new MailDetails();
		UserEntity userEntity = null;
		Map<String,Object> templateData = new HashMap<String, Object>();
		try {
			userEntity = userDao.getUserByEmail(user.getEmailId().toLowerCase());
			if(null != userEntity)
				userData = UserEntityToVo(userEntity);
			
			if (null != userData) {
				if(userData.getIsRegistered()){
			//	String PUBLIC_SALT = PasswordDecrypt.secrandom();
				if(userData.getUserExpiryDate() !=null && userData.getUserExpiryDate().before(new Date())) {
					userData.setStatusMessage("UPDATEPASSWORD.ERROR.USER_EXPIRED");
					userData.setStatus(false);
				} else {
					String pwd = user.getPassword();
					String[] email = user.getEmailId().toLowerCase().split("@");
					String hashpwd = PasswordDecrypt.getDigestvalid(pwd, email[0]);
					int i = new Date().compareTo(userData.getPasswordExpiryDate());
					if(i>0) { 
						//UserEntity userEntity = userDao.getUserByEmail(user.getEmailId());
						userEntity.setIsPasswordExpired(true);
						userDao.updatePasswordExipry(userEntity);
						String accessKey = AccessTokenGenerator.generateAccessKey();
						//email configuration for password expired
						RestTemplate restTemplate = new RestTemplate();
						mailDetails.setEmail_from("donotreply@codemantra.com");
						mailDetails.setTo_email(user.getEmailId());
						mailDetails.setCreatedBy(user.getEmailId());
						mailDetails.setSubject(resetPassword);
						templateData.put("to", userData.getFirstName());
						templateData.put("passwordLink", MANAGE_VERIFY_ACCESS_SERVICE_URL+accessKey);
						templateData.put("from", "Manage Support Team");
						templateData.put("passwordUpdateType", resetPassword);
						mailDetails.setTemplateData(templateData);
						mailDetails.setTemplateName("forgotPassword.ftl");
						APIResponse response = restTemplate.postForObject( MANAGE_EMAIL_SERVICE_URL , mailDetails, APIResponse.class);
						if(ResponseCode.SUCCESS.toString().equals(response.getCode())){
							logger.info("Mail sent Successfully for Password expired");				
							userData.setStatus(true);
							userData.setStatusMessage("LOGIN.ERROR.PASSWORD_EXPIRED_SUCCESS_EMAIL");
							updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_PASSWORD_EXPIRED_SUCCESS_EMAIL);
							Calendar cal = Calendar.getInstance();
							cal.setTime(new Date());
							cal.add(Calendar.DATE, 1);
							PasswordEntity passwordEntity = new PasswordEntity();
							passwordEntity.setAccessKey(accessKey);
							passwordEntity.setCreatedBy(user.getEmailId());
							passwordEntity.setCreatedOn(new Date());
							passwordEntity.setEmailId(user.getEmailId());
							passwordEntity.setIsActive(true);
							passwordEntity.setIsDeleted(false);
							passwordEntity.setPasswordLink(MANAGE_VERIFY_ACCESS_SERVICE_URL+accessKey);
							passwordEntity.setPassword(userEntity.getPassword());
							passwordEntity.setExpiryOn(cal.getTime());
							userDao.savePasswordEntity(passwordEntity);
						}else{	
							logger.info("Failed to send email for Password expired");
							//status = updateFailedEmail(mailDetails);                    // commented by Shahid
							userData.setStatusMessage("LOGIN.ERROR.PASSWORD_EXPIRED_FAILED_EMAIL");
							userData.setStatus(false);
							updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_PASSWORD_EXPIRED_FAILED_EMAIL);
						}
					} else {
						User userDataVerify = UserEntityToVo(userDao.verifyUser(user.getEmailId().toLowerCase(), hashpwd));
						System.out.println(userData.getEmailId().toLowerCase());
						Oauth oauth = new Oauth();
						if (null != userDataVerify) {
						//	int hours =0;
							if (userDataVerify.getIsActive()) {
								if(!userEntity.isLocked()) {
									try {
										/*if(null != userEntity.getLockedTime()) {
											DateTime dt1 = new DateTime(userEntity.getLockedTime());
											DateTime dt2 = new DateTime(new Date());
											hours = Hours.hoursBetween(dt1, dt2).getHours();
										}*/
										//if(null != userEntity.getLockedTime() && hours >= 24) {
											userEntity.setLockCount(0);
											userEntity.setLocked(false);
											userEntity.setLockedTime(null);
										//}
										userDao.updateLockCount(userEntity);
										logger.info("Login successfull");
										userData.setStatusMessage("LOGIN.SUCCESS");
										userData.setIsPasswordExpired(false);
										RestTemplate template = new RestTemplate();
										String uri = MANAGE_OAUTH_SERVICE_URL+"grant_type=password&username="+userData.getEmailId()+
												"&password="+URLEncoder.encode(pwd, "utf-8")+"&client_id="+APP_CLIENT_ID+"&client_secret="+APP_CLIENT_SECRET;
										Oauth oauth1 = template.postForObject(uri, oauth, Oauth.class);
										if(oauth1!=null) {
											userData.setStatus(true);
											logger.info("Oauth authentication is success");
											//userData.setOautAaccessToken(oauth1.getAccess_token());
											userData.setOautAaccessToken("1862a43c-ba67-46f7-bf2b-c611f625f944");
											updateAuditLogs(userData.getEmailId(),ipAddress,"Oauth authentication is success");
											userEntity.setOnlineStatus("31");
											userEntity.setLockCount(0);
											userDao.updateOnlineStatus(userEntity);
										} else {
											logger.info("Oauth authentication failed");
											userData.setStatus(false);
											userData.setStatusMessage("LOGIN.ERROR.OAUTH_AUTHENTICATE_FAIL");
											updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_OAUTH_AUTHENTICATE_FAIL);
										}
									} catch(Exception e) {
										logger.error("Exception in oauth service: "+e);
										userData.setStatus(false);
										userData.setStatusMessage("LOGIN.ERROR.OAUTH_SERVICE_FAIL");
										updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_OAUTH_SERVICE_FAIL);
									}
								} else {
									userData.setStatus(false);
									userData.setStatusMessage("LOGIN.ERROR.MESSAGE.LOCKED.USER");
									updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_MESSAGE_LOCKED_USER);
								}
							} else {
								logger.info("Deactivated user");
								userData.setStatus(false);
								userData.setStatusMessage("LOGIN.ERROR.DEACTIVATED_USER");
								updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_DEACTIVATED_USER);
							}
						} else {
							// TODO Need to add business logic for invalid attempts
							userData = new User();
							logger.info("Invalid Password");
							userData.setStatus(false);
							userData.setStatusMessage("LOGIN.ERROR.MESSAGE");
							updateAuditLogs(userData.getEmailId().toLowerCase(),ipAddress,LOGIN_ERROR_INVALID_PASSWORD);
							if(null != userEntity.getLockCount()) {
								int hours =0;
								//userEntity.setLocked(false);
								if(null != userEntity.getLockedTime()) {
									DateTime dt1 = new DateTime(userEntity.getLockedTime());
									DateTime dt2 = new DateTime(new Date());
									hours = Hours.hoursBetween(dt1, dt2).getHours();
								}
								if(null != userEntity.getLockedTime() && hours >= 24) {
									userEntity.setLockCount(0);
									userEntity.setLocked(false);
									userEntity.setLockedTime(null);
								} else if(userEntity.getLockCount() == 5) {
									userEntity.setLocked(true);
									userEntity.setLockedTime(new Date());
								} 
								if(userEntity.getLockCount() >=5 ){
									userData.setStatus(false);
									userData.setStatusMessage("LOGIN.ERROR.MESSAGE.LOCKED.USER");
									updateAuditLogs(userData.getEmailId().toLowerCase(),ipAddress,LOGIN_ERROR_MESSAGE_LOCKED_USER);
								}
								userEntity.setLockCount(userEntity.getLockCount()+1);
							} else {
								userEntity.setLockCount(1);
							}
							userDao.updateLockCount(userEntity);
						}
					}
				}
				}else {
					logger.info("user not Register");
					userData = new User();
					userData.setStatus(false);
					userData.setStatusMessage("LOGIN.ERROR.MESSAGE");
					updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_NOT_REGISTER);
				}
			} else {
				logger.info("Invalid username");
				userData = new User();
				userData.setStatus(false);
				userData.setStatusMessage("LOGIN.ERROR.MESSAGE");
				updateAuditLogs(userData.getEmailId(),ipAddress,LOGIN_ERROR_INVALID_USERNAME);
			}

		}  catch (ResourceAccessException | HttpClientErrorException exception) {
			logger.error("Exception in sending email: "+exception);
			status = updateFailedEmail(mailDetails);
			userData.setStatusMessage("LOGIN.ERROR.PASSWORD_EXPIRED_FAILED_EMAIL");
			userData.setStatus(status.isStatus());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userData;
	}

	/*@Override
	public Status forgotPwd(String emailId) throws  ResourceAccessException,Exception{
		User userData = null;
		boolean result = false;
		Status status = new Status();
		RestTemplate restTemplate = new RestTemplate();
		MailDetails mailDetails = new MailDetails();
		Map<String,Object> templateData = new HashMap<String, Object>();
		try {
			userData = UserEntityToVo(userDao.getUserByEmail(emailId));

			if (null != userData) {
				logger.info("Email is valid");
				String accessKey = AccessTokenGenerator.generateAccessKey();
				String url = MANAGE_VERIFY_ACCESS_SERVICE_URL+accessKey;
				result = userDao.updateAccesskey(emailId, accessKey,url);
				if(result) {
					//Email logic code
					mailDetails.setEmail_from("donotreply@codemantra.com");
					mailDetails.setTo_email(emailId);
					mailDetails.setSubject("Reset Password");
					mailDetails.setCreatedBy(emailId);
					templateData.put("to", userData.getFirstName()+" "+userData.getLastName());
					templateData.put("passwordLink", MANAGE_VERIFY_ACCESS_SERVICE_URL+accessKey);
					templateData.put("from", "Manage Support Team");
					mailDetails.setTemplateData(templateData);
					mailDetails.setTemplateName("forgotPassword.ftl");
				    APIResponse response = restTemplate.postForObject( MANAGE_EMAIL_SERVICE_URL, mailDetails, APIResponse.class);
				    if(ResponseCode.SUCCESS.toString().equals(response.getCode())){
						logger.info("Mail sent Successfully for Forgot password");				
						status.setMessage("FORGOTPASSWORD.SUCCESS.EMAIL_LINK");
						status.setStatus(true);
					}else{	
						logger.info("Failed to send mail for Forgot password");
						status = updateFailedEmail(mailDetails);
					}
				}
			} else {
				logger.info("Email is invalid");
				status.setMessage("FORGOTPASSWORD.ERROR.CHECK_USERNAME");
				status.setStatus(false);
			}
		} catch (ResourceAccessException | HttpClientErrorException exception) {
			status = updateFailedEmail(mailDetails);
		} 
		catch (Exception e) {
			e.printStackTrace();
		//	throw e;
		}
		return status;
	}*/
	@Override
	public Status forgotPwd(String emailId,String lang) throws  ResourceAccessException,Exception{
		UserEntity userData = null;
		String newAccesskey = null;
		Status status = new Status();
		RestTemplate restTemplate = new RestTemplate();
		MailDetails mailDetails = new MailDetails();
		Map<String,Object> templateData = new HashMap<String, Object>();
		try {
			userData = userDao.getUserByEmail(emailId);

			if (null != userData) {
				logger.info("Email is valid::"+userData.isLocked());
				if(userData.getUserExpiryDate() !=null && userData.getUserExpiryDate().before(new Date())) {
					logger.info("User expired");
					status.setMessage("FORGOTPASSWORD.ERROR.USER_EXPIRED");
					status.setStatus(false);
				} else if(userData.isLocked()){
					logger.info("User locked");
					status.setMessage("LOGIN.ERROR.MESSAGE.LOCKED.USER");
					status.setStatus(false);
				} else {
					String accessKey = AccessTokenGenerator.generateAccessKey();
					String url = MANAGE_VERIFY_ACCESS_SERVICE_URL+accessKey;
					newAccesskey = userDao.updateAccesskey(emailId, accessKey,url);
					logger.info("Accesskey"+newAccesskey);
					if(newAccesskey!=null) {
						//Email logic code
						mailDetails.setEmail_from("donotreply@codemantra.com");
						mailDetails.setTo_email(emailId);
						mailDetails.setSubject(updatePassword);
						mailDetails.setCreatedBy(emailId);
						templateData.put("to", userData.getFirstName()== null?"User":userData.getFirstName());
						templateData.put("passwordLink", MANAGE_VERIFY_ACCESS_SERVICE_URL+newAccesskey+"/"+lang);
						templateData.put("from", "Manage Support Team");
						templateData.put("passwordUpdateType", updatePassword);
						mailDetails.setTemplateData(templateData);
						mailDetails.setTemplateName("forgotPassword_"+lang+".ftl");
						System.out.println("UserLanguage"+lang);
						
					    APIResponse response = restTemplate.postForObject( MANAGE_EMAIL_SERVICE_URL, mailDetails, APIResponse.class);
					    
					    System.out.println(response.getCode()+"code");
					    System.out.println(response.getStatusMessage()+"message");
					   // if(ResponseCode.SUCCESS.toString().equals(response.getCode())){
							logger.info("Mail sent Successfully for Forgot password");				
							status.setMessage("FORGOTPASSWORD.SUCCESS.EMAIL_LINK");
							status.setStatus(true);
						/*}else{	
							logger.info("Failed to send mail for Forgot password");
							//status = updateFailedEmail(mailDetails);              // commented by Shahid
							status.setStatus(false);
							status.setMessage("EMAIL.ERROR.MESSAGE");
						}*/
					}
				}
			} else {
				logger.info("Email is invalid");
				status.setMessage("FORGOTPASSWORD.ERROR.CHECK_USERNAME");
				status.setStatus(false);
			}
		} catch (ResourceAccessException | HttpClientErrorException exception) {
			status = updateFailedEmail(mailDetails);
			status.setMessage("FORGOTPASSWORD.SUCCESS.EMAIL_LINK");
			status.setStatus(true);
		} 
		catch (Exception e) {
			e.printStackTrace();
		//	throw e;
		}
		return status;
	}
	@Override
	public User changePwd(String emailId, String oldPwd, String newPwd) {
		User userData = null;
		try {
			userData = UserEntityToVo(
					userDao.verifyUser(emailId, PasswordDecrypt.getDigestvalid(oldPwd, PasswordDecrypt.secrandom())));
			if (null != userData) {

				userData.setHashPassword(PasswordDecrypt.getDigestvalid(newPwd, PasswordDecrypt.secrandom()));
				userData.setModifiedOn(new Timestamp(new Date().getTime()));

			} else {
				userData = new User();
				userData.setStatusMessage("Kindly Check your Username/Password");
			}
		} catch (Exception e) {
			logger.error("Exception::"+e.getMessage());
		}
		return null;
	}

	private UserEntity UserVoToUserEntity(User user) {
		UserEntity userEntity = new UserEntity();
		userEntity.setUserId(user.getUserId());
		userEntity.setFirstName(user.getFirstName());
		userEntity.setLastName(user.getLastName());
		userEntity.setPassword(user.getPassword());
		userEntity.setAddress(user.getAddress());
		userEntity.setCity(user.getCity());
		userEntity.setZipCode(user.getZipCode());
		userEntity.setEmailId(user.getEmailId());
		userEntity.setContactNo(user.getContactNo());
		userEntity.setProfilePicName(user.getProfilePicName());
		userEntity.setIsActive(user.getIsActive());
		userEntity.setIsRegistered(user.getIsRegistered());
		userEntity.setRegisteredOn(user.getRegisteredOn());
		userEntity.setIsDeleted(user.getIsDeleted());
		userEntity.setCreatedBy(user.getCreatedBy());
		userEntity.setCreatedOn(user.getCreatedOn());
		userEntity.setModifiedBy(user.getModifiedBy());
		userEntity.setModifiedOn(user.getModifiedOn());
		userEntity.setPasswordExpiryDate(user.getPasswordExpiryDate());
		userEntity.setIsPasswordExpired(user.getIsPasswordExpired());
		return userEntity;
	}

	private User UserEntityToVo(UserEntity userEntity) {
		User user = null;
		if(userEntity != null) {
			user = new User();
			user.setUserId(userEntity.getUserId());
			user.setUserName(userEntity.getFirstName());
			user.setFirstName(userEntity.getFirstName());
			user.setLastName(userEntity.getLastName());
			user.setPassword(userEntity.getPassword());
			user.setAddress(userEntity.getAddress());
			user.setCity(userEntity.getCity());
			user.setZipCode(userEntity.getZipCode());
			user.setEmailId(userEntity.getEmailId());
			user.setContactNo(userEntity.getContactNo());
			user.setProfilePicName(userEntity.getProfilePicName());
			user.setIsActive(userEntity.getIsActive());
			user.setIsRegistered(userEntity.getIsRegistered());
			user.setRegisteredOn(userEntity.getRegisteredOn());
			user.setIsDeleted(userEntity.getIsDeleted());
			user.setCreatedBy(userEntity.getCreatedBy());
			user.setCreatedOn(userEntity.getCreatedOn());
			user.setModifiedBy(userEntity.getModifiedBy());
			user.setModifiedOn(userEntity.getModifiedOn());
			user.setPasswordExpiryDate(userEntity.getPasswordExpiryDate());
			user.setIsPasswordExpired(userEntity.getIsPasswordExpired());
		}
		return user;
	}

	@Override
	public Status updatePassword(String emailId, String password, String accessKey,String lang) {
		User userData = null;
		boolean result = false;
		boolean pwdResult = false;
		Status status = null;
		RestTemplate restTemplate = new RestTemplate();
		MailDetails mailDetails = new MailDetails();
		Map<String,Object> templateData = new HashMap<String,Object>();
		try {
			userData = UserEntityToVo(userDao.getUserByEmail(emailId));
			status = new Status();
			if (null != userData) {
				
				if(userData.getUserExpiryDate() !=null && userData.getUserExpiryDate().before(new Date())) {
					status.setMessage("UPDATEPASSWORD.ERROR.USER_EXPIRED");
					status.setStatus(false);
					
				} else {
					String[] email = emailId.split("@");
					String hashpwd = PasswordDecrypt.getDigestvalid(password, email[0]);
					userData.setPassword(hashpwd);
					userData.setModifiedOn(new Timestamp(new Date().getTime()));
					userData.setCreatedOn(new Timestamp(new Date().getTime()));
					userData.setCreatedBy(emailId);
					userData.setModifiedBy(emailId);
					userData.setIsRegistered(true);
					pwdResult = userDao.checkForPreviousPwd(hashpwd,emailId);
					System.out.println(pwdResult+"pwdResult");
					if(pwdResult) {
						result = userDao.updateUserPassword(UserVoToUserEntity(userData),accessKey);
						System.out.println(result+"result");
						if (result) {
							mailDetails.setEmail_from("donotreply@codemantra.com");
							mailDetails.setTo_email(emailId);
							mailDetails.setSubject("Password Updated");
							mailDetails.setCreatedBy(emailId);
							templateData.put("to", userData.getFirstName());
							templateData.put("from", "Manage Support Team");
							mailDetails.setTemplateData(templateData);
							mailDetails.setTemplateName("passwordupdate_"+lang+".ftl");
							APIResponse response = restTemplate.postForObject( MANAGE_EMAIL_SERVICE_URL, mailDetails, APIResponse.class);
							System.out.println(response.getCode()+"response");
							//if(ResponseCode.SUCCESS.toString().equals(response.getCode())){
								logger.info("Mail sent Successfully for update password");				
								status.setMessage("UPDATEPASSWORD.SUCCESS.MESSAGE");
								status.setStatus(true);
							/*}else{				
								//status = updateFailedEmail(mailDetails);  // commented by Shahid
								status.setStatus(false);
								status.setMessage("EMAIL.ERROR.MESSAGE");
								System.out.println(status+"status");
							}*/
						} else {
							status.setMessage("UPDATEPASSWORD.ERROR.MESSAGE");
							status.setStatus(false);
						}
					} else {
						status.setStatus(false);
						status.setMessage("UPDATEPASSWORD.ERROR.LAST_PASSWORDS");
					}
				}
			} else {
				status.setMessage("UPDATEPASSWORD.ERROR.INVALID_EMAIL");
				status.setStatus(false);
			}
		} catch (ResourceAccessException | HttpClientErrorException exception) {
			status = updateFailedEmail(mailDetails);
			status.setMessage("UPDATEPASSWORD.SUCCESS.MESSAGE");
			status.setStatus(true);
		} catch (Exception e) {
			logger.error("Exception::"+e.getMessage());
		}
		return status;
	}

	@Override
	public Status verifyAccessKey(String accessKey,String emailId) throws Exception {

		Status status = new Status();
		PasswordEntity passwordEntity;
		try {
			passwordEntity = userDao.getEmailByAccesskey(accessKey);
			if(passwordEntity==null) {
				status.setStatus(false);
				status.setMessage("VERIFYACCESS.ERROR.ACCESSKEY_NOT_VALID");
			} else {
				passwordEntity = userDao.checkAccessKey(accessKey,passwordEntity.getEmailId());
				if(passwordEntity != null) {
					Date currentDate = new Date();
			        Date dbDate = passwordEntity.getCreatedOn();
			        long diff = currentDate.getTime() - dbDate.getTime();
			        long days = diff / (24 * 60 * 60 * 1000);
			        
			      //  final long days = ChronoUnit.DAYS.between(dbDate.toInstant(),currentDate.toInstant());
					System.out.println(days);
					if(days <= 5) {
						status.setStatus(true);
						status.setMessage("VERIFYACCESS.SUCCESS.ACCESSKEY_VALID");
					} else {
						status.setStatus(false);
						status.setMessage("VERIFYACCESS.ERROR.ACCESSKEY_EXPIRED");
					}
				} else {
					
					status.setStatus(false);
					status.setMessage("VERIFYACCESS.ERROR.ACCESSKEY_NOT_VALID");
				}
			}
		} catch (Exception e) {
			logger.error("Exception::"+e.getMessage());
		}
		return status;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Status logout(String userId,String token,String ipAddress) {
		Status status = new Status();
		RestTemplate template = new RestTemplate();
		AuditLogEntity auditLogEntity = new AuditLogEntity();
		try {
			UserEntity userData = userDao.getUserByUserId(userId);
			if(null == userData){
				status.setCode(ResponseCode.ERROR.toString());
				status.setMessage(USER_NOT_EXISTS);
				status.setStatus(false);
			}else {
				userData.setOnlineStatus("32");
				userDao.updateOnlineStatus(userData);
				//status.setStatus(true);
		    	//status.setMessage("LOGOUT.SUCCESS.MESSAGE");
			//	String uri = MANAGE_OAUTH_LOGOUT_URL+"access_token="+token;
		    //	APIResponse<String> response = template.postForObject(uri,null, APIResponse.class);
		    	
		    /*	URL url = new URL(uri);
		    	URLConnection con = url.openConnection();
		    	HttpURLConnection http = (HttpURLConnection)con;
		    	http.setRequestMethod("POST"); // PUT is another valid option
		    	http.setDoOutput(true);*/
		    	
		    //	if(200 == 200){
		    		logger.info("LOGOUT.SUCCESS.MESSAGE");
		    		status.setStatus(true);
			    	status.setMessage("LOGOUT.SUCCESS.MESSAGE");
			    	auditLogEntity.setEmailId(userData.getEmailId());
					auditLogEntity.setStatus("LOGOUT");
					auditLogEntity.setClientIp(ipAddress);
					auditLogEntity.setUserId(userData.getUserId());
					auditLogEntity.setLoggedTime(new Date());
					userDao.insertAuditLogs(auditLogEntity);
		    //	}*else {
		    /*		status.setStatus(false);
			    	status.setMessage("LOGOUT.ERROR.MESSAGE");
		    	}*/
			}
	    	
		} catch(Exception e) {
			logger.error("Exception :: ", e);
			status.setStatus(false);
	    	status.setMessage("LOGOUT.ERROR.MESSAGE");
		}
		return status;
	}

	@Override
	public Status updateFailedEmail(MailDetails mailDetails) {
		Status status = new Status();
		MailDetailsEntity detailsEntity = new MailDetailsEntity();
		detailsEntity.setToEmail(mailDetails.getTo_email());
		detailsEntity.setCcEmail(null);
		detailsEntity.setSubject(mailDetails.getSubject());
		detailsEntity.setEmailFrom("donotreply@codemantra.com");
		detailsEntity.setHeader(null);
		detailsEntity.setHeaderValue(null);
		detailsEntity.setCompanyEmail(null);
		detailsEntity.setTemplateData(mailDetails.getTemplateData());
		detailsEntity.setTemplateName(mailDetails.getTemplateName());
		detailsEntity.setUpdateFlag(1);
		detailsEntity.setCreatedBy(mailDetails.getCreatedBy());
		userDao.emailupdate(detailsEntity);
		status.setStatus(false);
		status.setMessage("EMAIL.ERROR.MESSAGE");
		return status;
	}

	@Override
	public String getEmailIdByAccessKey(String accessKey) {
		PasswordEntity passwordEntity;
		String emailId = null;
		passwordEntity = userDao.getEmailByAccesskey(accessKey);
		if(passwordEntity!=null) {
			emailId = passwordEntity.getEmailId().toLowerCase();
		}
		return emailId;
	}

	
	@Override
	public Status checkExistingPassword(String emailId, String oldPwd) {
		UserEntity userData = null;
		Status status = new Status();
		try {
			emailId = emailId.toLowerCase();
			String[] email = emailId.split("@");
			String hashpwd = PasswordDecrypt.getDigestvalid(oldPwd, email[0]);
			
			userData = userDao.verifyUser(emailId, hashpwd);
			
			if(null == userData){
				status.setCode("EXISTING_PASSWORD_ERROR");
				status.setMessage(EXISTING_PASSWORD_ERROR);
				status.setStatus(false);
			}else
				status.setStatus(true);
		} catch (Exception e) {
			status.setCode("EXISTING_PASSWORD_ERROR");
			status.setMessage(EXISTING_PASSWORD_ERROR);
			status.setStatus(false);
		}
		return status;
	}
	
	@Override
	public Status changePassword(String emailId, String password) {
		User userData = null;
		boolean result = false;
		boolean pwdResult = false;
		Status status = null;
		RestTemplate restTemplate = new RestTemplate();
		MailDetails mailDetails = new MailDetails();
		Map<String,Object> templateData = new HashMap<String,Object>();
		try {
			emailId = emailId.toLowerCase();
			userData = UserEntityToVo(userDao.getUserByEmail(emailId));
			status = new Status();
			if (null != userData) {
				
				String[] email = emailId.split("@");
				String hashpwd = PasswordDecrypt.getDigestvalid(password, email[0]);
				userData.setPassword(hashpwd);
				userData.setModifiedOn(new Timestamp(new Date().getTime()));
				userData.setModifiedBy(userData.getUserId());
				pwdResult = userDao.checkForPreviousPwd(hashpwd,emailId);
				if(pwdResult) {
					result = userDao.changeUserPassword(UserVoToUserEntity(userData),AccessTokenGenerator.generateAccessKey());
					if (result) {
						mailDetails.setEmail_from("donotreply@codemantra.com");
						mailDetails.setTo_email(emailId);
						mailDetails.setSubject("Password Updated");
						mailDetails.setCreatedBy(userData.getUserId());
						templateData.put("to", userData.getFirstName()==null?"":userData.getFirstName());
						templateData.put("from", "Manage Support Team");
						mailDetails.setTemplateData(templateData);
						mailDetails.setTemplateName("passwordupdate.ftl");
						System.out.println(MANAGE_EMAIL_SERVICE_URL);
						System.out.println(new Gson().toJson(mailDetails));
						APIResponse response = restTemplate.postForObject( MANAGE_EMAIL_SERVICE_URL, mailDetails, APIResponse.class);
												
					//	if(ResponseCode.SUCCESS.toString().equals(response.getCode())){
							logger.info("Mail sent Successfully for Change Password");				
							status.setMessage("UPDATEPASSWORD.SUCCESS.MESSAGE");
							status.setStatus(true);
						/*}else{		
							status.setStatus(false);
							status.setMessage("EMAIL.ERROR.MESSAGE");
						}*/
					} else {
						status.setMessage("UPDATEPASSWORD.ERROR.MESSAGE");
						status.setStatus(false);
					}
				} else {
					status.setStatus(false);
					status.setMessage("UPDATEPASSWORD.ERROR.LAST_PASSWORDS");
					
				}
			} else {
				status.setMessage("UPDATEPASSWORD.ERROR.INVALID_EMAIL");
				status.setStatus(false);
			}
		} catch (ResourceAccessException | HttpClientErrorException exception) {
			status = updateFailedEmail(mailDetails);
			status.setMessage("UPDATEPASSWORD.SUCCESS.MESSAGE");
			status.setStatus(true);
		} catch (Exception e) {
			status.setMessage("UPDATEPASSWORD.ERROR.MESSAGE");
			status.setStatus(true);
		}
		return status;
	}
	
	@Override
	public String getLoggedUserId(String email) {
		String userId = "";
		try {
			userId = userDao.getLoggedUserId(email.toLowerCase());
		} catch (Exception e) {

		}
		return userId;
	}

	@Override
	public boolean updateAuditLogs(String emailId, String ipAddress,String status) {
		String userId = "";
		boolean result = false;
		AuditLogEntity auditLogEntity = new AuditLogEntity();
		try {
			emailId = emailId.toLowerCase();
			userId = userDao.getLoggedUserId(emailId);
			auditLogEntity.setEmailId(emailId);
			auditLogEntity.setStatus(status);
			auditLogEntity.setClientIp(ipAddress);
			auditLogEntity.setUserId(userId);
			auditLogEntity.setLoggedTime(new Date());
			result = userDao.insertAuditLogs(auditLogEntity);
		} catch (Exception e) {
			logger.error("Exception::"+e.getMessage());
		}
		return result;
	}
	
}