/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
23-06-2017		    v1.1       	   Shahid ul Islam	        Added User Master Service Code
06-09-2017			v1.2       	   Shahid ul Islam	  		Added Methods for Change Password
***********************************************************************************************************************/

package com.codemantra.manage.login.dao;

import com.codemantra.manage.login.entity.AuditLogEntity;
import com.codemantra.manage.login.entity.MailDetailsEntity;
import com.codemantra.manage.login.entity.PasswordEntity;
import com.codemantra.manage.login.entity.UserEntity;

public interface UserDao {
	
	public boolean updateUserPassword(UserEntity user, String accessKey);
	
	public PasswordEntity checkAccessKey(String accessKey,String emailId) throws Exception;
	
	public String updateAccesskey(String email_id,String accesskey,String url);
	
	public PasswordEntity getEmailByAccesskey(String accesskey);
	
	public boolean checkForPreviousPwd(String hashPassword,String emailId);

	public boolean emailupdate(MailDetailsEntity detailsEntity);
	
	public boolean changeUserPassword(UserEntity user, String accessKey);
	
	public boolean updateOnlineStatus(UserEntity user);
	
	public boolean updateLockCount(UserEntity user);
	
	public boolean updatePasswordExipry(UserEntity user);
	
	public boolean insertAuditLogs(AuditLogEntity auditLogEntity);
	
	public UserEntity getUserByEmail(String email_id);
	
	public UserEntity getUserByUserId(String userId);

	public UserEntity verifyUser(String email_id, String pwd);	
	
	public boolean savePasswordEntity(PasswordEntity pwdEntity);
	
	public String getLoggedUserId(String emailId);

}
