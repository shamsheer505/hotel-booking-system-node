/**********************************************************************************
Date          	Version       Modified By      		Description  
***********		********     *************			*************	
19-05-2017		v1.0       	   Saravanan K	  		Initial Version.
06-09-2017		v1.1       	   Shahid ul Islam	  	Added Methods for Change Password
***********************************************************************************/

package com.codemantra.manage.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.codemantra.manage.login.dto.APIResponse;
import com.codemantra.manage.login.dto.APIResponse.ResponseCode;
import com.codemantra.manage.login.entity.AuditLogEntity;
import com.codemantra.manage.login.model.SetPassword;
import com.codemantra.manage.login.model.Status;
import com.codemantra.manage.login.model.User;
import com.codemantra.manage.login.service.UserService;
import com.codemantra.manage.login.util.PasswordValidator;

@CrossOrigin
@RestController
@RequestMapping("/manage-login-service/")
public class LoginController {  
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	HttpSession session = null; 
			
	@Autowired
    private UserService loginService;

    @RequestMapping(value = "login", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody 
    
    public APIResponse<User> loginCheck(@RequestBody User loginUser,HttpServletRequest request) {
    	APIResponse<User> response = new APIResponse<User>();
		User user = null;
    	try {
    		if(loginUser.getEmailId()!=null && loginUser.getPassword()!=null) {
        		loginUser.setEmailId(loginUser.getEmailId().toLowerCase());
    			user = loginService.validateUser(loginUser,loginUser.getClientIp());
        		if(user.isStatus()){
            	//	session=request.getSession(true);
            		System.out.println("IP Address::" +loginUser.getClientIp());
            	//	session.setAttribute("user", user);
            		response.setCode(ResponseCode.SUCCESS.toString());
            		response.setStatus(user.getStatusMessage());
            		response.setData(user);
            	}else{
            		response.setCode(ResponseCode.UNAUTHORIZED.toString());
            		response.setStatus(user.getStatusMessage());
            	}
    		} else {
    			response.setCode(ResponseCode.ERROR.toString());
        		response.setStatus("LOGIN.ERROR.BLANK.USERNAME/PASSWORD");
    		}
    	} catch(Exception e){
    		e.printStackTrace();
    	}
        return response;    
    }
    
    @RequestMapping(value = "forgotpassword", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
   
    public APIResponse<User> verifyEmail(@RequestBody User loginUser) {
    	APIResponse<User> response = new APIResponse<User>();	
    	Status status = null;
    	try {
    		if(null!=loginUser.getEmailId()) {
    			loginUser.setEmailId(loginUser.getEmailId().toLowerCase());
    			logger.info("Email Id - " + loginUser.getEmailId());    	
    	    	status = loginService.forgotPwd(loginUser.getEmailId(),loginUser.getLang());    		
    	    	if(!status.isStatus()) {
    	    		response.setCode(ResponseCode.UNAUTHORIZED.toString());
    	    		response.setStatus(status.getMessage());   	       
    	    	} else {
    	    		response.setCode(ResponseCode.SUCCESS.toString());
    				response.setStatus(status.getMessage()); 
    	    	}
    		} else {
    			response.setCode(ResponseCode.ERROR.toString());
    			response.setStatus("LOGIN.ERROR.BLANK.EMAIL");
    		}
    	
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}      
        return response;    
    }   

/*    @RequestMapping(value = "forgotpassword", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
   
    public APIResponse<User> verifyEmail(@RequestBody User loginUser) {
    	APIResponse<User> response = new APIResponse<User>();	
    	Status status = null;
    	try {
    		if(loginUser.getEmailId()!=null) {
    			logger.info("Email Id - " + loginUser.getEmailId());
    			logger.info("Email Id - " + loginUser.getla;    
    	    	status = loginService.forgotPwd(loginUser.getEmailId());    		
    	    	if(!status.isStatus()) {
    	    		response.setCode(ResponseCode.UNAUTHORIZED.toString());
    	    		response.setStatus(status.getMessage());   	       
    	    	} else {
    	    		response.setCode(ResponseCode.SUCCESS.toString());
    				response.setStatus(status.getMessage()); 
    	    	}
    		} else {
    			response.setCode(ResponseCode.ERROR.toString());
    			response.setStatus("LOGIN.ERROR.BLANK.EMAIL");
    		}
    	
    	} catch(Exception e) {
    		logger.error(e.getMessage());
    	}      
        return response;    
    }
    */
    
    @RequestMapping(value = "verifyaccess/{accesskey}/{email_id}", method = RequestMethod.GET)
    @ResponseBody
    public APIResponse<Boolean> verifyAccessKey(@PathVariable String email_id,@PathVariable String accesskey) throws Exception {
    	APIResponse<Boolean> response = new APIResponse<Boolean>();
    	Status accessKey_status = null;
    	email_id = email_id.toLowerCase();
    	accessKey_status = loginService.verifyAccessKey(accesskey,email_id);
    	if(accessKey_status.isStatus()) {
    		response.setCode(ResponseCode.SUCCESS.toString());
    		response.setStatus(accessKey_status.getMessage());
    		
    	} else {
    		response.setCode(ResponseCode.UNAUTHORIZED.toString());
    		response.setStatus(accessKey_status.getMessage());
    	}
		return response;
    	
    }
    
    @RequestMapping(value = "verifyaccesswithoutemail/{accesskey}", method = RequestMethod.GET)
    @ResponseBody
    public APIResponse<Boolean> verifyAccessKeyWithoutemail(@PathVariable String accesskey) throws Exception {
    	APIResponse<Boolean> response = new APIResponse<Boolean>();
    	Status accessKey_status = null;
    	accessKey_status = loginService.verifyAccessKey(accesskey,null);
    	if(accessKey_status.isStatus()) {
    		response.setCode(ResponseCode.SUCCESS.toString());
    		response.setStatus(accessKey_status.getMessage());
    		
    	} else {
    		response.setCode(ResponseCode.UNAUTHORIZED.toString());
    		response.setStatus(accessKey_status.getMessage());
    	}
		return response;
    	
    }
    
    @RequestMapping(value = "setpassword", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public APIResponse<SetPassword> updatePassword(@RequestBody SetPassword password) {
    	//logger.info(password.getPassword());
    	System.out.println(password.getAccessKey());
    	Status status = null;
    	String emailId = null;
    	String passwordMatches = null;
    	PasswordValidator passwordValidator = new PasswordValidator();
    	password.setPassword(password.getPassword().trim());
    	APIResponse<SetPassword> response = new APIResponse<SetPassword>();
    	try {
    		if(null!=password.getAccessKey()) {
    			emailId = loginService.getEmailIdByAccessKey(password.getAccessKey());
    			System.out.println(password.getPassword()+"password");
    			System.out.println(emailId+"emailId");
    			if(emailId !=null) {
    				if(!password.getPassword().equalsIgnoreCase(emailId)) {
            			if(password.getPassword().equalsIgnoreCase(password.getConfirmPassword())) {
                			passwordMatches = passwordValidator.validate(password.getPassword());
                			if(passwordMatches == null) {
                    			System.out.println(password.getPassword());
                            	status = loginService.updatePassword(emailId,password.getPassword(),password.getAccessKey(),password.getLang());
                            	if(status.isStatus()) {
                            		logger.info("Password Updated for user: "+emailId);
                               		response.setCode(ResponseCode.SUCCESS.toString());
                               		response.setStatus(status.getMessage());
                            	} else {
                            		response.setCode(ResponseCode.ERROR.toString());
                               		response.setStatus(status.getMessage());
                            	}
                			} else {
                				response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
                    			response.setStatus(passwordMatches);
                			}
                			
                    	} else {
                    			response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
                    			response.setStatus("UPDATEPASSWORD.ERROR.PASSWORD_NOTMATCH");
                    		}
            		} else {
            			response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
            			response.setStatus("UPDATEPASSWORD.ERROR.EMAIL_PASSWORD_MATCH");
            		}
    			} else {
    				response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
    				response.setStatus("VERIFYACCESS.ERROR.ACCESSKEY_NOT_VALID");
    			}
    			
    		}
    	} catch(Exception e){
    		e.printStackTrace();
    	}
		return response;  
    }
    
    
    
    @RequestMapping(value = "logout/{userid}/{token}/{ipAddress:.+}", method = RequestMethod.GET)
    @ResponseBody
   
    public APIResponse<Object> logout(@PathVariable String userid,@PathVariable String token,@PathVariable String ipAddress,HttpServletRequest request) {
    	APIResponse<Object> response = new APIResponse<Object>();
    	Status status = null;
    	try {
    		//User user = (User) session.getAttribute("user");
    		status = loginService.logout(userid,token,ipAddress);
    		if(status.isStatus()) {
    		//	session.invalidate();
    			response.setCode(ResponseCode.SUCCESS.toString());
    			response.setStatus(status.getMessage());
    		} else {
    			response.setCode(ResponseCode.ERROR.toString());
    			response.setStatus(status.getMessage());
    		}
    	} catch(Exception e){
    		e.printStackTrace();
    	}
		return response;
    }
    
    /* Shahid - Change Password Changes Start */
    
    @RequestMapping(value = "changepassword", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public APIResponse<SetPassword> changePassword(@RequestBody SetPassword password) {
    	
    	Status status = null;
    	String passwordMatches = null;
    	PasswordValidator passwordValidator = new PasswordValidator();
    	APIResponse<SetPassword> response = new APIResponse<SetPassword>();
    	
    	Status existingPasswordCheckStatus = new Status();
    	
    	try {
    		password.setEmailId(password.getEmailId().toLowerCase());
    		existingPasswordCheckStatus = loginService.checkExistingPassword(password.getEmailId(),password.getOldPassword()); 
    		
    		if(existingPasswordCheckStatus.isStatus()){
    			
    			if(!password.getPassword().equalsIgnoreCase(password.getEmailId())) {
        			if(password.getPassword().equalsIgnoreCase(password.getConfirmPassword())) {
            			passwordMatches = passwordValidator.validate(password.getPassword());
            			if(passwordMatches == null) {
                        	status = loginService.changePassword(password.getEmailId(),password.getPassword());
                        	if(status.isStatus()) {
                        		logger.info("Password Updated for user: "+password.getEmailId());
                           		response.setCode(ResponseCode.SUCCESS.toString());
                           		response.setStatus(status.getMessage());
                        	} else {
                        		response.setCode(ResponseCode.ERROR.toString());
                           		response.setStatus(status.getMessage());
                        	}
            			} else {
            				response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
                			response.setStatus(passwordMatches);
            			}
            			
                	} else {
                			response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
                			response.setStatus("UPDATEPASSWORD.ERROR.PASSWORD_NOTMATCH");
                		}
        		} else {
        			response.setCode(ResponseCode.PRECONDITION_FAILED.toString());
        			response.setStatus("UPDATEPASSWORD.ERROR.EMAIL_PASSWORD_MATCH");
        		}
    			
    			
    		}else{
    			response.setCode(ResponseCode.PRECONDITION_FAILED.toString());           		
           		response.setStatus(existingPasswordCheckStatus.getCode());
				response.setStatusMessage(existingPasswordCheckStatus.getMessage()); 
    		}
    		
    	} catch(Exception e){
    		e.printStackTrace();
    	}
		return response;  
    }
    
    /* Shahid - Change Password Changes End */
    
    @RequestMapping(value = "getLoggedUserId", method = RequestMethod.POST)
    @ResponseBody
    public APIResponse<Object> getLoggedUser(@RequestBody User user,HttpServletRequest request) {
		APIResponse<Object> response = new APIResponse<Object>();
		String userId = "";
		try {
			
			userId = loginService.getLoggedUserId(user.getEmailId().toLowerCase());
			response.setData(userId);
		} catch(Exception e){
    		logger.error(e.getMessage());
    	}
		return response;
	}
    
    @RequestMapping(value = "updateAuditLogs", method = RequestMethod.POST)
    @ResponseBody
    public APIResponse<Object> updateAuditLogs(@RequestBody AuditLogEntity auditLogEntity,HttpServletRequest request) {
		APIResponse<Object> response = new APIResponse<Object>();
		boolean result;
		try {
			auditLogEntity.setEmailId(auditLogEntity.getEmailId().toLowerCase());
			result = loginService.updateAuditLogs(auditLogEntity.getEmailId(),request.getRemoteAddr(),auditLogEntity.getStatus());
			if(result) {
				response.setCode(ResponseCode.SUCCESS.toString());
			} else {
				response.setCode(ResponseCode.ERROR.toString());
			}
		} catch(Exception e){
    		logger.error(e.getMessage());
    	}
		return response;
	}
}
