/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
23-06-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

public class DistributionPartnerAccess extends Access{
	
	private String partnerCode;
	private String partnerName;
	
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

}
