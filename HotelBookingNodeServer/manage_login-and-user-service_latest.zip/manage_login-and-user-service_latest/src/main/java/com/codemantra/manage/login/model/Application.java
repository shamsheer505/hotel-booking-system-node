/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
28-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.login.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mApplication")
public class Application {

	private String applicationId;
	private String applicationName;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	
	

}
