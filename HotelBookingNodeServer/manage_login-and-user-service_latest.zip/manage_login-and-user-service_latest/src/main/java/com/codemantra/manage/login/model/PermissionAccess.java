/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
23-06-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

public class PermissionAccess extends Access {
	
	private String permissionCode;
	private String permissionName;
	
	public String getPermissionCode() {
		return permissionCode;
	}
	public void setPermissionCode(String permissionCode) {
		this.permissionCode = permissionCode;
	}
	public String getPermissionName() {
		return permissionName;
	}
	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

}
