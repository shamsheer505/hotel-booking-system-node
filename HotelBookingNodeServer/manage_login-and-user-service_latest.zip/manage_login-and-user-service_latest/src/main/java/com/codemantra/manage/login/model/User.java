/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
13-06-2017			v1.1		   Saravanan K				Added additional fields based on UX	
16-06-2017			v1.2		   Shahid				    Modified the whole class because of Changes in User Master
***********************************************************************************************************************/

package com.codemantra.manage.login.model;

import java.util.Date;
import java.util.List;

public class User {
	private String userId;
	private String userName;
	private String loginName;
	private String firstName;
	private String lastName;
	private String emailId;
	private String contactNo;
	/*private String address1;
	private String address2;*/
	private String address;
	private String city;
	private String jobTitle;
	private String countryName;
	private String profilePicName;
	/*private Date invitation_expiry_on;
	private String invitation_url;*/
	private long logCount;
	private String hashPassword;
	private String saltKey;
	private boolean isActive;
	private boolean isDeleted;
	private int modificationCounter;
	private long departmentId;
	private long companyId;
	private String createdBy;
	private Date createdOn;
	private String modifiedBy;
	private Date modifiedOn;
	private String role;
	private String password;
	/*private boolean url_is_active;*/
	private Date passwordExpiryDate;
	private boolean passwordExpired;
	/*private String password_expire_days;
	private String logo_path;*/
	private String zipCode;
	private String zone;
	private boolean status;
	private String statusMessage;
	private String oautAaccessToken;
	private String clientIp;
	
	private String lang;
	
	
/*	private Map<String, List<Imprint>> imprint;
	private List<Format> format_Rights;
	private List<Channel> chaneel_Rights;
	private List<Permissions> permissions;
	
	v1.1 Starts here 
	private List<Region> regions;
	private List<DistributionPartner> distributionPartners;
	private List<Vendor> vendors;
	private List<Application> application;
	private List<MetaDataType> metaDataTypes;
	private Map<String, List<ProductCategory>> ProductCategory;
	private List<MetaData> metaData;
	private List<Activity> activities;
	private List<Screen> screens;
	v1.1 Ends here */

/*	LinkedList<Map<String, Object>> screens= new LinkedList<>();
	LinkedList<Map<String, Object>> permissions= new LinkedList<>();
	LinkedList<Map<String, Object>> applications= new LinkedList<>();
	LinkedList<Map<String, Object>> activities= new LinkedList<>();
	LinkedList<Map<String, Object>> formats= new LinkedList<>();
	LinkedList<Map<String, Object>> accounts= new LinkedList<>();*/
	
	/*private List<ScreenAccess> screens;
	private List<PermissionAccess> permissions;
	private List<ApplicationAccess> applications;
	private List<ActivityAccess> activities;
	private List<FormatAccess> formats;
	private List<AccountAccess> accounts;*/
	
	private boolean isRegistered;
	private Date registeredOn;
	private String accessKey;
	
	
	private List<String> account;
	private List<String> metadataType;
	private List<String> imprint;
	private List<String> productCategory;
	private List<String> metadata;
	private List<String> partner;
	private List<String> vendor;
	private List<String> application;
	
	// Added on 28-07-2017 - For retrieval of Names to show in the screen
	
	private Role roleEntity;
	private List<Account> accountList;
	private List<MetaDataType> metadataTypeList;
	private List<ProductCategory> productCategoryList;
	private List<MetaDataGroup> metadataGroupList;
	private List<PartnerType> partnerTypeList;
	private List<Application> applicationList;
	private Date userExpiryDate;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	/*public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}*/
	public String getAddress(){
		return address;
	}
	public void setAddress(String address){
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getProfilePicName() {
		return profilePicName;
	}
	public void setProfilePicName(String profilePicName) {
		this.profilePicName = profilePicName;
	}
	public long getLogCount() {
		return logCount;
	}
	public void setLogCount(long logCount) {
		this.logCount = logCount;
	}
	public String getHashPassword() {
		return hashPassword;
	}
	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}
	public String getSaltKey() {
		return saltKey;
	}
	public void setSaltKey(String saltKey) {
		this.saltKey = saltKey;
	}
	public boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public int getModificationCounter() {
		return modificationCounter;
	}
	public void setModificationCounter(int modificationCounter) {
		this.modificationCounter = modificationCounter;
	}
	public long getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}
	public long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getPasswordExpiryDate() {
		return passwordExpiryDate;
	}
	public void setPasswordExpiryDate(Date passwordExpiryDate) {
		this.passwordExpiryDate = passwordExpiryDate;
	}
	public boolean getIsPasswordExpired() {
		return passwordExpired;
	}
	public void setIsPasswordExpired(boolean passwordExpired) {
		this.passwordExpired = passwordExpired;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
/*	public List<ScreenAccess> getScreens() {
		return screens;
	}
	public void setScreens(List<ScreenAccess> screens) {
		this.screens = screens;
	}
	public List<PermissionAccess> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<PermissionAccess> permissions) {
		this.permissions = permissions;
	}
	public List<ApplicationAccess> getApplications() {
		return applications;
	}
	public void setApplications(List<ApplicationAccess> applications) {
		this.applications = applications;
	}
	public List<ActivityAccess> getActivities() {
		return activities;
	}
	public void setActivities(List<ActivityAccess> activities) {
		this.activities = activities;
	}
	public List<FormatAccess> getFormats() {
		return formats;
	}
	public void setFormats(List<FormatAccess> formats) {
		this.formats = formats;
	}
	public List<AccountAccess> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<AccountAccess> accounts) {
		this.accounts = accounts;
	}*/
	public boolean getIsRegistered() {
		return isRegistered;
	}
	public void setIsRegistered(boolean isRegistered) {
		this.isRegistered = isRegistered;
	}
	public Date getRegisteredOn() {
		return registeredOn;
	}
	public void setRegisteredOn(Date registeredOn) {
		this.registeredOn = registeredOn;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public boolean isStatus() {
		return status;
	}
	public String getOautAaccessToken() {
		return oautAaccessToken;
	}
	public void setOautAaccessToken(String oautAaccessToken) {
		this.oautAaccessToken = oautAaccessToken;
	}
	public String getClientIp() {
		return clientIp;
	}
	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}
	public List<String> getAccount() {
		return account;
	}
	public void setAccount(List<String> account) {
		this.account = account;
	}
	public List<String> getMetadataType() {
		return metadataType;
	}
	public void setMetadataType(List<String> metadataType) {
		this.metadataType = metadataType;
	}
	public List<String> getImprint() {
		return imprint;
	}
	public void setImprint(List<String> imprint) {
		this.imprint = imprint;
	}
	public List<String> getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(List<String> productCategory) {
		this.productCategory = productCategory;
	}
	public List<String> getMetadata() {
		return metadata;
	}
	public void setMetadata(List<String> metadata) {
		this.metadata = metadata;
	}
	public List<String> getPartner() {
		return partner;
	}
	public void setPartner(List<String> partner) {
		this.partner = partner;
	}
	public List<String> getVendor() {
		return vendor;
	}
	public void setVendor(List<String> vendor) {
		this.vendor = vendor;
	}
	public List<String> getApplication() {
		return application;
	}
	public void setApplication(List<String> application) {
		this.application = application;
	}
	
	// Added on 28-07-2017 - For retrieval of Names to show in the screen
	

	public Role getRoleEntity() {
		return roleEntity;
	}
	public void setRoleEntity(Role roleEntity) {
		this.roleEntity = roleEntity;
	}
	public List<Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	public List<MetaDataType> getMetadataTypeList() {
		return metadataTypeList;
	}
	public void setMetadataTypeList(List<MetaDataType> metadataTypeList) {
		this.metadataTypeList = metadataTypeList;
	}
	public List<ProductCategory> getProductCategoryList() {
		return productCategoryList;
	}
	public void setProductCategoryList(List<ProductCategory> productCategoryList) {
		this.productCategoryList = productCategoryList;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public List<MetaDataGroup> getMetadataGroupList() {
		return metadataGroupList;
	}
	public void setMetadataGroupList(List<MetaDataGroup> metadataGroupList) {
		this.metadataGroupList = metadataGroupList;
	}
	public List<PartnerType> getPartnerTypeList() {
		return partnerTypeList;
	}
	public void setPartnerTypeList(List<PartnerType> partnerTypeList) {
		this.partnerTypeList = partnerTypeList;
	}
	public List<Application> getApplicationList() {
		return applicationList;
	}
	public void setApplicationList(List<Application> applicationList) {
		this.applicationList = applicationList;
	}
	public Date getUserExpiryDate() {
		return userExpiryDate;
	}
	public void setUserExpiryDate(Date userExpiryDate) {
		this.userExpiryDate = userExpiryDate;
	}
	
	
}
