/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
16-06-2017			v1.0      	    Sinduja                 Initial version
***********************************************************************************************************************/

package com.codemantra.manage.login.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "mPassword")
public class PasswordEntity {
	
	@Field("userId")
	private String userId;

	@Field("emailId")
	private String emailId;
	
	@Field("passwordLink")
	private String passwordLink;
	
	@Field("accessKey")
	private String accessKey;
	
	@Field("isActive")
	private boolean isActive;
	
	@Field("isDeleted")
	private boolean isDeleted;
	
	@Field("createdBy")
	private String createdBy;
	
	@Field("createdOn")
	private Date createdOn;
	
	@Field("modifiedBy")
	private String modifiedBy;
	
	@Field("modifiedOn")
	private Date modifiedOn;
	
	@Field("password")
	private String password;
	
	@Field("expiryOn")
	private Date expiryOn;
	
	@Field("userType")
	private Date userType;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPasswordLink() {
		return passwordLink;
	}

	public void setPasswordLink(String passwordLink) {
		this.passwordLink = passwordLink;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getExpiryOn() {
		return expiryOn;
	}

	public void setExpiryOn(Date expiryOn) {
		this.expiryOn = expiryOn;
	}

	public Date getUserType() {
		return userType;
	}

	public void setUserType(Date userType) {
		this.userType = userType;
	}
	
}