/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
19-05-2017			v1.0       	   	 Saravanan K	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.login.model;

import java.util.Date;

public class ForgetPassword implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private int forget_password_id;
	private User user_id;
	private Date created_on;
	private Date expiry_on;
	private String password_link;
	private Boolean is_active;
	
	
	public int getForget_password_id() {
		return forget_password_id;
	}
	public void setForget_password_id(int forget_password_id) {
		this.forget_password_id = forget_password_id;
	}
	public User getUser_id() {
		return user_id;
	}
	public void setUser_id(User user_id) {
		this.user_id = user_id;
	}
	public Date getCreated_on() {
		return created_on;
	}
	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}
	public Date getExpiry_on() {
		return expiry_on;
	}
	public void setExpiry_on(Date expiry_on) {
		this.expiry_on = expiry_on;
	}
	public String getPassword_link() {
		return password_link;
	}
	public void setPassword_link(String password_link) {
		this.password_link = password_link;
	}
	public Boolean getIs_active() {
		return is_active;
	}
	public void setIs_active(Boolean is_active) {
		this.is_active = is_active;
	}	
}