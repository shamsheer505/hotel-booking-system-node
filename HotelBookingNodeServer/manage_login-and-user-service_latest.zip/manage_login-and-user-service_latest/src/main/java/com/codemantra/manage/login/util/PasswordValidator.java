package com.codemantra.manage.login.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.codemantra.manage.login.model.Status;

public class PasswordValidator {
	
	/*private Pattern pattern;
	private Matcher matcher;

	private static final String PASSWORD_PATTERN ="^[A-Za-z]*((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";

	//private static final String PASSWORD_PATTERN ="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	
	public PasswordValidator(){
		  pattern = Pattern.compile(PASSWORD_PATTERN);
	}

	
	public boolean validate(final String password){
		  matcher = pattern.matcher(password);
		  System.out.println("result::"+matcher.matches());
		  return matcher.matches();

	  }
	*/
	public String validate(final String password){
		String errMsg = null;
		if(password.length() < 8 ) {
			errMsg = "UPDATEPASSWORD.ERROR.MINCHARACTER";
	        return errMsg;
		} 
		if(password.length() >= 16 ) {
			errMsg = "UPDATEPASSWORD.ERROR.MAXCHARACTER";
			return errMsg;
		}
		if(!password.matches("^[a-zA-Z].*")) {
			errMsg = "UPDATEPASSWORD.ERROR.FIRSTCHARACTER";
			return errMsg;
		}
	    if(!password.matches("(?=.*[0-9]).*") ) {
	    	errMsg = "UPDATEPASSWORD.ERROR.NUMBER";
			return errMsg;
	    }
	    if(!password.matches("(?=.*[a-z]).*") ) {
	    	errMsg = "UPDATEPASSWORD.ERROR.LOWERCASE";
			return errMsg;
	    }
	    if(!password.matches("(?=.*[A-Z]).*") ) {
	    	errMsg = "UPDATEPASSWORD.ERROR.UPPERCASE";
	    }
	    if(!password.matches("(?=.*[!@#$%^*]).*") ) {
	    	errMsg = "UPDATEPASSWORD.ERROR.SPECIALCHARACTER";
			return errMsg;
	    }
	    if(password.contains(" ")) {
	    	errMsg = "UPDATEPASSWORD.ERROR.WHITESPACE";
			return errMsg;
	    }
		return errMsg;
	}
}
