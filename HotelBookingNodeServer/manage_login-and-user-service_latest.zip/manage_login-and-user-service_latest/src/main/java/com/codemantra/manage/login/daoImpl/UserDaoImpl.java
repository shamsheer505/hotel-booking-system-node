/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********     *************		   *************	
19-05-2017		v1.0       	   Saravanan K	        Initial Version.
23-06-2017		v1.1       	   Shahid ul Islam	    Added User Master Service Code
06-09-2017		v1.2       	   Shahid ul Islam	  	Added Methods for Change Password
***********************************************************************************/

package com.codemantra.manage.login.daoImpl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.Fields;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.codemantra.manage.login.dao.UserDao;
import com.codemantra.manage.login.entity.AuditLogEntity;
import com.codemantra.manage.login.entity.MailDetailsEntity;
import com.codemantra.manage.login.entity.PasswordEntity;
import com.codemantra.manage.login.entity.UserEntity;
import com.codemantra.manage.login.model.AccountAccess;
import com.codemantra.manage.login.model.KeyValue;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.WriteResult;

@Repository
@Qualifier("userDao")
public class UserDaoImpl implements UserDao {
	@Autowired
	MongoTemplate mongoTemplate;
	@Autowired
	MongoOperations mongoOperations;

	public String collectionName = "mUser";
	
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	DB database = null;
	DBCollection coll = null;

	@Override	
	public UserEntity getUserByEmail(String email_id) {
		UserEntity userData = null;
		try {
			Query query = new Query();
			
			/** Even the Email Ids of Deleted users should not be
			 *  allowed to be used for new User creation, so no filtering for Deleted Users **/
			
			query.addCriteria(Criteria.where("emailId").is(email_id).and("isDeleted").is(Boolean.FALSE).and("isActive").is(Boolean.TRUE));  
			logger.info("Query ["+query+"]");
			userData = mongoOperations.findOne(query, UserEntity.class, collectionName);
			logger.info("UserData ["+userData+"]");
		} catch (Exception e) {
			logger.error("Exception occured while retrieving User Data by Email :: "+e);
			userData = null;
		}
		return userData;
	}
	
	@Override	
	public UserEntity getUserByUserId(String userId) {
		UserEntity userData = null;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("userId").is(userId).and("isDeleted").is(Boolean.FALSE));
			logger.info("Query ["+query+"]");
			userData = mongoOperations.findOne(query, UserEntity.class, collectionName);
			logger.info("UserData ["+userData+"]");
		} catch (Exception e) {
			logger.error("Exception occured while retrieving User Data by Id :: "+e);
			userData = null;
		}
		return userData;
	}
	
	
	@Override
	public boolean savePasswordEntity(PasswordEntity pwdEntity) {
		boolean result = false;
		try {

			mongoOperations.insert(pwdEntity);
			result = true;

		} catch (Exception e) {
			e.printStackTrace();
			result = false;			
		} 
		return result;
	}
	
	@Override
	public UserEntity verifyUser(String email_id, String pwd) {
		UserEntity userData = null;
		try {
			Query query2 = new Query();
			email_id = email_id.toLowerCase();
			query2.addCriteria(Criteria.where("emailId").is(email_id).and("password").is(pwd));
			System.out.println("Username::::" + email_id + "Password" + pwd);
			userData = mongoOperations.findOne(query2, UserEntity.class, collectionName);
			System.out.println("userData:::::::" + userData);
		} catch (Exception e) {
		}
		return userData;
	}
	 
	@Override
	public boolean updateUserPassword(UserEntity user, String accessKey) {
		boolean result = false;
		try {
			if (user != null) {
				Query query = new Query();
				java.util.Date date = new java.util.Date();
	            java.util.Date newDate = DateUtils.addDays(date, 90);
	            user.setEmailId(user.getEmailId().toLowerCase());
				query.addCriteria(Criteria.where("emailId").is(user.getEmailId()));

				Update update = new Update();

				update.set("password", user.getPassword());
				update.set("modifiedBy", user.getModifiedBy());
				update.set("modifiedDate", new Date());
				update.set("passwordExpiryDate",newDate);
				update.set("isPasswordExpired", false);
				update.set("isRegistered", true);
				update.set("registeredOn", new Timestamp(new Date().getTime()));                       // changed by Shahid
				WriteResult wrResult = mongoOperations.updateMulti(query, update, UserEntity.class);
				System.out.println(wrResult+"wrResult");
				if (wrResult.getN() > 0) {
					Query query1 = new Query();
					query1.addCriteria(Criteria.where("accessKey").is(accessKey).and("isActive").is(true).and("isDeleted").is(false).and("emailId").is(user.getEmailId()));
					Update updatePwd = new Update();
					updatePwd.set("password", user.getPassword());
					updatePwd.set("isActive", false);
					updatePwd.set("isDeleted", true);
					WriteResult wrResultpwd = mongoOperations.updateMulti(query1, updatePwd, PasswordEntity.class);
					System.out.println(wrResultpwd+"wrResultpwd");
					if(wrResultpwd.getN() > 0) {
						result = true;
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	@Override
	public boolean updateOnlineStatus(UserEntity user) {
		boolean result = false;
		try {
			if (user != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(user.getEmailId().toLowerCase()));

				Update update = new Update();
				update.set("onlineStatus", user.getOnlineStatus());
				WriteResult wrResult = mongoOperations.updateMulti(query, update, UserEntity.class);
				System.out.println(wrResult+"wrResult");
				if (wrResult.getN() > 0) {
					result = true;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	@Override
	public boolean updateLockCount(UserEntity user) {
		boolean result = false;
		try {
			if (user != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(user.getEmailId().toLowerCase()));
				Update update = new Update();
				update.set("lockedTime", user.getLockedTime());
				update.set("lockCount", user.getLockCount());
				update.set("isLocked", user.isLocked());
				WriteResult wrResult = mongoOperations.updateMulti(query, update, UserEntity.class);
				System.out.println(wrResult+"wrResult");
				if (wrResult.getN() > 0) {
					result = true;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	@Override
	public boolean updatePasswordExipry(UserEntity user) {
		boolean result = false;
		try {
			if (user != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(user.getEmailId().toLowerCase()));

				Update update = new Update();
				update.set("isPasswordExpired", user.getIsPasswordExpired());
				WriteResult wrResult = mongoOperations.updateMulti(query, update, UserEntity.class);
				System.out.println(wrResult+"wrResult");
				if (wrResult.getN() > 0) {
					result = true;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}

	@Override
	public PasswordEntity checkAccessKey(String accessKey,String emailId) throws Exception {
		PasswordEntity passwordEntity = null;
		try {
			if(accessKey != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("accessKey").is(accessKey).and("isActive").is(true).and("isDeleted").is(false).and("emailId").is(emailId.toLowerCase()));
				passwordEntity = mongoOperations.findOne(query, PasswordEntity.class, "mPassword");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return passwordEntity;
	}
	
//	@Override
	public PasswordEntity checkAccessKey(String emailId) throws Exception {
		PasswordEntity passwordEntity = null;
		try {
			if(emailId != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(emailId.toLowerCase()).and("isActive").is(true).and("isDeleted").is(false));
				passwordEntity = mongoOperations.findOne(query, PasswordEntity.class, "mPassword");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return passwordEntity;
	}


	@Override
	public String updateAccesskey(String email_id, String accesskey,String link) {
	//	boolean result = false;
		try {
			email_id = email_id.toLowerCase();
			PasswordEntity pwd = checkAccessKey(email_id);
			if(pwd!=null && pwd.getAccessKey()!=null && !pwd.getAccessKey().equalsIgnoreCase("") )
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				
				//if(sdf.format(new Date()).equals(sdf.format(pwd.getExpiryOn()))) {
				if((pwd.getExpiryOn()).compareTo(new Date()) >0){
					accesskey=pwd.getAccessKey();
					
					Query query = new Query();
					query.addCriteria(Criteria.where("emailId").is(email_id).and("accessKey").is(pwd.getAccessKey()).and("isActive").is(true));
					Update update = new Update();
					//update.set("isActive", false);
					//update.set("isDeleted", true);
					Calendar cal = Calendar.getInstance(); 
					cal.setTime(new Date()); 
					cal.add(Calendar.DATE, 1); 
					update.set("expiryOn",cal.getTime());
					WriteResult wrResult = mongoOperations.updateMulti(query, update, PasswordEntity.class);
				//	result=true;
				} else {
					Query query = new Query();
					query.addCriteria(Criteria.where("emailId").is(email_id).and("accessKey").is(pwd.getAccessKey()).and("isActive").is(true));
					Update update = new Update();
					update.set("isActive", false);
					update.set("isDeleted", true);
					WriteResult wrResult = mongoOperations.updateMulti(query, update, PasswordEntity.class);
					//insert new access key if password expired
					Calendar cal = Calendar.getInstance(); 
					cal.setTime(new Date()); 
					cal.add(Calendar.DATE, 1); 
					PasswordEntity passwordEntity = new PasswordEntity();
					passwordEntity.setAccessKey(accesskey);
					passwordEntity.setCreatedBy(email_id);
					passwordEntity.setCreatedOn(new Date());
					passwordEntity.setEmailId(email_id);
					passwordEntity.setIsActive(true);
					passwordEntity.setIsDeleted(false);
					passwordEntity.setPasswordLink(link);
					passwordEntity.setPassword(null);
					passwordEntity.setExpiryOn(cal.getTime());
					mongoOperations.insert(passwordEntity);
				//	result = true;
				}
				
				/*Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(email_id).and("isActive").is(true));
				Update update = new Update();
				
				
				Calendar cal = Calendar.getInstance(); // creates calendar
			    cal.setTime(new Date()); // sets calendar time/date
			    cal.add(Calendar.HOUR_OF_DAY, 1); // adds one hour
			    
				
				update.set("expiryOn", cal.getTime());
				//update.set("isDeleted", true);
				WriteResult wrResult = mongoOperations.updateMulti(query, update, PasswordEntity.class);
				result=true;*/

			}
			else if(accesskey != null) {
				
				
				/*Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(email_id).and("isActive").is(true));
				Update update = new Update();

				update.set("isActive", false);
				update.set("isDeleted", true);
				WriteResult wrResult = mongoOperations.updateMulti(query, update, PasswordEntity.class);
*/				//if (wrResult.getN() > 0)
				//{
					Calendar cal = Calendar.getInstance();
					cal.setTime(new Date());
					cal.add(Calendar.DATE, 1);
					PasswordEntity passwordEntity = new PasswordEntity();
					passwordEntity.setAccessKey(accesskey);
					passwordEntity.setCreatedBy(email_id);
					passwordEntity.setCreatedOn(new Date());
					passwordEntity.setEmailId(email_id);
					passwordEntity.setIsActive(true);
					passwordEntity.setIsDeleted(false);
					passwordEntity.setPasswordLink(link);
					passwordEntity.setPassword(null);
					passwordEntity.setExpiryOn(cal.getTime());
					mongoOperations.insert(passwordEntity);
					//result = true;
				//}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return accesskey;
	}
	
	
	
	
	@Override
	public PasswordEntity getEmailByAccesskey(String accesskey) {

		PasswordEntity passwordEntity = null;
		try {
			if(accesskey != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("accessKey").is(accesskey));
				passwordEntity = mongoOperations.findOne(query, PasswordEntity.class, "mPassword");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return passwordEntity;
	}

	@Override
	public boolean checkForPreviousPwd(String hashPassword, String emailId) {
		
		List<PasswordEntity> passwordsList = null;
		boolean result = false;
		int count = 0;
		try {
			emailId  = emailId.toLowerCase();
			if(hashPassword != null) {
				Query query = new Query();
				query.addCriteria(Criteria.where("emailId").is(emailId));
				query.limit(5);
				query.with(new Sort(Sort.Direction.DESC,"createdOn"));
				passwordsList = (List<PasswordEntity>) mongoTemplate.find(query, PasswordEntity.class, "mPassword");
				if(passwordsList.size()<0) {
					result = true;
				} else {
					for(PasswordEntity pwd:passwordsList) {
						if(pwd.getPassword()!=null && !pwd.getPassword().isEmpty() && pwd.getPassword().equalsIgnoreCase(hashPassword)) {
							count++;
							break;
						}
					}
					if(count>0) {
						result = false;
					} else {
						result = true;
					}
				}
			}
		}catch (Exception e) {
			throw e;
		}
		return result;
	}

	@Override
	public boolean emailupdate(MailDetailsEntity detailsEntity) {
		
		boolean result = false;
		try {
			mongoTemplate.insert(detailsEntity, "tMailDetails");
			result = true;

		} catch (Exception e) {
			throw e;
		} finally {
			
		}
		return result;
	}
	
	/** Method not used **/
/*	
	public List<KeyValue> getKeyValueList(String coll, String keyField, String valueField, String filterField, String filterFieldVal){
		List<KeyValue> keyValueList = null;
		
		try{
			Aggregation aggregation = newAggregation(
					match(Criteria.where(filterField).is(filterFieldVal)),
			        project(Fields.fields().and("key", keyField).and("value", valueField))			        
			    );
			
			AggregationResults<KeyValue> groupResults =  mongoTemplate.aggregate(aggregation, coll, KeyValue.class);
			keyValueList = groupResults.getMappedResults();
			
			System.out.println("KeyValue List size ["+keyValueList.size()+"]");
		}catch (Exception e) {
			logger.error("Exception occured while retrieving User Data by Id :: "+e);
			keyValueList = null;
		}
		
		return keyValueList;
	}*/
	
	/**
	 * This Method is used to retrieve key-value pairs across multiple documents/sub-documents in a collection filtered using single criteria
	 * Parameter 'keyField' is used to get the name of the key field
	 * Parameter 'valueField' is used to get the name of the value field
	 * Parameter 'criteriaFieldName' is used to get the name of the field to be used for filtering out the documents/sub-documents
	 * Parameter 'criteriaFieldValue' is used to get the value of the criteria field for filtering out the documents/sub-documents
	 * Parameter 'unwindField', is used to get the name of the unwind field, if unwinding is needed else null
	 */
	
	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField, String criteriaFieldName, U criteriaFieldValue, String unwindField) {
		
		List<KeyValue> result = null;
		try {
			
			Aggregation aggregation;
			
			if(null == unwindField){
				aggregation = newAggregation(
						match(Criteria.where(criteriaFieldName).is(criteriaFieldValue)),
						project(Fields.fields().and("key", keyField).and("value",valueField))	        
				    );
			}else{
				aggregation = newAggregation(
						unwind(unwindField),
						match(Criteria.where(criteriaFieldName).is(criteriaFieldValue)),
						project(Fields.fields().and("key", keyField).and("value",valueField))		        
				    );
			}
			
			AggregationResults<KeyValue> groupResults =  mongoTemplate.aggregate(aggregation, collection, KeyValue.class);
		    result = groupResults.getMappedResults();			
		} catch (Exception e) {
			logger.info("Exception occured while updating Master :: "+e);
			result = null;
		}
		
		return result;
	}
	
	/**
	 * This Method is used to retrieve key-value pairs across multiple documents/sub-documents in a collection filtered using multiple criteria
	 * Parameter 'keyField' is used to get the name of the key field
	 * Parameter 'valueField' is used to get the name of the value field
	 * Parameter 'criteriaMap' is used to get the criteria for filtering out the documents/sub-documents
	 * Parameter 'unwindField', is used to get the name of the unwind field, if unwinding is needed else null
	 */
	
	public <U> List<KeyValue> getKeyValueList(String collection, String keyField, String valueField, Map<String, Object> criteriaMap, String unwindField) {
		
		List<KeyValue> result = null;
		Criteria criteria =  new Criteria();
		try {	
			
			if(criteriaMap != null && criteriaMap.size() > 0){
				List<Criteria> criterias = new ArrayList<Criteria>(criteriaMap.size());				
				criteriaMap.forEach((k,v) -> {
					if(v instanceof Collection<?>){
						criterias.add(Criteria.where(k).in((Collection<?>) v));
					}else
						criterias.add(Criteria.where(k).is(v));
				});
			    criteria = new Criteria().andOperator(criterias.toArray(new Criteria[criterias.size()]));					
			}
			
			Aggregation aggregation;
			
			if(null == unwindField){
				aggregation = newAggregation(
						match(criteria),
						project(Fields.fields().and("key", keyField).and("value",valueField))	        
				    );
			}else{
				aggregation = newAggregation(
						unwind(unwindField),
						match(criteria),
						project(Fields.fields().and("key", keyField).and("value",valueField))		        
				    );
			}
			
			AggregationResults<KeyValue> groupResults =  mongoTemplate.aggregate(aggregation, collection, KeyValue.class);
		    result = groupResults.getMappedResults();			
		} catch (Exception e) {
			logger.info("Exception occured while Retrieving Data in getSingleFieldValueList :: "+e);
			result = null;
		}
		
		return result;
	}
	
	
	
	
	
	
	public <T, U> List<?> retrieveAccessInfoLOVs(T targetObj, String coll, String keyField, String valueField, String filterField, U filterFieldVal)
    {	
		List<?> result = null;
		try {
			
			Aggregation aggregation;
			
			if(targetObj instanceof AccountAccess){				
				aggregation = newAggregation(
						match(Criteria.where(filterField).in((List<?>)filterFieldVal)),
				        project(Fields.fields().and(keyField).and(valueField))			        
				    );
			}else{
				aggregation = newAggregation(
						match(Criteria.where(filterField).is(filterFieldVal)),
				        project(Fields.fields().and(keyField).and(valueField))			        
				    );
			}
			
			AggregationResults<?> groupResults =  mongoTemplate.aggregate(aggregation, coll, targetObj.getClass());
		    result = groupResults.getMappedResults();					
			
		} catch (Exception e) {
			logger.error("Exception occured while retrieving User Data by Id :: "+e);
			result = null;
		}		
		return result;		
    }
	
	@Override
	public boolean changeUserPassword(UserEntity user, String accessKey) {
		boolean result = false;
		try {
			if (user != null) {
				Query query = new Query();
				java.util.Date date = new java.util.Date();
	            java.util.Date newDate = DateUtils.addDays(date, 90);
				query.addCriteria(Criteria.where("userId").is(user.getUserId()));

				Update update = new Update();

				update.set("password", user.getPassword());
				update.set("modifiedBy", user.getUserId() );
				update.set("modifiedOn", new Timestamp(new Date().getTime()));
				update.set("passwordExpiryDate",newDate);
				update.set("isPasswordExpired", false);
				WriteResult wrResult = mongoTemplate.updateMulti(query, update, UserEntity.class);
				System.out.println(wrResult+"wrResult");
				if (wrResult.getN() > 0) {
					Query query1 = new Query();
					query1.addCriteria(Criteria.where("emailId").is(user.getEmailId()).and("isActive").is(true).and("isDeleted").is(false));
					Update updatePwd = new Update();
					updatePwd.set("isActive", false);
					updatePwd.set("isDeleted", true);
					WriteResult wrResultpwd = mongoOperations.updateMulti(query1, updatePwd, PasswordEntity.class);
					System.out.println(wrResultpwd+"wrResultpwd");
					//if(wrResultpwd.getN() > 0) {
						PasswordEntity passwordEntity = new PasswordEntity();
						
						Date currentDate = new Date();
						Calendar cal = Calendar.getInstance(); 
						cal.setTime(new Date()); 
						cal.add(Calendar.DATE, 1);
						passwordEntity.setUserId(user.getUserId());
						passwordEntity.setEmailId(user.getEmailId().toLowerCase());
						passwordEntity.setAccessKey(accessKey);
						passwordEntity.setIsActive(true);
						passwordEntity.setIsDeleted(false);						
						passwordEntity.setCreatedBy(user.getUserId());
						passwordEntity.setCreatedOn(currentDate);
						passwordEntity.setModifiedBy(user.getUserId());
						passwordEntity.setModifiedOn(currentDate);						
						passwordEntity.setPassword(user.getPassword());
						passwordEntity.setExpiryOn(cal.getTime());
						mongoOperations.insert(passwordEntity);
						
						result = true;
					//}
				}
			}
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	@Override
	public String getLoggedUserId(String emailId) {
		UserEntity userEntity;
		String userId = "";
		try {

			Query query = new Query();
			query.addCriteria(Criteria.where("emailId").is(emailId.toLowerCase()));
			logger.info("Query [" + query + "]");
			userEntity = mongoOperations.findOne(query, UserEntity.class);
			userId = userEntity.getUserId();

		} catch (Exception e) {
			logger.error("Exception occured while retrieving user list :: " + e.getMessage());
			throw e;
		}
		return userId;	
	}

	@Override
	public boolean insertAuditLogs(AuditLogEntity auditLogEntity) {
		boolean result = false;
		try {
			mongoOperations.insert(auditLogEntity);
			result = true;
			
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			result = false;			
		} 
		return result;
	}
}