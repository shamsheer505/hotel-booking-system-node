/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
23-06-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

public class ImprintAccess extends Access {
	
	private String imprintCode;
	private String imprintName;
	
	public String getImprintCode() {
		return imprintCode;
	}
	public void setImprintCode(String imprintCode) {
		this.imprintCode = imprintCode;
	}
	public String getImprintName() {
		return imprintName;
	}
	public void setImprintName(String imprintName) {
		this.imprintName = imprintName;
	}
	

}
