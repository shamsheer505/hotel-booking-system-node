package com.codemantra.manage.login.model;

public class Screen {

}
