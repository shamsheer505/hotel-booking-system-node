/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.login.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "M_PERMISSIONS")
public class Permissions {

	@Field("PERMISSION_NAME")
	private String permissionName;
	@Field("PERMISSION_DESCRIPTION")
	private String permissionDescription;
	@Field("IS_ACTIVE")
	private boolean isActive;
	@Field("CREATED_BY")
	private String createdBy;
	@Field("CREATED_ON")
	private Date createdDate;
	@Field("MODIFIED_BY")
	private String modifiedBy;
	@Field("MODIFIED_ON")
	private Date modifiedDate;
	@Field("MODIFICATION_COUNTER")
	private String modificationCounter;

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	public String getPermissionDescription() {
		return permissionDescription;
	}

	public void setPermissionDescription(String permissionDescription) {
		this.permissionDescription = permissionDescription;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModificationCounter() {
		return modificationCounter;
	}

	public void setModificationCounter(String modificationCounter) {
		this.modificationCounter = modificationCounter;
	}

}
