/**********************************************************************************************************************
Date          		Version       	Modified By      		Description  
***********			********     	*************			*************	
22-05-2017			v1.0       	   Bharath Prasanna	  		Initial Version.
***********************************************************************************************************************/

package com.codemantra.manage.login.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "M_FORMAT")
public class Format {

	@Field("FORMAT_CODE")
	private String formatCode;
	@Field("FORMAT_DESCRIPTION")
	private String formatDescription;
	@Field("CREATED_BY")
	private String createdBy;
	@Field("CREATED_ON")
	private Date createdDate;
	@Field("MODIFIED_BY")
	private String modifiedBy;
	@Field("MODIFIED_ON")
	private Date modifiedDate;
	@Field("IS_ACTIVE")
	private boolean isActive;

	public String getFormatCode() {
		return formatCode;
	}

	public void setFormatCode(String formatCode) {
		this.formatCode = formatCode;
	}

	public String getFormatDescription() {
		return formatDescription;
	}

	public void setFormatDescription(String formatDescription) {
		this.formatDescription = formatDescription;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

}
