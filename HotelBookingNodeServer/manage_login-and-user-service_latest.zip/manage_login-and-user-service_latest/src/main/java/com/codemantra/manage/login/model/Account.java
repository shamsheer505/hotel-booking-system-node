/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
28-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mAccount")
public class Account{
	
	private String accountId;
	private String accountName;
	

	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

}
