/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
28-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/

package com.codemantra.manage.login.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "metaDataGroupConfig")
public class MetaDataGroup {


	private String groupNameId;
	private String groupName;
	private String groupNameDisplayOrder;
	
	public String getGroupNameId() {
		return groupNameId;
	}
	public void setGroupNameId(String groupNameId) {
		this.groupNameId = groupNameId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupNameDisplayOrder() {
		return groupNameDisplayOrder;
	}
	public void setGroupNameDisplayOrder(String groupNameDisplayOrder) {
		this.groupNameDisplayOrder = groupNameDisplayOrder;
	}

}
