/**********************************************************************************
Date          	Version       Modified By       	Description  
***********		********      *************		    *************	
17-07-2017		v1.0       	  Shahid ul Islam	    Initial Version.
***********************************************************************************/
package com.codemantra.manage.login.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "mProductCategory")
public class ProductCategoryEntity extends MBaseEntity{

	@Id
	private String id;
	
	@Field("metadataTypeCode")
	private String metadataTypeCode;
	
	@Field("productCategoryId")
	private String productCategoryId;
	
	@Field("productCategoryName")
	private String productCategoryName;
	
	@Field("productCategoryCode")
	private String productCategoryCode;
	
	@Field("parentId")
	private String parentId;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMetadataTypeCode() {
		return metadataTypeCode;
	}
	public void setMetadataTypeCode(String metadataTypeCode) {
		this.metadataTypeCode = metadataTypeCode;
	}
	public String getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(String productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public String getProductCategoryName() {
		return productCategoryName;
	}
	public void setProductCategoryName(String productCategoryName) {
		this.productCategoryName = productCategoryName;
	}
	public String getProductCategoryCode() {
		return productCategoryCode;
	}
	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	
	
	
	
}
